MeffortSuiteDefaults={}
local M=MeffortSuiteDefaults
local accountKeys={"masterEnabled","style","badges","rankHint","questSpace","questSpaceConfirmations",
    "badgeTextOutline","badgeTextShadow","wayEnabled","wayTheme","autoSortBags","autoSellJunk","autoRepair",
    "autoBankCrafting","autoSortBank","autoOpenFlightMaster",
    "showLoginMessage","lootValue","lootValueAllItems","lootValueAuctionator","lootValueBoth","fastAutoLoot",
    "lootValueDuration","lootTrackerLayout","backpackFreeSlots","collapseMinimapButtons","minimapButtonPosition",
    "colors","textColors","actionText","petSoundsMuted","petSoundFilesEnabled"}
local characterKeys={"rangedMode","fishingRightClick","fishingQuietAudio","fishingCameraZoom","fishingZoomOutDelay","fishingBobberZoom",
    "targetDistance","arcaneBlast","mageScrollRightClick","enchantQueue"}
local function Tables()
    if type(MeffortSuiteDB)~="table" then MeffortSuiteDB={} end
    if type(MeffortSuiteCharDB)~="table" then MeffortSuiteCharDB={} end
    return MeffortSuiteDB,MeffortSuiteCharDB
end
local function Read(fn,...)
    if type(fn)~="function" then return end
    local ok,value=pcall(fn,...)
    if not ok then return nil,false end
    if type(issecretvalue)=="function" then
        local safe,secret=pcall(issecretvalue,value)
        if not safe or secret then return nil,false end
    end
    return value,true
end
local function RecoveryPending()
    local db=Tables()
    return (type(db.fishingAudioRestore)=="table" and next(db.fishingAudioRestore)~=nil)
        or db.fishingCameraRestore~=nil or db.fishingInteractIconRestore~=nil
        or (type(db.fishingBobberTargetRestore)=="table" and next(db.fishingBobberTargetRestore)~=nil)
        or db.backpackCountRestore~=nil or db.petSoundRestore~=nil or (type(db.petSoundFileRestore)=="table" and next(db.petSoundFileRestore)~=nil)
end
function M.Pending()
    return (type(MeffortSuiteCharDB)=="table" and MeffortSuiteCharDB.restoreDefaultsPending==true)
        or (type(MeffortSuiteDB)=="table" and MeffortSuiteDB.restoreDefaultsPending==true)
end
local function ReloadReady()
    if Read(InCombatLockdown)~=false then return false,"Finish combat before restoring defaults." end
    local cursor,known=Read(GetCursorInfo)
    if not known then return false,"Cursor state unavailable; retry before restoring defaults." end
    if cursor~=nil or Read(CursorHasItem)==true then return false,"Clear the cursor first." end
    if Read(IsMouseButtonDown,"RightButton")==true then return false,"Release the right mouse button first." end
    if type(ReloadUI)~="function" then return false,"UI reload is unavailable in this client." end
    return true
end
function M.CanRestore()
    if M.Pending() then return false,"Defaults are queued; reload the UI to apply them." end
    return ReloadReady()
end
function M.CanReload()
    if not M.Pending() then return false,"Available if a defaults reload needs retrying." end
    return ReloadReady()
end
function M.Reload()
    if not M.Pending() then return false,"No defaults reset is pending." end
    local ready,why=ReloadReady();if not ready then return false,why end
    local ok,result=pcall(ReloadUI)
    local success=ok and result~=false
    return success,success and "Reloading to apply defaults." or "Reload failed; use Reload UI to retry."
end
function M.Restore()
    local ready,why=M.CanRestore();if not ready then return false,why end
    local db,char=Tables()
    if type(MeffortSuiteSetMasterEnabled)=="function" then MeffortSuiteSetMasterEnabled(false)
    else db.masterEnabled=false end
    for _,module in ipairs({MeffortSuiteFishingAudio or false,MeffortSuiteSound or false,MeffortSuiteBackpack or false})do
        if module and type(module.Refresh)=="function" then pcall(module.Refresh)end
    end
    if MeffortSuiteFishingCamera then MeffortSuiteFishingCamera.Restore() end
    if RecoveryPending() then return false,"Prior game settings still need restoration. The suite remains off; retry before resetting." end
    char.restoreDefaultsPending=true
    return M.Reload()
end
function M.ApplyPending()
    if not M.Pending() then return false end
    local db,char=Tables()
    if RecoveryPending() then db.masterEnabled=false;return false end
    -- Apply before login initialization so cached module settings start cleanly.
    for _,key in ipairs(accountKeys)do db[key]=nil end
    -- Older account-wide reset requests did not record the initiating character.
    if char.restoreDefaultsPending==true then
        for _,key in ipairs(characterKeys)do char[key]=nil end
        char.initialized=true
    end
    db.initialized=true;db.schemaVersion=2
    db.restoreDefaultsPending=nil
    char.restoreDefaultsPending=nil
    return true
end
