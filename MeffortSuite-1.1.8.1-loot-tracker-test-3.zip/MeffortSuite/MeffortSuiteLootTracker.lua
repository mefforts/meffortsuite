MeffortSuiteLootTracker={}
local M=MeffortSuiteLootTracker
local prices=MeffortSuiteLootValue
local defaultWidth,defaultHeight,rowHeight=376,300,19
local minWidth,minHeight,maxWidth,maxHeight=320,270,680,620
local compactHeight=20
local compactNames={vendor="Vendor total",auctionator="Auctionator estimate",coins="Coins looted"}
local session={byKey={},items={},coins=0,count=0}
local tracking,queued=false,false
local panel,details,strip,stripAmount,status,startButton,itemsButton,valuesButton,coinValue
local scroll,content,empty,valuesPanel,vendorValue,auctionValue,priceNote
local rows={}
local layout,operation

local function SuiteActive()
    return MeffortSuite.Active()
end
function M.IsTracking()
    return tracking and SuiteActive()
end

local function Finite(value)
    return type(value)=="number" and math.abs(value)<math.huge
end
local function Clamp(value,lower,upper)
    return math.max(lower,math.min(upper,value))
end
local function SavedLayout()
    local saved=MeffortSuiteDB.lootTrackerLayout
    if type(saved)~="table" then saved={};MeffortSuiteDB.lootTrackerLayout=saved end
    saved.width=Finite(saved.width) and Clamp(saved.width,minWidth,maxWidth) or defaultWidth
    saved.height=Finite(saved.height) and Clamp(saved.height,minHeight,maxHeight) or defaultHeight
    saved.view=saved.view=="values" and "values" or "items"
    saved.compact=saved.compact==true
    if not compactNames[saved.compactValue] then saved.compactValue="vendor" end
    return saved
end
local function PlaceWindow()
    local screenWidth,screenHeight=UIParent:GetSize()
    local scale=panel:GetScale()
    local w,h=panel:GetWidth()*scale,panel:GetHeight()*scale
    local x=Finite(layout.x) and layout.x or screenWidth-w-28
    local y=Finite(layout.y) and layout.y or -(screenHeight-h)/2
    x=Clamp(x,0,math.max(0,screenWidth-w))
    y=Clamp(y,math.min(0,h-screenHeight),0)
    panel:ClearAllPoints()
    panel:SetPoint("TOPLEFT",UIParent,"TOPLEFT",x/scale,y/scale)
end
local function SizeStrip()
    local width=math.max(24,math.ceil(stripAmount:GetStringWidth())+8)
    local screenWidth,screenHeight=UIParent:GetSize()
    local scale=Clamp(math.min((screenWidth-8)/width,(screenHeight-8)/compactHeight),.1,1)
    if panel:GetWidth()~=width or panel:GetHeight()~=compactHeight or panel:GetScale()~=scale then
        panel:SetScale(scale)
        panel:SetSize(width,compactHeight)
        PlaceWindow()
    end
end
local function ShowingItems()
    return layout and not layout.compact and layout.view=="items"
end
local function RenderItems()
    if not scroll or not ShowingItems() or not panel:IsShown() then return end
    local capacity=math.ceil(scroll:GetHeight()/rowHeight)+1
    for index=#rows+1,capacity do
        local name=content:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        name:SetJustifyH("LEFT")
        name:SetWordWrap(false)
        local quantity=content:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        rows[index]={name=name,quantity=quantity}
    end
    local first=math.floor(scroll:GetVerticalScroll()/rowHeight)+1
    local count=#session.items
    for offset,row in ipairs(rows) do
        local index=first+offset-1
        local item=offset<=capacity and session.items[count-index+1] or nil
        row.name:SetShown(item~=nil)
        row.quantity:SetShown(item~=nil)
        if item then
            local y=-(index-1)*rowHeight
            row.name:ClearAllPoints()
            row.name:SetPoint("TOPLEFT",content,"TOPLEFT",2,y)
            row.name:SetPoint("TOPRIGHT",content,"TOPRIGHT",-58,y)
            row.name:SetText(item.name)
            row.quantity:ClearAllPoints()
            row.quantity:SetPoint("TOPRIGHT",content,"TOPRIGHT",-5,y)
            row.quantity:SetText(tostring(item.count))
        end
    end
end
local function UpdateItemsLayout()
    if not ShowingItems() or not panel:IsShown() then return end
    local listWidth=math.max(1,scroll:GetWidth())
    local listHeight=math.max(1,#session.items*rowHeight)
    if content:GetWidth()~=listWidth or content:GetHeight()~=listHeight then
        content:SetSize(listWidth,listHeight)
        scroll:UpdateScrollChildRect()
        if scroll:GetVerticalScroll()>scroll:GetVerticalScrollRange() then
            scroll:SetVerticalScroll(scroll:GetVerticalScrollRange())
        end
    end
    RenderItems()
end
local function SessionValues()
    local vendorTotal,auctionTotal=session.coins,session.coins
    local missing,fallback=0,0
    for _,item in ipairs(session.items) do
        local vendor,auction=prices.TrackQuote(item)
        if vendor then vendorTotal=vendorTotal+vendor*item.count
        else missing=missing+item.count end
        if auction then
            auctionTotal=auctionTotal+auction*item.count
        elseif vendor then
            auctionTotal=auctionTotal+vendor*item.count
            fallback=fallback+item.count
        end
    end
    return vendorTotal,auctionTotal,missing,fallback
end
local function RenderValues()
    local vendorTotal,auctionTotal,missing,fallback=SessionValues()
    local auctionAvailable=prices.HasAuctionator()
    vendorValue:SetText(prices.FormatMoney(vendorTotal))
    auctionValue:SetText(auctionAvailable and prices.FormatMoney(auctionTotal) or "Unavailable")
    local note="Totals include coins."
    if not auctionAvailable then note=note.." Load Auctionator for AH estimates."
    elseif fallback>0 then note=note.." Items without an AH price use vendor value." end
    if missing>0 then note=note.." Partial totals. Waiting for prices on "..missing.." items." end
    priceNote:SetText(note)
end
local function CompactValue()
    local mode=layout.compactValue
    if mode=="auctionator" and not prices.HasAuctionator() then return "vendor" end
    return mode
end
local function RenderStrip()
    local mode=CompactValue()
    local amount=session.coins
    if mode~="coins" then
        local vendor,auction=SessionValues()
        amount=mode=="auctionator" and auction or vendor
    end
    stripAmount:SetText("+ "..prices.FormatMoney(amount,10))
    stripAmount:SetAlpha(M.IsTracking() and 1 or .72)
    if not operation then SizeStrip() end
end
local function Render()
    if not panel or not panel:IsShown() then return end
    if layout.compact then RenderStrip();return end
    local running=M.IsTracking()
    local count=session.count
    local state=running and "Tracking" or (SuiteActive() and "Stopped" or "Suite off")
    status:SetText(state.."  ·  "..count..(count==1 and " item" or " items"))
    coinValue:SetText(prices.FormatMoney(session.coins))
    startButton:SetText(running and "Stop tracking" or "Start tracking")
    startButton:SetEnabled(SuiteActive())
    local items=ShowingItems()
    itemsButton:SetEnabled(layout.view~="items")
    valuesButton:SetEnabled(layout.view~="values")
    scroll:SetShown(items)
    empty:SetShown(items and count==0)
    valuesPanel:SetShown(not items)
    if items then UpdateItemsLayout() else RenderValues() end
end
local function RefreshSoon()
    if queued or not panel or not panel:IsShown() then return end
    if not (C_Timer and C_Timer.After) then Render();return end
    queued=true
    C_Timer.After(0,function()
        queued=false
        Render()
    end)
end
local function Label(parent,text,font,point,x,y)
    local label=parent:CreateFontString(nil,"OVERLAY",font or "GameFontHighlightSmall")
    label:SetPoint(point,parent,point,x,y)
    label:SetText(text)
    return label
end
local function Button(text,w,point,x,y,action)
    local button=CreateFrame("Button",nil,details,"UIPanelButtonTemplate")
    button:SetSize(w,24)
    button:SetPoint(point,details,point,x,y)
    button:SetText(text)
    button:SetScript("OnClick",action)
    return button
end
local function SetView(selected)
    layout.view=selected
    Render()
end
local function SavePosition()
    local x,y=panel:GetLeft(),panel:GetTop()
    local left,top=UIParent:GetLeft(),UIParent:GetTop()
    if Finite(x) and Finite(y) and Finite(left) and Finite(top) then
        local scale=panel:GetScale()
        layout.x,layout.y=x*scale-left,y*scale-top
    end
end
local function StopGeometry()
    if not operation then return end
    panel:StopMovingOrSizing()
    if operation=="size" then
        layout.width=panel:GetWidth()
        if not layout.compact then layout.height=panel:GetHeight() end
    end
    operation=nil
    SavePosition()
    panel:SetUserPlaced(false)
    PlaceWindow()
    if layout.compact and panel:IsShown() then SizeStrip() end
end
local function ApplyLayout()
    details:SetShown(not layout.compact)
    strip:SetShown(layout.compact)
    if layout.compact then
        panel:SetResizeBounds(1,compactHeight,maxWidth,compactHeight)
        panel:SetResizable(false)
        SizeStrip()
        PlaceWindow()
        return
    end
    panel:SetResizable(true)
    local screenWidth,screenHeight=UIParent:GetSize()
    local scale=Clamp(math.min((screenWidth-24)/minWidth,(screenHeight-24)/minHeight),.1,1)
    local widthLimit=Clamp((screenWidth-24)/scale,minWidth,maxWidth)
    local heightLimit=Clamp((screenHeight-24)/scale,minHeight,maxHeight)
    panel:SetScale(scale)
    panel:SetResizeBounds(minWidth,minHeight,widthLimit,heightLimit)
    local w=Clamp(layout.width,minWidth,widthLimit)
    local h=Clamp(layout.height,minHeight,heightLimit)
    panel:SetSize(w,h)
    PlaceWindow()
end
local function SetCompact(compact)
    StopGeometry()
    SavePosition()
    layout.compact=compact
    ApplyLayout()
    Render()
end
local function StripTooltip(self)
    if not GameTooltip then return end
    GameTooltip:SetOwner(self,"ANCHOR_TOPLEFT")
    GameTooltip:SetText(compactNames[CompactValue()])
    GameTooltip:AddLine(M.IsTracking() and "Tracking" or "Stopped",1,1,1)
    GameTooltip:AddLine("Click to expand. Right-click to change the total.",1,1,1)
    GameTooltip:AddLine("Drag to move.",1,1,1)
    GameTooltip:Show()
end
local function HideStripTooltip(self)
    if GameTooltip and GameTooltip:IsOwned(self) then GameTooltip:Hide() end
end
local function CreateStrip()
    strip=CreateFrame("Button",nil,panel)
    strip:SetAllPoints(panel)
    strip:Hide()
    strip:EnableMouse(true)
    strip:RegisterForClicks("LeftButtonUp","RightButtonUp")
    strip:RegisterForDrag("LeftButton")
    local background=strip:CreateTexture(nil,"BACKGROUND")
    background:SetAllPoints()
    background:SetColorTexture(.04,.035,.029,.82)
    stripAmount=Label(strip,"+ "..prices.FormatMoney(0,10),"GameFontHighlightSmallOutline","CENTER",0,0)
    stripAmount:SetWordWrap(false)
    local dragged=false
    strip:SetScript("OnMouseDown",function(_,mouse)if mouse=="LeftButton" then dragged=false end end)
    strip:SetScript("OnDragStart",function(self)
        dragged=true
        operation="move"
        HideStripTooltip(self)
        panel:StartMoving()
    end)
    strip:SetScript("OnDragStop",StopGeometry)
    strip:SetScript("OnEnter",StripTooltip)
    strip:SetScript("OnLeave",HideStripTooltip)
    strip:SetScript("OnHide",HideStripTooltip)
    strip:SetScript("OnClick",function(self,mouse)
        if mouse=="RightButton" then
            local mode=CompactValue()
            if mode=="vendor" and prices.HasAuctionator() then layout.compactValue="auctionator"
            else layout.compactValue=mode=="coins" and "vendor" or "coins" end
            RenderStrip()
            StripTooltip(self)
        elseif not dragged then
            HideStripTooltip(self)
            SetCompact(false)
        end
    end)
end
local function CreateWindow()
    layout=SavedLayout()
    panel=CreateFrame("Frame","MeffortSuiteLootTrackerWindow",UIParent)
    panel:Hide()
    panel:SetFrameStrata("DIALOG")
    panel:SetClampedToScreen(true)
    panel:EnableMouse(true)
    panel:SetMovable(true)
    panel:RegisterForDrag("LeftButton")
    panel:SetScript("OnDragStart",function(self)operation="move";self:StartMoving()end)
    panel:SetScript("OnDragStop",StopGeometry)
    panel:SetScript("OnHide",StopGeometry)
    details=CreateFrame("Frame",nil,panel,BackdropTemplateMixin and "BackdropTemplate" or nil)
    details:SetAllPoints(panel)
    if details.SetBackdrop then
        details:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",
            edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",tile=true,tileSize=32,edgeSize=24,
            insets={left=7,right=7,top=7,bottom=7}})
        details:SetBackdropColor(.11,.085,.06,.98)
    else
        local background=details:CreateTexture(nil,"BACKGROUND")
        background:SetAllPoints()
        background:SetColorTexture(.11,.085,.06,.98)
    end
    local close=CreateFrame("Button",nil,details,"UIPanelCloseButton")
    close:SetPoint("TOPRIGHT",details,"TOPRIGHT",-5,-5)
    close:SetScript("OnClick",function()panel:Hide()end)
    Button("Compact",76,"TOPRIGHT",-35,-10,function()SetCompact(true)end)
    Label(details,"Loot Tracker","GameFontNormalLarge","TOPLEFT",16,-14)
    status=Label(details,"","GameFontHighlightSmall","TOPLEFT",17,-39)
    itemsButton=Button("Items",76,"TOPLEFT",16,-60,function()SetView("items")end)
    valuesButton=Button("Values",76,"TOPLEFT",98,-60,function()SetView("values")end)
    Label(details,"Coins looted","GameFontNormal","TOPLEFT",17,-98)
    coinValue=Label(details,"","GameFontHighlight","TOPRIGHT",-21,-98)
    startButton=Button("Start tracking",112,"BOTTOMLEFT",17,15,function()M.SetTracking(not M.IsTracking())end)

    local grip=CreateFrame("Button",nil,details)
    grip:SetSize(18,18)
    grip:SetPoint("BOTTOMRIGHT",details,"BOTTOMRIGHT",-4,4)
    grip:EnableMouse(true)
    grip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    grip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    grip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    grip:SetScript("OnMouseDown",function(_,mouse)
        if mouse=="LeftButton" then operation="size";panel:StartSizing("BOTTOMRIGHT") end
    end)
    grip:SetScript("OnMouseUp",function(_,mouse)
        if mouse=="LeftButton" and operation=="size" then StopGeometry() end
    end)

    scroll=CreateFrame("ScrollFrame",nil,details,"UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT",details,"TOPLEFT",17,-123)
    scroll:SetPoint("BOTTOMRIGHT",details,"BOTTOMRIGHT",-35,52)
    content=CreateFrame("Frame",nil,scroll)
    content:SetSize(defaultWidth-53,1)
    scroll:SetScrollChild(content)
    scroll:HookScript("OnVerticalScroll",RenderItems)
    scroll:HookScript("OnSizeChanged",UpdateItemsLayout)
    empty=Label(details,"No loot recorded yet.",nil,"TOPLEFT",19,-129)
    valuesPanel=CreateFrame("Frame",nil,details)
    valuesPanel:SetPoint("TOPLEFT",details,"TOPLEFT",17,-129)
    valuesPanel:SetPoint("BOTTOMRIGHT",details,"BOTTOMRIGHT",-21,52)
    Label(valuesPanel,"Vendor total","GameFontNormal","TOPLEFT",0,0)
    vendorValue=Label(valuesPanel,"","GameFontHighlight","TOPRIGHT",0,0)
    Label(valuesPanel,"Auctionator estimate","GameFontNormal","TOPLEFT",0,-27)
    auctionValue=Label(valuesPanel,"","GameFontHighlight","TOPRIGHT",0,-27)
    priceNote=Label(valuesPanel,"",nil,"TOPLEFT",0,-56)
    priceNote:SetPoint("TOPRIGHT",valuesPanel,"TOPRIGHT",0,-56)
    priceNote:SetJustifyH("LEFT")
    priceNote:SetWordWrap(true)
    CreateStrip()
end

function M.Open()
    if not panel then CreateWindow() end
    ApplyLayout()
    panel:Show()
    if panel.Raise then panel:Raise() end
    Render()
end
function M.SetTracking(enabled)
    if enabled and not SuiteActive() then return end
    if enabled and not tracking then
        session={byKey={},items={},coins=0,count=0}
        if scroll then scroll:SetVerticalScroll(0) end
    end
    tracking=enabled==true
    if tracking then M.Open() else Render() end
    if MeffortSuiteSettingsUI then MeffortSuiteSettingsUI.Refresh() end
end
function M.RefreshMaster()
    if not SuiteActive() then tracking=false end
    Render()
end
function M.RecordItem(key,id,link,quantity)
    local item=session.byKey[key]
    if not item then
        item={id=id,link=link,name=link:match("|h%[(.-)%]|h") or ("Item "..id),count=0,
            allItems=true,auctionator=true,both=true}
        session.byKey[key]=item
        session.items[#session.items+1]=item
    end
    item.count=item.count+quantity
    session.count=session.count+quantity
    RefreshSoon()
end
function M.RecordMoney(amount)
    session.coins=session.coins+amount
    RefreshSoon()
end
function M.ItemDataReady(id)
    if not id then return end
    for _,item in ipairs(session.items) do
        if item.id==id and item.vendor==nil then
            item.nextTry=nil
            if not ShowingItems() then RefreshSoon() end
        end
    end
end

local events=CreateFrame("Frame")
events:RegisterEvent("PLAYER_REGEN_ENABLED")
events:RegisterEvent("ADDON_LOADED")
events:RegisterEvent("DISPLAY_SIZE_CHANGED")
events:RegisterEvent("UI_SCALE_CHANGED")
events:SetScript("OnEvent",function(_,event,addon)
    if event=="DISPLAY_SIZE_CHANGED" or event=="UI_SCALE_CHANGED" then
        if panel and panel:IsShown() and not operation then ApplyLayout() end
    elseif event=="ADDON_LOADED" then
        if addon~="Auctionator" then return end
        for _,item in ipairs(session.items) do
            if item.source~="Auctionator" then
                item.auctionChecked,item.value,item.source,item.nextTry=nil,nil,nil,nil
            end
        end
    end
    RefreshSoon()
end)
