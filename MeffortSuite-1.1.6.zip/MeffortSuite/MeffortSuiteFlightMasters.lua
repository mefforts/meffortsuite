local suite = MeffortSuite
MeffortSuiteFlightMasters = {}
local flight = MeffortSuiteFlightMasters
local selectedInGossip = false
local gossipOpen,serial,shiftBypass=false,0,false
local status = "not used"

local function DB()
    if type(MeffortSuiteDB) ~= "table" then MeffortSuiteDB = {} end
    return MeffortSuiteDB
end

function flight.Enabled()
    return DB().autoOpenFlightMaster ~= false
end

function flight.SetEnabled(value)
    DB().autoOpenFlightMaster = value == true
    suite.Message("Skip flight master dialogue " .. (flight.Enabled() and "ON" or "OFF") ..
        (flight.Enabled() and ". Hold Shift while talking to see the normal dialogue." or "."))
end

local function SelectFlightMasterGossip()
    if selectedInGossip or not suite or not suite.Active() or not flight.Enabled() then return end
    local shortcuts=MeffortSuiteGossipServices
    if not shortcuts or type(shortcuts.TryService)~="function" then
        status="gossip selection unavailable"
        return
    end
    if shortcuts.Selected() then return end
    if shiftBypass or (type(IsShiftKeyDown) == "function" and IsShiftKeyDown()) then return end
    if type(InCombatLockdown) == "function" and InCombatLockdown() then return end
    -- Set before selection in case choosing it fires nested gossip events.
    selectedInGossip=true
    local selected,reason=shortcuts.TryService("taxi")
    if selected then
        status = "taxi map requested"
    else
        selectedInGossip=false
        status=reason or "no flight map requested"
    end
end

function flight.Status()
    suite.Message("Flight master dialogue: " .. (flight.Enabled() and "ON" or "OFF") ..
        "; last action: " .. status)
end

function flight.Command(arg)
    arg = (arg or ""):lower():match("^%s*(.-)%s*$")
    if arg == "on" then
        flight.SetEnabled(true)
    elseif arg == "off" then
        flight.SetEnabled(false)
    else
        flight.Status()
        if arg ~= "status" then suite.Message("/msuite flight on | off | status") end
    end
end

local frame = CreateFrame("Frame")
frame:RegisterEvent("PLAYER_LOGIN")
frame:RegisterEvent("GOSSIP_SHOW")
frame:RegisterEvent("GOSSIP_CLOSED")
frame:RegisterEvent("TAXIMAP_OPENED")
pcall(frame.RegisterEvent,frame,"GOSSIP_OPTIONS_REFRESHED")
frame:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        local db = DB()
        if db.autoOpenFlightMaster == nil then db.autoOpenFlightMaster = true end
    elseif event == "GOSSIP_SHOW" then
        gossipOpen=true;serial=serial+1
        shiftBypass=shiftBypass or (type(IsShiftKeyDown)=="function" and IsShiftKeyDown()) or false
        SelectFlightMasterGossip()
        local ticket=serial
        if C_Timer and type(C_Timer.After)=="function" then C_Timer.After(.1,function()
            if gossipOpen and serial==ticket then SelectFlightMasterGossip() end
        end) end
    elseif event=="GOSSIP_OPTIONS_REFRESHED" then
        if gossipOpen then SelectFlightMasterGossip() end
    elseif event == "GOSSIP_CLOSED" or event == "TAXIMAP_OPENED" then
        gossipOpen=false;serial=serial+1;shiftBypass=false
        selectedInGossip = false
    end
end)
