local UI={}
MeffortSuiteSettingsUI=UI

local FONT=STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
local HOME_W,HOME_H=362,432
local DETAIL_W,MIN_DETAIL_H,MAX_DETAIL_H=452,220,560
local BODY_W=406
local C={
  mint={1,.81,.30,1}, gold={1,.82,.28,1}, red={.56,.54,.48,1},
  muted={.71,.67,.59,1}, white={1,.92,.74,1},
}
local frame,headerTitle,logo,backButton,infoButton,masterButton,masterText,statusTitle,statusDetail
local home,tiles,scroller,resetButton,homeButton
local pages={};local activePage="overview"
local history,inputDrafts={},{}
local OpenPage,RefreshUI
local function RGB(tex,c)
  tex:SetColorTexture(c[1],c[2],c[3],c[4] or 1)
end
local function WoWBackdrop(widget)
  local backdrop={
    bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",
    tile=true,tileSize=32,edgeSize=24,
    insets={left=7,right=7,top=7,bottom=7},
  }
  if widget.SetBackdrop then
    widget:SetBackdrop(backdrop)
    if widget.SetBackdropColor then widget:SetBackdropColor(.11,.085,.06,.98)end
    if widget.SetBackdropBorderColor then widget:SetBackdropBorderColor(.78,.62,.30,1)end
  else
    local bg=widget:CreateTexture(nil,"BACKGROUND")
    bg:SetAllPoints(widget)
    bg:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Background")
    bg:SetVertexColor(.72,.60,.44,1)
    local edge=widget:CreateTexture(nil,"BORDER")
    edge:SetAllPoints(widget)
    edge:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Border")
  end
end

local function Font(parent,text,size,color,flags)
  local t=parent:CreateFontString(nil,"OVERLAY","GameFontHighlight")
  t:SetFont(FONT,size or 12,flags or "")
  t:SetTextColor((color or C.white)[1],(color or C.white)[2],(color or C.white)[3],1)
  t:SetText(text or "")
  return t
end
local function DB()
  if type(MeffortSuiteDB)~="table" then MeffortSuiteDB={} end
  return MeffortSuiteDB
end
local function Char()
  if type(MeffortSuiteCharDB)~="table" then MeffortSuiteCharDB={} end
  return MeffortSuiteCharDB
end
local function Range()
  local char=Char()
  if type(char.targetDistance)~="table" then char.targetDistance={} end
  return char.targetDistance
end
local Action=MeffortSuiteActionText.GetSettings
local function IsActive() return not MeffortSuite or not MeffortSuite.Active or MeffortSuite.Active() end
local function OnOff(active) return active and "ON" or "OFF" end
local function Capability(module)
  if module and type(module.Available)=="function" then return module.Available() end
end
local function Features()
  local d=DB()
  local range,ranged=MeffortSuiteTargetDistance,MeffortSuiteRanged
  local fish,arcane,audio=MeffortSuiteFishing,MeffortSuiteArcaneBlast,MeffortSuiteFishingAudio
  local mode=ranged and ranged.Mode and ranged.Mode() or "off"
  local quietFishing=audio and audio.Enabled and audio.Enabled()
  return {
    ranged=mode=="right" or mode=="shift",
    range=(range and range.Enabled and range.Enabled()) or (arcane and arcane.Enabled and arcane.Enabled()),
    inventory=d.autoSortBags~=false or d.autoSellJunk~=false or d.autoRepair~=false or
      d.autoBankCrafting~=false or d.autoSortBank~=false or d.lootValue~=false or d.fastAutoLoot~=false or d.backpackFreeSlots~=false,
    quest=d.questSpace~=false or d.autoOpenSingleService~=false or d.questRewardVendor~=false,
    way=d.wayEnabled==true or d.autoOpenFlightMaster~=false,
    tooltips=d.enabled==true or d.style~=false or d.badges~=false or d.rankHint~=false,
    action=Action().enabled,
    fishing=(fish and fish.Enabled and fish.Enabled()) or quietFishing,
    audio=d.petSoundsMuted==true or d.petSoundFilesEnabled==true or quietFishing,
  }
end
local function Weapon()
  local m=MeffortSuiteRanged
  if not m or not m.Kind then return nil end
  local kind=m.Kind()
  if kind=="wand" then return "Wand","Interface\\Icons\\INV_Wand_01" end
  if kind~="ranged" then return nil end
  local attack
  if m.EquippedWeapon then attack=m.EquippedWeapon()
  elseif m.AbilityName then attack=m.AbilityName() end
  if attack=="Shoot Gun" then return "Gun","Interface\\Icons\\INV_Weapon_Rifle_03" end
  if attack=="Shoot Crossbow" then return "Crossbow","Interface\\Icons\\INV_Weapon_Crossbow_01" end
  if attack=="Shoot Bow" or attack=="Auto Shot" then return "Bow","Interface\\Icons\\INV_Weapon_Bow_07" end
  if attack=="Throw" then return "Thrown","Interface\\Icons\\INV_ThrowingKnife_03" end
  return "Ranged","Interface\\Icons\\Ability_Marksmanship"
end

local function Skin(button)
  local active=button:CreateTexture(nil,"OVERLAY")
  active:SetPoint("BOTTOMLEFT",button,"BOTTOMLEFT",7,4)
  active:SetPoint("BOTTOMRIGHT",button,"BOTTOMRIGHT",-7,4)
  active:SetHeight(2)
  active:SetTexture("Interface\\Buttons\\WHITE8X8")
  active:SetVertexColor(1,.79,.22)
  active:Hide()
  local obj={button=button,selected=false,active=active}
  function obj:Paint()
    if self.selected then self.active:Show() else self.active:Hide() end
  end
  return obj
end
local function PressButton(parent,label,width,height,fn)
  local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
  b:SetSize(width,height)
  b:SetText("")
  local skin=Skin(b)
  local text=Font(b,label,12,C.white)
  text:SetPoint("CENTER",b,"CENTER",0,1)
  text:SetJustifyH("CENTER")
  text:SetWidth(width-14)
  b:SetScript("OnClick",function() if fn then fn() end end)
  return {button=b,skin=skin,text=text}
end
local function Tips(widget,title,detail)
  local oldEnter=widget:GetScript("OnEnter")
  local oldLeave=widget:GetScript("OnLeave")
  widget:SetScript("OnEnter",function(self)
    if oldEnter then oldEnter(self) end
    if GameTooltip then
      GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
      GameTooltip:SetText(title,1,1,1)
      local body=type(detail)=="function" and detail() or detail
      if body and body~="" then GameTooltip:AddLine(body,.83,.79,.69,true) end
      GameTooltip:Show()
    end
  end)
  widget:SetScript("OnLeave",function(self)
    if oldLeave then oldLeave(self) end
    if GameTooltip then GameTooltip:Hide() end
  end)
end

local entry={
  {"ranged","Ranged attack","Interface\\Icons\\Ability_Marksmanship","Set your ranged attack to right-click or Shift + right-click"},
  {"inventory","Bags","Interface\\Icons\\INV_Misc_Bag_08","Loot values, sorting, merchants and banking"},
  {"quest","Quests","Interface\\Icons\\INV_Misc_Note_01","Reward prices, quest hotkeys and service dialogue"},
  {"range","Combat","Interface\\Icons\\Ability_Warrior_Charge","Target range and Arcane Blast tracking"},
  {"way","Map","Interface\\Icons\\INV_Misc_Map_01","Waypoints and flight masters"},
  {"tooltips","Tooltips","Interface\\Icons\\INV_Misc_Book_09","Spell explanations and badges"},
  {"action","Bars","Interface\\Icons\\Spell_Frost_FrostBolt02","Action bar keybind labels"},
  {"fishing","Fishing","Interface\\Icons\\Trade_Fishing","Right-click fishing and pole-equipped audio"},
  {"audio","Sounds","Interface\\Icons\\Spell_Holy_Silence","Native pet sounds, targeted files and fishing audio"},
}
local function BuildHome()
  home=CreateFrame("Frame",nil,frame)
  home:SetPoint("TOPLEFT",frame,"TOPLEFT",10,-88)
  home:SetSize(HOME_W-20,HOME_H-94)
  tiles={}
  for _,data in ipairs(entry) do
    local id,label,icon,tip=data[1],data[2],data[3],data[4]
    local b=CreateFrame("Button",nil,home)
    b:SetSize(108,96)
    local face=b:CreateTexture(nil,"BACKGROUND")
    face:SetAllPoints(b)
    face:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Background")
    face:SetVertexColor(.40,.37,.32,.98)
    local edges={}
    local function Edge(anchor1,thickness)
      local t=b:CreateTexture(nil,"BORDER")
      t:SetTexture("Interface\\Buttons\\WHITE8X8")
      t:SetVertexColor(.66,.52,.28,.90)
      if anchor1=="TOP" or anchor1=="BOTTOM" then
        t:SetPoint(anchor1.."LEFT",b,anchor1.."LEFT",1,0)
        t:SetPoint(anchor1.."RIGHT",b,anchor1.."RIGHT",-1,0)
        t:SetHeight(thickness)
      else
        t:SetPoint("TOP"..anchor1,b,"TOP"..anchor1,0,-1)
        t:SetPoint("BOTTOM"..anchor1,b,"BOTTOM"..anchor1,0,1)
        t:SetWidth(thickness)
      end
      edges[#edges+1]=t
    end
    Edge("TOP",1)
    Edge("BOTTOM",1)
    Edge("LEFT",1)
    Edge("RIGHT",1)

    local over=b:CreateTexture(nil,"HIGHLIGHT")
    over:SetAllPoints(b)
    over:SetTexture("Interface\\Buttons\\WHITE8X8")
    over:SetVertexColor(1,.77,.31,.10)

    local down=b:CreateTexture(nil,"ARTWORK")
    down:SetAllPoints(b)
    down:SetTexture("Interface\\Buttons\\WHITE8X8")
    down:SetVertexColor(.18,.13,.05,.30)
    down:Hide()

    local pict=b:CreateTexture(nil,"ARTWORK")
    pict:SetSize(46,46)
    pict:SetPoint("TOP",b,"TOP",0,-7)
    pict:SetTexture(icon)
    pict:SetTexCoord(.08,.92,.08,.92)
    local caption=Font(b,label,12,C.white)
    caption:SetPoint("TOP",b,"TOP",0,-56)
    caption:SetWidth(100)
    caption:SetJustifyH("CENTER")
    local badge=Font(b,"OFF",10,C.muted,"OUTLINE")
    badge:SetPoint("BOTTOM",b,"BOTTOM",0,9)
    badge:SetJustifyH("CENTER")
    b:SetScript("OnMouseDown",function()down:Show();pict:ClearAllPoints();pict:SetPoint("TOP",b,"TOP",0,-8)end)
    b:SetScript("OnMouseUp",function()down:Hide();pict:ClearAllPoints();pict:SetPoint("TOP",b,"TOP",0,-7)end)
    b:SetScript("OnLeave",function()down:Hide();pict:ClearAllPoints();pict:SetPoint("TOP",b,"TOP",0,-7)end)
    b:SetScript("OnClick",function() OpenPage(id) end)
    Tips(b,label,function()
      local preference=Features()[id]
      return tip.."\n\nConfigured: "..OnOff(preference)..(IsActive() and
        "\nSettings stay saved when the suite is disabled." or
        "\nMeffortSuite is disabled. Enable it to activate these preferences.")
    end)
    tiles[#tiles+1]={id=id,b=b,pict=pict,caption=caption,badge=badge,edges=edges}
  end
end
local function UpdateHome()
  if not tiles then return end
  local weaponLabel,weaponIcon=Weapon()
  local status=Features()
  local active=IsActive()
  local n=0
  for _,t in ipairs(tiles) do
    local visible=t.id~="ranged" or weaponLabel~=nil
    if visible then
      local c=n%3
      local r=math.floor(n/3)
      t.b:ClearAllPoints()
      t.b:SetPoint("TOPLEFT",home,"TOPLEFT",4+c*112,-3-r*101)
      t.b:Show()
      if t.id=="ranged" then t.caption:SetText(weaponLabel);t.pict:SetTexture(weaponIcon)end
      local off=not (active and status[t.id])
      t.badge:SetText(OnOff(not off))
      t.badge:SetTextColor(off and .56 or 1,off and .54 or .83,off and .49 or .33,1)
      for _,edge in ipairs(t.edges) do
        edge:SetVertexColor(off and .40 or .80,off and .37 or .64,off and .30 or .33,.92)
      end
      t.pict:SetDesaturated(off)
      n=n+1
    else t.b:Hide() end
  end
end

local scopes={ranged="Character settings",range="Character settings",rangeadvanced="Character settings",
  arcaneblast="Character settings | Mage only",inventory="Account settings | Bank lists: this character",loot="Account settings",
  quest="Account settings",way="Account settings",tooltips="Account settings",
  action="Account settings",fishing="Character settings",audio="Account settings | Fishing audio: this character",soundfiles="Account settings",defaults="Account preferences + this character",badges="Account settings"}
local guidance={
  inventory="Start with Looting & loot value for fast looting and floating totals. Below, configure bag sorting, merchant actions and your personal-bank lists. Keep in bags takes priority over deposits.",
  loot="For fast looting, enable Auto Loot in the game's controls, then turn on Fast auto loot below. For floating values, choose vendor, AH, or both, set the reading time and try Preview. Both totals include received coins.",
  quest="Reward prices show what the full item stack sells for; you still choose the reward. For dialogue shortcuts, Space follows quest priority and numbers follow menu order. Hold Shift to keep service dialogue open.",
  ranged="Choose Right-click or Shift + right-click for this character. Equip the matching ranged weapon. A fishing pole gives fishing priority; an enabled standalone MeffortWand owns wand input.",
  range="Enable the dot, set your warning distance, then unlock it to drag. Lock it again when positioned. The warning appears only when range is known; an absent dot can mean the distance is unknown.",
  rangeadvanced="Automatic detection is recommended. Use an exact spellbook name only when you need a specific spell's range. Return to Combat to adjust the dot and position.",
  arcaneblast="First add Arcane Blast to Blizzard Tracked Buffs. Enable the overlay here, then choose stacks, remaining time and the optional timer wheel.",
  fishing="Equip a fishing pole and enable right-click fishing. Double right-click lets you keep normal camera turning. Quiet audio activates while the pole is equipped and keeps the bite audible.",
  way="Create a native map pin or use /way with coordinates. Turn on Suite waypoint arrow to follow your pin. The flight-master shortcut opens the flight map so you can select a route.",
  tooltips="Choose Replace for a concise explanation or Compare to retain the original beside it. Explanations use English data. Header styling and badges are separate appearance options.",
  badges="Choose background and text colors together, using the preview for contrast. These colors affect tooltip badges. Change action-bar text separately under Bars.",
  action="Enable custom labels, set a readable size and use the live preview to position them. Native red range warnings keep priority. Changes requested during combat finish after combat.",
  audio="The native pet toggle mutes the game's pet-sound category, not only footsteps. Some companions use shared creature sounds that this setting may not cover. Verified sound files can be selected separately under Advanced sound-file muting.",
  soundfiles="Use this only when the exact sound-file IDs are known. No companion presets are assumed. Muting a shared file affects every creature using it, including other pets or NPCs. Avoid managing the same files in multiple sound addons.",
  defaults="Review the reset before continuing. This restores account preferences and this character's settings, then reloads the UI. Other characters' personal settings, bank item lists, custom sound-file lists, macros and game keybindings are kept. Unapplied settings drafts are discarded on reload.",
  help="Choose a task below. Back returns to your previous page and scroll position. Home opens the category launcher. Hover a setting for its details.",
  about="Preferences are kept when the suite is off. Use Setup & help for task guidance and report-copy instructions.",
}
local function Wrapped(p,message,size,color)
  local t=Font(p,message,size or 11,color or C.muted)
  t:SetPoint("TOPLEFT",p,"TOPLEFT",11,-p.height)
  t:SetWidth(BODY_W-24);t:SetJustifyH("LEFT")
  if type(t.SetWordWrap)=="function" then t:SetWordWrap(true)end
  local lines=0
  for line in (message.."\n"):gmatch("(.-)\n") do lines=lines+math.max(1,math.ceil(#line/65))end
  local h=type(t.GetStringHeight)=="function" and t:GetStringHeight()
  if type(h)~="number" or h~=h or h<=0 or h==math.huge then h=lines*14 end
  p.height=p.height+math.max(14,h)+9;p:SetHeight(math.max(130,p.height+10))
  return t
end
local function Page(key,heading)
  local p=CreateFrame("Frame",nil,scroller)
  p:SetSize(BODY_W,130)
  p.height=8
  if scopes[key] then
    local scope=Font(p,scopes[key],10,C.muted)
    scope:SetPoint("TOPLEFT",p,"TOPLEFT",11,-8)
    scope:SetWidth(BODY_W-24);scope:SetJustifyH("LEFT")
    p.height=29
  end
  p.refreshers={}
  p.label=heading
  pages[key]=p
  if guidance[key] then Wrapped(p,guidance[key]) end
  return p
end
local function AddRefresh(p,fn) p.refreshers[#p.refreshers+1]=fn end
local function Reserve(p,h)
  local y=-p.height
  p.height=p.height+h
  p:SetHeight(math.max(130,p.height+10))
  return y
end
local function RowFrame(p,h)
  local y=Reserve(p,h+2)
  local f=CreateFrame("Frame",nil,p)
  f:SetPoint("TOPLEFT",p,"TOPLEFT",1,y)
  f:SetSize(BODY_W-5,h)
  local line=f:CreateTexture(nil,"BACKGROUND")
  line:SetPoint("BOTTOMLEFT",f,"BOTTOMLEFT",7,0)
  line:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",-7,0)
  line:SetHeight(1)
  line:SetTexture("Interface\\Buttons\\WHITE8X8")
  line:SetVertexColor(.35,.29,.20,.65)
  return f,line
end
local function TextRow(p,message,color)
  local row=RowFrame(p,30)
  local t=Font(row,message,11,color or C.muted)
  t:SetPoint("LEFT",row,"LEFT",10,0)
  t:SetWidth(BODY_W-22)
  t:SetJustifyH("LEFT")
  return t
end
local function Section(p,title)
  local row=RowFrame(p,27)
  local t=Font(row,title,12,C.gold)
  t:SetPoint("LEFT",row,"LEFT",10,0);t:SetJustifyH("LEFT")
  return t
end
local function Toggle(p,label,detail,read,write)
  local row=RowFrame(p,37)
  local check=CreateFrame("CheckButton",nil,row,"UICheckButtonTemplate")
  check:SetSize(29,29)
  check:SetPoint("LEFT",row,"LEFT",7,0)
  local txt=Font(row,label,12,C.white)
  txt:SetPoint("LEFT",check,"RIGHT",3,0)
  txt:SetWidth(BODY_W-100);txt:SetJustifyH("LEFT")
  local state=Font(row,"OFF",10,C.muted)
  state:SetPoint("RIGHT",row,"RIGHT",-9,0)
  state:SetWidth(48);state:SetJustifyH("RIGHT")
  local function Change(value) write(value);RefreshUI() end
  check:SetScript("OnClick",function(self)Change(self:GetChecked() and true or false)end)
  local hit=CreateFrame("Button",nil,row)
  hit:SetPoint("TOPLEFT",row,"TOPLEFT",39,0)
  hit:SetPoint("BOTTOMRIGHT",row,"BOTTOMRIGHT",0,0)
  hit:RegisterForClicks("LeftButtonUp")
  hit:SetScript("OnClick",function()Change(read()~=true)end)
  AddRefresh(p,function()
    local on=read()==true
    check:SetChecked(on)
    state:SetText(on and "ON" or "OFF")
    state:SetTextColor(on and 1 or .55,on and .82 or .53,on and .28 or .49)
  end)
  Tips(check,label,detail);Tips(hit,label,detail)
  return check
end
local function Choice(p,label,options,read,write)
  local row=RowFrame(p,66)
  local l=Font(row,label,12,C.white);l:SetPoint("TOPLEFT",row,"TOPLEFT",11,-8)
  local state=Font(row,"",11,C.mint)
  state:SetPoint("TOPRIGHT",row,"TOPRIGHT",-11,-10)
  local list={}
  local w=(BODY_W-27-(#options-1)*5)/#options
  for i,o in ipairs(options) do
    local b=PressButton(row,o.label,w,29,function()write(o.value);RefreshUI()end)
    b.button:SetPoint("BOTTOMLEFT",row,"BOTTOMLEFT",9+(i-1)*(w+5),8)
    list[#list+1]={ui=b,item=o}
  end
  AddRefresh(p,function()
    local now=read()
    state:SetText("")
    for _,o in ipairs(list) do
      local selected=o.item.value==now
      o.ui.skin.selected=selected
      o.ui.skin:Paint()
      o.ui.text:SetTextColor(selected and C.gold[1] or C.white[1],selected and C.gold[2] or C.white[2],selected and C.gold[3] or C.white[3])
      if selected then state:SetText("Selected: "..o.item.label) end
    end
  end)
end
local function Stepper(p,label,lo,hi,step,read,write,unit)
  local row=RowFrame(p,52)
  local name=Font(row,label,12,C.white)
  name:SetPoint("TOPLEFT",row,"TOPLEFT",11,-7)
  local value=Font(row,"",19,C.gold)
  value:SetPoint("BOTTOMLEFT",row,"BOTTOMLEFT",12,7)
  value:SetWidth(150)
  local function change(delta)
    local n=tonumber(read()) or lo
    n=math.max(lo,math.min(hi,n+delta))
    write(n)
    RefreshUI()
  end
  local controls={ {"-5",-step*5},{"-",-step},{"+",step},{"+5",step*5}}
  for i,c in ipairs(controls) do
    local b=PressButton(row,c[1],46,29,function()change(c[2])end)
    b.button:SetPoint("RIGHT",row,"RIGHT",-(9+(4-i)*49),-8)
  end
  AddRefresh(p,function()
    local n=read() or lo
    value:SetText(tostring(n)..(unit or ""))
  end)
end
local function Link(p,label,action,right,available)
  local row=RowFrame(p,available and 55 or 35)
  local b=PressButton(row,label,BODY_W-19,29,function()
    local ready=true
    if available then ready=available() end
    if ready then action() end
    RefreshUI()
  end)
  b.button:SetPoint(available and "TOP" or "CENTER",row,available and "TOP" or "CENTER",0,available and -2 or 1)
  b.text:SetJustifyH("LEFT")
  b.text:ClearAllPoints();b.text:SetPoint("LEFT",b.button,"LEFT",12,1)
  b.text:SetWidth(BODY_W-100)
  local suffix
  if right then
    suffix=Font(b.button,right,11,C.gold)
    suffix:SetPoint("RIGHT",b.button,"RIGHT",-12,1)
  end
  if available then
    local reason=Font(row,"",10,C.muted)
    reason:SetPoint("BOTTOMLEFT",row,"BOTTOMLEFT",12,6)
    reason:SetWidth(BODY_W-28);reason:SetJustifyH("LEFT")
    AddRefresh(p,function()
      local ready,why=available()
      if ready then b.button:Enable() else b.button:Disable() end
      b.text:SetTextColor(ready and C.white[1] or C.muted[1],ready and C.white[2] or C.muted[2],ready and C.white[3] or C.muted[3])
      reason:SetText(why or (ready and "Ready" or "Unavailable"))
    end)
  end
  return b
end
local function Input(p,label,get,apply,buttonName,maxLetters)
  local row=RowFrame(p,96)
  local l=Font(row,label,12,C.white)
  l:SetPoint("TOPLEFT",row,"TOPLEFT",11,-9)
  l:SetWidth(BODY_W-24);l:SetJustifyH("LEFT")
  local field=CreateFrame("EditBox",nil,row,"InputBoxTemplate")
  field:SetPoint("TOPLEFT",row,"TOPLEFT",17,-34)
  field:SetSize(240,26)
  field:SetAutoFocus(false)
  field:SetMaxLetters(maxLetters or 60)
  Tips(field,label,"Use Enter or the save button to apply. Esc discards this draft. Maximum "..tostring(maxLetters or 60).." characters.")
  local feedback=Font(row,"Saved",10,C.muted)
  feedback:SetPoint("BOTTOMLEFT",row,"BOTTOMLEFT",12,9)
  feedback:SetWidth(BODY_W-28);feedback:SetJustifyH("LEFT")
  local dirty,loading=false,false
  local function Restore(message)
    loading=true;field:SetText(tostring(get() or ""));loading=false;dirty=false
    feedback:SetText(message or "Saved")
  end
  local function Save()
    local ok,result,why=pcall(apply,field:GetText())
    if not ok or result==false then
      feedback:SetText(why or "Could not save. Check the value and try again.")
      return
    end
    Restore("Saved");field:ClearFocus();RefreshUI()
  end
  field:SetScript("OnTextChanged",function()
    if loading then return end
    dirty=field:GetText()~=tostring(get() or "")
    feedback:SetText(dirty and ("Unsaved - Enter or "..(buttonName or "Apply").."; Esc discards") or "Saved")
    if frame and frame:IsShown() then RefreshUI() end
  end)
  field:SetScript("OnEnterPressed",Save)
  field:SetScript("OnEscapePressed",function(self)Restore("Changes discarded");self:ClearFocus();RefreshUI()end)
  local btn=PressButton(row,buttonName or "Apply",105,30,Save)
  btn.button:SetPoint("TOPRIGHT",row,"TOPRIGHT",-10,-32)
  inputDrafts[#inputDrafts+1]=function()return dirty end
  AddRefresh(p,function()
    -- Never replace an unapplied draft on blur, navigation, or status refresh.
    if not dirty and not field:HasFocus() and field:GetText()~=tostring(get() or "") then Restore() end
    if dirty then btn.button:Enable() else btn.button:Disable() end
  end)
  return function(message)Restore(message);field:ClearFocus()end
end
local function ColorHex(s)
  s=tostring(s or "ffffff"):gsub("#","")
  if not s:match("^%x%x%x%x%x%x$") then s="ffffff" end
  return {tonumber(s:sub(1,2),16)/255,tonumber(s:sub(3,4),16)/255,tonumber(s:sub(5,6),16)/255,1}
end
local function Swatch(p,title,category)
  local row=RowFrame(p,40)
  local preview=row:CreateTexture(nil,"ARTWORK")
  preview:SetPoint("TOPLEFT",row,"TOPLEFT",11,-7)
  preview:SetPoint("BOTTOMLEFT",row,"BOTTOMLEFT",11,7)
  preview:SetWidth(150)
  preview:SetTexture("Interface\\AddOns\\MeffortSuite\\Textures\\SoftBadge.tga")
  local text=Font(row,title,11,C.white)
  text:SetPoint("CENTER",preview,"CENTER",0,0)
  text:SetWidth(140);text:SetJustifyH("CENTER")
  local function chip(offset,kind)
    local b=CreateFrame("Button",nil,row,"UIPanelButtonTemplate")
    b:SetSize(66,25)
    b:SetPoint("RIGHT",row,"RIGHT",offset,0)
    local sample=b:CreateTexture(nil,"OVERLAY")
    sample:SetPoint("TOPLEFT",b,"TOPLEFT",5,-5)
    sample:SetPoint("BOTTOMRIGHT",b,"BOTTOMRIGHT",-5,5)
    b:SetScript("OnClick",function()
      if MeffortSuiteBadgeThemeRead and MeffortSuiteBadgeThemeWrite and MeffortSuiteShowColorPicker then
        MeffortSuiteShowColorPicker(MeffortSuiteBadgeThemeRead(category,kind),function(hex)
          MeffortSuiteBadgeThemeWrite(category,kind,hex);RefreshUI()
        end)
      end
    end)
    Tips(b,title..(kind=="background" and ": background" or ": text"),"Choose a color. The preview shows the two colors together. Esc in the color picker cancels.")
    AddRefresh(p,function()
      if MeffortSuiteBadgeThemeRead then RGB(sample,ColorHex(MeffortSuiteBadgeThemeRead(category,kind))) end
    end)
  end
  chip(-85,"background");chip(-9,"text")
  AddRefresh(p,function()
    if not MeffortSuiteBadgeThemeRead then return end
    local bg=ColorHex(MeffortSuiteBadgeThemeRead(category,"background"))
    local fg=ColorHex(MeffortSuiteBadgeThemeRead(category,"text"))
    preview:SetVertexColor(bg[1],bg[2],bg[3],.9)
    text:SetTextColor(fg[1],fg[2],fg[3],1)
    text:SetFont(FONT,11,DB().badgeTextOutline==true and "OUTLINE" or "")
    text:SetShadowColor(0,0,0,DB().badgeTextShadow~=false and .95 or 0)
    text:SetShadowOffset(DB().badgeTextShadow~=false and 1 or 0,DB().badgeTextShadow~=false and -1 or 0)
  end)
end
local function ApplyBar()
  if MeffortSuiteActionText and MeffortSuiteActionText.ApplyAll then MeffortSuiteActionText.ApplyAll() end
end
local function Build(key)
  local m=MeffortSuiteTargetDistance
  local fishing=MeffortSuiteFishing
  local ranged=MeffortSuiteRanged
  local p
  if key=="range" then
    p=Page(key,"Combat")
    Toggle(p,"Out-of-range dot","Only appears when the target is definitely beyond range.",function()return m and m.Enabled()end,function(v)if m then m.SetEnabled(v)end end)
    Stepper(p,"Warning distance",1,100,1,function()return Range().rangeYards or 30 end,function(n)if m then m.SetYards(n)end end," yd")
    Stepper(p,"Dot size",10,26,1,function()return Range().fontSize or 19 end,function(n)if m then m.SetSize(n)end end," px")
    Toggle(p,"Lock dot position","With Out-of-range dot on, unlock it to drag the preview. Lock it after placing it.",function()return Range().locked~=false end,function(v)if m then m.SetLocked(v)end end)
    Link(p,"Reset position",function()if m then m.Reset()end end,"RESET")
    Link(p,"Advanced spell detection",function()OpenPage("rangeadvanced")end," > ")
    if MeffortSuiteArcaneBlast and MeffortSuiteArcaneBlast.IsMage() then
      Link(p,"Arcane Blast stacks / timer",function()OpenPage("arcaneblast")end," > ")
    end
  elseif key=="rangeadvanced" then
    p=Page(key,"Range: Advanced")
    local restoreSpell=Input(p,"Spell name (exact spellbook text)",function()return Range().spellName or "" end,function(s)
      if m then return m.SetSpell(s) end
      return false,"Range checks are unavailable."
    end,"Use spell")
    Link(p,"Use automatic range checks",function()
      if m and m.SetSpell("auto") then restoreSpell("Automatic range checks") end
    end,"AUTO")
    TextRow(p,"Unknown distances intentionally show no warning.")
  elseif key=="arcaneblast" then
    p=Page(key,"Arcane Blast")
    local ab=MeffortSuiteArcaneBlast
    if not ab or not ab.IsMage or not ab.IsMage() then
      TextRow(p,"Arcane Blast tracking is available to Mages.")
      return p
    end
    Toggle(p,"Arcane Blast on Tracked Buffs","Mage-only stack and timer overlay on Blizzard tracked buff icons.",function()return ab and ab.GetOption("enabled")end,function(v)if ab then ab.SetOption("enabled",v)end end)
    Toggle(p,"Show stack count","Display 1-4 in the lower-right corner of the icon.",function()return ab and ab.GetOption("stacks")end,function(v)if ab then ab.SetOption("stacks",v)end end)
    Toggle(p,"Show remaining time","Seconds until the 18-second Arcane Blast effect expires.",function()return ab and ab.GetOption("timer")end,function(v)if ab then ab.SetOption("timer",v)end end)
    Toggle(p,"Show timer wheel","Optional swipe shading over the tracked buff icon.",function()return ab and ab.GetOption("wheel")end,function(v)if ab then ab.SetOption("wheel",v)end end)
    TextRow(p,"Add Arcane Blast to Blizzard Tracked Buffs first.")
    TextRow(p,"Combat tracking uses successful casts; syncs afterward.")
  elseif key=="ranged" then
    p=Page(key,"Ranged attack")
    local message=TextRow(p,"")
    AddRefresh(p,function()message:SetText("Detected: "..tostring(ranged and ranged.AbilityName() or "Unavailable"))end)
    local readiness=TextRow(p,"")
    AddRefresh(p,function()
      local available,why=Capability(ranged)
      local pending=ranged and ranged.Pending and ranged.Pending()
      readiness:SetText(pending and "Input settings will refresh after combat." or
        (available==false and (why or "Right-click controls unavailable; normal mouse controls retained.") or "Right-click behavior is saved for this character."))
    end)
    Choice(p,"Right-click behavior",{{label="Off",value="off"},{label="Right-click",value="right"},{label="Shift + right-click",value="shift"}},function()return ranged and ranged.Mode() or "off"end,function(v)if ranged then ranged.SetMode(v)end end)
    local owner=TextRow(p,"")
    AddRefresh(p,function()owner:SetText("Macro owner: "..tostring(MeffortRightClickShared and MeffortRightClickShared.Owner() or "None"))end)
    Link(p,"Clean up old duplicate macros",function()
      if ranged and ranged.CleanupMacros then
        local count,err=ranged.CleanupMacros()
        if MeffortSuite and MeffortSuite.Message then
          MeffortSuite.Message(count and ("Removed "..tostring(count).." duplicates.") or ("Macro cleanup: "..tostring(err)))
        end
      end
    end,"CLEAN")
    TextRow(p,"Standalone MeffortWand takes priority when enabled.")
    TextRow(p,"Warriors and rogues select Throw or Shoot from the equipped weapon.")
  elseif key=="fishing" then
    p=Page(key,"Fishing")
    Toggle(p,"Right-click to fish","Works only with a fishing pole equipped.",function()return fishing and fishing.Enabled()end,function(v)if fishing then fishing.SetEnabled(v)end end)
    Choice(p,"Casting gesture",{{label="Single right-click",value="single"},{label="Double right-click",value="double"}},function()return fishing and fishing.Mode() or "double"end,function(v)if fishing then fishing.SetMode(v)end end)
    TextRow(p,"Use double right-click to keep normal camera turning.",C.gold)
    Section(p,"Fishing audio")
    Toggle(p,"Quiet fishing audio","While a fishing pole is equipped, mute music, ambience and dialogue. No cast is needed. Sound effects keep their current volume, so the bite and other effects remain audible. Prior volumes restore when the pole is removed or this setting is disabled. Manual volume changes are retained.",function()return MeffortSuiteFishingAudio and MeffortSuiteFishingAudio.Enabled() or false end,function(v)if MeffortSuiteFishingAudio then MeffortSuiteFishingAudio.SetEnabled(v)end end)
    local audio=TextRow(p,"")
    AddRefresh(p,function()audio:SetText("Quiet audio: "..(MeffortSuiteFishingAudio and MeffortSuiteFishingAudio.Status() or "unavailable"))end)
    local equip=TextRow(p,"")
    AddRefresh(p,function()
      local available,why=Capability(fishing)
      equip:SetText(available==false and (why or "This client cannot safely enable right-click fishing.") or
        (fishing and fishing.IsPoleEquipped() and "Fishing pole equipped" or "Equip a fishing pole to use this feature"))
    end)
    Link(p,"Pet sounds and advanced audio",function()OpenPage("audio")end," > ")
  elseif key=="loot" then
    p=Page(key,"Bags: Loot")
    Section(p,"Auto-loot")
    Toggle(p,"Fast auto loot","On by default; saved OFF choices are retained. Request loot on the next frame when native auto-loot is active, respecting the game's auto-loot setting and modifier key. Manual looting stays manual. Confirmations, full bags and combat use the native loot window. No loot-window hooks or automatic confirmations. Saved for all characters.",function()return DB().fastAutoLoot~=false end,function(v)if MeffortSuiteFastLoot then MeffortSuiteFastLoot.SetEnabled(v)else DB().fastAutoLoot=v end end)
    Section(p,"Floating totals")
    Toggle(p,"Floating loot value","Show a gently rising coin total after looting: money received plus item value. AoE loot uses one combined total. A corpse's nameplate position is used when available; otherwise the loot-click position is used.",function()return DB().lootValue~=false end,function(v)if MeffortSuiteLootValue then MeffortSuiteLootValue.SetEnabled(v)else DB().lootValue=v end end)
    Toggle(p,"Include all item qualities","Count value from every item quality. Turn off to count grey items only. Uses vendor prices unless Auctionator AH values are enabled. Applies from the next loot window and is saved for all characters.",function()return DB().lootValueAllItems~=false end,function(v)if MeffortSuiteLootValue and MeffortSuiteLootValue.SetIncludeAllItems then MeffortSuiteLootValue.SetIncludeAllItems(v)else DB().lootValueAllItems=v end end)
    Toggle(p,"Use Auctionator AH values","Single-value display: use Auctionator's cached per-item AH estimates instead of vendor prices. Off by default. Show vendor + AH together takes precedence while enabled. Missing/invalid prices and bind-on-pickup/quest items use vendor value. Coins stay exact. Requires Auctionator's price API; no scan is started. Estimates depend on cached data, not guaranteed sales. Applies from the next loot window; saved for all characters.",function()return DB().lootValueAuctionator==true end,function(v)if MeffortSuiteLootValue and MeffortSuiteLootValue.SetUseAuctionator then MeffortSuiteLootValue.SetUseAuctionator(v)else DB().lootValueAuctionator=v end end)
    Toggle(p,"Show vendor + AH together","Off by default. Show vendor value first, then a smaller, muted (AH estimate) in the same floating total. Each side includes the coins actually received; compare the two totals rather than adding them. Uses Auctionator automatically for this display, with vendor fallback for missing prices or non-auctionable items. The quality filter still applies. Takes precedence over the single-value AH toggle without changing that saved preference. Applies from the next loot window; saved for all characters.",function()return DB().lootValueBoth==true end,function(v)if MeffortSuiteLootValue and MeffortSuiteLootValue.SetShowBothValues then MeffortSuiteLootValue.SetShowBothValues(v)else DB().lootValueBoth=v end end)
    Stepper(p,"Float duration",2,12,1,function()return MeffortSuiteLootValue and MeffortSuiteLootValue.Duration and MeffortSuiteLootValue.Duration() or DB().lootValueDuration or 6 end,function(n)if MeffortSuiteLootValue and MeffortSuiteLootValue.SetDuration then MeffortSuiteLootValue.SetDuration(n)else DB().lootValueDuration=n end end," sec")
    TextRow(p,"Default: 6 seconds. Applies to new floats and previews.")
    Link(p,"Preview loot value",function()if MeffortSuiteLootValue then MeffortSuiteLootValue.Preview()end end,"SHOW",function()
      local ready=IsActive() and DB().lootValue~=false and MeffortSuiteLootValue~=nil
      return ready,ready and "Show a sample total without changing your money or bags." or "Enable Floating loot value and MeffortSuite first."
    end)
    local lootSummary=TextRow(p,"")
    AddRefresh(p,function()
      if DB().lootValueBoth==true then
        lootSummary:SetText(MeffortSuiteLootValue and MeffortSuiteLootValue.PricingStatus and
          MeffortSuiteLootValue.PricingStatus() or "Vendor + (AH estimates); vendor fallback")
      elseif DB().lootValueAuctionator==true then
        lootSummary:SetText(MeffortSuiteLootValue and MeffortSuiteLootValue.PricingStatus and
          MeffortSuiteLootValue.PricingStatus() or "Auctionator AH estimates; vendor fallback")
      else lootSummary:SetText(DB().lootValueAllItems~=false and
        "Coins + all item vendor values; AoE loot is combined." or
        "Coins + grey-item vendor value; AoE loot is combined.")end
    end)
    Link(p,"Bags and banking",function()OpenPage("inventory")end," > ")
  elseif key=="inventory" then
    p=Page(key,"Bags")
    Link(p,"Looting & loot value",function()OpenPage("loot")end," > ")
    Section(p,"Bags and merchants")
    Toggle(p,"Backpack free-slot count","On by default. Show the game's empty-slot total over the native backpack icon, using the client's normal counting rules. It updates automatically as bags change. Turning this off restores your previous game setting, so a count you already enabled in game can remain visible. Custom bag bars may manage their own counter. Changes requested in combat wait until it ends.",function()return DB().backpackFreeSlots~=false end,function(v)if MeffortSuiteBackpack then MeffortSuiteBackpack.SetEnabled(v)else DB().backpackFreeSlots=v end end)
    local backpackState=TextRow(p,"")
    AddRefresh(p,function()backpackState:SetText(MeffortSuiteBackpack and MeffortSuiteBackpack.Status() or "Native backpack count unavailable.")end)
    Toggle(p,"Auto-sort","Sort bags when opened.",function()return DB().autoSortBags~=false end,function(v)DB().autoSortBags=v;if MeffortSuiteInventory then MeffortSuiteInventory.RefreshBags()end end)
    Toggle(p,"Sell junk","Automatically sell grey items at a merchant.",function()return DB().autoSellJunk~=false end,function(v)DB().autoSellJunk=v end)
    Toggle(p,"Auto-repair","Automatically repair equipment at merchants.",function()return DB().autoRepair~=false end,function(v)DB().autoRepair=v end)
    Section(p,"Personal banking")
    Toggle(p,"Auto-bank items","Deposit crafting reagents and items from your inclusion list when your personal bank opens.",function()return MeffortSuiteBank and MeffortSuiteBank.Enabled() or false end,function(v)if MeffortSuiteBank then MeffortSuiteBank.SetEnabled(v)end end)
    Toggle(p,"Auto-sort personal bank","Sort your personal-bank tabs when the bank opens and after deposits.",function()return MeffortSuiteBank and MeffortSuiteBank.SortEnabled() or false end,function(v)if MeffortSuiteBank then MeffortSuiteBank.SetSortEnabled(v)end end)
    Input(p,"Keep in bags (comma-separated item names or IDs)",function()return MeffortSuiteBank and MeffortSuiteBank.Exclusions() or "" end,function(value)if MeffortSuiteBank and type(MeffortSuiteBank.SetExclusions)=="function" then return MeffortSuiteBank.SetExclusions(value)end;return false,"Bank item lists are unavailable." end,"Save list",250)
    Input(p,"Also deposit (comma-separated item names or IDs)",function()return MeffortSuiteBank and type(MeffortSuiteBank.Inclusions)=="function" and MeffortSuiteBank.Inclusions() or "" end,
      function(value)if MeffortSuiteBank and type(MeffortSuiteBank.SetInclusions)=="function" then return MeffortSuiteBank.SetInclusions(value)end;return false,"Bank item lists are unavailable." end,"Save list",250)
    TextRow(p,"Also deposit adds non-crafting items. Keep in bags always wins.")
    TextRow(p,"Use exact item names or IDs. Both lists are saved for this character.")
    TextRow(p,"Saving either list stops current transfers. Use Deposit items now or reopen the bank.")
    Link(p,"Deposit items now",function()if MeffortSuiteBank then MeffortSuiteBank.DepositNow(false)end end,"BANK",function()
      local bank=MeffortSuiteBank
      if not bank then return false,"Banking is unavailable." end
      if bank.CanDepositStatus then return bank.CanDepositStatus() end
      return false,"Open your personal bank to deposit reagents."
    end)
    Link(p,"Retry merchant actions",function()if MeffortSuiteInventory and MeffortSuiteInventory.VendorStatus then MeffortSuiteInventory.VendorStatus(true)end end,"RETRY",function()
      if not IsActive() then return false,"Enable MeffortSuite first." end
      local inv=MeffortSuiteInventory
      local ready=inv and inv.CanUseMerchant and inv.CanUseMerchant()
      return ready==true,ready and "Recheck junk sales and repairs at this merchant." or "Open a merchant first."
    end)
  elseif key=="quest" then
    p=Page(key,"Quests")
    Section(p,"Reward prices")
    Toggle(p,"Reward vendor values","Show the total vendor sell price for each item reward, including stack quantity. Enabled by default for all characters. Labels use free space below the item name; hover a reward for its full value when the native layout is compact. Unsellable rewards say No vendor value. Never selects or claims a reward.",function()return DB().questRewardVendor~=false end,function(v)if MeffortSuiteRewardValue then MeffortSuiteRewardValue.SetEnabled(v)else DB().questRewardVendor=v end end)
    TextRow(p,"Vendor prices include the full stack. Hover for the total.")
    Section(p,"Dialogue shortcuts")
    Toggle(p,"Quest dialogue hotkeys","Space prefers available quests, then ready turn-ins, then unfinished quests. In quest dialogue it accepts, continues or completes. Keys 1–9 follow menu order.",function()return DB().questSpace~=false end,function(v)DB().questSpace=v;if MeffortSuiteQuestSpace then MeffortSuiteQuestSpace.Refresh()end end)
    Toggle(p,"Space accepts confirmations","Use Space to choose the affirmative button on eligible game prompts. Requires Quest dialogue hotkeys. Prompts with text entry or payment keep their usual controls.",function()return DB().questSpaceConfirmations~=false end,function(v)DB().questSpaceConfirmations=v;if MeffortSuiteQuestSpace then MeffortSuiteQuestSpace.Refresh()end end)
    local readiness=TextRow(p,"")
    AddRefresh(p,function()
      local q=MeffortSuiteQuestSpace
      local available,why=Capability(q)
      local standalone=MeffortSuite and MeffortSuite.StandaloneLoaded("MeffortBars")
      readiness:SetText(standalone and "Suite quest hotkeys pause while MeffortBars is loaded." or
        available==false and (why or "Quest hotkeys are unavailable in this client.") or "Quest hotkeys pause during combat.")
    end)
    TextRow(p,"SPACE   Available > Ready to turn in > Unfinished",C.gold)
    TextRow(p,"1-9   Menu order   |   * marks the Spacebar choice")
    TextRow(p,"Long titles keep their native layout; a number may be hidden while its shortcut still works.")
    Section(p,"Service shortcuts")
    Toggle(p,"Skip single-option service dialogue","Open a known shop or service when it is the only choice and no quests are offered. Hold Shift to see the dialogue.",
      function()return DB().autoOpenSingleService~=false end,
      function(value)if MeffortSuiteGossipServices then MeffortSuiteGossipServices.SetEnabled(value)else DB().autoOpenSingleService=value end end)
    TextRow(p,"Hold Shift to keep normal NPC dialogue.")
    TextRow(p,"Service shortcuts wait for you on paid or confirmation choices.")
  elseif key=="way" then
    p=Page(key,"Map")
    Toggle(p,"Suite waypoint arrow","Show the Suite arrow for map pins, including pins created with /way. Off by default.",function()return DB().wayEnabled==true end,function(v)DB().wayEnabled=v;if MeffortSuiteWay then MeffortSuiteWay.Refresh()end end)
    TextRow(p,"/way 49.4 12.9 sets a pin on the open map, or your current zone.")
    TextRow(p,"/way Hillsbrad Foothills 87.3 49.6 sets a pin in a named zone.")
    TextRow(p,"Use /msuite way 49.4 12.9 if another addon provides /way.")
    Toggle(p,"Skip flight master dialogue","Open a recognized flight map automatically. Hold Shift for normal dialogue. You choose the route.",function()return MeffortSuiteFlightMasters and MeffortSuiteFlightMasters.Enabled() or false end,function(v)if MeffortSuiteFlightMasters then MeffortSuiteFlightMasters.SetEnabled(v)end end)
    Choice(p,"Arrow style",{{label="Teal",value="teal"},{label="Treecko",value="treecko"}},function()return DB().wayTheme or "teal"end,function(v)if MeffortSuiteWay then MeffortSuiteWay.SetTheme(v,true)end end)
  elseif key=="tooltips" then
    p=Page(key,"Tooltips")
    Toggle(p,"Simple spell explanations","Replace complex descriptions with simplified tooltips.",function()return DB().enabled==true end,function(v)if MeffortSuiteSetTooltipsEnabled then MeffortSuiteSetTooltipsEnabled(v)end end)
    Choice(p,"Description display",{{label="Replace",value="replace"},{label="Compare",value="compare"}},function()return MeffortSuiteGetTooltipMode and MeffortSuiteGetTooltipMode() or "replace"end,function(v)if MeffortSuiteSetTooltipMode then MeffortSuiteSetTooltipMode(v)end end)
    Toggle(p,"Highlight headers & costs","Higher contrast for spell information.",function()return DB().style~=false end,function(v)DB().style=v end)
    Toggle(p,"Spell badges","Show cast time, range and resource tags.",function()return DB().badges~=false end,function(v)DB().badges=v end)
    Toggle(p,"New-rank reminder","Display a notice when new spell ranks are available.",function()return DB().rankHint~=false end,function(v)DB().rankHint=v end)
    Link(p,"Customize badge colors",function()OpenPage("badges")end," > ")
    local status=TextRow(p,"")
    AddRefresh(p,function()
      local info=MeffortSuiteTooltipStatus and MeffortSuiteTooltipStatus()
      local standalone=MeffortSuite and MeffortSuite.StandaloneLoaded("MeffortBars")
      if standalone then status:SetText("Suite spell tooltips pause while MeffortBars is loaded.")
      elseif info and not info.available then status:SetText("Spell tooltip features are unavailable in this client.")
      elseif info and not info.localeSupported then status:SetText("Spell tooltip features require an English game client.")
      elseif DB().style==false then status:SetText("Enable Highlight headers & costs to use spell badges.")
      else status:SetText("Spell descriptions use English game data.") end
    end)
  elseif key=="badges" then
    p=Page(key,"Colors")
    TextRow(p,"Preview your palette; native warning colors stay unchanged.")
    Toggle(p,"Text outline","Improve readability against bright badges.",function()return DB().badgeTextOutline==true end,function(v)DB().badgeTextOutline=v end)
    Toggle(p,"Text shadow","Increase contrast on badge text.",function()return DB().badgeTextShadow~=false end,function(v)DB().badgeTextShadow=v end)
    TextRow(p,"PREVIEW                         BACKGROUND       TEXT",C.gold)
    local palette={{"instant","Instant"},{"channel","Channel"},{"cast","Cast"},{"cooldown","Cooldown"},
      {"range","Range"},{"Mana","Mana"},{"Rage","Rage"},{"Energy","Energy"},
      {"Focus","Focus"},{"Health","Health"},{"Combo","Combo"},{"Reagent","Reagent"},{"Requirement","Requirement"}}
    for _,pair in ipairs(palette) do Swatch(p,pair[2],pair[1])end
    Link(p,"Restore default colors",function()if MeffortSuiteBadgeThemeReset then MeffortSuiteBadgeThemeReset()end end,"RESET")
  elseif key=="action" then
    p=Page(key,"Bars")
    if MeffortSuite and MeffortSuite.StandaloneLoaded("MeffortBars") then
      TextRow(p,"Suite action-bar styling pauses while MeffortBars is loaded.",C.gold)
    end
    Toggle(p,"Custom keybind labels","Use Suite hotkey labels on action bars.",function()return Action().enabled end,function(v)Action().enabled=v;ApplyBar()end)
    Link(p,"Open live position preview",function()
      if MeffortSuiteActionText and MeffortSuiteActionText.OpenPreview then
        local scroll=scroller:GetVerticalScroll() or 0
        MeffortSuiteActionText.OpenPreview(function()
          frame:Show()
          OpenPage("action",true,scroll)
        end)
      end
    end,"EDIT")
    Stepper(p,"Text size",8,24,1,function()return Action().size end,function(n)Action().size=n;ApplyBar()end," px")
    Stepper(p,"Horizontal offset",-22,22,1,function()return Action().x end,function(n)Action().x=n;Action().position="custom";ApplyBar()end,"")
    Stepper(p,"Vertical offset",-22,22,1,function()return Action().y end,function(n)Action().y=n;Action().position="custom";ApplyBar()end,"")
    Toggle(p,"Text outline","Improve contrast on icons.",function()return Action().outline end,function(v)Action().outline=v;ApplyBar()end)
    Toggle(p,"Text shadow","Add a subtle shadow behind hotkeys.",function()return Action().shadow end,function(v)Action().shadow=v;ApplyBar()end)
    Link(p,"Pick text color",function()
      if MeffortSuiteShowColorPicker then MeffortSuiteShowColorPicker(Action().hex,function(hex)Action().hex=hex;ApplyBar();RefreshUI()end)end
    end,"COLOR")
  elseif key=="audio" then
    p=Page(key,"Sounds")
    Section(p,"Pets")
    Toggle(p,"Mute native pet sounds","Off by default. Uses the game's Pet Sounds setting. This is broader than footsteps and may include combat pets. Shared creature footsteps may remain audible. Your prior setting restores when disabled or when the suite is off; manual changes in game are respected.",function()return DB().petSoundsMuted==true end,function(v)if MeffortSuiteSound then MeffortSuiteSound.SetNativeEnabled(v)else DB().petSoundsMuted=v end end)
    local state=TextRow(p,"")
    AddRefresh(p,function()state:SetText(MeffortSuiteSound and MeffortSuiteSound.NativeStatus() or "Sound controls unavailable.")end)
    Link(p,"Advanced sound-file muting",function()OpenPage("soundfiles")end," > ")
    Section(p,"Fishing")
    Toggle(p,"Quiet fishing audio","Mute music, ambience and dialogue while a pole is equipped. Sound effects and master volume are unchanged. Prior settings restore afterward; manual volume changes are retained.",function()return MeffortSuiteFishingAudio and MeffortSuiteFishingAudio.Enabled() or false end,function(v)if MeffortSuiteFishingAudio then MeffortSuiteFishingAudio.SetEnabled(v)end end)
    Link(p,"Right-click fishing settings",function()OpenPage("fishing")end," > ")
  elseif key=="soundfiles" then
    p=Page(key,"Sounds: Files")
    Toggle(p,"Mute selected sound files","Off by default. Mutes the listed file IDs using the client's mute API. Disabling restores only files recorded by this feature. Files are global sounds, not isolated to your own companion. Other addons using the same files can conflict.",function()return DB().petSoundFilesEnabled==true end,function(v)if MeffortSuiteSound then MeffortSuiteSound.SetFilesEnabled(v)else DB().petSoundFilesEnabled=v end end)
    Wrapped(p,"Enter verified sound-file IDs, not sound-kit IDs, pet names or spell IDs. Leave the list empty until the correct files are known.")
    Input(p,"Sound-file IDs (comma-separated)",function()return MeffortSuiteSound and MeffortSuiteSound.Files() or ""end,function(value)if MeffortSuiteSound then return MeffortSuiteSound.SetFiles(value)end;return false,"Sound controls unavailable."end,"Save list",500)
    local state=TextRow(p,"")
    AddRefresh(p,function()state:SetText(MeffortSuiteSound and MeffortSuiteSound.FileStatus() or "Sound controls unavailable.")end)
    Link(p,"Pet and fishing sounds",function()OpenPage("audio")end," > ")
  elseif key=="defaults" then
    p=Page(key,"Restore Defaults")
    Section(p,"Default behavior")
    Wrapped(p,"Returns tools to their installation defaults: normal vendor loot totals, six-second floats, reward prices, fast loot and backpack count on, added sound mutes off, double-click fishing, and class-specific ranged defaults. Bag sorting, junk sales, repairs and bank conveniences return to their normal defaults.")
    Wrapped(p,"Before reloading, the suite stops active work and restores the game's audio and backpack settings it has changed. Your other addons and game settings are kept.")
    local feedback
    Link(p,"Restore defaults & reload",function()
      local ok,why=MeffortSuiteDefaults.Restore()
      feedback:SetText(why or (ok and "Reloading to apply defaults." or "Defaults were not changed."))
    end,"RESET",function()
      if not MeffortSuiteDefaults then return false,"Defaults controls unavailable." end
      return MeffortSuiteDefaults.CanRestore()
    end)
    feedback=TextRow(p,"")
    Link(p,"Reload UI",function()local _,why=MeffortSuiteDefaults.Reload();feedback:SetText(why or "")end,"RELOAD",function()
      if not MeffortSuiteDefaults then return false,"Defaults controls unavailable." end
      return MeffortSuiteDefaults.CanReload()
    end)
  elseif key=="help" then
    p=Page(key,"Setup & help")
    Section(p,"Choose a task")
    Link(p,"Set up loot values and reading time",function()OpenPage("loot")end," > ")
    Link(p,"Configure quest rewards and shortcuts",function()OpenPage("quest")end," > ")
    Link(p,"Set up fishing",function()OpenPage("fishing")end," > ")
    Link(p,"Configure pet and fishing sounds",function()OpenPage("audio")end," > ")
    Link(p,"Manage personal-bank item lists",function()OpenPage("inventory")end," > ")
    Link(p,"Place custom keybind labels",function()OpenPage("action")end," > ")
    Section(p,"Saving and scope")
    Wrapped(p,"Checkboxes and choices save immediately. Text fields save with Enter or their save button; Esc discards that field's draft. Unapplied text survives navigation. Each page identifies account or character settings.")
    Section(p,"If a feature is waiting")
    Wrapped(p,"Check Suite ON first, then the feature's own switch. Fishing needs an equipped pole; banking needs an open personal bank. AH estimates need Auctionator data. Protected input changes may wait until combat ends.")
    Section(p,"Share a problem with Mefforts")
    Wrapped(p,"Before reloading or logging out, copy a diagnostic report. Choose Select report, press Ctrl+C (Command+C on Mac), then paste it outside the game with Ctrl+V (Command+V). Include what you clicked and the NPC or window.")
    Link(p,"Open diagnostic report",function()MeffortSuiteExportDiagnostics()end,"OPEN",function()
      return type(MeffortSuiteExportDiagnostics)=="function","Copy before reloading or logging out."
    end)
    Link(p,"Restore Defaults",function()OpenPage("defaults")end," > ")
    Link(p,"About and login message",function()OpenPage("about")end," > ")
  elseif key=="about" then
    p=Page(key,"About")
    TextRow(p,"MeffortSuite "..MeffortSuite.Version,C.gold)
    Toggle(p,"Show login message","Print one chat message when logging in or reloading. Applies to all characters.",function()return DB().showLoginMessage~=false end,function(v)DB().showLoginMessage=v end)
    Link(p,"Restore Defaults",function()OpenPage("defaults")end," > ")
    TextRow(p,"/msuite   Open feature launcher")
    TextRow(p,"/msuite diagnostics   Module status and recent errors")
    Link(p,"Open diagnostic report",function()if MeffortSuiteExportDiagnostics then MeffortSuiteExportDiagnostics()end end,"OPEN")
    TextRow(p,"/msuite distance   Range command")
    TextRow(p,"/msuite arcane   Mage Tracked Buffs settings")
    TextRow(p,"/msuite fishing   Fishing command")
    TextRow(p,"/msuite bank now   Deposit listed items and reagents")
    TextRow(p,"/msuite bank sort on/off   Bank auto-sort")
    TextRow(p,"/msuite flight on/off   Flight master dialogue")
  else return nil end
  return p
end
local names={audio="Sounds",soundfiles="Sounds: Files",defaults="Restore Defaults",loot="Bags: Loot",help="Setup & help",overview="MeffortSuite",ranged="Ranged attack",range="Combat",arcaneblast="Arcane Blast",rangeadvanced="Advanced range",inventory="Bags",quest="Quests",way="Map",tooltips="Tooltips",action="Bars",fishing="Fishing",badges="Colors",about="About"}
local aliases={sounds="audio",sound="audio",looting="loot",rewards="quest",support="help",home="overview",combat="range",interface="tooltips",appearance="tooltips",convenience="inventory",distance="range",arcane="arcaneblast",wand="ranged",shoot="ranged",throw="ranged",bags="inventory",quests="quest",dialogue="quest",services="quest",map="way",bars="action",colors="badges",professions="fishing",profession="fishing"}
local parentPages={loot="inventory",rangeadvanced="range",arcaneblast="range",badges="tooltips",soundfiles="audio"}
local function GoBack()
  local previous=table.remove(history)
  if previous then OpenPage(previous.id,true,previous.scroll)
  else OpenPage(parentPages[activePage] or "overview",true,0) end
end
local function HasDrafts()
  for _,dirty in ipairs(inputDrafts) do if dirty() then return true end end
  return false
end
local function FitToScreen()
  if not frame or not frame.SetScale or not UIParent or not UIParent.GetWidth or not UIParent.GetHeight then return end
  local w,h=UIParent:GetWidth(),UIParent:GetHeight()
  if type(w)~="number" or type(h)~="number" or w<=0 or h<=0 then return end
  local widthScale=math.max(.1,math.min(1,(w-24)/frame:GetWidth()))
  local page=pages[activePage]
  if page then frame:SetHeight(math.max(MIN_DETAIL_H,math.min(MAX_DETAIL_H,page.height+108,(h-24)/widthScale))) end
  frame:SetScale(math.max(.1,math.min(widthScale,(h-24)/frame:GetHeight())))
end
RefreshUI=function()
  if not frame then return end
  local on=IsActive()
  masterText:SetText(on and "Suite ON" or "Suite OFF")
  masterText:SetTextColor(on and C.mint[1] or C.red[1],on and C.mint[2] or C.red[2],on and C.mint[3] or C.red[3])
  masterButton.skin.selected=on;masterButton.skin:Paint()
  local resetPending=MeffortSuiteDefaults and MeffortSuiteDefaults.Pending()
  if resetPending then masterButton.button:Disable()else masterButton.button:Enable()end
  local ranged=MeffortSuiteRanged
  local pending=ranged and ranged.Pending and ranged.Pending() and
    type(InCombatLockdown)=="function" and InCombatLockdown()
  statusTitle:SetText(resetPending and "Reload required to apply defaults" or pending and (on and "MeffortSuite enabled - input changes pending" or
    "MeffortSuite disabled - input changes pending") or
    (on and "MeffortSuite enabled" or "MeffortSuite disabled - preferences retained"))
  statusTitle:SetTextColor(on and C.gold[1] or C.muted[1],on and C.gold[2] or C.muted[2],on and C.gold[3] or C.muted[3])
  statusDetail:SetText(resetPending and "Use Reload UI on Restore Defaults; preferences reset on reload." or pending and "Right-click changes apply after combat; preferences saved." or
    HasDrafts() and "Unsaved text. Press Enter to save or Esc to discard in the field." or
    (on and (activePage=="overview" and "Choose a category. ? opens setup and help." or "Hover a setting for details. ? opens setup and help.") or "Enable the suite above to use your saved preferences."))
  if activePage=="overview" then UpdateHome() end
  local page=pages[activePage]
  if page then for _,fn in ipairs(page.refreshers) do fn()end end
end
OpenPage=function(id,goingBack,scroll)
  if not frame then return end
  id=aliases[id] or id or "overview"
  if id~="overview" and not names[id] then id="overview" end
  local same=id==activePage
  if not same and not goingBack and id~="overview" then
    for i=#history,1,-1 do
      if history[i].id==id then
        scroll=history[i].scroll
        for j=#history,i,-1 do history[j]=nil end
        break
      end
    end
    if not scroll and (#history>0 or parentPages[activePage]~=id) then
      history[#history+1]={id=activePage,scroll=scroller:GetVerticalScroll() or 0}
    end
  end
  local isHome=id=="overview"
  activePage=id
  if isHome then
    history={}
    frame:SetSize(HOME_W,HOME_H)
    headerTitle:SetText("MeffortSuite")
    headerTitle:ClearAllPoints();headerTitle:SetPoint("TOPLEFT",frame,"TOPLEFT",53,-16)
    headerTitle:SetWidth(144)
    logo:Show();infoButton:Show();backButton:Hide();homeButton:Hide()
    scroller:Hide();home:Show();if resetButton then resetButton:Show()end
  else
    local page=pages[id] or Build(id)
    if not page then return OpenPage("overview") end
    frame:SetSize(DETAIL_W,math.max(MIN_DETAIL_H,math.min(MAX_DETAIL_H,page.height+108)))
    headerTitle:SetText(names[id] or "Settings")
    headerTitle:ClearAllPoints();headerTitle:SetPoint("TOPLEFT",frame,"TOPLEFT",135,-16)
    headerTitle:SetWidth(155)
    logo:Hide();infoButton:Show();backButton:Show();homeButton:Show()
    home:Hide();scroller:Show();if resetButton then resetButton:Hide()end
    for key,v in pairs(pages) do if key~=id then v:Hide()end end
    if not same then scroller:SetScrollChild(page) end
    page:Show()
  end
  FitToScreen()
  if not isHome and (scroll or not same) then
    if scroller.UpdateScrollChildRect then scroller:UpdateScrollChildRect() end
    scroller:SetVerticalScroll(scroll or 0)
  end
  RefreshUI()
end
local function CreatePanel()
  if frame then return frame end
  local backdropTemplate=BackdropTemplateMixin and "BackdropTemplate" or nil
  frame=CreateFrame("Frame","MeffortSuiteSettingsV2",UIParent,backdropTemplate)
  frame:SetSize(HOME_W,HOME_H)
  frame:SetPoint("CENTER",UIParent,"CENTER",0,0)
  frame:SetFrameStrata("DIALOG")
  frame:SetClampedToScreen(true)
  frame:EnableMouse(true)
  frame:SetMovable(true)
  frame:RegisterForDrag("LeftButton")
  frame:SetScript("OnDragStart",function(self)self:StartMoving()end)
  frame:SetScript("OnDragStop",function(self)self:StopMovingOrSizing()end)
  WoWBackdrop(frame)
  local hdr=frame:CreateTexture(nil,"ARTWORK")
  hdr:SetPoint("TOPLEFT",frame,"TOPLEFT",11,-7)
  hdr:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-11,-7)
  hdr:SetHeight(40)
  hdr:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Background")
  hdr:SetVertexColor(.55,.42,.21,.89)
  local line=frame:CreateTexture(nil,"ARTWORK")
  line:SetPoint("TOPLEFT",frame,"TOPLEFT",12,-47)
  line:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-12,-47)
  line:SetHeight(1)
  line:SetTexture("Interface\\Buttons\\WHITE8X8")
  line:SetVertexColor(.83,.67,.32,1)
  logo=frame:CreateTexture(nil,"ARTWORK")
  logo:SetTexture("Interface\\AddOns\\MeffortSuite\\Textures\\MeffortSuiteIcon.tga")
  logo:SetPoint("TOPLEFT",frame,"TOPLEFT",15,-12)
  logo:SetSize(29,29)
  headerTitle=Font(frame,"MeffortSuite",16,C.gold)
  headerTitle:SetPoint("TOPLEFT",frame,"TOPLEFT",53,-16)
  headerTitle:SetJustifyH("LEFT")
  if headerTitle.SetWordWrap then headerTitle:SetWordWrap(false) end
  local close=CreateFrame("Button",nil,frame,"UIPanelCloseButton")
  close:SetSize(29,29)
  close:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-10,-11)
  close:SetScript("OnClick",function()frame:Hide()end)
  masterButton=PressButton(frame,"",86,26,function()
    if MeffortSuiteSetMasterEnabled then MeffortSuiteSetMasterEnabled(not IsActive())end
    RefreshUI()
  end)
  masterButton.button:SetPoint("RIGHT",close,"LEFT",-1,0)
  masterText=masterButton.text
  Tips(masterButton.button,"Enable MeffortSuite","Turn the whole suite on or off. Individual preferences stay saved. During combat, protected input changes may wait until combat ends.")
  statusTitle=Font(frame,"",11,C.gold)
  statusTitle:SetPoint("TOPLEFT",frame,"TOPLEFT",16,-55)
  statusTitle:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-16,-55)
  statusTitle:SetJustifyH("LEFT")
  statusDetail=Font(frame,"",10,C.muted)
  statusDetail:SetPoint("TOPLEFT",frame,"TOPLEFT",16,-71)
  statusDetail:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-16,-71)
  statusDetail:SetJustifyH("LEFT")
  infoButton=PressButton(frame,"?",24,24,function()OpenPage("help")end).button
  Tips(infoButton,"Setup & help","Open task guidance, saving instructions and diagnostic-report help. Back returns to this page.")
  infoButton:SetPoint("RIGHT",masterButton.button,"LEFT",-2,0)
  backButton=PressButton(frame,"< Back",60,25,GoBack).button
  backButton:SetPoint("TOPLEFT",frame,"TOPLEFT",11,-11)
  homeButton=PressButton(frame,"Home",52,25,function()OpenPage("overview")end).button
  homeButton:SetPoint("LEFT",backButton,"RIGHT",3,0)
  Tips(homeButton,"Home","Return to the feature launcher.")
  if frame.GetFrameLevel and backButton.SetFrameLevel then backButton:SetFrameLevel(frame:GetFrameLevel()+9)end
  scroller=CreateFrame("ScrollFrame",nil,frame,"UIPanelScrollFrameTemplate")
  scroller:SetPoint("TOPLEFT",frame,"TOPLEFT",14,-91)
  scroller:SetPoint("BOTTOMRIGHT",frame,"BOTTOMRIGHT",-29,16)
  scroller:Hide()
  BuildHome()
  resetButton=PressButton(frame,"Restore Defaults",150,23,function()OpenPage("defaults")end).button
  resetButton:SetPoint("BOTTOMLEFT",frame,"BOTTOMLEFT",14,10)
  Tips(resetButton,"Restore Defaults","Review a reset of account preferences and this character's settings. Nothing changes until you confirm; the UI then reloads.")
  if type(UISpecialFrames)=="table" then
    local found=false
    for _,v in ipairs(UISpecialFrames) do if v=="MeffortSuiteSettingsV2" then found=true;break end end
    if not found then table.insert(UISpecialFrames,"MeffortSuiteSettingsV2")end
  end
  local evt=CreateFrame("Frame",nil,frame)
  evt:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
  evt:RegisterEvent("SPELLS_CHANGED")
  for _,event in ipairs({"PLAYER_REGEN_ENABLED","PLAYER_REGEN_DISABLED","BANKFRAME_OPENED","BANKFRAME_CLOSED","MERCHANT_SHOW","MERCHANT_CLOSED","TRADE_SKILL_SHOW","TRADE_SKILL_CLOSE","UI_SCALE_CHANGED","DISPLAY_SIZE_CHANGED"}) do
    pcall(evt.RegisterEvent,evt,event)
  end
  local refreshQueued=false
  evt:SetScript("OnEvent",function()
    if frame and frame:IsShown() then
      FitToScreen();RefreshUI()
      -- Modules may receive the same event after the settings frame does.
      if not refreshQueued and C_Timer and C_Timer.After then
        refreshQueued=true
        C_Timer.After(0,function()
          refreshQueued=false
          if frame and frame:IsShown() then FitToScreen();RefreshUI() end
        end)
      end
    end
  end)
  frame:Hide()
  return frame
end
function UI.Open(id)
  local win=CreatePanel()
  local fresh=not win:IsShown()
  if fresh then history={};activePage="overview" end
  if MeffortSuiteActionText and MeffortSuiteActionText.HidePanel then MeffortSuiteActionText.HidePanel() end
  win:Show()
  OpenPage(id or "overview",fresh)
end
function UI.Hide()if frame then frame:Hide()end end
function UI.Refresh()RefreshUI()end
function UI.HasUnsavedChanges()return HasDrafts()end
function UI.CurrentPage()return activePage end
function MeffortSuiteOpenSettings(page)UI.Open(page or "overview")end
function MeffortSuiteShowMainSettings()UI.Open(activePage=="action" and "action" or "overview")end
function MeffortSuiteHideMainSettings()UI.Hide()end

local function CreateOptionsPage()
  local panel=CreateFrame("Frame",nil,UIParent)
  panel.name="MeffortSuite"
  panel:Hide()
  local title=Font(panel,"MeffortSuite",20,C.gold)
  title:SetPoint("TOPLEFT",panel,"TOPLEFT",16,-16)
  local version=Font(panel,"Version "..tostring(MeffortSuite and MeffortSuite.Version or ""),12,C.muted)
  version:SetPoint("TOPLEFT",title,"BOTTOMLEFT",0,-8)
  local description=Font(panel,"Open MeffortSuite to configure bags, loot, quests, combat, fishing, travel, and interface tools.",12,C.white)
  description:SetPoint("TOPLEFT",panel,"TOPLEFT",16,-70)
  description:SetPoint("TOPRIGHT",panel,"TOPRIGHT",-16,-70)
  description:SetJustifyH("LEFT")
  local open=CreateFrame("Button",nil,panel,"UIPanelButtonTemplate")
  open:SetSize(200,26)
  open:SetPoint("TOPLEFT",panel,"TOPLEFT",16,-116)
  open:SetText("Open MeffortSuite")
  open:SetScript("OnClick",function()
    if SettingsPanel and SettingsPanel:IsShown() and type(SettingsPanel.Close)=="function" then
      SettingsPanel:Close(true)
      if SettingsPanel:IsShown() then return end
    elseif InterfaceOptionsFrame and InterfaceOptionsFrame:IsShown() and type(HideUIPanel)=="function" then
      HideUIPanel(InterfaceOptionsFrame)
    end
    UI.Open("overview")
  end)
  local check=CreateFrame("CheckButton",nil,panel,"UICheckButtonTemplate")
  check:SetSize(29,29)
  check:SetPoint("TOPLEFT",panel,"TOPLEFT",12,-158)
  local label=Font(panel,"Show login message",12,C.white)
  label:SetPoint("LEFT",check,"RIGHT",3,0)
  local detail=Font(panel,"Print one chat message when logging in or reloading. Applies to all characters.",12,C.muted)
  detail:SetPoint("TOPLEFT",panel,"TOPLEFT",16,-198)
  detail:SetPoint("TOPRIGHT",panel,"TOPRIGHT",-16,-198)
  detail:SetJustifyH("LEFT")
  check:SetScript("OnClick",function(self)DB().showLoginMessage=self:GetChecked() and true or false end)
  panel:SetScript("OnShow",function()check:SetChecked(DB().showLoginMessage~=false)end)
  return panel
end

local optionsRegistered=false
local optionsEvents=CreateFrame("Frame")
optionsEvents:RegisterEvent("ADDON_LOADED")
optionsEvents:RegisterEvent("PLAYER_LOGIN")
optionsEvents:SetScript("OnEvent",function(self)
  if optionsRegistered then return end
  if Settings and type(Settings.RegisterCanvasLayoutCategory)=="function" and type(Settings.RegisterAddOnCategory)=="function" then
    local panel=CreateOptionsPage()
    local category=Settings.RegisterCanvasLayoutCategory(panel,"MeffortSuite")
    Settings.RegisterAddOnCategory(category)
  elseif type(InterfaceOptions_AddCategory)=="function" then
    InterfaceOptions_AddCategory(CreateOptionsPage())
  else return end
  optionsRegistered=true
  self:UnregisterEvent("ADDON_LOADED")
  self:UnregisterEvent("PLAYER_LOGIN")
end)
