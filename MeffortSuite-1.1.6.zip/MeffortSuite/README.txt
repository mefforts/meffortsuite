MeffortSuite 1.1.6
World of Warcraft: Forever 1.60.1 | Interface 16001

GET STARTED
Install the Forever file with CurseForge, or extract the MeffortSuite folder
into the Forever client's Interface/AddOns folder. Replace the existing
MeffortSuite folder when updating. Keep the folder name MeffortSuite and leave
your SavedVariables in place. Reload the UI if the game is already open.

Type /msuite or open Options > AddOns > MeffortSuite. Choose a category to see
its settings. A category lights up and shows ON when one or more of its
features are enabled. The Suite switch turns the addon on or off and saves
your individual feature preferences. Use Back to return to your last page,
Home to return to the launcher, and ? for setup and troubleshooting.

Toggles and choices save immediately. Save text changes with Enter or the
button beside the field. Esc discards that field's unsaved edit. Text drafts
stay available when you switch pages. The scope at the top of each page shows
which settings apply to the whole account and which apply to this character.
Changes to protected controls may wait until combat ends.

FIND A SETTING
Bags       Bag sorting, backpack count, junk sales, repairs and bank lists.
           Looting & loot value includes fast looting and the loot preview.
Quests     Reward vendor values, Space and number keys, and service shortcuts.
Combat     Target range warning and the Mage Arcane Blast tracker.
Ranged    Right-click or Shift + right-click settings for supported classes.
Map        Waypoint arrow and flight-master dialogue.
Tooltips   Spell explanations, header highlighting, badge colors and rank hints.
Bars       Keybind labels, text size and position, and a live preview.
Fishing    Right-click casting, click mode and quiet fishing audio.
Sounds     Pet sounds, advanced sound-file muting and quiet fishing audio.
About      Login message, diagnostic reports and Restore Defaults.

LOOT, BAGS AND BANKING
Fast auto loot is on by default and follows the game's Auto Loot option and
modifier key. Manual looting, full bags, combat and confirmations use the
game's usual controls. Existing saved OFF choices carry forward.

Floating loot value is on by default. The total combines received coins and
the vendor value of all received item qualities. It combines area loot into
one total. Fishing and items opened from inventory are excluded. Turn off
Include all item qualities for grey items only. Float duration starts at six
seconds and can be set from 2 to 12 seconds. Preview loot value shows the
current display style. The float uses an available corpse nameplate or the
loot-click position. Changes apply to new loot windows and previews.

Use Auctionator AH values to replace vendor prices with Auctionator's cached
item estimates. Show vendor + AH together puts both totals on the same float.
Each total includes actual coins received. Missing prices and items that
cannot be auctioned use vendor values. You can use all other loot features
without Auctionator.

Backpack free-slot count uses the native count on the default backpack icon.
Turning it off restores the count setting you had before the addon changed it.
Custom bag bars may have their own count control. Automatic merchant actions
sell junk and use personal gold for repairs. Use Retry merchant actions while
the merchant remains open if an action is pending or failed.

Auto-bank items deposits crafting reagents in your personal bank. Add more
items with Also deposit, or exclude items with Keep in bags. Enter comma-
separated exact names or numeric item IDs. IDs work across languages. Keep in
bags takes priority. Both lists are saved per character. Save with Enter or
Save list. To apply changed lists, use Deposit items now or reopen the bank.
Unidentified items stay in bags until their names and stack information load.

QUESTS AND TRAVEL
Reward vendor values are on by default. Each supported item reward shows
the full stack's vendor value, or you can hover it when space is limited.
The game's reward selection and claim controls are used.

In quest dialogue, Space accepts, continues or completes the current quest.
In a menu, it prefers an available quest, a quest ready to turn in, then an
unfinished quest. Without quests it selects the first choice. Number keys 1
through 9 follow the menu order. An asterisk marks the Space choice. A menu
row can still have a keyboard shortcut when there is too little room to show
its label.

With Space accepts confirmations enabled in Quests, Space chooses the
affirmative button on eligible game prompts such as Yes/No or Accept/Cancel. It
requires Quest dialogue hotkeys. Prompts with text entry, payment, or extra
choices use their usual controls. The shortcut pauses during combat.

The service shortcut can open a known shop, trainer or bank when there is one
choice and no quests. Hold Shift to keep the dialogue open. Flight masters
have their own control under Map. It opens the flight map for you to select
a destination. Service shortcuts wait for you on paid and confirmation choices.

Suite waypoint arrow is off by default. Enable it under Map to follow native
map pins. Use /way 49.4 12.9 to place a pin on the open map or your current
zone. Add a zone name before the coordinates to
choose another area. If the name is ambiguous, use /way #mapID x y. Coordinates
are percentages from 0 to 100. If another addon owns /way, use /msuite way.

COMBAT AND FISHING
Choose Shift + right-click for a ranged attack if you want to keep ordinary
right-click for native melee. Equip a matching wand, bow, gun, crossbow or
thrown weapon. Warrior and Rogue macros select the attack for the current
weapon. Hunter Auto Shot uses its normal repeating behavior. An equipped
fishing pole gives fishing priority. An active standalone MeffortWand takes
priority for wand input. Use Clean up old duplicate macros explicitly if
you want to remove recognized duplicate generated macros.

The range dot appears only when the client confirms the target is beyond
the chosen distance. Turn on Out-of-range dot before unlocking its position
to drag it. Lock dot position controls placement. Use automatic range
detection unless you need an exact spell for Advanced spell detection. To use the Mage tracker, first add
Arcane Blast to Blizzard's Tracked Buffs, then choose stacks, time and the
optional timer wheel under Combat.

Equip a fishing pole for right-click fishing. Double-click is the default
for new characters and lets you turn the camera with a normal right-click
drag. Select single-click if you prefer one-click casting. Quiet fishing
audio can mute music, ambience and dialogue while a pole is equipped. The
bite and other sound effects keep their current volume.

TOOLTIPS, BARS AND SOUNDS
Tooltips offers English spell explanations in Replace or Compare mode.
Enable Highlight headers & costs to use the spell badges. Customize badge
colors under Tooltips. The new-rank reminder is a separate option.
If the older MeffortBars addon is loaded, it handles tooltips, action-bar
labels and quest shortcuts.

Bars custom keybind labels start at size 20 with horizontal and vertical
offsets of -15. Saved sizes and positions carry forward. Adjust the values
under Bars or drag the sample in the live preview. Reset appearance returns
the label style to its defaults. Native red range warnings take priority.

Pet-sound options start off. Mute native pet sounds uses the game's Pet Sounds
category. It can also affect combat pets, and shared footsteps may remain
audible. Advanced sound-file muting accepts verified numeric sound-file IDs.
Every source using a muted file is affected. Turning off a sound option
restores the settings or files the addon changed. Manual native volume
changes are respected.

RESTORE DEFAULTS
Open Restore Defaults from Settings or run /msuite defaults. Read the review
and choose Restore defaults & reload to apply the reset. It resets account
preferences and this character's feature settings during reload. It keeps bank
and sound-file lists, macros, game keybindings and other characters' settings.
Finish combat, clear the cursor and release the right mouse button before
resetting. If the reload needs a retry, choose Reload UI from the review page.

COMMANDS
/msuite                    Open the launcher
/msuite help               Open setup and troubleshooting
/msuite on | off           Turn the suite on or off
/msuite bags               Open Bags
/msuite loot               Open loot settings
/msuite rewards            Open Quests
/msuite sounds             Open Sounds
/msuite arcane             Open the Arcane Blast settings
/msuite fishing settings   Open Fishing
/msuite ranged settings    Open Ranged attack settings
/msuite bars               Open Bars
/msuite combat             Open Combat
/msuite map                Open Map
/msuite tooltips           Open Tooltips
/msuite about              Open About
/msuite vendor [retry]     Check or retry merchant actions
/msuite bank now           Deposit items at an open personal bank
/msuite defaults           Open the Restore Defaults review
/msuite diagnostics        Show session diagnostics in chat
/msuite export             Open a copyable diagnostic report

TROUBLESHOOTING
Check Suite ON and the feature's own setting first. If a feature needs an
equipped item or an open game window, its settings page explains what to do.
A blocked interface action can leave a diagnostic record even when no Lua
error appears.

To report an issue, open /msuite export before reloading or logging out.
Choose Select report, copy with Ctrl+C (Command+C on Mac), then paste outside
the game with Ctrl+V (Command+V on Mac). Include what you clicked and the NPC
or window involved. The session report remains local until you share it.
Use About or the native AddOns options to turn off Show login message.

See ATTRIBUTION.txt and LICENSE for source credits and licensing.
