MeffortSuiteFishingCamera={}
local M=MeffortSuiteFishingCamera
local fishing=MeffortSuiteFishing
local tracker=CreateFrame("Frame")
local ready,inWorld,lineOut=false,false,false
local castID
local iconActive,iconStatus=false,"off"
local status="off"
local view,move
local zoomMotion,pitchMotion
local pitchVelocity,lookTime=0,0
local issuingZoom,writingCVar=false,false
local tiltDegrees=6
local defaultDelay,maxDelay,delayStep=2.75,10,.25
local zoomTolerance=.05
local iconSettings={SoftTargetIconGameObject=1,SoftTargetIconInteract=1}
local oldBobberSettings={
    SoftTargetInteract=3,SoftTargetNameplateInteract=1,SoftTargetIconGameObject=1,
    SoftTargetIconInteract=1,SoftTargetInteractRange=30,SoftTargetInteractArc=2,cameraFov=50,
}

local function DB()
    if type(MeffortSuiteDB)~="table" then MeffortSuiteDB={} end
    return MeffortSuiteDB
end
local function Char()
    if type(MeffortSuiteCharDB)~="table" then MeffortSuiteCharDB={} end
    return MeffortSuiteCharDB
end
local function Public(value)
    if not issecretvalue or not issecretvalue(value) then return value end
end
local function Call(fn,...)
    if type(fn)~="function" then return false end
    local ok,result=pcall(fn,...)
    if not ok then return false end
    result=Public(result)
    return result~=false,result
end
local function Number(value)
    if type(value)~="string" and type(value)~="number" then return end
    local n=tonumber(value)
    if n and n==n and n>=0 and n<math.huge then return n end
end
local function Read(name)
    local _,value=Call(C_CVar and C_CVar.GetCVar or GetCVar,name)
    return Number(value)
end
local function Write(name,value)
    writingCVar=true
    Call(C_CVar and C_CVar.SetCVar or SetCVar,name,tostring(value))
    writingCVar=false
end
local function Locked()
    return type(InCombatLockdown)=="function" and InCombatLockdown()
end

local function RestoreValues(key,settings)
    local db=DB()
    local saved=db[key]
    if type(saved)~="table" then db[key]=nil;return true end
    local pending={}
    for name,applied in pairs(settings) do
        local entry=saved[name]
        if type(entry)=="table" and Number(entry.previous) and entry.applied==applied then
            local current=Read(name)
            if current==applied and not Locked() then
                Write(name,entry.previous)
                current=Read(name)
            end
            if current==nil or current==applied then pending[name]=entry end
        end
    end
    db[key]=next(pending) and pending or nil
    return db[key]==nil
end
local function RestoreOldCamera()
    local db=DB()
    local saved=db.fishingCameraRestore
    if type(saved)=="number" then saved={previous=saved,applied=50} end
    local previous=type(saved)=="table" and Number(saved.previous)
    if previous and previous>0 then
        local current=Read("cameraFov")
        if current==nil then return false end
        if current==saved.applied or current==saved.pending then
            if Locked() then return false end
            Write("cameraFov",previous)
            if Read("cameraFov")~=previous then return false end
        end
    end
    db.fishingCameraRestore=nil
    return true
end
local function SetCog(wanted)
    if iconActive and wanted then return true end
    iconActive=false
    if not RestoreValues("fishingInteractIconRestore",iconSettings) then
        iconStatus="restoration pending";return false
    end
    iconStatus="off"
    if not wanted then return true end
    iconActive=true
    local db=DB()
    local saved={}
    local unavailable=false
    for name,enabled in pairs(iconSettings) do
        local current=Read(name)
        if current==0 then
            saved[name]={previous=current,applied=enabled}
            db.fishingInteractIconRestore=saved
            Write(name,enabled)
            current=Read(name)
            if current~=nil and current~=enabled then saved[name]=nil end
        end
        if current~=enabled then unavailable=true end
    end
    db.fishingInteractIconRestore=next(saved) and saved or nil
    iconStatus=unavailable and "native setting unavailable" or "enabled during cast"
    return true
end

local function Zoom()
    local _,value=Call(GetCameraZoom)
    return Number(value)
end
local function StopMotion(direction)
    if direction then Call(_G["MoveView"..direction.."Stop"]) end
end
local function Drive(direction,previous,speed)
    if previous~=direction then StopMotion(previous) end
    if Call(_G["MoveView"..direction.."Start"],speed) then return direction end
    StopMotion(direction)
end
local function StopCamera()
    StopMotion(zoomMotion)
    StopMotion(pitchMotion)
    zoomMotion,pitchMotion=nil,nil
    pitchVelocity=0
    if move and move.nativeReturn then
        move.nativeReturn,move.zoomIssued=nil,nil
        -- Zero-speed holds cancel the client's pending zoom before a recast.
        Call(MoveViewOutStart,0)
        Call(MoveViewInStart,0)
        StopMotion("Out")
        StopMotion("In")
    end
end
local function DriveZoom(speed)
    if math.abs(speed)<.01 then
        StopMotion(zoomMotion)
        zoomMotion=nil
        return true
    end
    local rate=Read("cameraZoomSpeed") or 20
    zoomMotion=Drive(speed<0 and "In" or "Out",zoomMotion,math.min(6,math.abs(speed)/math.max(1,rate)))
    return zoomMotion~=nil
end
local function DrivePitch(speed)
    if math.abs(speed)<.08 then
        StopMotion(pitchMotion)
        pitchMotion=nil
        pitchVelocity=0
        return
    end
    local rate=Read("cameraPitchMoveSpeed") or 90
    pitchMotion=Drive(speed>0 and "Down" or "Up",pitchMotion,math.abs(speed)/math.max(1,rate))
    pitchVelocity=pitchMotion and speed or 0
    if not pitchMotion then view.manualPitch=true end
end
local function ZoomBy(amount)
    if math.abs(amount)<.04 then return end
    issuingZoom=true
    local ok=Call(amount>0 and CameraZoomOut or CameraZoomIn,math.abs(amount),true)
    issuingZoom=false
    return ok
end
local function ReleaseView()
    StopCamera()
    view,move=nil,nil
    lookTime=0
    tracker:SetScript("OnUpdate",nil)
end

function M.Enabled() return Char().fishingCameraZoom==true end
local function ClampDelay(value)
    local delay=tonumber(value)
    if not delay or delay~=delay or math.abs(delay)==math.huge then return end
    delay=math.max(0,math.min(maxDelay,delay))
    return math.floor(delay/delayStep+.5)*delayStep
end
function M.ZoomOutDelay()
    return ClampDelay(Char().fishingZoomOutDelay) or defaultDelay
end
function M.SetZoomOutDelay(value)
    local delay=ClampDelay(value)
    if delay then Char().fishingZoomOutDelay=delay end
end
function M.ZoomOutDelayLimits()
    return 0,maxDelay,delayStep
end
local function IdleStatus() return M.Enabled() and "waiting for a fishing cast" or "off" end
local function Active()
    return ready and inWorld and MeffortSuite.Active() and not Locked()
end
local function UpdateReturn(distance,dt,looking)
    if not move.zoomIssued then
        local delta=view.distance-distance
        local duration=math.abs(delta)/math.max(1,Read("cameraZoomSpeed") or 20)
        move.zoomIssued=true
        move.elapsed=0
        move.timeout=math.max(1.25,duration+.8)
        move.pitchSpeed=view.tilt/math.max(.35,math.min(duration,1.2))
        if not view.manualZoom and math.abs(delta)>zoomTolerance then
            move.nativeReturn=ZoomBy(delta)
            move.zoomFailed=not move.nativeReturn
        end
    end
    if math.abs(distance-view.distance)<=zoomTolerance then move.nativeReturn=nil end
    local pitchDone=view.manualPitch or view.tilt<=.01
    if pitchDone or looking then
        DrivePitch(0)
    else
        local speed=math.min(move.pitchSpeed,view.tilt/math.max(dt,1/60))
        if math.abs(speed+pitchVelocity)>.001 then DrivePitch(-speed) end
    end
    if (not move.nativeReturn and pitchDone) or move.elapsed>move.timeout then
        local finished=not move.nativeReturn and not move.zoomFailed
        ReleaseView()
        status=finished and IdleStatus() or "camera return stopped before the previous distance"
    end
end

local function UpdateCamera(_,dt)
    if Locked() then StopCamera();return end
    local distance=Zoom()
    if not distance then ReleaseView();status="camera distance unavailable";return end
    local _,looking=Call(IsMouselooking)
    looking=looking==true or looking==1
    lookTime=looking and lookTime+dt or 0
    if lookTime>.16 and not view.manualPitch then
        view.manualPitch=true
        DrivePitch(0)
    end
    view.tilt=math.max(0,math.min(tiltDegrees,view.tilt+pitchVelocity*dt))
    if not move then return end
    move.elapsed=move.elapsed+dt
    if move.phase=="hold" then
        if move.elapsed<M.ZoomOutDelay() then return end
        move={phase="out",elapsed=0}
        status="returning to your previous view"
        return
    end
    if dt<=0 then return end
    if move.phase=="out" then UpdateReturn(distance,dt,looking);return end
    local horizon=math.max(1/120,math.min(dt,.15))
    local t=math.min(1,(move.elapsed+horizon)/move.duration)
    local ease=t*t*(3-2*t)
    local zoomAhead=move.from*(1-ease)
    local zoomDone=view.manualZoom or distance<=.001
    if zoomDone then
        DriveZoom(0)
    elseif move.fallbackAt then
        zoomDone=move.elapsed-move.fallbackAt>.75
    elseif move.elapsed>move.duration+.55 or not DriveZoom(math.min(0,(zoomAhead-distance)/horizon)) then
        DriveZoom(0)
        move.fallbackAt=move.elapsed
        ZoomBy(-math.max(.05,distance))
    end
    local tiltAhead=move.tilt+(tiltDegrees-move.tilt)*ease
    local pitchDone=view.manualPitch or (t==1 and math.abs(tiltDegrees-view.tilt)<.003)
    if pitchDone then DrivePitch(0)
    elseif not looking then
        DrivePitch(math.max(-36,math.min(36,(tiltAhead-view.tilt)/horizon)))
    else DrivePitch(0) end
    if t==1 and zoomDone and (pitchDone or move.elapsed>move.duration+.55) then
        StopCamera()
        move=nil
        status=distance<=.001 and "first-person fishing view" or
            (view.manualZoom and "manual camera zoom" or "first-person zoom unconfirmed")
    end
end

local function StartView()
    if view and (not move or move.phase=="in") then return end
    local distance=Zoom()
    if not distance then status="camera distance unavailable";return end
    if not view then view={distance=distance,tilt=0} end
    StopCamera()
    move={phase="in",from=distance,tilt=view.tilt,elapsed=0,duration=math.min(.84,.46+distance*.014)}
    status="zooming into first person"
    tracker:SetScript("OnUpdate",UpdateCamera)
end
local function EndView(hold)
    if not view then status=IdleStatus();return end
    hold=hold and M.ZoomOutDelay()>0
    if move and (move.phase=="out" or (hold and move.phase=="hold")) then return end
    StopCamera()
    if hold then
        move={phase="hold",elapsed=0}
        status="holding view for a recast"
        return
    end
    move={phase="out",elapsed=0}
    status="returning to your previous view"
end
local function Reconcile()
    local active=Active()
    RestoreOldCamera()
    local oldIconsRestored=RestoreValues("fishingBobberTargetRestore",oldBobberSettings)
    SetCog(active and oldIconsRestored and lineOut and fishing.InteractEnabled())
    if active and lineOut and M.Enabled() then StartView()
    elseif inWorld and not Locked() then EndView(active and M.Enabled())
    else
        StopCamera()
        if not view then status=IdleStatus() end
    end
end
function M.Refresh()
    lineOut=ready and inWorld and fishing.IsFishingChannel()
    Reconcile()
end
function M.Restore()
    local distance=Zoom()
    if view and distance and not view.manualZoom then
        StopCamera()
        ZoomBy(view.distance-distance)
    end
    ReleaseView()
    status=IdleStatus()
    local cogRestored=SetCog(false)
    local cameraRestored=RestoreOldCamera()
    local legacyRestored=RestoreValues("fishingBobberTargetRestore",oldBobberSettings)
    return cameraRestored and cogRestored and legacyRestored
end
function M.SetEnabled(value)
    Char().fishingCameraZoom=value==true
    M.Refresh()
end
function M.Status() return status..". Interact cog: "..iconStatus end

local function ManualZoom()
    if view and not issuingZoom then
        view.manualZoom=true
        if move then move.nativeReturn=nil end
        DriveZoom(0)
    end
end
for _,event in ipairs({"PLAYER_LOGIN","PLAYER_ENTERING_WORLD","PLAYER_LEAVING_WORLD","PLAYER_LOGOUT",
    "PLAYER_REGEN_DISABLED","PLAYER_REGEN_ENABLED","CVAR_UPDATE"}) do
    tracker:RegisterEvent(event)
end
for _,event in ipairs({"UNIT_SPELLCAST_CHANNEL_START","UNIT_SPELLCAST_CHANNEL_STOP"}) do
    tracker:RegisterUnitEvent(event,"player")
end
tracker:SetScript("OnEvent",function(_,event,unit,guid,spellID)
    if event=="CVAR_UPDATE" then
        unit=Public(unit)
        if not writingCVar and type(unit)=="string" and unit:lower()=="softtargetinteract" then Reconcile() end
    elseif event=="UNIT_SPELLCAST_CHANNEL_START" then
        if unit=="player" and (fishing.IsFishingSpell(spellID) or fishing.IsFishingChannel()) then
            lineOut,castID=true,Public(guid)
            Reconcile()
        end
    elseif event=="UNIT_SPELLCAST_CHANNEL_STOP" then
        guid=Public(guid)
        if unit=="player" and (not castID or not guid or castID==guid) then
            lineOut,castID=false,nil
            Reconcile()
        end
    elseif event=="PLAYER_LOGIN" then
        ready=true
        if type(hooksecurefunc)=="function" then
            if type(CameraZoomIn)=="function" then pcall(hooksecurefunc,"CameraZoomIn",ManualZoom) end
            if type(CameraZoomOut)=="function" then pcall(hooksecurefunc,"CameraZoomOut",ManualZoom) end
        end
        M.Restore()
    elseif event=="PLAYER_LEAVING_WORLD" or event=="PLAYER_LOGOUT" then
        inWorld,lineOut,castID=false,false,nil
        M.Restore()
    else
        if event=="PLAYER_ENTERING_WORLD" then inWorld=true end
        M.Refresh()
    end
end)
