local module = {}
MeffortSuiteActionText = module

local buttonPrefixes = {
    "ActionButton", "MultiBarBottomLeftButton", "MultiBarBottomRightButton",
    "MultiBarLeftButton", "MultiBarRightButton",
    "MultiBar5Button", "MultiBar6Button", "MultiBar7Button",
    "PetActionButton", "StanceButton", "BonusActionButton",
}
local original = setmetatable({}, { __mode = "k" })
local nativeColors = setmetatable({}, { __mode = "k" })
local appliedColors = setmetatable({}, { __mode = "k" })
local hotkeyHooked,rangeHooked=false,false
local pending = false
local fontFallback = STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
local applying = false
local lastError
local defaultSize,defaultX,defaultY = 20,-15,-15

local function Clamp(v,lo,hi,fallback)
    v=tonumber(v)
    if not v or v~=v or v==math.huge or v==-math.huge then v=fallback or 0 end
    return math.max(lo,math.min(hi,v))
end
local function DB()
    if type(MeffortSuiteDB)~="table" then MeffortSuiteDB={} end
    local s=MeffortSuiteDB.actionText
    if type(s)~="table" then s={};MeffortSuiteDB.actionText=s end
    if type(s.enabled)~="boolean" then s.enabled=true end
    s.size=Clamp(s.size,8,24,defaultSize)
    s.x=math.floor(Clamp(s.x,-22,22,defaultX)+0.5)
    s.y=math.floor(Clamp(s.y,-22,22,defaultY)+0.5)
    if type(s.hex)~="string" or not s.hex:match("^%x%x%x%x%x%x$") then s.hex="fff0c2" end
    if type(s.outline)~="boolean" then s.outline=true end
    if type(s.shadow)~="boolean" then s.shadow=true end
    return s
end
module.GetSettings=DB
local function InCombat()
    return InCombatLockdown and InCombatLockdown() or false
end
local function MasterActive()
    return not MeffortSuiteIsActive or MeffortSuiteIsActive()
end
local function FromHex(raw)
    if type(raw)~="string" then return end
    local hex=raw:gsub("#",""):gsub("%s+","")
    if not hex:match("^%x%x%x%x%x%x$") then return end
    hex=hex:lower()
    return hex,tonumber(hex:sub(1,2),16)/255,tonumber(hex:sub(3,4),16)/255,tonumber(hex:sub(5,6),16)/255
end
local function Restricted(value)
    if type(issecretvalue)~="function" then return false end
    local ok,result=pcall(issecretvalue,value)
    return not ok or result==true
end
local function Color(fn,object)
    if type(fn)~="function" then return end
    local ok,r,g,b,a=pcall(fn,object)
    if not ok then return end
    local values={r,g,b}
    for i=1,3 do
        local value=values[i]
        if Restricted(value) then return end
        if type(value)~="number" or value~=value or value==math.huge or value==-math.huge then return end
    end
    if Restricted(a) then return end
    if a==nil then a=1
    elseif type(a)~="number" or a~=a or a==math.huge or a==-math.huge then return end
    return {r=r,g=g,b=b,a=a}
end
local function ReadColor(hotkey)return Color(hotkey.GetTextColor,hotkey)end
local function SameColor(a,b)
    return a and b and math.abs(a.r-b.r)<.01 and math.abs(a.g-b.g)<.01
        and math.abs(a.b-b.b)<.01 and math.abs(a.a-b.a)<.01
end
local function Red(color)
    return color and color.r>=.55 and color.g<color.r*.68 and color.b<color.r*.68
end
local function WarningColor(hotkey,current)
    if not current then return true end
    local native=nativeColors[hotkey]
    if Red(native) and (SameColor(current,native) or SameColor(current,appliedColors[hotkey])) then return true,native end
    if Red(current) and not SameColor(current,appliedColors[hotkey]) then return true,current end
    return false
end
local function DefaultColor()
    local native=ACTIONBAR_HOTKEY_FONT_COLOR
    return native and Color(native.GetRGB,native) or {r=.6,g=.6,b=.6,a=1}
end
local function ApplyColor(hotkey)
    local preserve,color=WarningColor(hotkey,ReadColor(hotkey))
    if preserve then
        if color then hotkey:SetTextColor(color.r,color.g,color.b,color.a) end
        return
    end
    local _,r,g,b=FromHex(DB().hex)
    hotkey:SetTextColor(r,g,b,1)
    appliedColors[hotkey]=ReadColor(hotkey)
end
local function Capture(hotkey)
    if original[hotkey] then return end
    local src={ points={} }
    if hotkey.GetNumPoints and hotkey.GetPoint then
        local n=hotkey:GetNumPoints() or 0
        for i=1,math.min(n,4) do
            local point,relative,relativePoint,x,y=hotkey:GetPoint(i)
            if point then src.points[#src.points+1]={point,relative,relativePoint,x,y} end
        end
    end
    if hotkey.GetFont then src.font,src.size,src.flags=hotkey:GetFont() end
    local color=ReadColor(hotkey)
    if Red(color) then color=DefaultColor() end
    if color then src.r,src.g,src.b,src.a=color.r,color.g,color.b,color.a end
    if hotkey.GetShadowColor then src.sr,src.sg,src.sb,src.sa=hotkey:GetShadowColor() end
    if hotkey.GetShadowOffset then src.sx,src.sy=hotkey:GetShadowOffset() end
    if hotkey.GetJustifyH then src.justify=hotkey:GetJustifyH() end
    original[hotkey]=src
end
local function Restore(hotkey)
    local src=original[hotkey]
    if not src then return end
    local preserve,warning=WarningColor(hotkey,ReadColor(hotkey))
    if hotkey.SetFont and src.font then hotkey:SetFont(src.font,src.size or 12,src.flags or "") end
    if hotkey.ClearAllPoints then
        hotkey:ClearAllPoints()
        for _,point in ipairs(src.points) do
            hotkey:SetPoint(point[1],point[2],point[3],point[4],point[5])
        end
    end
    if hotkey.SetTextColor then
        if preserve then
            if warning then hotkey:SetTextColor(warning.r,warning.g,warning.b,warning.a) end
        else
            local color=nativeColors[hotkey]
            if color and not Red(color) then hotkey:SetTextColor(color.r,color.g,color.b,color.a)
            elseif src.r then hotkey:SetTextColor(src.r,src.g,src.b,src.a or 1) end
        end
    end
    if src.sr and hotkey.SetShadowColor then hotkey:SetShadowColor(src.sr,src.sg,src.sb,src.sa or 1) end
    if src.sx and hotkey.SetShadowOffset then hotkey:SetShadowOffset(src.sx,src.sy) end
    if src.justify and hotkey.SetJustifyH then hotkey:SetJustifyH(src.justify) end
    original[hotkey]=nil
    appliedColors[hotkey]=nil
end
local function Hotkey(button)
    if not button then return end
    if button.HotKey then return button.HotKey end
    local name=button.GetName and button:GetName()
    return name and _G[name.."HotKey"]
end
local function StyleButton(button)
    if not button then return end
    local hotkey=Hotkey(button)
    if not hotkey or not hotkey.SetFont or not hotkey.SetPoint then return end
    if InCombat() then pending=true;return end
    local current=ReadColor(hotkey)
    if not current then pending=true;return end
    local preserve,warning=WarningColor(hotkey,current)
    local s=DB()
    if not s.enabled or not MasterActive() then Restore(hotkey);return end
    Capture(hotkey)
    local src=original[hotkey]
    local font=src.font or fontFallback
    local flags=s.outline and "OUTLINE" or ""
    hotkey:SetFont(font,s.size,flags)
    hotkey:ClearAllPoints()
    hotkey:SetPoint("CENTER",button,"CENTER",s.x,s.y)
    if hotkey.SetJustifyH then hotkey:SetJustifyH("CENTER") end
    if hotkey.SetTextColor then
        if preserve then hotkey:SetTextColor(warning.r,warning.g,warning.b,warning.a)
        else ApplyColor(hotkey) end
    end
    if hotkey.SetShadowColor then
        if s.shadow then hotkey:SetShadowColor(0,0,0,0.96) else hotkey:SetShadowColor(0,0,0,0) end
    end
    if hotkey.SetShadowOffset then hotkey:SetShadowOffset(s.shadow and 1 or 0,s.shadow and -1 or 0) end
end
function module.ApplyAll()
    if InCombat() then pending=true;return false end
    if applying then return false end
    applying=true
    local succeeded=true
    lastError=nil
    for _,prefix in ipairs(buttonPrefixes) do
        for i=1,12 do
            local button=_G[prefix..i]
            if button then
                local ok,err=pcall(StyleButton,button)
                if not ok then
                    succeeded=false
                    pending=true
                    lastError=tostring(err)
                end
            end
        end
    end
    applying=false
    return succeeded
end
function module.LastError() return lastError end
function module.SetEnabled(value)
    DB().enabled=(value==true)
    module.ApplyAll()
end

function module.ResetAppearance()
    local settings=DB()
    settings.x,settings.y,settings.size=defaultX,defaultY,defaultSize
    settings.hex,settings.outline,settings.shadow="fff0c2",true,true
    module.ApplyAll()
end
function module.OpenPanel()
    if type(MeffortSuiteOpenSettings)=="function" then MeffortSuiteOpenSettings("action") end
end
module.TogglePanel=module.OpenPanel

local events=CreateFrame("Frame")
events:RegisterEvent("ADDON_LOADED")
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("PLAYER_ENTERING_WORLD")
events:RegisterEvent("PLAYER_REGEN_ENABLED")
events:RegisterEvent("UPDATE_BINDINGS")
events:RegisterEvent("ACTIONBAR_PAGE_CHANGED")
events:RegisterEvent("UPDATE_SHAPESHIFT_FORM")
events:RegisterEvent("PET_BAR_UPDATE")
local function InstallHooks()
    if type(hooksecurefunc)~="function" then return end
    if InCombat() then pending=true;return end
    if not hotkeyHooked and type(ActionButton_UpdateHotkeys)=="function" then
        local ok,result=pcall(hooksecurefunc,"ActionButton_UpdateHotkeys",function(button)
            if button and not InCombat() then pcall(StyleButton,button)
            elseif InCombat() then pending=true end
        end)
        hotkeyHooked=ok and result~=false
    end
    if not rangeHooked and type(ActionButton_UpdateRangeIndicator)=="function" then
        local ok,result=pcall(hooksecurefunc,"ActionButton_UpdateRangeIndicator",function(button)
            local hotkey=Hotkey(button)
            if not hotkey then return end
            local color=ReadColor(hotkey)
            nativeColors[hotkey]=color
            if color then appliedColors[hotkey]=nil end
            if InCombat() or not original[hotkey] or not DB().enabled or not MasterActive() then return end
            -- Native range red takes precedence over the configured text color.
            if color and not Red(color) then pcall(ApplyColor,hotkey) end
        end)
        rangeHooked=ok and result~=false
    end
end
events:SetScript("OnEvent",function(_,event)
    InstallHooks()
    if event=="ADDON_LOADED" then return end
    if event=="PLAYER_LOGIN" then DB() end
    if event=="PLAYER_REGEN_ENABLED" and pending then pending=false end
    module.ApplyAll()
end)
