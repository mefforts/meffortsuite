MeffortSuiteMageScrolls={}
local M=MeffortSuiteMageScrolls
local tracker=CreateFrame("Frame")
local spellID=1296017
local untranslated={
    [211780]=true,[211784]=true,[211785]=true,[211786]=true,[211787]=true,
    [211853]=true,[211854]=true,[211855]=true,[213543]=true,[213544]=true,
    [213545]=true,[213546]=true,[213547]=true,[281015]=true,[281016]=true,
    [281017]=true,[281018]=true,
}
local transferPanels={"MerchantFrame","BankFrame","GuildBankFrame","TradeFrame",
    "MailFrame","SendMailFrame","AuctionHouseFrame","AuctionFrame","ItemSocketingFrame"}
local overlay,hovered,armed
local clicking=false
local watchElapsed=0
local UpdateTarget
local setupAttempted=false
local status="off"
local lastItem="no bag item seen"
local routedClicks=0
local strataAbove={BACKGROUND="LOW",LOW="MEDIUM",MEDIUM="HIGH",HIGH="DIALOG"}

local function Public(value)
    return not issecretvalue or not issecretvalue(value)
end
local function Number(value)
    if Public(value) and type(value)=="number" and value==value
        and value~=math.huge and value~=-math.huge then return value end
end
local function Locked()
    return type(InCombatLockdown)=="function" and InCombatLockdown()
end
function M.IsMage()
    if type(UnitClass)~="function" then return false end
    local _,class=UnitClass("player")
    return Public(class) and class=="MAGE"
end
function M.Enabled()
    return M.IsMage() and type(MeffortSuiteCharDB)=="table" and MeffortSuiteCharDB.mageScrollRightClick==true
end
local function ContainerSlot(widget)
    local nativeGetBagID=ContainerFrameItemButtonMixin and ContainerFrameItemButtonMixin.GetBagID
    for _=1,4 do
        if not Public(widget) or (type(widget)~="table" and type(widget)~="userdata") then return end
        if widget==hovered or (nativeGetBagID and widget.GetBagID==nativeGetBagID
            and type(widget.GetID)=="function") then return widget end
        if type(widget.GetParent)~="function" then return end
        widget=widget:GetParent()
    end
end
local function HoveredSlot()
    if type(GetMouseFoci)=="function" then
        local ok,foci=pcall(GetMouseFoci)
        if ok and Public(foci) and type(foci)=="table" then
            for _,widget in ipairs(foci) do
                if not Public(widget) then return end
                if widget~=overlay then return ContainerSlot(widget) end
            end
        end
    elseif type(GetMouseFocus)=="function" then
        local ok,widget=pcall(GetMouseFocus)
        if ok and Public(widget) and widget and widget~=overlay then return ContainerSlot(widget) end
    end
    return hovered or (armed and armed.button)
end
local function UsingBagItem()
    if type(IsModifierKeyDown)=="function" and IsModifierKeyDown() then return true end
    if type(SpellIsTargeting)=="function" and SpellIsTargeting() then return true end
    if type(SpellCanTargetItem)=="function" and SpellCanTargetItem() then return true end
    if type(SpellCanTargetItemID)=="function" and SpellCanTargetItemID() then return true end
    if type(GetCursorInfo)=="function" then
        local cursor=GetCursorInfo()
        if not Public(cursor) or cursor~=nil then return true end
    end
    for _,name in ipairs(transferPanels) do
        local panel=_G[name]
        if panel and panel.IsShown and panel:IsShown() then return true end
    end
    return false
end
local function ScrollAt(button)
    if not button or not button:IsVisible() or not button:IsMouseOver() or UsingBagItem() then return end
    local alpha=button.GetEffectiveAlpha and Number(button:GetEffectiveAlpha())
    if alpha and alpha<=0 then return end
    local bag,slot=Number(button:GetBagID()),Number(button:GetID())
    if not bag or bag<0 or bag>4 or not slot or slot<1 then return end
    local info=C_Container.GetContainerItemInfo(bag,slot)
    if not Public(info) or type(info)~="table" then return end
    local id=Number(info.itemID)
    if not id then return end
    lastItem=string.format("item %d (bag %d, slot %d)",id,bag,slot)
    if not untranslated[id] then lastItem=lastItem.." is not an untranslated scroll";return end
    if not Public(info.isLocked) or info.isLocked
        or not Public(info.isFiltered) or info.isFiltered then lastItem=lastItem.." is locked or filtered";return end
    lastItem=lastItem.." matched"
    return bag,slot,id
end
local function Disarm()
    if clicking or not armed then return end
    armed=nil
    overlay:Hide()
    overlay:SetAttribute("type2",nil)
    overlay:SetAttribute("target-bag",nil)
    overlay:SetAttribute("target-slot",nil)
end

local function WatchTarget(_,elapsed)
    watchElapsed=watchElapsed+elapsed
    if watchElapsed>=.05 then
        watchElapsed=0
        UpdateTarget()
    end
end
UpdateTarget=function(preferred)
    if clicking or Locked() then return end
    if not M.Enabled() or not MeffortSuite.Active() then Disarm();return end
    local button=preferred or HoveredSlot()
    local bag,slot,id=ScrollAt(button)
    if not bag then Disarm();return end
    local x,y,w,h=button:GetRect()
    x,y,w,h=Number(x),Number(y),Number(w),Number(h)
    local scale,rootScale=Number(button:GetEffectiveScale()),Number(UIParent:GetEffectiveScale())
    if not x or not y or not w or w<=0 or not h or h<=0
        or not scale or scale<=0 or not rootScale or rootScale<=0 then Disarm();return end
    local ratio=scale/rootScale
    x,y,w,h=x*ratio,y*ratio,w*ratio,h*ratio
    local strata,level=button:GetFrameStrata(),button:GetFrameLevel()
    if armed and armed.button==button and armed.bag==bag and armed.slot==slot and armed.id==id
        and armed.x==x and armed.y==y and armed.w==w and armed.h==h
        and armed.strata==strata and armed.level==level then return end
    armed={button=button,bag=bag,slot=slot,id=id,x=x,y=y,w=w,h=h,strata=strata,level=level}
    -- Keep protected anchors on UIParent so bag buttons can move and recycle in combat.
    overlay:ClearAllPoints()
    overlay:SetPoint("BOTTOMLEFT",UIParent,"BOTTOMLEFT",x,y)
    overlay:SetSize(w,h)
    overlay:SetFrameStrata(strataAbove[strata] or strata)
    overlay:SetFrameLevel(level+1)
    overlay:SetAttribute("target-bag",bag)
    overlay:SetAttribute("target-slot",slot)
    overlay:SetAttribute("type2","spell")
    overlay:Show()
end

local function Initialize()
    if setupAttempted then return end
    setupAttempted=true
    if not (C_Container and type(C_Container.GetContainerItemInfo)=="function" and
        type(RegisterStateDriver)=="function" and UIParent) then
        status="native bag controls unavailable"
        return
    end
    local root,button
    local ok=pcall(function()
        root=CreateFrame("Frame",nil,UIParent,"SecureHandlerStateTemplate")
        button=CreateFrame("Button",nil,root,"SecureActionButtonTemplate")
        button:Hide()
        button:EnableMouse(true)
        button:SetMouseMotionEnabled(false)
        button:SetPassThroughButtons("LeftButton","MiddleButton","Button4","Button5")
        button:RegisterForClicks("RightButtonDown","RightButtonUp")
        button:SetAttribute("useOnKeyDown",false)
        button:SetAttribute("spell",spellID)
        button:SetScript("PreClick",function(_,mouse,down)
            if mouse~="RightButton" or down or Locked() then return end
            local bag,slot,id=ScrollAt(HoveredSlot())
            if not armed or not M.Enabled() or not MeffortSuite.Active()
                or bag~=armed.bag or slot~=armed.slot or id~=armed.id then
                Disarm()
            else
                clicking=true
            end
        end)
        button:SetScript("PostClick",function(_,_,down)
            if down then return end
            -- Cursor changes during the cast must preserve the target until WoW applies it.
            if clicking then routedClicks=routedClicks+1 end
            clicking=false
            UpdateTarget()
        end)
        if RegisterStateDriver(root,"visibility","[combat][mod] hide; show")==false then
            error("secure bag visibility unavailable")
        end
    end)
    if not ok then status="secure bag controls unavailable";return end
    overlay=button
    if not EventRegistry or type(EventRegistry.RegisterCallback)~="function" then return end
    pcall(EventRegistry.RegisterCallback,EventRegistry,"ContainerFrameItemButton.EnterButton",function(_,item)
        hovered=item
        UpdateTarget(item)
    end,tracker)
    pcall(EventRegistry.RegisterCallback,EventRegistry,"ContainerFrameItemButton.ExitButton",function(_,item)
        if hovered==item then
            hovered=nil
            if not Locked() then Disarm() end
        end
    end,tracker)
    pcall(EventRegistry.RegisterCallback,EventRegistry,"ContainerFrame.CloseBag",function()
        if hovered and not hovered:IsVisible() then hovered=nil end
        UpdateTarget()
    end,tracker)
end
function M.Refresh()
    if not M.IsMage() then return end
    if Locked() then tracker:SetScript("OnUpdate",nil);return end
    local active=M.Enabled() and MeffortSuite.Active()
    if active then Initialize() end
    tracker:SetScript("OnUpdate",active and overlay and WatchTarget or nil)
    if overlay then UpdateTarget() end
end
function M.SetEnabled(value)
    if not M.IsMage() then return end
    if type(MeffortSuiteCharDB)~="table" then MeffortSuiteCharDB={} end
    MeffortSuiteCharDB.mageScrollRightClick=value==true
    M.Refresh()
end
function M.Status()
    if not M.Enabled() then return "off" end
    if not MeffortSuite.Active() then return "suite off" end
    if Locked() then return "paused during combat" end
    if not overlay then return status end
    return string.format("ready; %s; clicks routed %d",lastItem,routedClicks)
end

tracker:RegisterEvent("PLAYER_LOGIN")
tracker:SetScript("OnEvent",function(_,event)
    if event=="PLAYER_LOGIN" then
        tracker:UnregisterEvent(event)
        if not M.IsMage() then return end
        for _,name in ipairs({"PLAYER_REGEN_ENABLED","PLAYER_REGEN_DISABLED","MODIFIER_STATE_CHANGED","BAG_UPDATE_DELAYED",
            "CURSOR_CHANGED","CURRENT_SPELL_CAST_CHANGED","ITEM_LOCK_CHANGED","MERCHANT_SHOW","MERCHANT_CLOSED",
            "BANKFRAME_OPENED","BANKFRAME_CLOSED","TRADE_SHOW","TRADE_CLOSED","MAIL_SHOW","MAIL_CLOSED",
            "AUCTION_HOUSE_SHOW","AUCTION_HOUSE_CLOSED","PLAYER_LEAVING_WORLD"}) do
            pcall(tracker.RegisterEvent,tracker,name)
        end
    elseif event=="PLAYER_LEAVING_WORLD" then
        hovered=nil
    end
    M.Refresh()
end)
