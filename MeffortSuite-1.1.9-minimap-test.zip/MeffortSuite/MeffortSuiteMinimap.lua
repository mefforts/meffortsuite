MeffortSuiteMinimap={}
local M=MeffortSuiteMinimap
local watcher=CreateFrame("Frame")
local collected,ownRows={},{}
local addonTitles={}
local ready,elapsed=false,0
local nativeNames={
    AddonCompartmentFrame=true,GameTimeFrame=true,TimeManagerClockButton=true,
    ExpansionLandingPageMinimapButton=true,QueueStatusMinimapButton=true,
    MinimapZoomIn=true,MinimapZoomOut=true,MinimapZoneTextButton=true,
    MiniMapTracking=true,MiniMapTrackingButton=true,MiniMapWorldMapButton=true,
    MiniMapMailFrame=true,MiniMapBattlefieldFrame=true,MiniMapLFGFrame=true,
}

local function Plain(text)
    if type(text)~="string" then return end
    return text:gsub("|c%x%x%x%x%x%x%x%x",""):gsub("|r",""):match("^%s*(.-)%s*$")
end
local function Key(text)
    local name=Plain(text)
    return name and name:lower():gsub("[%s_%-]","")
end
local function ReadAddonTitles()
    if not C_AddOns or not C_AddOns.GetNumAddOns or not C_AddOns.GetAddOnInfo then return end
    for index=1,C_AddOns.GetNumAddOns() do
        local name,title=C_AddOns.GetAddOnInfo(index)
        if name and not name:find("^Blizzard_") then
            local label=Plain(title)
            if not label or label=="" then label=name end
            addonTitles[Key(name)]=label
            addonTitles[Key(label)]=label
        end
    end
end
local function Identify(button,name)
    local broker=name and name:match("^LibDBIcon10_(.+)$")
    local stem=name and name:gsub("[_-]?[Mm]ini[Mm]ap[_-]?[Bb]utton.*$","")
        :gsub("[_-]?[Mm]ini[Mm]ap[_-]?[Ii]con.*$",""):gsub("[_-]?[Bb]utton$","")
    local title=broker and (addonTitles[Key(broker)] or Plain(broker)) or addonTitles[Key(stem)]
    local data=broker and button.dataObject
    local icon=type(data)=="table" and data.icon
    if type(icon)~="string" and type(icon)~="number" then icon=nil end
    if title and icon then return title,icon end
    local normal=button:GetNormalTexture()
    for _,region in ipairs({button:GetRegions()}) do
        if region.GetTexture and not region:IsForbidden() then
            local texture=region:GetTexture()
            local path=region.GetTextureFilePath and region:GetTextureFilePath()
            local owner=type(path)=="string" and path:lower():gsub("/","\\"):match("^interface\\addons\\([^\\]+)\\")
            if owner and addonTitles[Key(owner)] then
                return title or addonTitles[Key(owner)],texture
            end
            if not icon and (region==normal or region:GetDrawLayer()=="ARTWORK") then icon=texture end
        end
    end
    return title,icon or (normal and normal:GetTexture())
end
local function IsClickable(button)
    return not button:IsForbidden() and not button:IsProtected()
        and button:IsObjectType("Button") and button:GetScript("OnClick")~=nil
end
local function Candidate(button)
    if not IsClickable(button) or not button:IsShown() or not button:IsVisible() then return end
    local name=button:GetName()
    if nativeNames[name] or button==Minimap.ZoomIn or button==Minimap.ZoomOut
        or (MinimapCluster and (button==MinimapCluster.ZoneTextButton
            or MinimapCluster.Tracking and button==MinimapCluster.Tracking.Button))
        or (MinimapBackdrop and button==MinimapBackdrop.ExternalEventURLButton) then return end
    local current=collected[button]
    if not current and (not button:IsMouseClickEnabled()
        or (button:GetEffectiveAlpha()<=0 and not button.showOnMouseover)) then return end
    if current then return current.title,current.icon end
    return Identify(button,name)
end

local function RemoveRow(entries,state)
    local row=state.row
    if not row then return false end
    ownRows[row]=nil
    state.row=nil
    for i,entry in ipairs(entries) do
        if entry==row then table.remove(entries,i);return true end
    end
    return false
end
-- Leave the addon's shown state, anchors and settings in its own hands.
local function Restore(button,state)
    if button:IsForbidden() then return end
    if button:GetAlpha()==0 then button:SetAlpha(state.alpha) end
    if not button:IsMouseClickEnabled() then button:SetMouseClickEnabled(state.clicks) end
    if not button:IsMouseMotionEnabled() then button:SetMouseMotionEnabled(state.motion) end
end
local function Suppress(button,state)
    local alpha=button:GetAlpha()
    if alpha~=0 then state.alpha=alpha;button:SetAlpha(0) end
    if button:IsMouseClickEnabled() then button:SetMouseClickEnabled(false) end
    if button:IsMouseMotionEnabled() then button:SetMouseMotionEnabled(false) end
end
local function Collect(button,title,icon,compartment,existing)
    local state=collected[button]
    if not state then
        state={title=title,icon=icon,alpha=button:GetAlpha(),clicks=button:IsMouseClickEnabled(),
            motion=button:IsMouseMotionEnabled()}
        collected[button]=state
    end
    local changed=false
    if existing[Key(title)] or existing[button.compartmentData] then
        changed=RemoveRow(compartment.registeredAddons,state)
    elseif not state.row then
        local row={text=title,icon=icon}
        row.func=function(_,input)
            if collected[button]~=state or not button:IsVisible() or not IsClickable(button) then return end
            local mouse=type(input)=="table" and input.buttonName or input
            button:Click(type(mouse)=="string" and mouse or "LeftButton")
        end
        state.row=row
        ownRows[row]=true
        compartment:RegisterAddon(row)
    end
    Suppress(button,state)
    return changed
end
local function FindButtons(parent,depth,seen,found)
    if not parent or seen[parent] or parent:IsForbidden() then return end
    seen[parent]=true
    for _,child in ipairs({parent:GetChildren()}) do
        local title,icon=Candidate(child)
        if title and title~="" then
            found[child]={title=title,icon=icon}
        elseif depth>0 and not child:IsForbidden() and not child:IsObjectType("Button") then
            FindButtons(child,depth-1,seen,found)
        end
    end
end

function M.Enabled()
    return type(MeffortSuiteDB)=="table" and MeffortSuiteDB.collapseMinimapButtons==true
end
function M.SetEnabled(enabled)
    if type(MeffortSuiteDB)~="table" then MeffortSuiteDB={} end
    MeffortSuiteDB.collapseMinimapButtons=enabled==true
    M.Refresh()
end
function MeffortSuiteOpenFromMinimap()
    MeffortSuiteOpenSettings()
end

local function Reconcile(active)
    local compartment=AddonCompartmentFrame
    local entries=compartment and compartment.registeredAddons
    local changed=false
    local found={}
    if active and type(entries)=="table" and compartment:IsVisible() and compartment:IsEnabled() then
        local existing={}
        for _,entry in ipairs(entries) do
            local key=Key(entry.text)
            if key and not ownRows[entry] and type(entry.func)=="function" then
                existing[key]=true
                existing[entry]=true
            end
        end
        local seen={}
        FindButtons(Minimap,1,seen,found)
        FindButtons(MinimapBackdrop,1,seen,found)
        FindButtons(MinimapCluster,2,seen,found)
        for button,candidate in pairs(found) do
            if Collect(button,candidate.title,candidate.icon,compartment,existing) then changed=true end
        end
    end
    for button,state in pairs(collected) do
        if not found[button] then
            if type(entries)=="table" and RemoveRow(entries,state) then changed=true end
            Restore(button,state)
            collected[button]=nil
        end
    end
    if changed then compartment:UpdateDisplay() end
end
local function Watch(_,dt)
    elapsed=elapsed+dt
    if elapsed<.5 then return end
    elapsed=0
    M.Refresh()
end
function M.Refresh()
    if not ready then return end
    if InCombatLockdown() then watcher:SetScript("OnUpdate",nil);return end
    local active=M.Enabled() and MeffortSuite.Active() and Minimap and AddonCompartmentFrame
    watcher:SetScript("OnUpdate",active and Watch or nil)
    Reconcile(active)
end

watcher:RegisterEvent("PLAYER_LOGIN")
watcher:RegisterEvent("PLAYER_ENTERING_WORLD")
watcher:RegisterEvent("PLAYER_REGEN_ENABLED")
watcher:RegisterEvent("PLAYER_REGEN_DISABLED")
watcher:SetScript("OnEvent",function(_,event)
    if event=="PLAYER_LOGIN" then
        ReadAddonTitles()
        ready=true
    end
    M.Refresh()
end)
