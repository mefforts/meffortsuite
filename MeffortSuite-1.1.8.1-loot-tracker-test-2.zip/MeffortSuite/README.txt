MeffortSuite 1.1.8.1
World of Warcraft: Forever 1.60.1 | Interface 16001

GET STARTED
Install the Forever file with CurseForge, or extract the MeffortSuite folder
into the Forever client's Interface/AddOns folder. Replace the existing
MeffortSuite folder when updating. Keep the folder name MeffortSuite and leave
your SavedVariables in place. Reload the UI if the game is already open.

Type /msuite, choose MeffortSuite from its minimap menu, or open Options >
AddOns > MeffortSuite. Choose a category to see its settings. A category
lights up and shows ON when it has an enabled feature. The Suite switch
turns the addon on or off and saves your individual feature preferences.
Use Back to return to your last page,
Home to return to the launcher, and ? for setup and troubleshooting.

Toggles and choices save immediately. Save text changes with Enter or the
button beside the field. Esc discards that field's unsaved edit. Text drafts
stay available when you switch pages. The scope at the top of each page shows
which settings apply to the whole account and which apply to this character.
Changes to protected controls may wait until combat ends.

FIND A SETTING
Bags       Bag sorting, backpack count, junk sales, repairs and bank lists.
Loot       Fast auto loot, floating totals and Mage scroll shortcuts.
Quests     Space and number keys for quests and eligible confirmations.
Combat     Wand and ranged controls, range warnings, and Arcane Blast.
Map        Addon minimap buttons, waypoint arrow and flight-master dialogue.
Tooltips   Spell header highlighting, badge colors and rank hints.
Bars       Mana costs and custom keybind labels.
Fishing    Double right-click fishing, zoom and quiet fishing audio.
Sounds     Pet sounds, advanced sound-file muting and quiet fishing audio.
About      Login message, diagnostic reports and Restore Defaults.

LOOT, BAGS AND BANKING
Turn on Track loot in Loot to start a session. Items shows what you picked
up, with identical items grouped by quantity. Values shows vendor and
Auctionator totals, including coins looted. When Auctionator is available,
its estimate uses vendor prices for items without an auction estimate.
Drag the lower-right corner to resize the tracker. Compact keeps the
totals visible in a shorter window. The layout is saved. Use the close
button to hide the tracker while it keeps recording. Stop keeps the
results for review. Starting again or reloading clears the session.

Mages can turn on Right-click to comprehend scrolls in Loot. Learn
Comprehend Scroll, then right-click an untranslated scroll in your
standard bags outside combat. This option is off by default. Run
/msuite scrolls on a Mage for the last item seen and the click count.

Fast auto loot is on by default and follows the game's Auto Loot option and
modifier key. Manual looting, full bags, combat and confirmations use the
game's usual controls. Existing saved OFF choices carry forward.

Floating loot value is on by default. The total combines received coins and
the vendor value of all received item qualities. It combines area loot into
one total. Fishing and items opened from inventory are excluded. Turn off
Include all item qualities for grey items only. Float duration starts at six
seconds and can be set from 2 to 12 seconds. Preview loot value shows the
current display style. The float uses an available corpse nameplate or the
loot-click position. Changes apply to new loot windows and previews.

Use Auctionator AH values to replace vendor prices with Auctionator's cached
item estimates. Show vendor + AH together puts both totals on the same float.
Each total includes actual coins received. Missing prices and items that
cannot be auctioned use vendor values. You can use all other loot features
without Auctionator.

Backpack free-slot count uses the native count on the default backpack icon.
Turning it off restores the count setting you had before the addon changed it.
Custom bag bars may have their own count control. Automatic merchant actions
sell junk and use personal gold for repairs. Use Retry merchant actions while
the merchant remains open if an action is pending or failed.

Auto-bank items deposits crafting reagents in your personal bank. Add more
items with Also deposit, or exclude items with Keep in bags. Enter comma-
separated exact names or numeric item IDs. IDs work across languages. Keep in
bags takes priority. Both lists are saved per character. Save with Enter or
Save list. To apply changed lists, use Deposit items now or reopen the bank.
Unidentified items stay in bags until their names and stack information load.

QUESTS AND TRAVEL
Supported addon buttons are grouped under the round MeffortSuite icon by
default. Click it or type /msuite addons to open the menu. Choose
MeffortSuite in the menu to open settings. Entries support the original
left- and right-click actions. Left-drag the icon around the minimap rim
to set its saved position. Turn off Collapse addon minimap buttons in
Map to restore the individual buttons.

In quest dialogue, Space accepts, continues or completes the current quest.
In a menu, it prefers an available quest, a quest ready to turn in, then an
unfinished quest. Without quests it selects the first choice. Number keys 1
through 9 follow the menu order. An asterisk marks the Space choice. A menu
row can still have a keyboard shortcut when there is too little room to show
its label.

With Space accepts confirmations enabled in Quests, Space chooses the
affirmative button on eligible game prompts such as Yes/No or Accept/Cancel. It
requires Quest dialogue hotkeys. Prompts with text entry, payment, or extra
choices use their usual controls. The shortcut pauses during combat.

Skip flight master dialogue under Map opens the flight map so you can
choose a route. Hold Shift to see the regular dialogue.

Suite waypoint arrow is off by default. Enable it under Map to follow native
map pins. Use /way 49.4 12.9 to place a pin on the open map or your current
zone. Add a zone name before the coordinates to
choose another area. If the name is ambiguous, use /way #mapID x y. Coordinates
are percentages from 0 to 100. If another addon owns /way, use /msuite way.

COMBAT AND FISHING
The Combat tile shows your equipped wand or ranged weapon if your class
supports ranged controls. It uses your main hand when the ranged slot is
empty or your class has no ranged controls. A sword icon is the fallback
when neither slot provides an icon. The tile updates after gear changes.

Choose Shift + right-click for a ranged attack to keep ordinary right-click
for native melee. Warrior and Rogue macros select the attack for the equipped
bow, gun, crossbow, or thrown weapon. Hunter Auto Shot repeats as usual.
An equipped fishing pole gives fishing priority. An active standalone
MeffortWand takes priority for wand input.

The range dot appears only when the client confirms the target is beyond
the chosen distance. Turn on Out-of-range dot before unlocking its position
to drag it. Lock dot position controls placement. Use automatic range
detection unless you need an exact spell for Advanced spell detection.
To use the Mage tracker, first add Arcane Blast to Blizzard's Tracked Buffs.
Then choose stacks, time, and the timer wheel under Combat.

Equip a fishing pole and double right-click the world to cast. Turn on Enable
Interact Key in WoW's Options. The game shows its cog over the active bobber
when it is in Interact focus. Double right-click again when it splashes. One
right-click still works for normal camera turning.

Enable Zoom fishing view for a quick, smooth move into first person with a
slight downward tilt. Aim at the bobber as needed. The camera waits 2.75
seconds after a cast, then returns in one native zoom at WoW's camera speed.
Set Zoom-out delay in Fishing to change the wait from 0 to 10 seconds. A
quick recast interrupts the return. Quiet fishing audio can mute music,
ambience, and dialogue while a pole is equipped. The bite and other sound
effects keep their current volume.

TOOLTIPS, BARS AND SOUNDS
Enable Highlight headers & costs to use the spell badges. Customize badge
colors under Tooltips. The new-rank reminder is a separate option.
If the older MeffortBars addon is loaded, it handles tooltips, action-bar
keybind labels and quest shortcuts.

Mana cost percentage in Bars shows how much of your maximum mana a spell
costs, rounded to the nearest whole percent. The option starts on with a
blue label at the top center of its action icon. Adjust the size, color,
and offsets under Mana cost labels. Reset mana label appearance restores
the original look.

Bars custom keybind labels start at size 20 with horizontal and vertical
offsets of -15. Saved sizes and positions carry forward. Adjust the values
under Bars. Reset appearance restores the default label style. Native red
range warnings take priority.

Pet-sound options start off. Mute native pet sounds uses the game's Pet Sounds
category. It can also affect combat pets, and shared footsteps may remain
audible. Advanced sound-file muting accepts verified numeric sound-file IDs.
Every source using a muted file is affected. Turning off a sound option
restores the settings or files the addon changed. Manual native volume
changes are respected.

RESTORE DEFAULTS
Open Restore Defaults from Settings or run /msuite defaults. Read the review
and choose Restore defaults & reload to apply the reset. It resets account
preferences and this character's feature settings during reload. It keeps bank
and sound-file lists, macros, game keybindings and other characters' settings.
Finish combat, clear the cursor and release the right mouse button before
resetting. If the reload needs a retry, choose Reload UI from the review page.

COMMANDS
/msuite                    Open the launcher
/msuite help               Open setup and troubleshooting
/msuite on | off           Turn the suite on or off
/msuite bags               Open Bags
/msuite loot               Open loot settings
/msuite quests             Open Quests
/msuite sounds             Open Sounds
/msuite arcane             Open the Arcane Blast settings
/msuite fishing settings   Open Fishing
/msuite fishing status     Show fishing controls and Interact Key status
/msuite ranged settings    Open Combat
/msuite bars               Open Bars
/msuite combat             Open Combat
/msuite map                Open Map
/msuite addons             Open the minimap addon menu
/msuite tooltips           Open Tooltips
/msuite about              Open About
/msuite vendor [retry]     Check or retry merchant actions
/msuite bank now           Deposit items at an open personal bank
/msuite defaults           Open the Restore Defaults review
/msuite diagnostics        Show session diagnostics in chat
/msuite export             Open a copyable diagnostic report

TROUBLESHOOTING
Check Suite ON and the feature's own setting first. If a feature needs an
equipped item or an open game window, its settings page explains what to do.
A blocked interface action can leave a diagnostic record even when no Lua
error appears.

To report an issue, open /msuite export before reloading or logging out.
Choose Select report, copy with Ctrl+C (Command+C on Mac), then paste outside
the game with Ctrl+V (Command+V on Mac). Include what you clicked and the NPC
or window involved. The session report remains local until you share it.
Use About or the native AddOns options to turn off Show login message.

See ATTRIBUTION.txt and LICENSE for source credits and licensing.
