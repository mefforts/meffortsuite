MeffortSuiteLootValue={}
local M=MeffortSuiteLootValue
local events=CreateFrame("Frame")
local sessions,plates,positions,seenLines,lineOrder={},{},{},{},{}
local current,popups=nil,{}
local nextPopup,elapsed=1,0
local lastResult,lastTotal,lastOrigin="No confirmed loot yet",0,"none"
local lastPrices="none"
local lastAH
local MAX_VALUE,MAX_SESSIONS=1000000000000,12
local Update

local function Secret(value)
    if type(issecretvalue)~="function" then return false end
    local ok,result=pcall(issecretvalue,value)
    return not ok or result==true
end
local function Number(value)
    if not Secret(value) and type(value)=="number" and value==value
        and value~=math.huge and value~=-math.huge then return value end
end
local function Text(value)
    if not Secret(value) and type(value)=="string" then return value end
end
local function Yes(value)return not Secret(value) and (value==true or value==1)end
local function Call(fn,...)
    if type(fn)~="function" then return end
    local ok,value=pcall(fn,...)
    if ok and not Secret(value) then return value end
end
local function Now()return Number(Call(GetTime)) or 0 end
local function InCombat()return Yes(Call(InCombatLockdown))end
local function DB()
    if type(MeffortSuiteDB)~="table" then MeffortSuiteDB={} end
    return MeffortSuiteDB
end
function M.Enabled()return DB().lootValue~=false end
function M.IncludeAllItems()return DB().lootValueAllItems~=false end
function M.SetIncludeAllItems(value)DB().lootValueAllItems=value==true end
function M.UseAuctionator()return DB().lootValueAuctionator==true end
function M.SetUseAuctionator(value)DB().lootValueAuctionator=value==true end
function M.ShowBothValues()return DB().lootValueBoth==true end
function M.SetShowBothValues(value)DB().lootValueBoth=value==true end
function M.Duration()return math.max(2,math.min(12,Number(DB().lootValueDuration) or 6))end
function M.SetDuration(value)DB().lootValueDuration=math.max(2,math.min(12,Number(value) or 6))end
local function AuctionPriceAPI()
    local addon=Auctionator
    local api=type(addon)=="table" and type(addon.API)=="table" and addon.API.v1
    if type(api)=="table" and type(api.GetAuctionPriceByItemLink)=="function" then
        return api.GetAuctionPriceByItemLink
    end
end
function M.HasAuctionator()return AuctionPriceAPI()~=nil end
function M.PricingStatus()
    if M.ShowBothValues() then
        return AuctionPriceAPI() and "Vendor + (AH estimates); vendor fallback" or "Vendor + (AH vendor fallback; API unavailable)"
    end
    if not M.UseAuctionator() then return "Vendor values" end
    return AuctionPriceAPI() and "Auctionator AH estimates; vendor fallback" or
        "Auctionator price API unavailable; using vendor values"
end
local function Active()
    return M.Enabled() and (not MeffortSuite or not MeffortSuite.Active or MeffortSuite.Active())
end
local function Wake()events:SetScript("OnUpdate",Update)end
local function Point(frame)
    if not frame or type(frame.GetCenter)~="function" then return end
    if Yes(Call(frame.IsForbidden,frame)) then return end
    local ok,x,y=pcall(frame.GetCenter,frame)
    x,y=Number(x),Number(y)
    local scale=Number(Call(frame.GetEffectiveScale,frame)) or 1
    local parentScale=Number(Call(UIParent and UIParent.GetEffectiveScale,UIParent)) or 1
    if ok and x and y and scale>0 and parentScale>0 then return x*scale/parentScale,y*scale/parentScale end
end
local function Origin(sources)
    if not InCombat() and C_NamePlate and type(C_NamePlate.GetNamePlateForUnit)=="function" then
        for _,unit in ipairs({"mouseover","target"}) do
            local guid=Text(Call(UnitGUID,unit))
            if guid and (sources[guid] or (not next(sources) and Yes(Call(UnitIsDead,unit)))) then
                local plate=Call(C_NamePlate.GetNamePlateForUnit,unit)
                if plate and Yes(Call(plate.IsShown,plate)) then
                    local x,y=Point(plate)
                    if x then return {x=x,y=y,kind="nameplate"} end
                end
            end
        end
    end
    for guid in pairs(sources) do
        local saved=positions[guid]
        if saved and Now()-saved.at<=8 then return {x=saved.x,y=saved.y,kind="last nameplate position"} end
    end
    if type(GetCursorPosition)=="function" then
        local ok,x,y=pcall(GetCursorPosition)
        local scale=Number(Call(UIParent and UIParent.GetEffectiveScale,UIParent)) or 1
        x,y=Number(x),Number(y)
        if ok and x and y and scale>0 then return {x=x/scale,y=y/scale,kind="loot click"} end
    end
    local x,y=Point(UIParent)
    return {x=x or 200,y=y or 200,kind="screen center"}
end
local function PlateEvent(unit,added)
    unit=Text(unit)
    if not unit then return end
    if InCombat() then plates[unit]=nil;return end
    if added then
        local guid=Text(Call(UnitGUID,unit))
        local plate=C_NamePlate and Call(C_NamePlate.GetNamePlateForUnit,unit)
        if guid and plate then plates[unit]={guid=guid,frame=plate} end
    else
        local saved=plates[unit]
        if saved then
            local x,y=Point(saved.frame)
            if x then positions[saved.guid]={x=x,y=y,at=Now()} end
        end
        plates[unit]=nil
    end
    local count=0
    for guid,saved in pairs(positions) do
        count=count+1
        if Now()-saved.at>8 or count>64 then positions[guid]=nil end
    end
end

local function Pattern(format)
    format=Text(format)
    if not format or #format>1000 then return end
    local out,args,i,nextArg={"^"},{},1,1
    while i<=#format do
        local tail=format:sub(i)
        local index,kind=tail:match("^%%(%d+)%$([sd])")
        local token
        if kind then token="%"..index.."$"..kind
        else kind=tail:match("^%%([sd])");if kind then index=nextArg;nextArg=nextArg+1;token="%"..kind end end
        if token then
            args[#args+1]=tonumber(index)
            out[#out+1]=kind=="d" and "(%d+)" or "(.-)"
            i=i+#token
        elseif tail:sub(1,2)=="%%" then out[#out+1]="%%";i=i+2
        else out[#out+1]=format:sub(i,i):gsub("([%(%)%.%%%+%-%*%?%[%]%^%$])","%%%1");i=i+1 end
    end
    out[#out+1]="$"
    return table.concat(out),args
end
local patterns={}
local function Match(message,name,fallback)
    local format=Text(_G[name])
    local locale=Text(Call(GetLocale))
    if not format and (not locale or locale=="enUS" or locale=="enGB") then format=fallback end
    if not format then return end
    local entry=patterns[name]
    if not entry or entry.format~=format then
        local pattern,args=Pattern(format)
        if not pattern then return end
        entry={format=format,pattern=pattern,args=args};patterns[name]=entry
    end
    local captures={message:match(entry.pattern)}
    if #captures==0 then return end
    local args={}
    for i,value in ipairs(captures) do args[entry.args[i]]=value end
    return args
end
local function MoneyAmount(text)
    text=Text(text)
    if not text then return end
    local function Spaces(value)return value:gsub("\194\160"," "):gsub("\226\128\175"," ")end
    text=Spaces(text)
    for _=1,8 do
        local changed
        text,changed=text:gsub("(%d)[,%s%.](%d)","%1%2")
        if changed==0 then break end
    end
    local total,found=0,false
    for _,coin in ipairs({{"GOLD",10000,"%d Gold"},{"SILVER",100,"%d Silver"},{"COPPER",1,"%d Copper"}}) do
        for _,suffix in ipairs({"_AMOUNT","_AMOUNT_TEXTURE","_AMOUNT_SYMBOL"}) do
            local format=Text(_G[coin[1]..suffix])
            if not format and suffix=="_AMOUNT" and (not GetLocale or Call(GetLocale)=="enUS" or Call(GetLocale)=="enGB") then format=coin[3] end
            local pattern=format and Pattern(Spaces(format))
            local amount=pattern and tonumber(text:match(pattern:sub(2,-2)))
            if amount and amount>=0 and amount<=MAX_VALUE/coin[2] then
                total=total+amount*coin[2];found=true;break
            end
        end
    end
    if found and total>0 and total<=MAX_VALUE then return total end
end
local function MoneyText(amount,size)
    local gold=math.floor(amount/10000)
    local silver=math.floor(amount/100)%100
    local copper=amount%100
    local function Coin(value,kind)
        size=size or 14
        return tostring(value).."|TInterface\\MoneyFrame\\UI-"..kind.."Icon:"..size..":"..size..":1:0|t"
    end
    local out={}
    if gold>0 then out[#out+1]=Coin(gold,"Gold") end
    if silver>0 or gold>0 then out[#out+1]=Coin(silver,"Silver") end
    out[#out+1]=Coin(copper,"Copper")
    return "+ "..table.concat(out," ")
end
function M.FormatMoney(amount)
    return MoneyText(amount,12):sub(3)
end
local function PopupValues(popup,total,auction)
    local label,aside=popup.label,popup.aside
    local font=STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
    label:SetFont(font,16,"OUTLINE");aside:SetFont(font,13,"OUTLINE")
    label:SetText(MoneyText(total))
    label:ClearAllPoints();aside:ClearAllPoints()
    local screen=Number(Call(UIParent.GetWidth,UIParent)) or 1024
    local width=280
    if auction~=nil then
        aside:SetText("(AH "..MoneyText(auction,11):sub(3)..")");aside:Show()
        width=(Number(Call(label.GetStringWidth,label)) or 200)+(Number(Call(aside.GetStringWidth,aside)) or 230)+8
        if width>screen-24 and screen>48 then
            local ratio=(screen-24)/width
            label:SetFont(font,math.max(9,math.floor(16*ratio)),"OUTLINE")
            aside:SetFont(font,math.max(8,math.floor(13*ratio)),"OUTLINE")
            label:SetText(MoneyText(total,math.max(8,math.floor(14*ratio))))
            aside:SetText("(AH "..MoneyText(auction,math.max(7,math.floor(11*ratio))):sub(3)..")")
            width=(Number(Call(label.GetStringWidth,label)) or 200)+(Number(Call(aside.GetStringWidth,aside)) or 230)+8
        end
        label:SetPoint("LEFT",popup.frame,"LEFT",0,0)
        aside:SetPoint("LEFT",label,"RIGHT",8,0)
    else
        aside:Hide();label:SetPoint("CENTER",popup.frame,"CENTER",0,0)
    end
    popup.frame:SetSize(width,28)
    local margin=math.min(width/2,screen/2)
    if popup.originX then popup.x=math.max(margin,math.min(screen-margin,popup.originX)) end
end
local function Popup(total,origin,auction)
    if not UIParent then return end
    local popup=popups[nextPopup]
    if not popup then
        -- Keep floats separate from protected nameplates.
        local frame=CreateFrame("Frame","MeffortSuiteLootValue"..nextPopup,UIParent)
        frame:SetSize(280,28);frame:EnableMouse(false)
        local label=frame:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
        label:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",16,"OUTLINE")
        label:SetPoint("CENTER",frame,"CENTER",0,0)
        label:SetTextColor(1,.92,.65,1)
        label:SetShadowColor(0,0,0,1);label:SetShadowOffset(1,-1)
        local aside=frame:CreateFontString(nil,"OVERLAY","GameFontNormal")
        aside:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",13,"OUTLINE")
        aside:SetTextColor(.67,.78,.82,1)
        aside:SetShadowColor(0,0,0,1);aside:SetShadowOffset(1,-1)
        popup={frame=frame,label=label,aside=aside};popups[nextPopup]=popup
    end
    local width=Number(Call(UIParent.GetWidth,UIParent)) or 1024
    local height=Number(Call(UIParent.GetHeight,UIParent)) or 768
    local margin=math.min(140,width/2)
    popup.x=math.max(margin,math.min(width-margin,origin.x))
    popup.originX=origin.x
    popup.y=math.max(30,math.min(height-80,origin.y+18+(nextPopup-1)%3*16))
    popup.started=Now();popup.duration=M.Duration();popup.active=true;popup.session=nil
    popup.frame:SetFrameStrata(origin.kind=="preview" and "FULLSCREEN_DIALOG" or "MEDIUM")
    PopupValues(popup,total,auction);popup.frame:SetAlpha(1)
    popup.frame:ClearAllPoints();popup.frame:SetPoint("CENTER",UIParent,"BOTTOMLEFT",popup.x,popup.y)
    popup.frame:Show()
    nextPopup=nextPopup%6+1
    Wake()
    return popup
end
local function Identity(link)
    link=Text(link)
    if not link then return end
    local key=link:match("|H(item:[^|]+)|h") or link:match("^(item:[^|]+)")
    local id=key and tonumber(key:match("^item:(%d+)"))
    if Number(id) and id>0 and id<=2147483647 and id==math.floor(id) then return key,id end
end
local function Snapshot(excluded)
    if current or type(GetTime)~="function" then return end
    local count=excluded and 0 or Number(Call(GetNumLootItems))
    if not count or count<0 or count>100 or (count==0 and not excluded) then return end
    local session={items={},receipts={},sources={},money=0,moneySlots=0,moneyReceipts=0,
        allItems=M.IncludeAllItems(),both=M.ShowBothValues(),auctionator=M.UseAuctionator() or M.ShowBothValues(),
        opened=Now(),dirty=false,excluded=excluded==true}
    for slot=1,math.floor(count) do
        local link=Text(Call(GetLootSlotLink,slot))
        local key,id=Identity(link)
        local ok,_,_,quantity,_,quality,_,_,_,_,isCoin=pcall(GetLootSlotInfo,slot)
        quantity=ok and Number(quantity)
        quality=ok and Number(quality)
        local kind=Number(Call(GetLootSlotType,slot))
        if key and quantity and quantity>0 and quantity<=1000000 and quantity==math.floor(quantity) then
            local item=session.items[key]
            if not item then item={id=id,link=link,left=0,quality=quality};session.items[key]=item end
            item.left=item.left+quantity
        elseif (not Secret(isCoin) and isCoin==true) or kind==(LOOT_SLOT_MONEY or 2) then
            session.moneySlots=session.moneySlots+1
        end
        if not InCombat() and type(GetLootSourceInfo)=="function" then
            local values={pcall(GetLootSourceInfo,slot)}
            if values[1] then
                local first=Number(values[2]) and 3 or 2
                for i=first,math.min(#values,202),2 do
                    local guid=Text(values[i])
                    if guid then session.sources[guid]=true end
                end
            end
        end
    end
    if not excluded then session.origin=Origin(session.sources) end
    sessions[#sessions+1]=session
    if #sessions>MAX_SESSIONS then table.remove(sessions,1) end
    current=session
end
local function Eligible(session)
    return not session.failed and Now()-session.opened<=120 and (not session.closed or Now()-session.closed<=1.2)
end
local function Price(receipt)
    if receipt.value~=nil and (not receipt.both or receipt.vendor~=nil) then return receipt.value,receipt.vendor end
    if receipt.nextTry and Now()<receipt.nextTry then return end
    receipt.nextTry=Now()+.2
    local getter=C_Item and C_Item.GetItemInfo or GetItemInfo
    if type(getter)~="function" then return end
    local ok,name,_,quality,_,_,_,_,_,_,_,sell,_,_,bindType=pcall(getter,receipt.link)
    quality,sell=Number(quality),Number(sell)
    if ok and Text(name) and quality and quality~=0 and not receipt.allItems then receipt.value=0;receipt.vendor=0
    elseif ok and Text(name) and quality then
        if receipt.auctionator and not receipt.auctionChecked then
            receipt.auctionChecked=true
            -- Only transferable binding types can use an auction estimate.
            bindType=Number(bindType)
            if bindType==0 or bindType==2 or bindType==3 then
                local price=Number(Call(AuctionPriceAPI(),"MeffortSuite",receipt.link))
                if price and price>0 and price<=MAX_VALUE and price==math.floor(price) then
                    receipt.value=price;receipt.source="Auctionator"
                end
            end
        end
        if sell and sell>=0 and sell<=MAX_VALUE and sell==math.floor(sell) then
            receipt.vendor=sell
            if receipt.value==nil then receipt.value=sell;receipt.source="vendor" end
        end
    end
    if (receipt.value==nil or (receipt.both and receipt.vendor==nil)) and not receipt.requested and not InCombat() then
        receipt.requested=true
        if C_Item then Call(C_Item.RequestLoadItemDataByID,receipt.id) end
    end
    return receipt.value,receipt.vendor
end
function M.TrackQuote(receipt)
    local value,vendor=Price(receipt)
    return vendor,receipt.source=="Auctionator" and value or nil
end
local function ReceiptSource(key,id,quantity)
    -- Exact links across recent windows take precedence over item-ID fallback.
    for pass=1,2 do
        for i=#sessions,1,-1 do
            local session=sessions[i]
            if Eligible(session) then
                if session.excluded then break end
                local item=session.items[key]
                if pass==2 and not item then
                    for _,candidate in pairs(session.items) do
                        if candidate.id==id and candidate.left>=quantity then
                            if item then item=nil;break end
                            item=candidate
                        end
                    end
                end
                if item and item.left>=quantity then return session,item end
            end
        end
    end
end
local function ItemReceived(link,quantity,floating,tracker)
    local key,id=Identity(link)
    if not key or not quantity or quantity<1 or quantity>1000000 or quantity~=math.floor(quantity) then return end
    if tracker then tracker.RecordItem(key,id,link,quantity) end
    if not floating then return end
    local session,item=ReceiptSource(key,id,quantity)
    if not session then return end
    item.left=item.left-quantity
    local receipt=session.receipts[key]
    if not receipt then
        receipt={id=id,link=link,count=0,allItems=session.allItems,auctionator=session.auctionator,both=session.both}
        if not session.allItems and item.quality and item.quality>0 then receipt.value=0;receipt.vendor=0 end
        session.receipts[key]=receipt
    end
    receipt.count=receipt.count+quantity;Price(receipt)
    session.dirty=true
    if session.closed then Wake() end
end
local function Received(event,message,lineID,floating,tracker)
    message=Text(message)
    if not message or #message>4096 then return end
    lineID=Number(lineID)
    if lineID and lineID>0 then
        if seenLines[lineID] then return end
        seenLines[lineID]=true;lineOrder[#lineOrder+1]=lineID
        if #lineOrder>96 then seenLines[table.remove(lineOrder,1)]=nil end
    end
    if event=="CHAT_MSG_LOOT" then
        local args=Match(message,"LOOT_ITEM_SELF_MULTIPLE","You receive loot: %sx%d.")
        if args then ItemReceived(args[1],tonumber(args[2]),floating,tracker);return end
        args=Match(message,"LOOT_ITEM_SELF","You receive loot: %s.")
        if args then ItemReceived(args[1],1,floating,tracker) end
    else
        for _,format in ipairs({{"YOU_LOOT_MONEY_GUILD"},{"LOOT_MONEY_SPLIT_GUILD"},
            {"YOU_LOOT_MONEY","You loot %s."},{"LOOT_MONEY_SPLIT","Your share of the loot is %s."}}) do
            local args=Match(message,format[1],format[2])
            local amount=args and MoneyAmount(args[1])
            if amount then
                if tracker then tracker.RecordMoney(amount) end
                if not floating then return end
                for i=#sessions,1,-1 do
                    local session=sessions[i]
                    if Eligible(session) and session.excluded then break end
                    if Eligible(session) and session.moneyReceipts<session.moneySlots then
                        session.money=session.money+amount;session.moneyReceipts=session.moneyReceipts+1;session.dirty=true
                        if session.closed then Wake() end
                        return
                    end
                end
                return
            end
        end
    end
end
Update=function(_,delta)
    if not Active() then M.RefreshMaster();return end
    elapsed=elapsed+(Number(delta) or 0)
    if elapsed<.03 then return end
    elapsed=0
    local now,busy=Now(),false
    for i=#sessions,1,-1 do
        local session=sessions[i]
        if now-session.opened>120 or (session.closed and now-session.closed>4) then table.remove(sessions,i)
        elseif session.closed and session.dirty and not session.failed and not session.excluded then
            local total,vendorTotal,ready,auctionItems,vendorItems=session.money,session.money,true,0,0
            for _,receipt in pairs(session.receipts) do
                local value,vendor=Price(receipt)
                if value==nil then ready=false else total=total+value*receipt.count end
                if session.both then
                    if vendor==nil then ready=false else vendorTotal=vendorTotal+vendor*receipt.count end
                end
                if receipt.source=="Auctionator" then auctionItems=auctionItems+receipt.count
                elseif receipt.source=="vendor" then vendorItems=vendorItems+receipt.count end
            end
            if now-session.closed<.45 then busy=true
            elseif not ready and now-session.closed<2 then busy=true
            elseif not ready or total>MAX_VALUE or (session.both and vendorTotal>MAX_VALUE) then
                session.failed=true;session.dirty=false
                lastResult=ready and "Total omitted: value exceeds display limit" or "Total omitted: item prices unavailable"
            else
                session.dirty=false
                local primary=session.both and vendorTotal or total
                local auction=session.both and total or nil
                if (primary>0 or (auction and auction>0)) and (primary~=session.shown or auction~=session.shownAH) then
                    local popup=session.popup
                    if popup and popup.active and popup.session==session then
                        PopupValues(popup,primary-(popup.base or 0),auction and auction-(popup.baseAH or 0))
                    else
                        popup=Popup(primary-(session.shown or 0),session.origin,auction and auction-(session.shownAH or 0))
                        session.popup=popup
                        if popup then popup.session=session;popup.base=session.shown or 0;popup.baseAH=session.shownAH or 0 end
                    end
                    session.shown=primary;session.shownAH=auction;lastTotal=primary;lastAH=auction
                    lastOrigin=session.origin.kind;lastResult="Confirmed loot value shown"
                    lastPrices=auctionItems.." Auctionator items, "..vendorItems.." vendor items"
                end
            end
        end
    end
    for _,popup in ipairs(popups) do
        if popup.active then
            local progress=math.min(1,(now-popup.started)/(popup.duration or 6))
            if progress>=1 then popup.active=false;popup.session=nil;popup.frame:Hide()
            else
                busy=true
                popup.frame:SetPoint("CENTER",UIParent,"BOTTOMLEFT",popup.x,popup.y+36*(1-(1-progress)^2))
                popup.frame:SetAlpha(progress<.65 and 1 or (1-progress)/.35)
            end
        end
    end
    if not busy then events:SetScript("OnUpdate",nil) end
end
function M.RefreshMaster()
    if Active() then return end
    sessions,plates,positions={}, {}, {};current=nil
    for _,popup in ipairs(popups) do popup.active=false;popup.session=nil;popup.frame:Hide() end
    events:SetScript("OnUpdate",nil)
end
function M.SetEnabled(value)DB().lootValue=value==true;M.RefreshMaster()end
function M.Preview()
    if not Active() or not UIParent or type(GetTime)~="function" then return false end
    local x,y=Point(UIParent)
    x,y=x or 200,y or 200
    local settings=MeffortSuiteSettingsV2
    local right=Number(Call(settings and settings.GetRight,settings))
    local left=Number(Call(settings and settings.GetLeft,settings))
    local width=Number(Call(UIParent.GetWidth,UIParent)) or 1024
    if right and right+160<width then x=right+100
    elseif left then x=left-100 else x=x+300 end
    Popup(12345,{x=x,y=y-40,kind="preview"},M.ShowBothValues() and 23456 or nil)
    return true
end
function M.Status()
    return (M.Enabled() and "enabled" or "disabled").."; items "..(M.IncludeAllItems() and "all qualities" or "grey only")..
        "; pricing "..M.PricingStatus().."; "..lastResult.."; last value "..lastTotal.." copper; position "..lastOrigin..
        "; last prices "..lastPrices..(lastAH and ("; last AH estimate "..lastAH.." copper") or "")
end
function M.PrepareLoot(fromItem)
    if not Active() then return end
    if Yes(fromItem) or Yes(Call(IsFishingLoot)) then
        Snapshot(true)
        if current then current.excluded=true;current.dirty=false end
    else Snapshot() end
end
for _,event in ipairs({"LOOT_READY","LOOT_OPENED","LOOT_CLOSED","CHAT_MSG_LOOT","CHAT_MSG_MONEY",
    "GET_ITEM_INFO_RECEIVED","NAME_PLATE_UNIT_ADDED","NAME_PLATE_UNIT_REMOVED","PLAYER_LEAVING_WORLD"}) do
    pcall(events.RegisterEvent,events,event)
end
events:SetScript("OnEvent",function(_,event,...)
    if event=="PLAYER_LEAVING_WORLD" then
        sessions,plates,positions={}, {}, {};current=nil
        for _,popup in ipairs(popups) do popup.active=false;popup.session=nil;popup.frame:Hide() end
        events:SetScript("OnUpdate",nil);return
    end
    local floating=Active()
    local tracker=MeffortSuiteLootTracker
    if event=="CHAT_MSG_LOOT" or event=="CHAT_MSG_MONEY" then
        tracker=tracker and tracker.IsTracking() and tracker or nil
        if floating or tracker then
            Received(event,select(1,...),select(11,...),floating,tracker)
        end
        return
    end
    if tracker and event=="GET_ITEM_INFO_RECEIVED" then tracker.ItemDataReady(Number(...)) end
    if not floating then M.RefreshMaster();return end
    if event=="LOOT_READY" then Snapshot()
    elseif event=="LOOT_OPENED" then
        M.PrepareLoot(select(2,...))
    elseif event=="LOOT_CLOSED" then
        if current then current.closed=Now();if current.dirty then Wake() end;current=nil end
    elseif event=="NAME_PLATE_UNIT_ADDED" then PlateEvent(...,true)
    elseif event=="NAME_PLATE_UNIT_REMOVED" then PlateEvent(...,false)
    elseif event=="GET_ITEM_INFO_RECEIVED" then
        local id=Number(...)
        for _,session in ipairs(sessions) do
            for _,receipt in pairs(session.receipts) do if receipt.id==id then receipt.nextTry=nil end end
            if session.closed and session.dirty then Wake() end
        end
    end
end)
