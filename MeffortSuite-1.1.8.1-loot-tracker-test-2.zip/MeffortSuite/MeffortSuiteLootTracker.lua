MeffortSuiteLootTracker={}
local M=MeffortSuiteLootTracker
local prices=MeffortSuiteLootValue
local defaultWidth,defaultHeight,rowHeight=376,300,19
local minWidth,minHeight,maxWidth,maxHeight=320,270,680,620
local compactHeight=216
local session={byKey={},items={},coins=0,count=0}
local tracking,queued=false,false
local panel,status,startButton,itemsButton,valuesButton,compactButton,coinLabel,coinValue
local scroll,content,empty,valuesPanel,vendorValue,auctionValue,priceNote
local rows={}
local layout,operation

local function SuiteActive()
    return MeffortSuite.Active()
end
function M.IsTracking()
    return tracking and SuiteActive()
end

local function Finite(value)
    return type(value)=="number" and math.abs(value)<math.huge
end
local function Clamp(value,lower,upper)
    return math.max(lower,math.min(upper,value))
end
local function SavedLayout()
    local saved=MeffortSuiteDB.lootTrackerLayout
    if type(saved)~="table" then saved={};MeffortSuiteDB.lootTrackerLayout=saved end
    saved.width=Finite(saved.width) and Clamp(saved.width,minWidth,maxWidth) or defaultWidth
    saved.height=Finite(saved.height) and Clamp(saved.height,minHeight,maxHeight) or defaultHeight
    saved.view=saved.view=="values" and "values" or "items"
    saved.compact=saved.compact==true
    return saved
end
local function ShowingItems()
    return layout and not layout.compact and layout.view=="items"
end
local function RenderItems()
    if not scroll or not ShowingItems() or not panel:IsShown() then return end
    local capacity=math.ceil(scroll:GetHeight()/rowHeight)+1
    for index=#rows+1,capacity do
        local name=content:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        name:SetJustifyH("LEFT")
        name:SetWordWrap(false)
        local quantity=content:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        rows[index]={name=name,quantity=quantity}
    end
    local first=math.floor(scroll:GetVerticalScroll()/rowHeight)+1
    local count=#session.items
    for offset,row in ipairs(rows) do
        local index=first+offset-1
        local item=offset<=capacity and session.items[count-index+1] or nil
        row.name:SetShown(item~=nil)
        row.quantity:SetShown(item~=nil)
        if item then
            local y=-(index-1)*rowHeight
            row.name:ClearAllPoints()
            row.name:SetPoint("TOPLEFT",content,"TOPLEFT",2,y)
            row.name:SetPoint("TOPRIGHT",content,"TOPRIGHT",-58,y)
            row.name:SetText(item.name)
            row.quantity:ClearAllPoints()
            row.quantity:SetPoint("TOPRIGHT",content,"TOPRIGHT",-5,y)
            row.quantity:SetText(tostring(item.count))
        end
    end
end
local function UpdateItemsLayout()
    if not ShowingItems() or not panel:IsShown() then return end
    local listWidth=math.max(1,scroll:GetWidth())
    local listHeight=math.max(1,#session.items*rowHeight)
    if content:GetWidth()~=listWidth or content:GetHeight()~=listHeight then
        content:SetSize(listWidth,listHeight)
        scroll:UpdateScrollChildRect()
        if scroll:GetVerticalScroll()>scroll:GetVerticalScrollRange() then
            scroll:SetVerticalScroll(scroll:GetVerticalScrollRange())
        end
    end
    RenderItems()
end
local function RenderValues()
    local vendorTotal,auctionTotal=session.coins,session.coins
    local missing,fallback=0,0
    local auctionAvailable=prices.HasAuctionator()
    for _,item in ipairs(session.items) do
        local vendor,auction=prices.TrackQuote(item)
        if vendor then vendorTotal=vendorTotal+vendor*item.count
        else missing=missing+item.count end
        if auction then
            auctionTotal=auctionTotal+auction*item.count
        elseif vendor then
            auctionTotal=auctionTotal+vendor*item.count
            fallback=fallback+item.count
        end
    end
    vendorValue:SetText(prices.FormatMoney(vendorTotal))
    auctionValue:SetText(auctionAvailable and prices.FormatMoney(auctionTotal) or "Unavailable")
    local note="Totals include coins."
    if not auctionAvailable then note=note.." Load Auctionator for AH estimates."
    elseif fallback>0 then note=note.." Items without an AH price use vendor value." end
    if missing>0 then note=note.." Partial totals. Waiting for prices on "..missing.." items." end
    priceNote:SetText(note)
end
local function Render()
    if not panel or not panel:IsShown() then return end
    local running=M.IsTracking()
    local count=session.count
    local state=running and "Tracking" or (SuiteActive() and "Stopped" or "Suite off")
    status:SetText(state.."  ·  "..count..(count==1 and " item" or " items"))
    coinValue:SetText(prices.FormatMoney(session.coins))
    startButton:SetText(running and "Stop tracking" or "Start tracking")
    startButton:SetEnabled(SuiteActive())
    local items=ShowingItems()
    itemsButton:SetShown(not layout.compact)
    valuesButton:SetShown(not layout.compact)
    itemsButton:SetEnabled(layout.view~="items")
    valuesButton:SetEnabled(layout.view~="values")
    compactButton:SetText(layout.compact and "Expand" or "Compact")
    scroll:SetShown(items)
    empty:SetShown(items and count==0)
    valuesPanel:SetShown(not items)
    if items then UpdateItemsLayout() else RenderValues() end
end
local function RefreshSoon()
    if queued or not panel or not panel:IsShown() then return end
    if not (C_Timer and C_Timer.After) then Render();return end
    queued=true
    C_Timer.After(0,function()
        queued=false
        Render()
    end)
end
local function Label(parent,text,font,point,x,y)
    local label=parent:CreateFontString(nil,"OVERLAY",font or "GameFontHighlightSmall")
    label:SetPoint(point,parent,point,x,y)
    label:SetText(text)
    return label
end
local function Button(text,w,point,x,y,action)
    local button=CreateFrame("Button",nil,panel,"UIPanelButtonTemplate")
    button:SetSize(w,24)
    button:SetPoint(point,panel,point,x,y)
    button:SetText(text)
    button:SetScript("OnClick",action)
    return button
end
local function SetView(selected)
    layout.view=selected
    Render()
end
local function PlaceWindow()
    local screenWidth,screenHeight=UIParent:GetSize()
    local scale=panel:GetScale()
    local w,h=panel:GetWidth()*scale,panel:GetHeight()*scale
    local x=Finite(layout.x) and layout.x or screenWidth-w-28
    local y=Finite(layout.y) and layout.y or -(screenHeight-h)/2
    x=Clamp(x,0,math.max(0,screenWidth-w))
    y=Clamp(y,math.min(0,h-screenHeight),0)
    panel:ClearAllPoints()
    panel:SetPoint("TOPLEFT",UIParent,"TOPLEFT",x/scale,y/scale)
end
local function SavePosition()
    local x,y=panel:GetLeft(),panel:GetTop()
    local left,top=UIParent:GetLeft(),UIParent:GetTop()
    if Finite(x) and Finite(y) and Finite(left) and Finite(top) then
        local scale=panel:GetScale()
        layout.x,layout.y=x*scale-left,y*scale-top
    end
end
local function StopGeometry()
    if not operation then return end
    panel:StopMovingOrSizing()
    if operation=="size" then
        layout.width=panel:GetWidth()
        if not layout.compact then layout.height=panel:GetHeight() end
    end
    operation=nil
    SavePosition()
    panel:SetUserPlaced(false)
    PlaceWindow()
end
local function ApplyLayout()
    local screenWidth,screenHeight=UIParent:GetSize()
    local minimumHeight=layout.compact and compactHeight or minHeight
    local scale=Clamp(math.min((screenWidth-24)/minWidth,(screenHeight-24)/minimumHeight),.1,1)
    local widthLimit=Clamp((screenWidth-24)/scale,minWidth,maxWidth)
    local heightLimit=layout.compact and compactHeight or Clamp((screenHeight-24)/scale,minHeight,maxHeight)
    panel:SetScale(scale)
    panel:SetResizeBounds(minWidth,minimumHeight,widthLimit,heightLimit)
    local w=Clamp(layout.width,minWidth,widthLimit)
    local h=layout.compact and compactHeight or Clamp(layout.height,minHeight,heightLimit)
    panel:SetSize(w,h)
    PlaceWindow()

    local coinsY=layout.compact and -62 or -98
    coinLabel:ClearAllPoints()
    coinLabel:SetPoint("TOPLEFT",panel,"TOPLEFT",17,coinsY)
    coinValue:ClearAllPoints()
    coinValue:SetPoint("TOPRIGHT",panel,"TOPRIGHT",-21,coinsY)
    valuesPanel:ClearAllPoints()
    valuesPanel:SetPoint("TOPLEFT",panel,"TOPLEFT",17,layout.compact and -85 or -129)
    valuesPanel:SetPoint("BOTTOMRIGHT",panel,"BOTTOMRIGHT",-21,42)
end
local function CreateWindow()
    layout=SavedLayout()
    panel=CreateFrame("Frame","MeffortSuiteLootTrackerWindow",UIParent,BackdropTemplateMixin and "BackdropTemplate" or nil)
    panel:Hide()
    panel:SetFrameStrata("DIALOG")
    panel:SetClampedToScreen(true)
    panel:EnableMouse(true)
    panel:SetMovable(true)
    panel:SetResizable(true)
    panel:RegisterForDrag("LeftButton")
    panel:SetScript("OnDragStart",function(self)operation="move";self:StartMoving()end)
    panel:SetScript("OnDragStop",StopGeometry)
    panel:SetScript("OnHide",StopGeometry)
    if panel.SetBackdrop then
        panel:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",
            edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",tile=true,tileSize=32,edgeSize=24,
            insets={left=7,right=7,top=7,bottom=7}})
        panel:SetBackdropColor(.11,.085,.06,.98)
    else
        local background=panel:CreateTexture(nil,"BACKGROUND")
        background:SetAllPoints()
        background:SetColorTexture(.11,.085,.06,.98)
    end
    local close=CreateFrame("Button",nil,panel,"UIPanelCloseButton")
    close:SetPoint("TOPRIGHT",panel,"TOPRIGHT",-5,-5)
    close:SetScript("OnClick",function()panel:Hide()end)
    compactButton=Button("Compact",76,"TOPRIGHT",-35,-10,function()
        StopGeometry()
        SavePosition()
        layout.compact=not layout.compact
        ApplyLayout()
        Render()
    end)
    Label(panel,"Loot Tracker","GameFontNormalLarge","TOPLEFT",16,-14)
    status=Label(panel,"","GameFontHighlightSmall","TOPLEFT",17,-39)
    itemsButton=Button("Items",76,"TOPLEFT",16,-60,function()SetView("items")end)
    valuesButton=Button("Values",76,"TOPLEFT",98,-60,function()SetView("values")end)
    coinLabel=Label(panel,"Coins looted","GameFontNormal","TOPLEFT",17,-98)
    coinValue=Label(panel,"","GameFontHighlight","TOPRIGHT",-21,-98)
    startButton=Button("Start tracking",112,"BOTTOMLEFT",17,15,function()M.SetTracking(not M.IsTracking())end)

    local grip=CreateFrame("Button",nil,panel)
    grip:SetSize(18,18)
    grip:SetPoint("BOTTOMRIGHT",panel,"BOTTOMRIGHT",-4,4)
    grip:EnableMouse(true)
    grip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    grip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    grip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    grip:SetScript("OnMouseDown",function(_,mouse)
        if mouse=="LeftButton" then operation="size";panel:StartSizing("BOTTOMRIGHT") end
    end)
    grip:SetScript("OnMouseUp",function(_,mouse)
        if mouse=="LeftButton" and operation=="size" then StopGeometry() end
    end)

    scroll=CreateFrame("ScrollFrame",nil,panel,"UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT",panel,"TOPLEFT",17,-123)
    scroll:SetPoint("BOTTOMRIGHT",panel,"BOTTOMRIGHT",-35,52)
    content=CreateFrame("Frame",nil,scroll)
    content:SetSize(defaultWidth-53,1)
    scroll:SetScrollChild(content)
    scroll:HookScript("OnVerticalScroll",RenderItems)
    scroll:HookScript("OnSizeChanged",UpdateItemsLayout)
    empty=Label(panel,"No loot recorded yet.",nil,"TOPLEFT",19,-129)
    valuesPanel=CreateFrame("Frame",nil,panel)
    valuesPanel:SetPoint("TOPLEFT",panel,"TOPLEFT",17,-129)
    valuesPanel:SetPoint("BOTTOMRIGHT",panel,"BOTTOMRIGHT",-21,52)
    Label(valuesPanel,"Vendor total","GameFontNormal","TOPLEFT",0,0)
    vendorValue=Label(valuesPanel,"","GameFontHighlight","TOPRIGHT",0,0)
    Label(valuesPanel,"Auctionator estimate","GameFontNormal","TOPLEFT",0,-27)
    auctionValue=Label(valuesPanel,"","GameFontHighlight","TOPRIGHT",0,-27)
    priceNote=Label(valuesPanel,"",nil,"TOPLEFT",0,-56)
    priceNote:SetPoint("TOPRIGHT",valuesPanel,"TOPRIGHT",0,-56)
    priceNote:SetJustifyH("LEFT")
    priceNote:SetWordWrap(true)
end

function M.Open()
    if not panel then CreateWindow() end
    ApplyLayout()
    panel:Show()
    if panel.Raise then panel:Raise() end
    Render()
end
function M.SetTracking(enabled)
    if enabled and not SuiteActive() then return end
    if enabled and not tracking then
        session={byKey={},items={},coins=0,count=0}
        if scroll then scroll:SetVerticalScroll(0) end
    end
    tracking=enabled==true
    if tracking then M.Open() else Render() end
    if MeffortSuiteSettingsUI then MeffortSuiteSettingsUI.Refresh() end
end
function M.RefreshMaster()
    if not SuiteActive() then tracking=false end
    Render()
end
function M.RecordItem(key,id,link,quantity)
    local item=session.byKey[key]
    if not item then
        item={id=id,link=link,name=link:match("|h%[(.-)%]|h") or ("Item "..id),count=0,
            allItems=true,auctionator=true,both=true}
        session.byKey[key]=item
        session.items[#session.items+1]=item
    end
    item.count=item.count+quantity
    session.count=session.count+quantity
    RefreshSoon()
end
function M.RecordMoney(amount)
    session.coins=session.coins+amount
    RefreshSoon()
end
function M.ItemDataReady(id)
    if not id then return end
    for _,item in ipairs(session.items) do
        if item.id==id and item.vendor==nil then
            item.nextTry=nil
            if not ShowingItems() then RefreshSoon() end
        end
    end
end

local events=CreateFrame("Frame")
events:RegisterEvent("PLAYER_REGEN_ENABLED")
events:RegisterEvent("ADDON_LOADED")
events:RegisterEvent("DISPLAY_SIZE_CHANGED")
events:RegisterEvent("UI_SCALE_CHANGED")
events:SetScript("OnEvent",function(_,event,addon)
    if event=="DISPLAY_SIZE_CHANGED" or event=="UI_SCALE_CHANGED" then
        if panel and panel:IsShown() and not operation then ApplyLayout() end
    elseif event=="ADDON_LOADED" then
        if addon~="Auctionator" then return end
        for _,item in ipairs(session.items) do
            if item.source~="Auctionator" then
                item.auctionChecked,item.value,item.source,item.nextTry=nil,nil,nil,nil
            end
        end
    end
    RefreshSoon()
end)
