local VERSION="1.0.0"
local LIMIT=40
local known={"findYourselfAnywhere","findYourselfAnywhereOnlyInCombat","findYourselfInBG",
    "findYourselfInBGOnlyInCombat","findYourselfInRaid","findYourselfInRaidOnlyInCombat",
    "findYourselfMode","findYourselfModeOutline","findYourselfModeCircle","findYourselfModeIcon",
    "occludedSilhouettePlayer","Outline","OutlineEngineMode","graphicsOutlineMode"}

local function Secret(value)
    if type(issecretvalue)~="function" then return false end
    local ok,result=pcall(issecretvalue,value)
    return not ok or result==true
end
local function Text(value)
    if not Secret(value) and type(value)=="string" then return value end
end
local function Clean(value,limit)
    value=Text(value) or "unavailable"
    return value:gsub("[\r\n\t%z]"," "):gsub("|","||"):sub(1,limit or 140)
end
local function Message(value)
    local line="|cffffd166MeffortHighlightProbe|r: "..value
    if DEFAULT_CHAT_FRAME and type(DEFAULT_CHAT_FRAME.AddMessage)=="function" then
        DEFAULT_CHAT_FRAME:AddMessage(line)
    else print(line) end
end
local function GetValue(name,method,legacy)
    local api=type(C_CVar)=="table" and C_CVar[method]
    if type(api)=="function" then
        local ok,value=pcall(api,name)
        if ok and Text(value) then return value end
    end
    if type(legacy)=="function" then
        local ok,value=pcall(legacy,name)
        if ok then return Text(value) end
    end
end
local function Related(name)
    name=Text(name)
    if not name or #name>80 or not name:match("^[%w_]+$") then return false end
    local key=name:lower()
    return key:find("outline",1,true) or key:find("findyourself",1,true)
        or key:find("silhouette",1,true) or key:find("highlight",1,true)
end
local function Report()
    local entries,keys={},{}
    local function Add(name,help)
        if not Related(name) then return end
        local key=name:lower()
        if keys[key] then
            if Text(help) then keys[key].help=help end
            return
        end
        local entry={name=name,help=Text(help)}
        keys[key]=entry;entries[#entries+1]=entry
    end
    for _,name in ipairs(known) do Add(name) end
    local registry="unavailable"
    if type(ConsoleGetAllCommands)=="function" then
        local ok,commands=pcall(ConsoleGetAllCommands)
        if ok and not Secret(commands) and type(commands)=="table" then
            registry="available"
            local count=0
            for _,entry in pairs(commands) do
                count=count+1
                if count>50000 then registry="truncated";break end
                if not Secret(entry) and type(entry)=="table" and not Secret(entry.commandType)
                    and entry.commandType==0 then Add(Text(entry.command),Text(entry.help)) end
            end
        end
    end
    table.sort(entries,function(a,b)return a.name:lower()<b.name:lower() end)
    local interface="unknown"
    if type(GetBuildInfo)=="function" then
        local ok,_,_,_,value=pcall(GetBuildInfo)
        if ok and not Secret(value) and type(value)=="number" then interface=tostring(value) end
    end
    Message("Version "..VERSION.."; interface "..interface.."; read-only; registry "..registry..".")
    for index=1,math.min(LIMIT,#entries) do
        local entry=entries[index]
        local value=GetValue(entry.name,"GetCVar",GetCVar)
        local line=entry.name.." = "..(value and Clean(value,80) or "unsupported or unavailable")
        if value then
            local default=GetValue(entry.name,"GetCVarDefault",GetCVarDefault)
            if default then line=line.."; default "..Clean(default,80) end
        end
        if entry.help and entry.help~="" then line=line.."; "..Clean(entry.help) end
        Message(line)
    end
    if #entries>LIMIT then Message(tostring(#entries-LIMIT).." additional matching settings omitted.") end
    Message("Report complete. No settings changed; listed variables may affect more than your character.")
end

SLASH_MEFFORTHIGHLIGHTPROBE1="/mhprobe"
SLASH_MEFFORTHIGHLIGHTPROBE2="/mhighlightprobe"
SlashCmdList.MEFFORTHIGHLIGHTPROBE=function()
    local ok=pcall(Report)
    if not ok then Message("The client could not complete the read-only report. No settings changed.") end
end
