# MeffortHighlightProbe 1.0.0

A read-only settings checker for World of Warcraft: Forever, Interface 16001.
This tool does not change the character highlight or create an aura.

Extract the MeffortHighlightProbe folder into Interface/AddOns, enable it, and
reload the UI. Run `/mhprobe` to print related native settings to chat. The
report includes current values, defaults when available, and console help.
Unsupported standard settings are identified explicitly. The report is bounded
to 40 settings; a summary reports any omitted entries.

There is no login announcement, popup, saved configuration, timer, or event
polling. The checker never sets console variables, executes console commands,
casts spells, or changes graphics settings. Disabling or removing it requires
no cleanup. The report does not establish that a listed setting is writable or
that changing it would affect only your character.
