local THROW_SPELL_ID = 2764
local WEAPON_CLASS = 2
local THROWN_SUBCLASS = 16
local FISHING_POLE_SUBCLASS = 20
local ADDON_ICON = "Interface\\Icons\\INV_Weapon_ShortBlade_05"

local MODES = {
    right = { label = "Right-click", key = "BUTTON2", condition = "nomod" },
    shift = { label = "Shift + right-click", key = "SHIFT-BUTTON2", condition = "mod:shift,nomod:ctrl,nomod:alt" },
    off = { label = "Off" },
}
local MODE_ORDER = { "right", "shift", "off" }
local SETUP_HINTS = {
    pole = "Unequip your fishing pole to use Throw.",
    spell = "Learn Throw to use this shortcut.",
    weapon = "Equip a thrown weapon to use this shortcut.",
    ready = "Ready. Use the shortcut on a living enemy.",
}

local events = CreateFrame("Frame")
local controller, attackButton
local modeSetting
local supportedClass, activeMode, pending
local ownMouselook, spellDataRequested
local thrownType, fishingPoleType, throwName
local unavailableReason
local panel, statusText, toastCheck, loginToast
local modeButtons = {}

local function Message(message)
    print("|cff69ccf0MeffortThrow:|r " .. message)
end

local function StopMouselook()
    if not ownMouselook then return end
    ownMouselook = false
    events:SetScript("OnUpdate", nil)
    MouselookStop()
end

local function CheckMouselookRelease()
    if not IsMouseButtonDown("RightButton") then StopMouselook() end
end

local function HandleClick(_, button, down)
    if button ~= "RightButton" then return end
    if not down then
        StopMouselook()
    elseif activeMode == "right" and not ownMouselook and not IsMouselooking() then
        if MouselookStart() ~= false then
            ownMouselook = true
            events:SetScript("OnUpdate", CheckMouselookRelease)
        end
    end
end

local function ClearBinding()
    if not activeMode then return end
    UnregisterStateDriver(controller, "throw")
    ClearOverrideBindings(controller)
    controller:SetAttribute("state-throw", nil)
    activeMode = nil
end

local function InitSecureFrames()
    attackButton = CreateFrame("Button", "MeffortThrowAttackButton", UIParent, "SecureActionButtonTemplate")
    attackButton:RegisterForClicks("AnyDown", "AnyUp")
    attackButton:SetAttribute("useOnKeyDown", true)
    attackButton:SetAttribute("*type2", "macro")
    attackButton:SetScript("PostClick", HandleClick)

    controller = CreateFrame("Frame", "MeffortThrowBinding", UIParent, "SecureHandlerStateTemplate")
    controller:SetAttribute("_onstate-throw", [[
        self:ClearBindings()
        if newstate == "on" then
            self:SetBindingClick(false, self:GetAttribute("throw-key"), "MeffortThrowAttackButton", "RightButton")
        end
    ]])

    -- The default driver polls mouseover. Ask it to check promptly when the hovered unit changes.
    if SecureStateDriverManager then
        SecureStateDriverManager:RegisterEvent("UPDATE_MOUSEOVER_UNIT")
    end
end

local function ReadClientData()
    thrownType = C_Item.GetItemSubClassInfo(WEAPON_CLASS, THROWN_SUBCLASS)
    fishingPoleType = C_Item.GetItemSubClassInfo(WEAPON_CLASS, FISHING_POLE_SUBCLASS)
    throwName = C_Spell.GetSpellName(THROW_SPELL_ID)
    if not throwName and not spellDataRequested and C_Spell.RequestLoadSpellData then
        spellDataRequested = true
        C_Spell.RequestLoadSpellData(THROW_SPELL_ID)
    end
    return thrownType and fishingPoleType and throwName
end

local function ApplyMode()
    local mode = MeffortThrowDB.mode
    if mode == "off" and not activeMode then
        pending, unavailableReason = false, nil
        return
    end
    if mode == activeMode then
        pending = false
        return
    end
    if InCombatLockdown() then
        pending = true
        return
    end

    pending = false
    ClearBinding()
    unavailableReason = nil
    if mode == "off" then return end
    if not supportedClass then
        unavailableReason = "Throw shortcuts are available to Rogues and Warriors."
        return
    end
    if not (RegisterStateDriver and UnregisterStateDriver and ClearOverrideBindings and SecureCmdOptionParse
        and C_Item and C_Item.GetItemSubClassInfo and C_Spell and C_Spell.GetSpellName
        and C_Macro and C_Macro.RunMacroText) then
        unavailableReason = "This client does not provide the required secure controls."
        return
    end
    if mode == "right" and not (MouselookStart and MouselookStop and IsMouselooking and IsMouseButtonDown) then
        unavailableReason = "Camera controls are unavailable. Choose Shift + right-click."
        return
    end
    if not ReadClientData() then
        unavailableReason = "Waiting for Throw and weapon data from the client."
        return
    end
    if not SecureCmdOptionParse(("[known:%d] yes; [noknown:%d] no"):format(THROW_SPELL_ID, THROW_SPELL_ID)) then
        unavailableReason = "The client could not verify Throw."
        return
    end

    local choice = MODES[mode]
    local target = "[@mouseover,exists,harm,nodead]"
    local condition = ("[equipped:%s] off; [known:%d,equipped:%s,%s,@mouseover,exists,harm,nodead] on; off"):format(
        fishingPoleType, THROW_SPELL_ID, thrownType, choice.condition)

    -- Mouseover and equipment can change before the state driver updates.
    local action = ("/stopmacro [equipped:%s][noequipped:%s][noknown:%d]\n/target %s mouseover\n/cast %s %s"):format(
        fishingPoleType, thrownType, THROW_SPELL_ID, target, target, throwName)
    if not controller then InitSecureFrames() end
    attackButton:SetAttribute("*macrotext2", action)
    controller:SetAttribute("throw-key", choice.key)
    activeMode = mode
    local ok, result = pcall(RegisterStateDriver, controller, "throw", condition)
    if not ok or result == false then
        ClearBinding()
        unavailableReason = "The client could not register the Throw shortcut."
    end
end

local function GetMode()
    return MeffortThrowDB.mode
end

local function GetStatusText()
    if pending then
        return "Change saved. " .. MODES[activeMode or "off"].label .. " applies until combat ends."
    end
    if unavailableReason then return unavailableReason end
    if not activeMode then return "Normal right-click controls are active." end

    local state = SecureCmdOptionParse(("[equipped:%s] pole; [noknown:%d] spell; [noequipped:%s] weapon; ready"):format(
        fishingPoleType, THROW_SPELL_ID, thrownType))
    return SETUP_HINTS[state] or "The client could not check your equipment."
end

local function RefreshPanel()
    if not panel or not panel:IsShown() then return end
    for _, mode in ipairs(MODE_ORDER) do
        local button = modeButtons[mode]
        if GetMode() == mode then
            button:LockHighlight()
        else
            button:UnlockHighlight()
        end
    end
    statusText:SetText(GetStatusText())
    toastCheck:SetChecked(MeffortThrowDB.showLoginToast ~= false)
end

local function SetMode(mode)
    MeffortThrowDB.mode = mode
    ApplyMode()
    RefreshPanel()
    if pending and not (panel and panel:IsShown()) then
        Message("Change saved. It will apply after combat.")
    end
end

local function SelectMode(mode)
    if modeSetting then modeSetting:SetValue(mode) else SetMode(mode) end
end

local function CreatePanel()
    local dialog = CreateFrame("Frame", "MeffortThrowSettings", UIParent, "BasicFrameTemplateWithInset")
    dialog:Hide()
    dialog:SetSize(390, 174)
    dialog:SetPoint("CENTER")
    dialog:SetFrameStrata("DIALOG")
    dialog:SetClampedToScreen(true)
    dialog:EnableMouse(true)
    dialog:SetMovable(true)
    dialog.TitleText:SetText("MeffortThrow")
    table.insert(UISpecialFrames, dialog:GetName())

    local header = CreateFrame("Frame", nil, dialog)
    header:SetPoint("TOPLEFT", dialog, "TOPLEFT", 4, 0)
    header:SetPoint("TOPRIGHT", dialog, "TOPRIGHT", -28, 0)
    header:SetHeight(20)
    header:EnableMouse(true)
    header:RegisterForDrag("LeftButton")
    header:SetScript("OnDragStart", function() dialog:StartMoving() end)
    header:SetScript("OnDragStop", function() dialog:StopMovingOrSizing() end)
    dialog:SetScript("OnHide", function() dialog:StopMovingOrSizing() end)

    local icon = dialog:CreateTexture(nil, "ARTWORK")
    icon:SetSize(24, 24)
    icon:SetPoint("TOPLEFT", 20, -32)
    icon:SetTexture(ADDON_ICON)
    local label = dialog:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    label:SetPoint("LEFT", icon, "RIGHT", 8, 0)
    label:SetText("Throw shortcut")

    local previous
    for index, mode in ipairs(MODE_ORDER) do
        local selectedMode = mode
        local button = CreateFrame("Button", nil, dialog, "UIPanelButtonTemplate")
        button:SetSize(index == 2 and 144 or 98, 26)
        if previous then
            button:SetPoint("LEFT", previous, "RIGHT", 5, 0)
        else
            button:SetPoint("TOPLEFT", 20, -63)
        end
        button:SetText(MODES[mode].label)
        button:SetScript("OnClick", function() SelectMode(selectedMode) end)
        modeButtons[mode] = button
        previous = button
    end

    statusText = dialog:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    statusText:SetPoint("TOPLEFT", modeButtons.right, "BOTTOMLEFT", 0, -9)
    statusText:SetWidth(350)
    statusText:SetJustifyH("LEFT")

    toastCheck = CreateFrame("CheckButton", nil, dialog, "UICheckButtonTemplate")
    toastCheck:SetSize(25, 25)
    toastCheck:SetPoint("BOTTOMLEFT", 16, 17)
    toastCheck:SetScript("OnClick", function(self)
        MeffortThrowDB.showLoginToast = self:GetChecked() and true or false
    end)
    local toastLabel = dialog:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    toastLabel:SetPoint("LEFT", toastCheck, "RIGHT", 4, 0)
    toastLabel:SetText("Show login toast")

    dialog:SetScript("OnShow", RefreshPanel)
    return dialog
end

local function OpenPanel()
    if loginToast then loginToast:Hide() end
    panel = panel or CreatePanel()
    panel:Show()
    panel:Raise()
end

local function ShowLoginToast()
    if MeffortThrowDB.showLoginToast == false or (panel and panel:IsShown()) then return end

    local toast = CreateFrame("Button", nil, UIParent, "BackdropTemplate")
    loginToast = toast
    toast:SetSize(296, 60)
    toast:SetPoint("TOP", UIParent, "TOP", 0, -118)
    toast:SetFrameStrata("DIALOG")
    toast:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        edgeSize = 20,
        insets = { left = 5, right = 5, top = 5, bottom = 5 },
    })
    toast:SetBackdropColor(.12, .09, .065, .96)
    toast:SetBackdropBorderColor(.9, .72, .42)
    toast:SetScript("OnClick", OpenPanel)

    local highlight = toast:CreateTexture(nil, "HIGHLIGHT")
    highlight:SetPoint("TOPLEFT", 5, -5)
    highlight:SetPoint("BOTTOMRIGHT", -5, 5)
    highlight:SetColorTexture(1, .82, .45, .14)

    local close = CreateFrame("Button", nil, toast, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", 1, 0)
    close:SetScript("OnClick", function() toast:Hide() end)

    local icon = toast:CreateTexture(nil, "ARTWORK")
    icon:SetSize(34, 34)
    icon:SetPoint("LEFT", 14, 0)
    icon:SetTexture(ADDON_ICON)
    local title = toast:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    title:SetPoint("TOPLEFT", 57, -13)
    title:SetText("MeffortThrow")
    local text = toast:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    text:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -5)
    text:SetText("Click here or type /mthrow for settings.")
    C_Timer.After(8, function() toast:Hide() end)
end

local function RegisterSettings()
    if not (Settings and Settings.RegisterVerticalLayoutCategory and Settings.RegisterProxySetting
        and Settings.VarType and Settings.CreateControlTextContainer and Settings.CreateDropdown
        and Settings.RegisterAddOnCategory) then return end

    local function Options()
        local container = Settings.CreateControlTextContainer()
        for _, mode in ipairs(MODE_ORDER) do
            container:Add(mode, MODES[mode].label)
        end
        return container:GetData()
    end

    local category = Settings.RegisterVerticalLayoutCategory("MeffortThrow")
    modeSetting = Settings.RegisterProxySetting(category, "MeffortThrow_Mode", Settings.VarType.String,
        "Throw shortcut", "right", GetMode, SetMode)
    Settings.CreateDropdown(category, modeSetting, Options,
        "Targets a living enemy under the cursor and uses Throw. Requires a thrown weapon and the Throw skill.")
    Settings.RegisterAddOnCategory(category)
end

local function SlashCommand(text)
    local command = text:match("^%s*(%S*)%s*$")
    command = command and command:lower()
    if command == "on" then command = "right" end
    if MODES[command] then
        SelectMode(command)
        if not pending then Message(MODES[GetMode()].label .. ". " .. GetStatusText()) end
    elseif command == "status" then
        Message(MODES[GetMode()].label .. " selected. " .. GetStatusText())
    elseif command == "" then
        OpenPanel()
    else
        Message("Use /mthrow on, shift, off, or status.")
    end
end

events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("PLAYER_ENTERING_WORLD")
events:RegisterEvent("SPELLS_CHANGED")
events:RegisterEvent("SPELL_DATA_LOAD_RESULT")
events:RegisterEvent("PLAYER_REGEN_ENABLED")
events:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
events:RegisterEvent("GLOBAL_MOUSE_UP")
events:RegisterEvent("PLAYER_LEAVING_WORLD")
events:SetScript("OnEvent", function(_, event, detail, success)
    if event == "PLAYER_LOGIN" then
        local _, class = UnitClass("player")
        supportedClass = class == "ROGUE" or class == "WARRIOR"
        if type(MeffortThrowDB) ~= "table" then MeffortThrowDB = {} end
        if not MODES[MeffortThrowDB.mode] then MeffortThrowDB.mode = "right" end
        SLASH_MEFFORTTHROW1 = "/meffortthrow"
        SLASH_MEFFORTTHROW2 = "/mthrow"
        SlashCmdList.MEFFORTTHROW = SlashCommand
        RegisterSettings()
        ApplyMode()
    elseif event == "PLAYER_LEAVING_WORLD" or (event == "GLOBAL_MOUSE_UP" and detail == "RightButton") then
        StopMouselook()
    elseif event == "PLAYER_EQUIPMENT_CHANGED" then
        RefreshPanel()
    elseif MeffortThrowDB and (event == "PLAYER_ENTERING_WORLD" or event == "SPELLS_CHANGED"
        or (event == "SPELL_DATA_LOAD_RESULT" and detail == THROW_SPELL_ID and success)
        or (event == "PLAYER_REGEN_ENABLED" and pending)) then
        ApplyMode()
        RefreshPanel()
        if event == "PLAYER_ENTERING_WORLD" and (detail or success) and supportedClass
            and MeffortThrowDB.showLoginToast ~= false then
            C_Timer.After(2, ShowLoginToast)
        end
    end
end)
