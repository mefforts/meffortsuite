# MeffortThrow

Right-click a living enemy to target it and use **Throw** in World of Warcraft: Forever. MeffortThrow is a standalone addon for Rogues and Warriors with Throw learned and a thrown weapon equipped.

## Installation

Extract the ZIP and place the `MeffortThrow` folder in your client's `Interface/AddOns` directory.

## Controls

Type `/mthrow` or `/meffortthrow` to open the settings window. You can also change the Throw shortcut in **Options > AddOns > MeffortThrow**.

- **Right-click** is the default. Holding the button lets you turn the camera.
- **Shift + right-click** keeps the normal right-click action and moves Throw to a separate shortcut.
- **Off** disables the shortcut.

Settings are saved per character. Changes made in combat apply when combat ends. You can also use `/mthrow on`, `/mthrow shift`, `/mthrow off`, and `/mthrow status`.

Rogues and Warriors see a clickable `/mthrow` reminder after login or reload. Turn off **Show login toast** in the settings window to hide it.

Normal interactions remain available for friendly targets and corpses. The shortcut pauses while a fishing pole is equipped. If you use MeffortSuite alongside MeffortThrow, turn off the suite's ranged shortcut to give MeffortThrow control of the same click.

Licensed under MIT. See `LICENSE`.
