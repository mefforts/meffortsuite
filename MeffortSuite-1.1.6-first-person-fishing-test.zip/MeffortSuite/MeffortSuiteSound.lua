MeffortSuiteSound={}
local M=MeffortSuiteSound
local events=CreateFrame("Frame")
local away,busy,nativeApplied,nativeSuppressed=false,false,false,false
local nativeStatus,fileStatus="off","off"
local fileRecovery=false
local function Secret(v)
    if type(issecretvalue)~="function" then return false end
    local ok,result=pcall(issecretvalue,v)
    return not ok or result==true
end
local function Text(v)if not Secret(v) and type(v)=="string" then return v end end
local function DB()
    if type(MeffortSuiteDB)~="table" then MeffortSuiteDB={} end
    return MeffortSuiteDB
end
local function Read(fn,...)
    if type(fn)~="function" then return end
    local ok,v=pcall(fn,...)
    if ok and not Secret(v) then return v end
end
local function Call(operation,fn,...)
    if type(fn)~="function" then return false end
    if MeffortSuite and type(MeffortSuite.TryClientCall)=="function" then
        return MeffortSuite.TryClientCall("Sound",operation,fn,...)
    end
    return pcall(fn,...)
end
local function NativeValue()
    local value=Read(C_CVar and C_CVar.GetCVar or GetCVar,"Sound_EnablePetSounds")
    if Secret(value) or (type(value)~="string" and type(value)~="number") then return end
    local n=tonumber(value)
    if n==0 or n==1 then return tostring(value),n end
end
local function Write(value)
    busy=true
    local ok,result=Call("pet sound setting",C_CVar and C_CVar.SetCVar or SetCVar,"Sound_EnablePetSounds",value)
    busy=false
    return ok and not Secret(result) and result~=false
end
local function ID(v)
    if Secret(v) or type(v)~="number" or v~=v or v<1 or v>2147483647 or v~=math.floor(v) then return end
    return v
end
local function Parse(value)
    value=Text(value)
    if not value or #value>500 then return nil,"Use up to 500 characters of numeric sound-file IDs." end
    local set,list={},{}
    for token in value:gsub(","," "):gmatch("%S+") do
        if not token:match("^%d+$") then return nil,"Use sound-file IDs separated by commas or spaces." end
        local id=ID(tonumber(token))
        if not id then return nil,"Sound-file IDs must be whole numbers from 1 to 2147483647." end
        if not set[id] then
            list[#list+1]=id;set[id]=true
            if #list>64 then return nil,"Use at most 64 sound-file IDs." end
        end
    end
    table.sort(list)
    local formatted={};for i,id in ipairs(list)do formatted[i]=tostring(id)end
    local spaced=table.concat(formatted,", ")
    return set,#spaced<=500 and spaced or table.concat(formatted,",")
end
function M.NativeEnabled()return DB().petSoundsMuted==true end
function M.FilesEnabled()return DB().petSoundFilesEnabled==true end
function M.Files()return Text(DB().petSoundFiles) or "" end
function M.NativeAvailable()local _,value=NativeValue();return value~=nil end
function M.FilesAvailable()return type(MuteSoundFile)=="function" and type(UnmuteSoundFile)=="function"end
local function Active()return not away and (not MeffortSuite or not MeffortSuite.Active or MeffortSuite.Active())end
local function RestoreNative()
    nativeApplied=false
    local original=Text(DB().petSoundRestore)
    if original~="0" and original~="1" then DB().petSoundRestore=nil;return true end
    local _,value=NativeValue()
    if value==nil then return false end
    if value==0 then
        Write(original)
        local _,after=NativeValue()
        if after~=tonumber(original) then return false end
    end
    DB().petSoundRestore=nil
    return true
end
local function Ledger()
    if type(DB().petSoundFileRestore)~="table" then DB().petSoundFileRestore={} end
    return DB().petSoundFileRestore
end
local function SyncFiles(desired)
    local owned=Ledger()
    local pending=0
    for id,value in pairs(owned) do
        if not ID(id) or value~=true then owned[id]=nil
        elseif not desired[id] then
            local ok,result=Call("restore sound file",UnmuteSoundFile,id)
            if ok and not Secret(result) and result~=false then owned[id]=nil else pending=pending+1 end
        end
    end
    local count,failed=0,false
    for id in pairs(desired) do
        if not owned[id] then
            local ok,result=Call("mute sound file",MuteSoundFile,id)
            if ok and not Secret(result) and result~=false then owned[id]=true else failed=true end
        end
        if owned[id] then count=count+1 end
    end
    if not next(owned) then DB().petSoundFileRestore=nil end
    return count,pending,failed
end
function M.Refresh()
    if busy then return end
    local active=Active()
    local nativeEnabled,filesEnabled=M.NativeEnabled(),M.FilesEnabled()
    local pauseStatus=away and "waiting to enter the world" or "suite off"
    if not active or not nativeEnabled then
        nativeStatus=RestoreNative() and (nativeEnabled and pauseStatus or "off") or "prior pet-sound setting restoration pending"
    elseif nativeSuppressed then nativeStatus="changed in game; toggle off/on to reapply"
    elseif not nativeApplied then
        local _,value=NativeValue()
        if value==nil then nativeStatus="native pet-sound setting unavailable"
        elseif value==0 then nativeApplied=true;nativeStatus="already muted in game"
        else
            DB().petSoundRestore="1"
            Write("0")
            local _,after=NativeValue()
            if after==0 then nativeApplied=true;nativeStatus="native pet category muted"
            elseif after~=nil then DB().petSoundRestore=nil;nativeStatus="pet-sound setting was not changed"
            else nativeStatus="pet-sound change awaiting verification" end
        end
    end
    if fileRecovery then
        local _,pending=SyncFiles({})
        if pending>0 then fileStatus=pending.." sound-file restorations pending";return end
        fileRecovery=false
    end
    local desired={}
    local filesAvailable=M.FilesAvailable()
    if active and filesEnabled and filesAvailable then desired=Parse(M.Files()) or {} end
    local count,pending,failed=SyncFiles(desired)
    if not active or not filesEnabled then fileRecovery=pending>0 end
    if pending>0 then fileStatus=pending.." sound-file restorations pending"
    elseif not filesEnabled then fileStatus="off"
    elseif not active then fileStatus=pauseStatus
    elseif not filesAvailable then fileStatus="sound-file mute API unavailable"
    elseif not next(desired) then fileStatus="add verified sound-file IDs first"
    elseif failed then fileStatus="some sound-file requests were refused"
    else fileStatus=count.." selected sound files muted" end
end
function M.SetNativeEnabled(value)
    DB().petSoundsMuted=value==true;nativeSuppressed=false;M.Refresh()
end
function M.SetFilesEnabled(value)DB().petSoundFilesEnabled=value==true;M.Refresh()end
function M.SetFiles(value)
    local set,formatted=Parse(value)
    if not set then return false,formatted end
    DB().petSoundFiles=formatted;M.Refresh();return true
end
function M.CleanupComplete()
    return DB().petSoundRestore==nil and (type(DB().petSoundFileRestore)~="table" or next(DB().petSoundFileRestore)==nil)
end
function M.Status()return "Pet category: "..nativeStatus.."; targeted files: "..fileStatus end
function M.NativeStatus()return nativeStatus end
function M.FileStatus()return fileStatus end
for _,event in ipairs({"PLAYER_LOGIN","PLAYER_LOGOUT","PLAYER_LEAVING_WORLD","PLAYER_ENTERING_WORLD","PLAYER_REGEN_ENABLED","CVAR_UPDATE"})do
    pcall(events.RegisterEvent,events,event)
end
events:SetScript("OnEvent",function(_,event,key)
    if event=="CVAR_UPDATE" then
        key=Text(key)
        if busy or not key or key:lower()~="sound_enablepetsounds" then return end
        local _,value=NativeValue()
        if nativeApplied and value==1 then
            DB().petSoundRestore=nil;nativeApplied=false;nativeSuppressed=true
            nativeStatus="changed in game; toggle off/on to reapply"
        end
        return
    end
    if event=="PLAYER_LOGOUT" or event=="PLAYER_LEAVING_WORLD" then away=true
    elseif event=="PLAYER_ENTERING_WORLD" then away=false
    elseif event=="PLAYER_LOGIN" then
        RestoreNative()
        local _,pending=SyncFiles({});fileRecovery=pending>0
    end
    M.Refresh()
end)
