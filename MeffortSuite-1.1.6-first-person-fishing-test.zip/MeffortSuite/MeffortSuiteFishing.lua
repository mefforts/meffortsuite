MeffortSuiteFishing = {}
local module = MeffortSuiteFishing
local tracker = CreateFrame("Frame")
local bindingOwner, castButton
local doubleWindow,releaseWindow=0.5,0.85
local sequence
local castSpell
local lastCast=-math.huge
local lootOpen,away,deferredClear=false,false,false
local releaseEventAvailable,initializationAttempted=false,false
local lastResult="waiting for a double right-click"

local function Message(message)
    if MeffortSuite and MeffortSuite.Message then
        MeffortSuite.Message("Fishing: "..message)
    end
end
local function InLockdown()
    return type(InCombatLockdown)=="function" and InCombatLockdown()==true
end
local function Settings()
    if type(MeffortSuiteCharDB)~="table" then MeffortSuiteCharDB={} end
    if MeffortSuiteCharDB.fishingRightClick==nil then
        MeffortSuiteCharDB.fishingRightClick=true
    end
    return MeffortSuiteCharDB
end
function module.Enabled() return Settings().fishingRightClick==true end

-- An uncached equipped item may have an ID before its link is available.
function module.IsPoleEquipped()
    if type(IsEquippedItemType)=="function" then
        local ok,yes=pcall(IsEquippedItemType,"Fishing Poles")
        if ok and yes then return true end
    end
    local link
    if type(GetInventoryItemLink)=="function" then
        local ok,value=pcall(GetInventoryItemLink,"player",16)
        if ok then link=value end
    end
    if not link and type(GetInventoryItemID)=="function" then
        local ok,value=pcall(GetInventoryItemID,"player",16)
        if ok then link=value end
    end
    if not link then return false end
    local instant = type(GetItemInfoInstant)=="function" and GetItemInfoInstant
        or (C_Item and type(C_Item.GetItemInfoInstant)=="function" and C_Item.GetItemInfoInstant)
    if instant then
        local ok,_,_,_,_,_,classID,subclassID=pcall(instant,link)
        if ok and classID==2 and (subclassID==20 or subclassID==25) then return true end
    end
    if type(GetItemInfo)=="function" then
        local ok,_,_,_,_,_,_,subclass=pcall(GetItemInfo,link)
        if ok and type(subclass)=="string" and
            subclass:lower():find("fishing pole",1,true) then return true end
    end
    return false
end

local function FishingSpell()
    if castSpell then return castSpell end
    if C_Spell and type(C_Spell.GetSpellInfo)=="function" then
        local ok,info=pcall(C_Spell.GetSpellInfo,7620)
        if ok and type(info)=="table" and type(info.name)=="string" then
            castSpell=info.name
            return castSpell
        end
    end
    if C_Spell and type(C_Spell.GetSpellName)=="function" then
        local ok,name=pcall(C_Spell.GetSpellName,7620)
        if ok and type(name)=="string" and name~="" then
            castSpell=name
            return name
        end
    end
    if type(GetSpellInfo)=="function" then
        local ok,name=pcall(GetSpellInfo,7620)
        if ok and type(name)=="string" then castSpell=name;return name end
    end
    return "Fishing" -- Leave the fallback uncached until localized data loads.
end
function module.IsFishingSpell(id,name)
    if issecretvalue and issecretvalue(name) then name=nil end
    if not (issecretvalue and issecretvalue(id)) then
        if id==7620 or id==131474 or id==131476 then return true end
        if type(id)=="number" and not name then
            local getter=C_Spell and C_Spell.GetSpellName or GetSpellInfo
            if type(getter)=="function" then
                local ok,value=pcall(getter,id)
                if ok then name=value end
            end
        end
    end
    return (not issecretvalue or not issecretvalue(name)) and type(name)=="string" and name==FishingSpell()
end
local function PlayerChannel()
    if type(UnitChannelInfo)~="function" then return false,false end
    local ok,name,_,_,_,_,_,_,id=pcall(UnitChannelInfo,"player")
    if not ok then return true,false end
    if module.IsFishingSpell(id,name) then return true,true end
    return (issecretvalue and issecretvalue(name)) or type(name)=="string",false
end
function module.IsFishingChannel()
    local _,fishing=PlayerChannel()
    return fishing
end

function module.InteractEnabled()
    local getter=C_CVar and C_CVar.GetCVar or GetCVar
    if type(getter)~="function" then return false end
    local ok,value=pcall(getter,"SoftTargetInteract")
    if not ok or (issecretvalue and issecretvalue(value)) then return false end
    local flags=tonumber(value)
    return flags==2 or flags==3
end
local function WorldClick()
    local focus,available
    -- GetMouseFoci returns a frame list; GetMouseFocus returns a single frame.
    if type(GetMouseFoci)=="function" then
        local ok,value=pcall(GetMouseFoci)
        available=ok
        if ok and type(value)=="table" then
            focus=type(value.GetParent)=="function" and value or value[1]
        elseif ok then focus=value end
    end
    if not focus and type(GetMouseFocus)=="function" then
        local ok,value=pcall(GetMouseFocus)
        available=available or ok
        if ok then focus=value end
    end
    if not available or not WorldFrame then return false end
    if not focus or focus==UIParent then return true end
    for _=1,8 do
        if focus==WorldFrame then return true end
        if type(focus.GetParent)~="function" then break end
        local ok,parent=pcall(focus.GetParent,focus)
        if not ok or not parent or parent==focus then break end
        focus=parent
    end
    return false
end
local function Action()
    if not module.Enabled() or not MeffortSuite or not MeffortSuite.Active()
        or away or lootOpen or InLockdown() or not module.IsPoleEquipped() then return end
    local channeling,fishing=PlayerChannel()
    if fishing then
        if module.InteractEnabled() then return "interact" end
    elseif not channeling then
        return "cast"
    end
end

local function Clear()
    local hadBinding=sequence and sequence.bound
    sequence=nil
    tracker:SetScript("OnUpdate",nil)
    if not hadBinding and not deferredClear then return end
    -- The secure state driver removes the binding during combat.
    deferredClear=true
    if InLockdown() or not bindingOwner then return end
    local ok=pcall(bindingOwner.Execute,bindingOwner,[[self:ClearBindings()]])
    pcall(castButton.SetAttribute,castButton,"type",nil)
    deferredClear=not ok
end

local function Within(start,seconds)
    local age=GetTime()-start
    return age>=0 and age<=seconds
end
local function Watch()
    local click=sequence
    if not click or Action()~=click.action or not WorldClick()
        or not Within(click.secondDown or click.firstDown,click.secondDown and releaseWindow or doubleWindow) then
        Clear()
    end
end

local function Bind(click)
    -- The next physical right-click runs the native binding or presses the secure spell button.
    click.bound=true
    local ok=pcall(function()
        if click.action=="interact" then
            bindingOwner:Execute([[self:SetBinding(true,"BUTTON2","INTERACTTARGET")]])
        else
            castButton:SetAttribute("spell",FishingSpell())
            castButton:SetAttribute("type","spell")
            bindingOwner:Execute([[self:SetBindingClick(true,"BUTTON2","MeffortSuiteFishingCastButton","RightButton")]])
        end
    end)
    if not ok then
        Clear()
        lastResult="mouse binding rejected"
    else
        lastResult="waiting for the second click to "..click.action
    end
end

function module.Refresh()
    if deferredClear or (sequence and Action()~=sequence.action) then Clear() end
end
function module.SetEnabled(value)
    Settings().fishingRightClick=value==true
    Clear()
end
function module.Command(argument)
    local cmd=(argument or ""):lower():match("^%s*(.-)%s*$")
    if cmd=="on" or cmd=="off" or cmd=="double" then
        module.SetEnabled(cmd~="off")
        Message("double right-click fishing "..(module.Enabled() and "enabled" or "disabled"))
    elseif cmd=="status" or cmd=="debug" or cmd=="" then
        Message("double right-click "..(module.Enabled() and "on" or "off")
            ..", pole "..(module.IsPoleEquipped() and "equipped" or "needed")
            ..", Interact Key "..(module.InteractEnabled() and "on" or "off")
            ..", line "..(module.IsFishingChannel() and "out" or "idle")
            ..". Input: "..lastResult..".")
    else
        Message("/msuite fishing on|off|status|settings")
    end
end

local function OnMouseDown(button)
    if button~="RightButton" then
        if sequence then Clear() end
        return
    end
    if not bindingOwner or (type(IsMouseButtonDown)=="function" and IsMouseButtonDown("LeftButton")) then
        Clear()
        return
    end
    local action=Action()
    if not action or not WorldClick() then Clear();return end
    local click=sequence
    if click and click.bound and not click.secondDown and action==click.action and Within(click.firstDown,doubleWindow) then
        click.secondDown=GetTime()
        lastResult="second click received for "..action
        return
    end
    Clear()
    if deferredClear or (action=="cast" and GetTime()-lastCast<0.6) then return end
    sequence={action=action,firstDown=GetTime()}
    tracker:SetScript("OnUpdate",Watch)
end
local function OnMouseUp(button)
    local click=sequence
    if button~="RightButton" or not click then return end
    -- Defer binding changes until this physical release has finished dispatching.
    C_Timer.After(0,function()
        if sequence~=click then return end
        if click.bound then Clear();return end
        Watch()
        if sequence==click then Bind(click) end
    end)
end

local function Initialize()
    if bindingOwner or initializationAttempted or InLockdown() then return end
    initializationAttempted=true
    if not releaseEventAvailable or type(RegisterStateDriver)~="function"
        or not (C_Timer and type(C_Timer.After)=="function") then
        lastResult="secure mouse binding unavailable"
        return
    end
    local owner
    local ok=pcall(function()
        owner=CreateFrame("Frame","MeffortSuiteFishingSecureController",UIParent,"SecureHandlerStateTemplate")
        if type(owner.Execute)~="function" then error("restricted execution unavailable") end
        owner:SetAttribute("_onstate-fishcombat",[[
            if newstate == "off" then
                local button=self:GetFrameRef("cast")
                if button then button:SetAttribute("type",nil) end
                self:ClearBindings()
            end
        ]])
        if RegisterStateDriver(owner,"fishcombat","[combat] off; on")==false then
            error("secure combat state unavailable")
        end
        local button=CreateFrame("Button","MeffortSuiteFishingCastButton",UIParent,"SecureActionButtonTemplate")
        button:RegisterForClicks("AnyUp")
        button:SetAttribute("useOnKeyDown",false)
        button:SetScript("PostClick",function(self,mouse,down)
            if mouse=="RightButton" and not down and self:GetAttribute("type")=="spell" then
                lastCast=GetTime()
                lastResult="casting button received the second release"
            end
        end)
        owner:SetFrameRef("cast",button)
        owner:Execute([[self:ClearBindings()]])
        bindingOwner,castButton=owner,button
    end)
    if not ok then
        if owner and type(UnregisterStateDriver)=="function" then pcall(UnregisterStateDriver,owner,"fishcombat") end
        lastResult="secure mouse binding setup rejected"
        Message("Secure right-click fishing could not initialize. Normal mouse controls remain active.")
    end
end
function module.Available()
    if bindingOwner then return true end
    return false,InLockdown() and "Right-click fishing will initialize after combat."
        or "Secure right-click fishing is unavailable. Normal mouse controls remain active."
end

for _,event in ipairs({"PLAYER_LOGIN","PLAYER_ENTERING_WORLD","PLAYER_LEAVING_WORLD","PLAYER_LOGOUT",
    "GLOBAL_MOUSE_DOWN","PLAYER_EQUIPMENT_CHANGED","PLAYER_REGEN_ENABLED","PLAYER_REGEN_DISABLED",
    "SPELLS_CHANGED","LOOT_OPENED","LOOT_CLOSED","CVAR_UPDATE"}) do
    tracker:RegisterEvent(event)
end
for _,event in ipairs({"UNIT_SPELLCAST_CHANNEL_START","UNIT_SPELLCAST_CHANNEL_STOP","UNIT_SPELLCAST_INTERRUPTED",
    "UNIT_SPELLCAST_FAILED","UNIT_SPELLCAST_START","UNIT_SPELLCAST_STOP"}) do
    tracker:RegisterUnitEvent(event,"player")
end
do
    local ok,result=pcall(tracker.RegisterEvent,tracker,"GLOBAL_MOUSE_UP")
    releaseEventAvailable=ok and result~=false
end
tracker:SetScript("OnEvent",function(_,event,unit)
    if event=="GLOBAL_MOUSE_DOWN" then OnMouseDown(unit);return end
    if event=="GLOBAL_MOUSE_UP" then OnMouseUp(unit);return end
    if event=="CVAR_UPDATE" then
        if (not issecretvalue or not issecretvalue(unit)) and type(unit)=="string"
            and unit:lower()=="softtargetinteract" then module.Refresh() end
        return
    end
    if event=="PLAYER_LOGIN" or event=="PLAYER_REGEN_ENABLED" then Initialize() end
    if event=="PLAYER_ENTERING_WORLD" then away=false;lootOpen=false end
    if event=="PLAYER_LEAVING_WORLD" or event=="PLAYER_LOGOUT" then away=true end
    if event=="SPELLS_CHANGED" then castSpell=nil end
    if event=="LOOT_OPENED" then lootOpen=true end
    if event=="LOOT_CLOSED" then lootOpen=false end
    Clear()
end)
