MeffortSuiteBackpack={}
local M=MeffortSuiteBackpack
local events=CreateFrame("Frame")
local ready,away,busy,applied,suppressed,failed=false,false,false,false,false,false
local status="waiting for login"
local KEY="displayFreeBagSlots"
local function Secret(v)
    if type(issecretvalue)~="function" then return false end
    local ok,result=pcall(issecretvalue,v)
    return not ok or result==true
end
local function Read(fn,...)
    if type(fn)~="function" then return end
    local ok,value=pcall(fn,...)
    if ok and not Secret(value) then return value end
end
local function DB()
    if type(MeffortSuiteDB)~="table" then MeffortSuiteDB={} end
    return MeffortSuiteDB
end
local function Value()
    local value=Read(C_CVar and C_CVar.GetCVar or GetCVar,KEY)
    if value=="0" or value==0 then return 0 end
    if value=="1" or value==1 then return 1 end
end
local function Write(value,operation)
    local setter=C_CVar and C_CVar.SetCVar or SetCVar
    if type(setter)~="function" then return false end
    busy=true
    local ok,result
    if MeffortSuite and type(MeffortSuite.TryClientCall)=="function" then
        ok,result=MeffortSuite.TryClientCall("Backpack",operation,setter,KEY,value)
    else ok,result=pcall(setter,KEY,value) end
    busy=false
    return ok and not Secret(result) and result~=false
end
local function Restore()
    applied=false
    local original=DB().backpackCountRestore
    if original~="0" and original~="1" then DB().backpackCountRestore=nil;return true end
    local current=Value()
    if current==nil then return false end
    if current~=tonumber(original) then
        if current~=1 then DB().backpackCountRestore=nil;return true end
        if not Write(original,"restore native count") or Value()~=tonumber(original) then return false end
    end
    DB().backpackCountRestore=nil
    return true
end
function M.Enabled()return DB().backpackFreeSlots~=false end
function M.Refresh()
    if busy or not ready then return end
    if Read(InCombatLockdown)~=false then status="changes wait until combat ends";return end
    local active=not away and M.Enabled() and (not MeffortSuite or not MeffortSuite.Active or MeffortSuite.Active())
    if not active then
        status=Restore() and "prior game setting restored" or "native count restoration pending";return
    end
    if suppressed then status="changed in game; toggle off/on to reapply";return end
    if failed then status="native count request refused; reload to retry";return end
    local current=Value()
    if current==nil then status="native backpack counter unavailable";return end
    if current==1 then applied=true;status="native backpack counter on";return end
    if applied then
        DB().backpackCountRestore=nil;applied=false;suppressed=true
        status="changed in game; toggle off/on to reapply";return
    end
    DB().backpackCountRestore="0"
    local accepted=Write("1","enable native count")
    local after=Value()
    if accepted and after==1 then applied=true;status="native backpack counter on"
    else
        failed=true;status="native count request refused; reload to retry"
        if after==0 then DB().backpackCountRestore=nil end
    end
end
function M.SetEnabled(value)
    DB().backpackFreeSlots=value==true;suppressed=false
    if not M.Enabled() then failed=false end
    M.Refresh()
end
function M.Status()return (M.Enabled() and "enabled; " or "disabled; ")..status end
for _,event in ipairs({"PLAYER_LOGIN","PLAYER_ENTERING_WORLD","PLAYER_LEAVING_WORLD","PLAYER_LOGOUT","PLAYER_REGEN_ENABLED","CVAR_UPDATE"})do
    pcall(events.RegisterEvent,events,event)
end
events:SetScript("OnEvent",function(_,event,key)
    if event=="CVAR_UPDATE" then
        if busy or Secret(key) or type(key)~="string" or key:lower()~=KEY:lower() then return end
        if applied and Value()==0 then
            DB().backpackCountRestore=nil;applied=false;suppressed=true
            status="changed in game; toggle off/on to reapply"
        end
        return
    end
    if event=="PLAYER_LOGIN" then
        ready=true
        if Read(InCombatLockdown)==false then Restore() end
    elseif event=="PLAYER_ENTERING_WORLD" then ready=true;away=false
    elseif event=="PLAYER_LEAVING_WORLD" or event=="PLAYER_LOGOUT" then away=true end
    M.Refresh()
end)
