local module = {}
MeffortSuiteActionText = module

local buttonPrefixes = {
    "ActionButton", "MultiBarBottomLeftButton", "MultiBarBottomRightButton",
    "MultiBarLeftButton", "MultiBarRightButton",
    "MultiBar5Button", "MultiBar6Button", "MultiBar7Button",
    "PetActionButton", "StanceButton", "BonusActionButton",
}
local original = setmetatable({}, { __mode = "k" })
local nativeColors = setmetatable({}, { __mode = "k" })
local appliedColors = setmetatable({}, { __mode = "k" })
local hotkeyHooked,rangeHooked=false,false
local pending = false
local panel, previewText, previewSquare, stateText, controls, backToBars
local PANEL_WIDTH, PANEL_HEIGHT = 465, 575
local fontFallback = STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
local applying, syncingControls = false, false
local positionPending = false
local lastError
local defaultSize,defaultX,defaultY = 20,-15,-15

local function Clamp(v,lo,hi,fallback)
    v=tonumber(v)
    if not v or v~=v or v==math.huge or v==-math.huge then v=fallback or 0 end
    return math.max(lo,math.min(hi,v))
end
local function DB()
    if type(MeffortSuiteDB)~="table" then MeffortSuiteDB={} end
    local s=MeffortSuiteDB.actionText
    if type(s)~="table" then s={};MeffortSuiteDB.actionText=s end
    if type(s.enabled)~="boolean" then s.enabled=true end
    s.size=Clamp(s.size,8,24,defaultSize)
    s.x=math.floor(Clamp(s.x,-22,22,defaultX)+0.5)
    s.y=math.floor(Clamp(s.y,-22,22,defaultY)+0.5)
    if type(s.hex)~="string" or not s.hex:match("^%x%x%x%x%x%x$") then s.hex="fff0c2" end
    if type(s.outline)~="boolean" then s.outline=true end
    if type(s.shadow)~="boolean" then s.shadow=true end
    if type(s.position)~="string" then s.position="custom" end
    return s
end
module.GetSettings=DB
local function InCombat()
    return InCombatLockdown and InCombatLockdown() or false
end
local function MasterActive()
    return not MeffortSuiteIsActive or MeffortSuiteIsActive()
end
local function Info(msg)
    if DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then
        DEFAULT_CHAT_FRAME:AddMessage("|cff60d9bdMeffortSuite|r: "..msg)
    end
end
local function FromHex(raw)
    if type(raw)~="string" then return end
    local hex=raw:gsub("#",""):gsub("%s+","")
    if not hex:match("^%x%x%x%x%x%x$") then return end
    hex=hex:lower()
    return hex,tonumber(hex:sub(1,2),16)/255,tonumber(hex:sub(3,4),16)/255,tonumber(hex:sub(5,6),16)/255
end
local function Restricted(value)
    if type(issecretvalue)~="function" then return false end
    local ok,result=pcall(issecretvalue,value)
    return not ok or result==true
end
local function Color(fn,object)
    if type(fn)~="function" then return end
    local ok,r,g,b,a=pcall(fn,object)
    if not ok then return end
    local values={r,g,b}
    for i=1,3 do
        local value=values[i]
        if Restricted(value) then return end
        if type(value)~="number" or value~=value or value==math.huge or value==-math.huge then return end
    end
    if Restricted(a) then return end
    if a==nil then a=1
    elseif type(a)~="number" or a~=a or a==math.huge or a==-math.huge then return end
    return {r=r,g=g,b=b,a=a}
end
local function ReadColor(hotkey)return Color(hotkey.GetTextColor,hotkey)end
local function SameColor(a,b)
    return a and b and math.abs(a.r-b.r)<.01 and math.abs(a.g-b.g)<.01
        and math.abs(a.b-b.b)<.01 and math.abs(a.a-b.a)<.01
end
local function Red(color)
    return color and color.r>=.55 and color.g<color.r*.68 and color.b<color.r*.68
end
local function WarningColor(hotkey,current)
    if not current then return true end
    local native=nativeColors[hotkey]
    if Red(native) and (SameColor(current,native) or SameColor(current,appliedColors[hotkey])) then return true,native end
    if Red(current) and not SameColor(current,appliedColors[hotkey]) then return true,current end
    return false
end
local function DefaultColor()
    local native=ACTIONBAR_HOTKEY_FONT_COLOR
    return native and Color(native.GetRGB,native) or {r=.6,g=.6,b=.6,a=1}
end
local function ApplyColor(hotkey)
    local preserve,color=WarningColor(hotkey,ReadColor(hotkey))
    if preserve then
        if color then hotkey:SetTextColor(color.r,color.g,color.b,color.a) end
        return
    end
    local _,r,g,b=FromHex(DB().hex)
    hotkey:SetTextColor(r,g,b,1)
    appliedColors[hotkey]=ReadColor(hotkey)
end
local function Capture(hotkey)
    if original[hotkey] then return end
    local src={ points={} }
    if hotkey.GetNumPoints and hotkey.GetPoint then
        local n=hotkey:GetNumPoints() or 0
        for i=1,math.min(n,4) do
            local point,relative,relativePoint,x,y=hotkey:GetPoint(i)
            if point then src.points[#src.points+1]={point,relative,relativePoint,x,y} end
        end
    end
    if hotkey.GetFont then src.font,src.size,src.flags=hotkey:GetFont() end
    local color=ReadColor(hotkey)
    if Red(color) then color=DefaultColor() end
    if color then src.r,src.g,src.b,src.a=color.r,color.g,color.b,color.a end
    if hotkey.GetShadowColor then src.sr,src.sg,src.sb,src.sa=hotkey:GetShadowColor() end
    if hotkey.GetShadowOffset then src.sx,src.sy=hotkey:GetShadowOffset() end
    if hotkey.GetJustifyH then src.justify=hotkey:GetJustifyH() end
    original[hotkey]=src
end
local function Restore(hotkey)
    local src=original[hotkey]
    if not src then return end
    local preserve,warning=WarningColor(hotkey,ReadColor(hotkey))
    if hotkey.SetFont and src.font then hotkey:SetFont(src.font,src.size or 12,src.flags or "") end
    if hotkey.ClearAllPoints then
        hotkey:ClearAllPoints()
        for _,point in ipairs(src.points) do
            hotkey:SetPoint(point[1],point[2],point[3],point[4],point[5])
        end
    end
    if hotkey.SetTextColor then
        if preserve then
            if warning then hotkey:SetTextColor(warning.r,warning.g,warning.b,warning.a) end
        else
            local color=nativeColors[hotkey]
            if color and not Red(color) then hotkey:SetTextColor(color.r,color.g,color.b,color.a)
            elseif src.r then hotkey:SetTextColor(src.r,src.g,src.b,src.a or 1) end
        end
    end
    if src.sr and hotkey.SetShadowColor then hotkey:SetShadowColor(src.sr,src.sg,src.sb,src.sa or 1) end
    if src.sx and hotkey.SetShadowOffset then hotkey:SetShadowOffset(src.sx,src.sy) end
    if src.justify and hotkey.SetJustifyH then hotkey:SetJustifyH(src.justify) end
    original[hotkey]=nil
    appliedColors[hotkey]=nil
end
local function Hotkey(button)
    if not button then return end
    if button.HotKey then return button.HotKey end
    local name=button.GetName and button:GetName()
    return name and _G[name.."HotKey"]
end
local function StyleButton(button)
    if not button then return end
    local hotkey=Hotkey(button)
    if not hotkey or not hotkey.SetFont or not hotkey.SetPoint then return end
    if InCombat() then pending=true;return end
    local current=ReadColor(hotkey)
    if not current then pending=true;return end
    local preserve,warning=WarningColor(hotkey,current)
    local s=DB()
    if not s.enabled or not MasterActive() then Restore(hotkey);return end
    Capture(hotkey)
    local src=original[hotkey]
    local font=src.font or fontFallback
    local flags=s.outline and "OUTLINE" or ""
    hotkey:SetFont(font,s.size,flags)
    hotkey:ClearAllPoints()
    hotkey:SetPoint("CENTER",button,"CENTER",s.x,s.y)
    if hotkey.SetJustifyH then hotkey:SetJustifyH("CENTER") end
    if hotkey.SetTextColor then
        if preserve then hotkey:SetTextColor(warning.r,warning.g,warning.b,warning.a)
        else ApplyColor(hotkey) end
    end
    if hotkey.SetShadowColor then
        if s.shadow then hotkey:SetShadowColor(0,0,0,0.96) else hotkey:SetShadowColor(0,0,0,0) end
    end
    if hotkey.SetShadowOffset then hotkey:SetShadowOffset(s.shadow and 1 or 0,s.shadow and -1 or 0) end
end
function module.ApplyAll()
    if InCombat() then pending=true;return false end
    if applying then return false end
    applying=true
    local succeeded=true
    lastError=nil
    for _,prefix in ipairs(buttonPrefixes) do
        for i=1,12 do
            local button=_G[prefix..i]
            if button then
                local ok,err=pcall(StyleButton,button)
                if not ok then
                    succeeded=false
                    pending=true
                    lastError=tostring(err)
                end
            end
        end
    end
    applying=false
    return succeeded
end
function module.LastError() return lastError end
function module.SetEnabled(value)
    DB().enabled=(value==true)
    module.ApplyAll()
end

local function Label(parent,text,x,y,template)
    local f=parent:CreateFontString(nil,"OVERLAY",template or "GameFontHighlight")
    f:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
    if f.SetWidth then f:SetWidth(math.max(30,PANEL_WIDTH-x-20)) end
    if f.SetJustifyH then f:SetJustifyH("LEFT") end
    f:SetText(text)
    return f
end
local function Button(parent,text,w,h,x,y,fn)
    local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
    b:SetSize(w,h);b:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
    b:SetText(text);b:SetScript("OnClick",fn)
    return b
end
local function UpdatePreview()
    if not panel then return end
    local s=DB()
    local _,r,g,b=FromHex(s.hex)
    if previewText then
        previewText:SetFont(fontFallback,s.size,s.outline and "OUTLINE" or "")
        previewText:SetTextColor(r or 1,g or 1,b or 1)
        if previewText.SetShadowColor then
            previewText:SetShadowColor(0,0,0,s.shadow and 1 or 0)
            previewText:SetShadowOffset(s.shadow and 1 or 0,s.shadow and -1 or 0)
        end
        previewText:ClearAllPoints()
        previewText:SetPoint("CENTER",previewSquare,"CENTER",s.x,s.y)
    end
    if stateText then
        local standalone=MeffortSuite and type(MeffortSuite.StandaloneLoaded)=="function" and
            MeffortSuite.StandaloneLoaded("MeffortBars")
        if standalone then
            stateText:SetText("MeffortBars controls the live labels while loaded.")
        elseif not MasterActive() then
            stateText:SetText("MeffortSuite is off. Use /msuite on to enable it.")
        else
            stateText:SetText(s.enabled and "Custom labels are on" or "Custom labels are off")
        end
    end
    syncingControls=true
    if controls then for _,entry in ipairs(controls) do entry() end end
    syncingControls=false
end
local function ChangePosition(x,y,kind,deferApply)
    local s=DB()
    local nextX=math.floor(Clamp(x,-22,22)+0.5)
    local nextY=math.floor(Clamp(y,-22,22)+0.5)
    s.position=kind or "custom"
    if nextX==s.x and nextY==s.y then return false end
    s.x,s.y=nextX,nextY
    UpdatePreview()
    if deferApply then positionPending=true else module.ApplyAll() end
    return true
end
local function MakeSlider(parent,title,y,min,max,get,set)
    Label(parent,title,26,y,"GameFontNormal")
    local slider=CreateFrame("Slider",nil,parent,"OptionsSliderTemplate")
    slider:SetPoint("TOPLEFT",parent,"TOPLEFT",26,y-23)
    slider:SetSize(270,17)
    slider:SetMinMaxValues(min,max)
    if slider.SetValueStep then slider:SetValueStep(1) end
    if slider.SetObeyStepOnDrag then slider:SetObeyStepOnDrag(true) end
    local value=Label(parent,"",310,y-23,"GameFontHighlight")
    slider:SetScript("OnValueChanged",function(self,v)
        local rounded=math.floor((tonumber(v) or 0)+0.5)
        value:SetText(tostring(rounded))
        if syncingControls or rounded==get() then return end
        set(rounded)
        UpdatePreview()
        module.ApplyAll()
    end)
    controls[#controls+1]=function()
        local v=get()
        if slider:GetValue()~=v then slider:SetValue(v) end
        value:SetText(tostring(v))
    end
end
local function MakeCheck(parent,text,x,y,get,set,labelWidth)
    local check=CreateFrame("CheckButton",nil,parent,"UICheckButtonTemplate")
    check:SetSize(24,24)
    check:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
    local caption=check:CreateFontString(nil,"OVERLAY","GameFontHighlight")
    caption:SetPoint("LEFT",check,"RIGHT",5,0)
    local remaining=PANEL_WIDTH-x-24-5-18
    if caption.SetWidth then caption:SetWidth(math.max(40,math.min(labelWidth or remaining,remaining))) end
    if caption.SetJustifyH then caption:SetJustifyH("LEFT") end
    if caption.SetWordWrap then caption:SetWordWrap(false) end
    caption:SetText(text)
    check:SetScript("OnClick",function(self)
        set(self:GetChecked()==true)
        module.ApplyAll()
        UpdatePreview()
    end)
    controls[#controls+1]=function() check:SetChecked(get()) end
end
local function FitPreviewToScreen()
    if not panel or not panel:IsShown() or not UIParent then return end
    local w,h=UIParent:GetWidth(),UIParent:GetHeight()
    if type(w)=="number" and w>0 and type(h)=="number" and h>0 then
        panel:SetScale(math.max(.1,math.min(1,(w-24)/PANEL_WIDTH,(h-24)/PANEL_HEIGHT)))
    end
end
local function CreatePanel()
    if panel then return panel end
    panel=CreateFrame("Frame","MeffortSuiteActionTextSettings",UIParent)
    panel:SetSize(PANEL_WIDTH,PANEL_HEIGHT)
    panel:SetPoint("CENTER",UIParent,"CENTER",0,0)
    panel:SetFrameStrata("DIALOG")
    if panel.SetClampedToScreen then panel:SetClampedToScreen(true) end
    if type(UISpecialFrames)=="table" then
        local found=false
        for _,frameName in ipairs(UISpecialFrames) do
            if frameName=="MeffortSuiteActionTextSettings" then found=true;break end
        end
        if not found then table.insert(UISpecialFrames,"MeffortSuiteActionTextSettings") end
    end
    panel:SetMovable(true);panel:EnableMouse(true);panel:RegisterForDrag("LeftButton")
    panel:SetScript("OnDragStart",function(self)self:StartMoving()end)
    panel:SetScript("OnDragStop",function(self)self:StopMovingOrSizing()end)
    local bg=panel:CreateTexture(nil,"BACKGROUND")
    bg:SetAllPoints()
    bg:SetTexture("Interface\\AddOns\\MeffortSuite\\Textures\\ParchmentPanel.tga")
    Label(panel,"Action Bar Text",22,-20,"GameFontNormalLarge")
    Label(panel,"Customize the keybind text on your action buttons.",22,-50,"GameFontHighlightSmall")
    Button(panel,"Close",65,23,376,-16,function()panel:Hide()end)
    Button(panel,"Back to Bars",135,23,227,-16,function()
        local onBack=backToBars
        panel:Hide()
        if onBack then onBack()
        elseif MeffortSuiteOpenSettings then MeffortSuiteOpenSettings("action") end
    end)
    controls={}
    MakeCheck(panel,"Customize keybind labels",20,-82,
        function()return DB().enabled end,function(v)DB().enabled=v end,302)
    stateText=Label(panel,"",24,-115,"GameFontHighlightSmall")
    Label(panel,"PLACEMENT",24,-145,"GameFontNormal")
    Button(panel,"Top-right",90,25,23,-171,function()ChangePosition(12,12,"topright")end)
    Button(panel,"Center",90,25,120,-171,function()ChangePosition(0,0,"center")end)
    local placementHelp=Label(panel,"Drag the example or adjust the offsets.",23,-210,"GameFontHighlightSmall")
    placementHelp:SetWidth(260)

    local sample=CreateFrame("Frame",nil,panel)
    sample:SetSize(146,70)
    sample:SetPoint("TOPRIGHT",panel,"TOPRIGHT",-24,-156)
    local surface=sample:CreateTexture(nil,"ARTWORK")
    surface:SetAllPoints(sample);surface:SetColorTexture(0.29,0.20,0.11,1)
    previewSquare=sample
    local border=sample:CreateTexture(nil,"BACKGROUND")
    border:SetPoint("TOPLEFT",sample,"TOPLEFT",-1,1)
    border:SetPoint("BOTTOMRIGHT",sample,"BOTTOMRIGHT",1,-1)
    border:SetColorTexture(0.66,0.49,0.26,1)
    previewText=sample:CreateFontString(nil,"OVERLAY","GameFontNormal")
    previewText:SetText("SHIFT-Q")
    previewText:SetJustifyH("CENTER")
    local drag=CreateFrame("Button",nil,sample)
    drag:SetAllPoints(sample)
    drag:EnableMouse(true);drag:RegisterForDrag("LeftButton")
    drag:SetScript("OnDragStart",function(self)
        self.dragging=true
        self:SetScript("OnUpdate",function(obj)
            if not obj.dragging or not GetCursorPosition or not previewSquare.GetCenter then return end
            local cx,cy=previewSquare:GetCenter()
            if not cx or not cy then return end
            local scale=previewSquare.GetEffectiveScale and previewSquare:GetEffectiveScale() or 1
            local mx,my=GetCursorPosition()
            if not mx or not my then return end
            if type(scale)~="number" or scale<=0 then return end
            ChangePosition((mx/scale)-cx,(my/scale)-cy,"custom",true)
        end)
    end)
    local function FinishDrag(self)
        self.dragging=false
        self:SetScript("OnUpdate",nil)
        if positionPending then
            positionPending=false
            module.ApplyAll()
        end
    end
    drag:SetScript("OnDragStop",FinishDrag)
    drag:SetScript("OnHide",FinishDrag)

    MakeSlider(panel,"Horizontal offset",-248,-22,22,
        function()return DB().x end,function(v)DB().x=v;DB().position="custom" end)
    MakeSlider(panel,"Vertical offset",-303,-22,22,
        function()return DB().y end,function(v)DB().y=v;DB().position="custom" end)
    MakeSlider(panel,"Font size",-358,8,24,
        function()return DB().size end,function(v)DB().size=v end)
    MakeCheck(panel,"Text outline",22,-415,
        function()return DB().outline end,function(v)DB().outline=v end,142)
    MakeCheck(panel,"Text shadow",220,-415,
        function()return DB().shadow end,function(v)DB().shadow=v end,144)
    Label(panel,"TEXT COLOR",24,-458,"GameFontNormal")
    local color=CreateFrame("EditBox",nil,panel,"InputBoxTemplate")
    color:SetSize(100,22);color:SetPoint("TOPLEFT",panel,"TOPLEFT",26,-484)
    color:SetAutoFocus(false);color:SetMaxLetters(7)
    local colorFeedback=Label(panel,"",26,-515,"GameFontHighlightSmall")
    colorFeedback:SetWidth(265)
    local function ApplyHex()
        local hex=FromHex(color:GetText())
        if not hex then
            colorFeedback:SetText("Enter six hex digits, for example #FFF0C2.")
            return
        end
        DB().hex=hex
        color:ClearFocus()
        colorFeedback:SetText("")
        module.ApplyAll()
        UpdatePreview()
    end
    Button(panel,"Apply hex",86,24,145,-484,ApplyHex)
    color:SetScript("OnEnterPressed",ApplyHex)
    color:SetScript("OnEscapePressed",function(self)
        self:ClearFocus()
        self:SetText("#"..DB().hex)
        colorFeedback:SetText("")
    end)
    Button(panel,"Pick color...",113,24,244,-484,function()
        local ok=MeffortSuiteShowColorPicker and MeffortSuiteShowColorPicker(DB().hex,function(hex)
            DB().hex=hex
            color:ClearFocus()
            colorFeedback:SetText("")
            module.ApplyAll()
            UpdatePreview()
        end)
        if not ok then Info("The native color picker is unavailable.") end
    end)
    Button(panel,"Reset appearance",138,24,302,-516,function()
        local cfg=DB()
        cfg.x,cfg.y,cfg.size=defaultX,defaultY,defaultSize
        cfg.hex,cfg.outline,cfg.shadow="fff0c2",true,true
        cfg.position="custom"
        color:ClearFocus()
        colorFeedback:SetText("")
        module.ApplyAll()
        UpdatePreview()
    end)
    controls[#controls+1]=function()
        if not color:HasFocus() then color:SetText("#"..DB().hex) end
    end
    Label(panel,"Changes made during combat apply when combat ends.",23,-542,"GameFontHighlightSmall")
    panel:SetScript("OnShow",function()
        FitPreviewToScreen()
        UpdatePreview()
    end)
    panel:SetScript("OnHide",function()
        backToBars=nil
        color:ClearFocus()
        colorFeedback:SetText("")
    end)
    pcall(panel.RegisterEvent,panel,"UI_SCALE_CHANGED")
    pcall(panel.RegisterEvent,panel,"DISPLAY_SIZE_CHANGED")
    panel:SetScript("OnEvent",FitPreviewToScreen)
    panel:Hide()
    return panel
end
function module.OpenPreview(onBack)
    local ok,win=pcall(CreatePanel)
    if not ok or not win then Info("Action Bar Text settings could not open.");return false end
    backToBars=onBack
    if MeffortSuiteHideMainSettings then MeffortSuiteHideMainSettings() end
    win:Show()
    return true
end
function module.HidePanel()
    if panel then panel:Hide() end
end
function module.OpenPanel()
    if MeffortSuiteSettingsUI and type(MeffortSuiteOpenSettings)=="function" then
        module.HidePanel()
        MeffortSuiteOpenSettings("action")
        return
    end
    module.OpenPreview()
end
function module.TogglePanel()
    if MeffortSuiteSettingsUI and type(MeffortSuiteOpenSettings)=="function" then
        module.OpenPanel()
        return
    end
    local ok,win=pcall(CreatePanel)
    if not ok or not win then Info("Action Bar Text settings could not open.");return end
    if win:IsShown() then win:Hide() else module.OpenPanel() end
end

local events=CreateFrame("Frame")
events:RegisterEvent("ADDON_LOADED")
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("PLAYER_ENTERING_WORLD")
events:RegisterEvent("PLAYER_REGEN_ENABLED")
events:RegisterEvent("UPDATE_BINDINGS")
events:RegisterEvent("ACTIONBAR_PAGE_CHANGED")
events:RegisterEvent("UPDATE_SHAPESHIFT_FORM")
events:RegisterEvent("PET_BAR_UPDATE")
local function InstallHooks()
    if type(hooksecurefunc)~="function" then return end
    if InCombat() then pending=true;return end
    if not hotkeyHooked and type(ActionButton_UpdateHotkeys)=="function" then
        local ok,result=pcall(hooksecurefunc,"ActionButton_UpdateHotkeys",function(button)
            if button and not InCombat() then pcall(StyleButton,button)
            elseif InCombat() then pending=true end
        end)
        hotkeyHooked=ok and result~=false
    end
    if not rangeHooked and type(ActionButton_UpdateRangeIndicator)=="function" then
        local ok,result=pcall(hooksecurefunc,"ActionButton_UpdateRangeIndicator",function(button)
            local hotkey=Hotkey(button)
            if not hotkey then return end
            local color=ReadColor(hotkey)
            nativeColors[hotkey]=color
            if color then appliedColors[hotkey]=nil end
            if InCombat() or not original[hotkey] or not DB().enabled or not MasterActive() then return end
            -- Native range red takes precedence over the configured text color.
            if color and not Red(color) then pcall(ApplyColor,hotkey) end
        end)
        rangeHooked=ok and result~=false
    end
end
events:SetScript("OnEvent",function(_,event)
    InstallHooks()
    if event=="ADDON_LOADED" then return end
    if event=="PLAYER_LOGIN" then DB() end
    if event=="PLAYER_REGEN_ENABLED" and pending then pending=false end
    module.ApplyAll()
end)
