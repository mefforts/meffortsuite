MeffortSuiteFishingCamera={}
local M=MeffortSuiteFishingCamera
local fishing=MeffortSuiteFishing
local tracker=CreateFrame("Frame")
local ready,inWorld,lineOut=false,false,false
local castID
local iconActive,iconStatus=false,"off"
local status="off"
local view,move
local zoomMotion,pitchMotion
local pitchVelocity,lookTime=0,0
local issuingZoom,writingCVar=false,false
local holdTime,tiltDegrees=1.75,6
local zoomTolerance=.002
local iconSettings={SoftTargetIconGameObject=1,SoftTargetIconInteract=1}
local oldBobberSettings={
    SoftTargetInteract=3,SoftTargetNameplateInteract=1,SoftTargetIconGameObject=1,
    SoftTargetIconInteract=1,SoftTargetInteractRange=30,SoftTargetInteractArc=2,cameraFov=50,
}

local function DB()
    if type(MeffortSuiteDB)~="table" then MeffortSuiteDB={} end
    return MeffortSuiteDB
end
local function Char()
    if type(MeffortSuiteCharDB)~="table" then MeffortSuiteCharDB={} end
    return MeffortSuiteCharDB
end
local function Public(value)
    if not issecretvalue or not issecretvalue(value) then return value end
end
local function Call(fn,...)
    if type(fn)~="function" then return false end
    local ok,result=pcall(fn,...)
    if not ok then return false end
    result=Public(result)
    return result~=false,result
end
local function Number(value)
    if type(value)~="string" and type(value)~="number" then return end
    local n=tonumber(value)
    if n and n==n and n>=0 and n<math.huge then return n end
end
local function Read(name)
    local _,value=Call(C_CVar and C_CVar.GetCVar or GetCVar,name)
    return Number(value)
end
local function Write(name,value)
    writingCVar=true
    Call(C_CVar and C_CVar.SetCVar or SetCVar,name,tostring(value))
    writingCVar=false
end
local function Locked()
    return type(InCombatLockdown)=="function" and InCombatLockdown()
end

local function RestoreValues(key,settings)
    local db=DB()
    local saved=db[key]
    if type(saved)~="table" then db[key]=nil;return true end
    local pending={}
    for name,applied in pairs(settings) do
        local entry=saved[name]
        if type(entry)=="table" and Number(entry.previous) and entry.applied==applied then
            local current=Read(name)
            if current==applied and not Locked() then
                Write(name,entry.previous)
                current=Read(name)
            end
            if current==nil or current==applied then pending[name]=entry end
        end
    end
    db[key]=next(pending) and pending or nil
    return db[key]==nil
end
local function RestoreOldCamera()
    local db=DB()
    local saved=db.fishingCameraRestore
    if type(saved)=="number" then saved={previous=saved,applied=50} end
    local previous=type(saved)=="table" and Number(saved.previous)
    if previous and previous>0 then
        local current=Read("cameraFov")
        if current==nil then return false end
        if current==saved.applied or current==saved.pending then
            if Locked() then return false end
            Write("cameraFov",previous)
            if Read("cameraFov")~=previous then return false end
        end
    end
    db.fishingCameraRestore=nil
    return true
end
local function SetCog(wanted)
    if iconActive and wanted then return true end
    iconActive=false
    if not RestoreValues("fishingInteractIconRestore",iconSettings) then
        iconStatus="restoration pending";return false
    end
    iconStatus="off"
    if not wanted then return true end
    iconActive=true
    local db=DB()
    local saved={}
    local unavailable=false
    for name,enabled in pairs(iconSettings) do
        local current=Read(name)
        if current==0 then
            saved[name]={previous=current,applied=enabled}
            db.fishingInteractIconRestore=saved
            Write(name,enabled)
            current=Read(name)
            if current~=nil and current~=enabled then saved[name]=nil end
        end
        if current~=enabled then unavailable=true end
    end
    db.fishingInteractIconRestore=next(saved) and saved or nil
    iconStatus=unavailable and "native setting unavailable" or "enabled during cast"
    return true
end

local function Zoom()
    local _,value=Call(GetCameraZoom)
    return Number(value)
end
local function StopMotion(direction)
    if direction then Call(_G["MoveView"..direction.."Stop"]) end
end
local function Drive(direction,previous,speed)
    if previous~=direction then StopMotion(previous) end
    if Call(_G["MoveView"..direction.."Start"],speed) then return direction end
    StopMotion(direction)
end
local function StopCamera()
    StopMotion(zoomMotion)
    StopMotion(pitchMotion)
    zoomMotion,pitchMotion=nil,nil
    pitchVelocity=0
end
local function DriveZoom(speed)
    if math.abs(speed)<.01 then
        StopMotion(zoomMotion)
        zoomMotion=nil
        return true
    end
    local rate=Read("cameraZoomSpeed") or 20
    zoomMotion=Drive(speed<0 and "In" or "Out",zoomMotion,math.min(6,math.abs(speed)/math.max(1,rate)))
    return zoomMotion~=nil
end
local function DrivePitch(speed)
    if math.abs(speed)<.08 then
        StopMotion(pitchMotion)
        pitchMotion=nil
        pitchVelocity=0
        return
    end
    local rate=Read("cameraPitchMoveSpeed") or 90
    pitchMotion=Drive(speed>0 and "Down" or "Up",pitchMotion,math.abs(speed)/math.max(1,rate))
    pitchVelocity=pitchMotion and speed or 0
    if not pitchMotion then view.manualPitch=true end
end
local function ZoomBy(amount)
    if math.abs(amount)<.04 then return end
    issuingZoom=true
    local ok=Call(amount>0 and CameraZoomOut or CameraZoomIn,math.abs(amount),true)
    issuingZoom=false
    return ok
end
local function ReleaseView()
    StopCamera()
    view,move=nil,nil
    lookTime=0
    tracker:SetScript("OnUpdate",nil)
end

function M.Enabled() return Char().fishingCameraZoom==true end
local function IdleStatus() return M.Enabled() and "waiting for a fishing cast" or "off" end
local function Active()
    return ready and inWorld and MeffortSuite.Active() and not Locked()
end
local function UpdateCamera(_,dt)
    if Locked() then StopCamera();return end
    local distance=Zoom()
    if not distance then ReleaseView();status="camera distance unavailable";return end
    local _,looking=Call(IsMouselooking)
    looking=looking==true or looking==1
    lookTime=looking and lookTime+dt or 0
    if lookTime>.16 and not view.manualPitch then
        view.manualPitch=true
        DrivePitch(0)
    end
    view.tilt=math.max(0,math.min(tiltDegrees,view.tilt+pitchVelocity*dt))
    if not move then return end
    move.elapsed=move.elapsed+dt
    if move.phase=="hold" then
        if move.elapsed<holdTime then return end
        move={phase="out",from=distance,tilt=view.tilt,elapsed=0,
            duration=math.min(5.4,3.7+view.distance*.036)}
        status="returning to your previous view"
        return
    end
    local zoomIn=move.phase=="in"
    local target=zoomIn and 0 or view.distance
    local horizon=math.max(1/120,math.min(dt,.15))
    local t=math.min(1,(move.elapsed+horizon)/move.duration)
    local ease=zoomIn and t*t*(3-2*t) or t*t*t*(4-3*t)
    local zoomAhead=move.from+(target-move.from)*ease
    local remaining=target-distance
    local zoomDone=view.manualZoom or (zoomIn and distance<=.001) or (not zoomIn and math.abs(remaining)<=zoomTolerance)
    if zoomDone then
        DriveZoom(0)
    elseif move.fallbackAt then
        zoomDone=move.elapsed-move.fallbackAt>.75
    else
        local speed=(zoomAhead-distance)/horizon
        speed=zoomIn and math.min(0,speed) or math.max(0,speed)
        if move.elapsed>move.duration+.55 or not DriveZoom(speed) then
            DriveZoom(0)
            move.fallbackAt=move.elapsed
            ZoomBy(zoomIn and -math.max(.05,distance) or remaining)
        end
    end
    local targetTilt=zoomIn and tiltDegrees or 0
    local tiltAhead=move.tilt+(targetTilt-move.tilt)*ease
    local pitchDone=view.manualPitch or (t==1 and math.abs(targetTilt-view.tilt)<.003)
    if pitchDone then DrivePitch(0)
    elseif not looking then
        DrivePitch(math.max(-36,math.min(36,(tiltAhead-view.tilt)/horizon)))
    else DrivePitch(0) end
    if t==1 and zoomDone and (pitchDone or move.elapsed>move.duration+.55) then
        StopCamera()
        if zoomIn then
            move=nil
            status=distance<=.001 and "first-person fishing view" or
                (view.manualZoom and "manual camera zoom" or "first-person zoom unconfirmed")
        else
            ReleaseView()
            status=IdleStatus()
        end
    end
end

local function StartView()
    if view and (not move or move.phase=="in") then return end
    local distance=Zoom()
    if not distance then status="camera distance unavailable";return end
    if not view then view={distance=distance,tilt=0} end
    StopCamera()
    move={phase="in",from=distance,tilt=view.tilt,elapsed=0,duration=math.min(.84,.46+distance*.014)}
    status="zooming into first person"
    tracker:SetScript("OnUpdate",UpdateCamera)
end
local function EndView(hold)
    if not view then status=IdleStatus();return end
    if move and (move.phase=="out" or (hold and move.phase=="hold")) then return end
    StopCamera()
    if hold then
        move={phase="hold",elapsed=0}
        status="holding view for a recast"
        return
    end
    local distance=Zoom()
    if not distance then ReleaseView();status="camera distance unavailable";return end
    move={phase="out",from=distance,tilt=view.tilt,elapsed=0,duration=.65}
    status="returning to your previous view"
end
local function Reconcile()
    local active=Active()
    RestoreOldCamera()
    local oldIconsRestored=RestoreValues("fishingBobberTargetRestore",oldBobberSettings)
    SetCog(active and oldIconsRestored and lineOut and fishing.InteractEnabled())
    if active and lineOut and M.Enabled() then StartView()
    elseif inWorld and not Locked() then EndView(active and M.Enabled())
    else
        StopCamera()
        if not view then status=IdleStatus() end
    end
end
function M.Refresh()
    lineOut=ready and inWorld and fishing.IsFishingChannel()
    Reconcile()
end
function M.Restore()
    local distance=Zoom()
    if view and distance and not view.manualZoom then
        StopCamera()
        ZoomBy(view.distance-distance)
    end
    ReleaseView()
    status=IdleStatus()
    local cogRestored=SetCog(false)
    local cameraRestored=RestoreOldCamera()
    local legacyRestored=RestoreValues("fishingBobberTargetRestore",oldBobberSettings)
    return cameraRestored and cogRestored and legacyRestored
end
function M.SetEnabled(value)
    Char().fishingCameraZoom=value==true
    M.Refresh()
end
function M.Status() return status..". Interact cog: "..iconStatus end

local function ManualZoom()
    if view and not issuingZoom then
        view.manualZoom=true
        DriveZoom(0)
    end
end
for _,event in ipairs({"PLAYER_LOGIN","PLAYER_ENTERING_WORLD","PLAYER_LEAVING_WORLD","PLAYER_LOGOUT",
    "PLAYER_REGEN_DISABLED","PLAYER_REGEN_ENABLED","CVAR_UPDATE"}) do
    tracker:RegisterEvent(event)
end
for _,event in ipairs({"UNIT_SPELLCAST_CHANNEL_START","UNIT_SPELLCAST_CHANNEL_STOP"}) do
    tracker:RegisterUnitEvent(event,"player")
end
tracker:SetScript("OnEvent",function(_,event,unit,guid,spellID)
    if event=="CVAR_UPDATE" then
        unit=Public(unit)
        if not writingCVar and type(unit)=="string" and unit:lower()=="softtargetinteract" then Reconcile() end
    elseif event=="UNIT_SPELLCAST_CHANNEL_START" then
        if unit=="player" and (fishing.IsFishingSpell(spellID) or fishing.IsFishingChannel()) then
            lineOut,castID=true,Public(guid)
            Reconcile()
        end
    elseif event=="UNIT_SPELLCAST_CHANNEL_STOP" then
        guid=Public(guid)
        if unit=="player" and (not castID or not guid or castID==guid) then
            lineOut,castID=false,nil
            Reconcile()
        end
    elseif event=="PLAYER_LOGIN" then
        ready=true
        if type(hooksecurefunc)=="function" then
            if type(CameraZoomIn)=="function" then pcall(hooksecurefunc,"CameraZoomIn",ManualZoom) end
            if type(CameraZoomOut)=="function" then pcall(hooksecurefunc,"CameraZoomOut",ManualZoom) end
        end
        M.Restore()
    elseif event=="PLAYER_LEAVING_WORLD" or event=="PLAYER_LOGOUT" then
        inWorld,lineOut,castID=false,false,nil
        M.Restore()
    else
        if event=="PLAYER_ENTERING_WORLD" then inWorld=true end
        M.Refresh()
    end
end)
