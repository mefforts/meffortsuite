local suite = MeffortSuite
MeffortSuiteFlightMasters = {}
local flight = MeffortSuiteFlightMasters
local frame = CreateFrame("Frame")
local open,selected,continuing,shiftBypass=false,false,false,false
local selecting,recentSelection=false,false
local menuSerial,dispatchSerial=0,0
local status="not used"

local function DB()
    if type(MeffortSuiteDB) ~= "table" then MeffortSuiteDB = {} end
    return MeffortSuiteDB
end

function flight.Enabled()
    return DB().autoOpenFlightMaster ~= false
end

function flight.SetEnabled(value)
    DB().autoOpenFlightMaster = value == true
    suite.Message("Skip flight master dialogue " .. (flight.Enabled() and "ON" or "OFF") ..
        (flight.Enabled() and ". Hold Shift while talking to see the normal dialogue." or "."))
end

local function Secret(value)
    return type(issecretvalue) == "function" and issecretvalue(value)
end
local function Number(value)
    if not Secret(value) and type(value) == "number" and value == value
        and value ~= math.huge and value ~= -math.huge then return value end
end
local function Ready()
    if not suite or not suite.Active() then return false, "Suite disabled" end
    if type(InCombatLockdown) == "function" and InCombatLockdown() then return false, "in combat" end
    if shiftBypass or (type(IsShiftKeyDown) == "function" and IsShiftKeyDown()) then return false, "Shift bypass" end
    if not C_GossipInfo or (type(C_GossipInfo.SelectOption) ~= "function"
        and type(C_GossipInfo.SelectOptionByIndex)~="function") then
        return false, "gossip selection unavailable"
    end
    return true
end
local function ReadList(method)
    local fn = C_GossipInfo and C_GossipInfo[method]
    if type(fn) ~= "function" then return nil end
    local ok, value = pcall(fn)
    if ok and not Secret(value) and type(value) == "table" then return value end
end
local function NoQuests()
    for _, method in ipairs({"GetActiveQuests", "GetAvailableQuests"}) do
        local list = ReadList(method)
        if not list or next(list) ~= nil then return false end
    end
    return true
end
local function ZeroOrAbsent(value)
    if Secret(value) then return false end
    if value == nil then return true end
    return Number(value) == 0
end
local function FalseOrAbsent(value)
    if Secret(value) then return false end
    if value == nil then return true end
    return not Secret(value) and (value == false or value == 0)
end
local function EmptyOrAbsent(value)
    if Secret(value) then return false end
    if value == nil then return true end
    return not Secret(value) and type(value) == "string" and value == ""
end
local function Eligible(option)
    if not option then return nil end
    local id, icon = Number(option.gossipOptionID), Number(option.icon)
    if icon~=132057 or Secret(option.gossipOptionID) then return nil end
    local byIndex=false
    if option.gossipOptionID==nil or id==0 then
        id=Number(option.orderIndex);byIndex=true
        if not id or id<0 or id~=math.floor(id)
            or type(C_GossipInfo.SelectOptionByIndex)~="function" then return nil end
    elseif not id or id<=0 or id~=math.floor(id) then return nil end
    if not ZeroOrAbsent(option.status) then return nil end
    if Secret(option.overrideIconID) then return nil end
    if option.overrideIconID ~= nil and Number(option.overrideIconID)~=0 and Number(option.overrideIconID) ~= icon then return nil end
    if Secret(option.flags) then return nil end
    local flags=option.flags==nil and 0 or Number(option.flags)
    local hidden=Enum and Enum.GossipOptionRecFlags and Enum.GossipOptionRecFlags.HideOptionIDFromClient or 2
    if flags~=0 and flags~=hidden then return nil end
    for _, key in ipairs({"cost", "money", "boxMoney", "spellID"}) do
        if not ZeroOrAbsent(option[key]) then return nil end
    end
    for _, key in ipairs({"isCoded", "coded", "isConfirmation", "requiresConfirmation", "hasCost"}) do
        if not FalseOrAbsent(option[key]) then return nil end
    end
    for _, key in ipairs({"boxText", "confirmationText", "confirmText"}) do
        if not EmptyOrAbsent(option[key]) then return nil end
    end
    if Secret(option.rewards) then return nil end
    if option.rewards ~= nil then
        if type(option.rewards) ~= "table" or next(option.rewards) ~= nil then return nil end
    end
    return id, byIndex
end
local function FindFlightOption()
    local options=ReadList("GetOptions")
    if not options then return end
    local found,index
    for _,option in pairs(options) do
        if Secret(option) or type(option)~="table" then return end
        local id,byIndex=Eligible(option)
        if id~=nil then
            if found~=nil then return end
            found,index=id,byIndex
        end
    end
    return found,index
end

local function OpenFlightMap()
    if not open or not flight.Enabled() or selected or selecting or recentSelection then return end
    local ready,why=Ready()
    if not ready then status=why;return end
    if not NoQuests() then status="quest choices or metadata unavailable";return end
    local id,byIndex=FindFlightOption()
    if id==nil then status="no unambiguous flight option";return end
    local freshID,freshIndex=FindFlightOption()
    if id~=freshID or byIndex~=freshIndex or not NoQuests() then status="dialogue changed";return end
    local selectOption
    if byIndex then selectOption=C_GossipInfo.SelectOptionByIndex
    else selectOption=C_GossipInfo.SelectOption end
    if type(selectOption)~="function" then status="gossip selection unavailable";return end

    -- Selection can synchronously close or reopen dialogue.
    selected,selecting,recentSelection=true,true,true
    dispatchSerial=dispatchSerial+1
    local serial=dispatchSerial
    local function ClearDispatch()
        if serial==dispatchSerial then recentSelection=false end
    end
    if C_Timer and type(C_Timer.After)=="function" then C_Timer.After(0,ClearDispatch)
    else
        frame:SetScript("OnUpdate",function(self)
            self:SetScript("OnUpdate",nil)
            ClearDispatch()
        end)
    end
    local ok,result=pcall(selectOption,id)
    selecting=false
    status=ok and result~=false and "taxi map requested" or "selection refused"
end

function flight.Status()
    suite.Message("Flight master dialogue: " .. (flight.Enabled() and "ON" or "OFF") ..
        "; last action: " .. status)
end

function flight.Command(arg)
    arg = (arg or ""):lower():match("^%s*(.-)%s*$")
    if arg == "on" then
        flight.SetEnabled(true)
    elseif arg == "off" then
        flight.SetEnabled(false)
    else
        flight.Status()
        if arg ~= "status" then suite.Message("/msuite flight on | off | status") end
    end
end

for _,event in ipairs({"PLAYER_LOGIN","GOSSIP_SHOW","GOSSIP_CLOSED","TAXIMAP_OPENED"}) do frame:RegisterEvent(event) end
pcall(frame.RegisterEvent,frame,"GOSSIP_OPTIONS_REFRESHED")
frame:SetScript("OnEvent",function(_,event,interactionIsContinuing)
    if event=="PLAYER_LOGIN" then
        if DB().autoOpenFlightMaster==nil then DB().autoOpenFlightMaster=true end
    elseif event=="GOSSIP_SHOW" then
        if selecting or recentSelection then return end
        if not open and not continuing then selected=false end
        open,continuing=true,false
        shiftBypass=shiftBypass or (type(IsShiftKeyDown)=="function" and IsShiftKeyDown()) or false
        menuSerial=menuSerial+1
        local serial=menuSerial
        OpenFlightMap()
        if C_Timer and type(C_Timer.After)=="function" then
            C_Timer.After(.1,function()
                if menuSerial==serial then OpenFlightMap() end
            end)
        end
    elseif event=="GOSSIP_OPTIONS_REFRESHED" then
        OpenFlightMap()
    else
        menuSerial=menuSerial+1
        open=false
        continuing=event=="GOSSIP_CLOSED" and not Secret(interactionIsContinuing) and interactionIsContinuing==true
        if not continuing then
            shiftBypass=false
            if not selecting then selected=false end
        end
    end
end)
