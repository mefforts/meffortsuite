MeffortSuiteFishingCamera={}
local M=MeffortSuiteFishingCamera
local fishing=MeffortSuiteFishing
local tracker=CreateFrame("Frame")
local fov,closeup="cameraFov",50
local ready,inWorld,attempted=false,false,false
local castID
local status="off"
local legacySettings={
    SoftTargetInteract=3,
    SoftTargetNameplateInteract=1,
    SoftTargetIconGameObject=1,
    SoftTargetIconInteract=1,
    SoftTargetInteractRange=30,
    SoftTargetInteractArc=2,
    cameraFov=closeup,
}

local function DB()
    if type(MeffortSuiteDB)~="table" then MeffortSuiteDB={} end
    return MeffortSuiteDB
end
local function Char()
    if type(MeffortSuiteCharDB)~="table" then MeffortSuiteCharDB={} end
    return MeffortSuiteCharDB
end
local function Public(value)
    if not issecretvalue or not issecretvalue(value) then return value end
end
local function Read(name)
    local getter=C_CVar and C_CVar.GetCVar or GetCVar
    if type(getter)~="function" then return end
    local ok,value=pcall(getter,name)
    if ok then
        value=Public(value)
        if type(value)=="string" or type(value)=="number" then return tonumber(value) end
    end
end
local function Write(name,value)
    local setter=C_CVar and C_CVar.SetCVar or SetCVar
    if type(setter)=="function" then pcall(setter,name,tostring(value)) end
end
local function Locked()
    return type(InCombatLockdown)=="function" and InCombatLockdown()
end
local function RestoreValue(name,previous,applied)
    if type(previous)~="number" or previous~=previous or previous<0 or previous==math.huge then return true end
    local current=Read(name)
    if current==nil then return false end
    if current~=applied then return true end
    if Locked() then return false end
    Write(name,previous)
    local restored=Read(name)
    return restored~=nil and restored~=applied
end
local function RestoreLegacy()
    local db=DB()
    local entries=db.fishingBobberTargetRestore
    if entries==nil then return true end
    local pending={}
    if type(entries)=="table" then
        for name,applied in pairs(legacySettings) do
            local entry=entries[name]
            if type(entry)=="table" and entry.applied==applied and not RestoreValue(name,entry.previous,applied) then
                pending[name]=entry
            end
        end
    end
    db.fishingBobberTargetRestore=next(pending) and pending or nil
    return db.fishingBobberTargetRestore==nil
end
local function Stop()
    attempted=false
    local db=DB()
    local previous=db.fishingCameraRestore
    if previous==nil or RestoreValue(fov,previous,closeup) then
        db.fishingCameraRestore=nil
        return true
    end
    return false
end
function M.Enabled() return Char().fishingCameraZoom==true end
local function Eligible()
    return ready and inWorld and M.Enabled() and MeffortSuite.Active() and not Locked()
end
local function Start()
    if attempted then return end
    if not Stop() or not RestoreLegacy() then status="prior settings restoration pending";return end
    attempted=true
    local before=Read(fov)
    if not before or before<=0 or before==math.huge then status="field of view unavailable";return end
    if before<=closeup then status="field of view already narrow";return end
    local db=DB()
    db.fishingCameraRestore=before
    Write(fov,closeup)
    local after=Read(fov)
    if after==closeup then
        status="zoomed to 50 degrees"
    else
        if after~=nil then db.fishingCameraRestore=nil end
        status="field of view change unconfirmed"
    end
end
function M.Refresh()
    if Eligible() and fishing.IsFishingChannel() then
        Start()
    else
        local restored=Stop()
        local legacyRestored=RestoreLegacy()
        if not restored or not legacyRestored then status="prior settings restoration pending"
        elseif M.Enabled() then status="waiting for a fishing cast"
        else status="off" end
    end
end
function M.SetEnabled(value)
    Char().fishingCameraZoom=value==true
    M.Refresh()
end
function M.Status() return status end

for _,event in ipairs({"PLAYER_LOGIN","PLAYER_ENTERING_WORLD","PLAYER_LEAVING_WORLD","PLAYER_LOGOUT",
    "PLAYER_REGEN_DISABLED","PLAYER_REGEN_ENABLED","CVAR_UPDATE"}) do
    tracker:RegisterEvent(event)
end
for _,event in ipairs({"UNIT_SPELLCAST_CHANNEL_START","UNIT_SPELLCAST_CHANNEL_STOP"}) do
    tracker:RegisterUnitEvent(event,"player")
end
tracker:SetScript("OnEvent",function(_,event,unit,guid,spellID)
    if event=="CVAR_UPDATE" then
        unit=Public(unit)
        if type(unit)=="string" and unit:lower()==fov:lower() and DB().fishingCameraRestore~=nil then
            local current=Read(fov)
            if current and current~=closeup then
                DB().fishingCameraRestore=nil
                if attempted then status="field of view changed in game" end
            end
        end
        return
    end
    if event=="UNIT_SPELLCAST_CHANNEL_START" then
        if unit=="player" and Eligible() and (fishing.IsFishingSpell(spellID) or fishing.IsFishingChannel()) then
            castID=Public(guid)
            Start()
        end
        return
    end
    if event=="UNIT_SPELLCAST_CHANNEL_STOP" then
        guid=Public(guid)
        if unit~="player" or (castID and guid and castID~=guid) then return end
        castID=nil
        status=Stop() and (M.Enabled() and "waiting for a fishing cast" or "off") or "field of view restoration pending"
        return
    end
    if event=="PLAYER_LOGIN" then ready=true end
    if event=="PLAYER_ENTERING_WORLD" then inWorld=true end
    if event=="PLAYER_LEAVING_WORLD" or event=="PLAYER_LOGOUT" then inWorld=false;castID=nil end
    M.Refresh()
end)
