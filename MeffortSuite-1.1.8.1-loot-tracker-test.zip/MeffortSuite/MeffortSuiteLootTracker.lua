MeffortSuiteLootTracker={}
local M=MeffortSuiteLootTracker
local prices=MeffortSuiteLootValue
local width,height,rowHeight=376,300,19
local session={byKey={},items={},coins=0,count=0}
local tracking,queued=false,false
local view="items"
local panel,status,startButton,itemsButton,valuesButton,coinValue
local scroll,content,empty,valuesPanel,vendorValue,auctionValue,priceNote
local rows={}

local function SuiteActive()
    return MeffortSuite.Active()
end
function M.IsTracking()
    return tracking and SuiteActive()
end

local function RenderItems()
    if not scroll or view~="items" then return end
    local first=math.floor(scroll:GetVerticalScroll()/rowHeight)+1
    local count=#session.items
    for offset,row in ipairs(rows) do
        local index=first+offset-1
        local item=session.items[count-index+1]
        row.name:SetShown(item~=nil)
        row.quantity:SetShown(item~=nil)
        if item then
            local y=-(index-1)*rowHeight
            row.name:ClearAllPoints()
            row.name:SetPoint("TOPLEFT",content,"TOPLEFT",2,y)
            row.name:SetText(item.name)
            row.quantity:ClearAllPoints()
            row.quantity:SetPoint("TOPRIGHT",content,"TOPRIGHT",-5,y)
            row.quantity:SetText(tostring(item.count))
        end
    end
end
local function RenderValues()
    local vendorTotal,auctionTotal=session.coins,session.coins
    local missing,fallback=0,0
    local auctionAvailable=prices.HasAuctionator()
    for _,item in ipairs(session.items) do
        local vendor,auction=prices.TrackQuote(item)
        if vendor then vendorTotal=vendorTotal+vendor*item.count
        else missing=missing+item.count end
        if auction then
            auctionTotal=auctionTotal+auction*item.count
        elseif vendor then
            auctionTotal=auctionTotal+vendor*item.count
            fallback=fallback+item.count
        end
    end
    vendorValue:SetText(prices.FormatMoney(vendorTotal))
    auctionValue:SetText(auctionAvailable and prices.FormatMoney(auctionTotal) or "Unavailable")
    local note="Totals include coins."
    if not auctionAvailable then note=note.." Load Auctionator for AH estimates."
    elseif fallback>0 then note=note.." Items without an AH price use vendor value." end
    if missing>0 then note=note.." Partial totals. Waiting for prices on "..missing.." items." end
    priceNote:SetText(note)
end
local function Render()
    if not panel or not panel:IsShown() then return end
    local running=M.IsTracking()
    local count=session.count
    local state=running and "Tracking" or (SuiteActive() and "Stopped" or "Suite off")
    status:SetText(state.."  ·  "..count..(count==1 and " item" or " items"))
    coinValue:SetText(prices.FormatMoney(session.coins))
    startButton:SetText(running and "Stop tracking" or "Start tracking")
    startButton:SetEnabled(SuiteActive())
    itemsButton:SetEnabled(view~="items")
    valuesButton:SetEnabled(view~="values")
    scroll:SetShown(view=="items")
    empty:SetShown(view=="items" and count==0)
    valuesPanel:SetShown(view=="values")
    if view=="items" then
        local listHeight=math.max(1,#session.items*rowHeight)
        if content:GetHeight()~=listHeight then
            content:SetHeight(listHeight)
            scroll:UpdateScrollChildRect()
        end
        RenderItems()
    else RenderValues() end
end
local function RefreshSoon()
    if queued or not panel or not panel:IsShown() then return end
    if not (C_Timer and C_Timer.After) then Render();return end
    queued=true
    C_Timer.After(0,function()
        queued=false
        Render()
    end)
end
local function Label(parent,text,font,point,x,y)
    local label=parent:CreateFontString(nil,"OVERLAY",font or "GameFontHighlightSmall")
    label:SetPoint(point,parent,point,x,y)
    label:SetText(text)
    return label
end
local function Button(text,w,point,x,y,action)
    local button=CreateFrame("Button",nil,panel,"UIPanelButtonTemplate")
    button:SetSize(w,24)
    button:SetPoint(point,panel,point,x,y)
    button:SetText(text)
    button:SetScript("OnClick",action)
    return button
end
local function SetView(selected)
    view=selected
    Render()
end
local function CreateWindow()
    panel=CreateFrame("Frame","MeffortSuiteLootTrackerWindow",UIParent,BackdropTemplateMixin and "BackdropTemplate" or nil)
    panel:Hide()
    panel:SetSize(width,height)
    panel:SetPoint("RIGHT",UIParent,"RIGHT",-28,0)
    panel:SetFrameStrata("DIALOG")
    panel:SetClampedToScreen(true)
    panel:EnableMouse(true)
    panel:SetMovable(true)
    panel:RegisterForDrag("LeftButton")
    panel:SetScript("OnDragStart",function(self)self:StartMoving()end)
    panel:SetScript("OnDragStop",function(self)self:StopMovingOrSizing()end)
    if panel.SetBackdrop then
        panel:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",
            edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",tile=true,tileSize=32,edgeSize=24,
            insets={left=7,right=7,top=7,bottom=7}})
        panel:SetBackdropColor(.11,.085,.06,.98)
    else
        local background=panel:CreateTexture(nil,"BACKGROUND")
        background:SetAllPoints()
        background:SetColorTexture(.11,.085,.06,.98)
    end
    local close=CreateFrame("Button",nil,panel,"UIPanelCloseButton")
    close:SetPoint("TOPRIGHT",panel,"TOPRIGHT",-5,-5)
    close:SetScript("OnClick",function()panel:Hide()end)
    if type(UISpecialFrames)=="table" then UISpecialFrames[#UISpecialFrames+1]="MeffortSuiteLootTrackerWindow" end
    Label(panel,"Loot Tracker","GameFontNormalLarge","TOPLEFT",16,-14)
    status=Label(panel,"","GameFontHighlightSmall","TOPLEFT",17,-39)
    itemsButton=Button("Items",76,"TOPLEFT",16,-60,function()SetView("items")end)
    valuesButton=Button("Values",76,"TOPLEFT",98,-60,function()SetView("values")end)
    Label(panel,"Coins looted","GameFontNormal","TOPLEFT",17,-98)
    coinValue=Label(panel,"","GameFontHighlight","TOPRIGHT",-21,-98)
    startButton=Button("Start tracking",112,"BOTTOMRIGHT",-17,15,function()M.SetTracking(not M.IsTracking())end)

    scroll=CreateFrame("ScrollFrame",nil,panel,"UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT",panel,"TOPLEFT",17,-123)
    scroll:SetPoint("BOTTOMRIGHT",panel,"BOTTOMRIGHT",-35,52)
    content=CreateFrame("Frame",nil,scroll)
    content:SetSize(width-53,1)
    scroll:SetScrollChild(content)
    for index=1,math.ceil((height-175)/rowHeight)+2 do
        local name=Label(content,"",nil,"TOPLEFT",2,0)
        name:SetWidth(width-125)
        name:SetJustifyH("LEFT")
        name:SetWordWrap(false)
        local quantity=content:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        rows[index]={name=name,quantity=quantity}
    end
    scroll:HookScript("OnVerticalScroll",RenderItems)
    empty=Label(panel,"No loot recorded yet.",nil,"TOPLEFT",19,-129)
    valuesPanel=CreateFrame("Frame",nil,panel)
    valuesPanel:SetPoint("TOPLEFT",panel,"TOPLEFT",17,-129)
    valuesPanel:SetPoint("BOTTOMRIGHT",panel,"BOTTOMRIGHT",-21,52)
    Label(valuesPanel,"Vendor total","GameFontNormal","TOPLEFT",0,0)
    vendorValue=Label(valuesPanel,"","GameFontHighlight","TOPRIGHT",0,0)
    Label(valuesPanel,"Auctionator estimate","GameFontNormal","TOPLEFT",0,-27)
    auctionValue=Label(valuesPanel,"","GameFontHighlight","TOPRIGHT",0,-27)
    priceNote=Label(valuesPanel,"",nil,"TOPLEFT",0,-56)
    priceNote:SetWidth(width-39)
    priceNote:SetJustifyH("LEFT")
    priceNote:SetWordWrap(true)
end

function M.Open()
    if not panel then CreateWindow() end
    local w,h=UIParent:GetWidth(),UIParent:GetHeight()
    if w>0 and h>0 then panel:SetScale(math.max(.1,math.min(1,(w-24)/width,(h-24)/height))) end
    panel:Show()
    if panel.Raise then panel:Raise() end
    Render()
end
function M.SetTracking(enabled)
    if enabled and not SuiteActive() then return end
    if enabled and not tracking then
        session={byKey={},items={},coins=0,count=0}
        if scroll then scroll:SetVerticalScroll(0) end
    end
    tracking=enabled==true
    if tracking then M.Open() else Render() end
    if MeffortSuiteSettingsUI then MeffortSuiteSettingsUI.Refresh() end
end
function M.RefreshMaster()
    if not SuiteActive() then tracking=false end
    Render()
end
function M.RecordItem(key,id,link,quantity)
    local item=session.byKey[key]
    if not item then
        item={id=id,link=link,name=link:match("|h%[(.-)%]|h") or ("Item "..id),count=0,
            allItems=true,auctionator=true,both=true}
        session.byKey[key]=item
        session.items[#session.items+1]=item
    end
    item.count=item.count+quantity
    session.count=session.count+quantity
    RefreshSoon()
end
function M.RecordMoney(amount)
    session.coins=session.coins+amount
    RefreshSoon()
end
function M.ItemDataReady(id)
    if not id then return end
    for _,item in ipairs(session.items) do
        if item.id==id and item.vendor==nil then
            item.nextTry=nil
            if view=="values" then RefreshSoon() end
        end
    end
end

local events=CreateFrame("Frame")
events:RegisterEvent("PLAYER_REGEN_ENABLED")
events:RegisterEvent("ADDON_LOADED")
events:SetScript("OnEvent",function(_,event,addon)
    if event=="ADDON_LOADED" then
        if addon~="Auctionator" then return end
        for _,item in ipairs(session.items) do
            if item.source~="Auctionator" then
                item.auctionChecked,item.value,item.source,item.nextTry=nil,nil,nil,nil
            end
        end
    end
    RefreshSoon()
end)
