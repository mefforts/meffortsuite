MeffortSuite 1.1.4g
WoW Forever | Interface 16001

INSTALLATION
Extract the MeffortSuite folder into Interface/AddOns, replacing the previous
MeffortSuite folder. Keep the folder name unchanged, then reload the game.
Existing SavedVariables and saved OFF preferences are retained.

SETTINGS
Open /msuite, or Options > AddOns > MeffortSuite, to configure each tool.
The login announcement appears once in chat when logging in or reloading.
Disable Show login message in Options or /msuite > About to hide it for all
characters. No announcement popup opens on screen.

Toggles save immediately. Text fields save with Enter or Apply; Esc discards
the current edit. Unsaved text is retained
when navigating between settings pages. Scope labels identify account and
character settings. The master switch keeps individual preferences saved.
Protected input and display changes requested in combat finish after combat.

FLOATING LOOT VALUE
Floating loot value is enabled by default. Open /msuite > Bags to turn it off
for all characters or use Preview loot value to see a sample. Include all item
qualities is on by default in this version. Turn it off for grey items only.
The quality choice applies from the next loot window and is saved account-wide.

After closing a loot window, one gently rising total combines coins actually
received with the vendor value of all items received. Items with zero vendor
value contribute zero. Quantities and copper values are retained exactly. AoE loot uses one combined total. Short delayed
receipts can update the same float. Unclaimed items and other players' loot do
not count. Fishing and loot opened from inventory items are excluded.

The float uses an available corpse nameplate's screen position outside combat,
or a briefly remembered nameplate position. Otherwise it appears near the
cursor position captured when looting begins. This is a screen-space display;
it cannot follow a hidden 3D corpse as the camera moves. No nameplate layout or
mouse controls are changed.

Uncached included-item prices are requested once and checked briefly. A batch with
unavailable prices is omitted rather than guessed. Native localized self-loot
messages are used where available. The preview does not change bags or money.

BAGS AND BANKING
- Sort bags when opened; sell junk and repair with personal gold at merchants.
- Deposit crafting reagents and sort the personal bank when opened.
- In /msuite > Bags, add non-crafting items under Also deposit. Use exact item
  names or numeric item IDs, separated by commas. IDs work across languages.
- Keep in bags takes priority over Also deposit and ordinary reagent deposits.
  Both lists are saved per character. Leave Also deposit empty to retain the
  normal reagent selection.
- Save list changes with Enter or Save list. Saving either list stops remaining
  transfers. Use Deposit items now at an open bank, or reopen the bank, to apply
  the new selection. Requests already sent cannot be reversed.
- Unidentified items stay in bags until their names and stack information are
  ready. Native bank restrictions still apply. Custom lists never fall back to
  an unrestricted deposit if selective transfer support is unavailable.
- Skip Orgrimmar banker dialogue for Soran, Karus, and Koma. Hold Shift to bypass.

PROFESSIONS
- Right-click fishing with a pole equipped. New characters use double-click;
  existing choices are retained. Single-click prevents normal camera turning.
- Quiet fishing audio is optional under /msuite > Professions and starts off
  per character. It mutes music, ambience and dialogue during Fishing with a
  pole equipped. Sound effects, including the bite, keep their current volume;
  other effects remain audible. Prior volumes restore after fishing or when
  disabled. Volume changes made while fishing are retained.
- Open Enchanting and click the MeffortSuite side tab to use Enchant Queue.
  Select a recipe, drag in a target item, enter a count, and add it to the queue.
- Next requires a separate click or key press for every enchant and confirmation.
  Bind it under Keybindings > AddOns > MeffortSuite.
- Queues scroll and persist per character. Clear offers Undo until the next edit.
  If a result cannot be confirmed, Check result pauses for your inspection;
  uncertain enchants are never automatically retried.
- The queue closes with Enchanting. If Next is unavailable, follow its status
  message or use Blizzard's crafting controls.

COMBAT AND INTERFACE
- Right-click wand, bow, gun, crossbow, and thrown attacks with shared macros.
- Choose Shift + click to keep ordinary right-click for native melee and use
  Shift + right-click for the ranged shot. No measured-distance switch is used.
  Warriors use native single-shot attacks; Shoot Gun needs a new input for each
  shot. Hunter Auto Shot is a separate repeating ability.
- Optional conservative target-range warning; unknown distances show no warning.
- Mage Arcane Blast stacks, countdown, and timer wheel on Blizzard Tracked Buffs.
  Add Arcane Blast to Tracked Buffs first. Combat estimates reconcile afterward.
- English spell explanations, tooltip-header badges, rank alerts, and colors.
- Action-bar keybinding labels with a live position preview. Native red range
  warnings take priority over custom colors. Full styling refreshes wait until
  combat ends; native range warnings continue normally during combat.
- Quest dialogue shortcuts: Space prefers available quests, then quests ready
  to turn in, then unfinished quests. It still accepts/continues/completes the
  current quest dialogue; with no quests it selects the first conversation
  choice. Number keys 1-9 keep their original menu order, with
  labels to the left of native menu icons; * marks the Spacebar choice. Normal controls
  return outside dialogue. Long or unsupported rows keep their native layout;
  their number may be omitted while the keyboard shortcut remains available.
  If a row changes layout unexpectedly, its original spacing is restored and
  its number is paused for that conversation. A new conversation can show it
  again; its keyboard shortcut remains available throughout.
- Single-option service shortcuts open recognized shops, trainers, banks, or
  flight maps only when there is exactly one choice and no quests. Hold Shift
  to see the dialogue. Unknown, paid, or confirmation choices stay manual.
  Configure this separately under Quests; existing bank/flight settings remain
  independent and their saved OFF choices are respected.
- Optional waypoint arrow and flight-master dialogue shortcut. The shortcut
  opens the flight map without selecting a route. Hold Shift to bypass.

COMMANDS
/msuite                         Open settings
/msuite on | off                Toggle the suite; retain feature preferences
/msuite professions             Open profession settings
/msuite enchant                 Toggle the queue while Enchanting is open
/msuite fishing status          Check fishing setup
/msuite arcane                  Open Arcane Blast settings
/msuite bank now                Deposit selected items and reagents at an open bank
/msuite bank on | off           Toggle automatic deposits
/msuite bank sort on | off      Toggle personal-bank sorting
/msuite bank gossip on | off    Toggle Orgrimmar banker shortcut
/msuite flight on | off         Toggle flight-master shortcut
/msuite services on | off       Toggle single-option service shortcuts
/msuite vendor [retry]          Check or retry merchant actions
/way 49.4 12.9                  Set a native map pin at percentage coordinates
/way Hillsbrad Foothills 87.3 49.6  Set a pin in a named zone
/msuite way 49.4 12.9           Set a pin even if another addon owns /way
/msuite diagnostics             Show client, menu-label state, and recorded errors
/msuite export                  Open a copyable diagnostic report
/msuite help                    Show command help

COMPATIBILITY
Coordinate commands use an explicit zone name when supplied, otherwise the
displayed world map when open, or your current zone. Zone names come from the
client's live map data, including newly added Forever zones such as Zephras and
Hyjal. Use the name shown by your client; names may be quoted. Ambiguous names
report map IDs: /way #mapID x y selects one explicitly. Coordinates must be
between 0 and 100. The existing arrow follows the new pin when enabled; quest super-tracking is preserved. Other addons'
/way commands are retained.

Targets WoW Forever Interface 16001. Spell explanations and header parsing use
English data. Saved deposit exclusions and enchant queues are per character.
Enabled standalone MeffortWand takes priority over the suite's wand handling.
Supported preferences from older Meffort addons migrate on first installation.

TROUBLESHOOTING
Use /msuite diagnostics to review the current session in chat, or /msuite export
to open a copyable report. The About page also has Copy diagnostic report.
If an interface action fails, open the report before reloading. It records
client-reported blocked and forbidden actions, generic interface failures,
recent guarded-operation errors, and menu status even when no Lua error appears.
Reports include the active suite call, bounded event stacks, and nearby calls
when available. Nearby calls are correlation only; an event may arrive after
the triggering call has returned.
Reports identify the source and function only when the client supplies them;
a reported addon name does not identify every step in a taint chain.
If a range or camera call is blocked, that call is paused for the affected
combat condition until reload. Out-of-combat calls remain available after a
combat-only block. Saved tool preferences are retained. Owned camera-release
cleanup retries after combat.
Events are recorded after this version loads and are cleared by a UI reload.
The report contains no chat transcript and never sends information to others.

If an item move is blocked, follow the status message and check your cursor
before retrying. Enchanting always requires player input. This unofficial addon
is not affiliated with Blizzard.

See ATTRIBUTION.txt, LICENSE, and THIRD-PARTY-EnchantQueue-LICENSE.txt for credits
and licensing.
