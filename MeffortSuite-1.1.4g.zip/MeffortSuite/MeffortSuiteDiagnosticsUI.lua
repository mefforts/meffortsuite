local frame,reportBox,scroll

local function OpenReport()
    if not frame then
        frame=CreateFrame("Frame","MeffortSuiteDiagnosticReport",UIParent,BackdropTemplateMixin and "BackdropTemplate" or nil)
        frame:SetSize(600,460)
        frame:SetPoint("CENTER",UIParent,"CENTER",0,0)
        frame:SetFrameStrata("DIALOG")
        frame:SetClampedToScreen(true)
        frame:EnableMouse(true)
        if frame.SetBackdrop then
            frame:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",
                edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",tile=true,tileSize=32,edgeSize=24,
                insets={left=7,right=7,top=7,bottom=7}})
            frame:SetBackdropColor(.11,.085,.06,.98)
        end
        local title=frame:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
        title:SetPoint("TOPLEFT",frame,"TOPLEFT",18,-16)
        title:SetText("MeffortSuite diagnostic report")
        local help=frame:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        help:SetPoint("TOPLEFT",frame,"TOPLEFT",18,-40)
        help:SetText("Select the report and press Ctrl+C (Command+C on Mac) to copy.")
        local close=CreateFrame("Button",nil,frame,"UIPanelCloseButton")
        close:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-6,-6)
        close:SetScript("OnClick",function()frame:Hide()end)
        scroll=CreateFrame("ScrollFrame",nil,frame,"UIPanelScrollFrameTemplate")
        scroll:SetPoint("TOPLEFT",frame,"TOPLEFT",18,-64)
        scroll:SetPoint("BOTTOMRIGHT",frame,"BOTTOMRIGHT",-34,52)
        reportBox=CreateFrame("EditBox",nil,scroll)
        reportBox:SetMultiLine(true)
        reportBox:SetAutoFocus(false)
        reportBox:SetFontObject(ChatFontNormal or GameFontHighlightSmall)
        reportBox:SetWidth(540)
        reportBox:SetHeight(330)
        reportBox:SetMaxLetters(50000)
        reportBox:SetScript("OnEscapePressed",function()frame:Hide()end)
        scroll:SetScrollChild(reportBox)
        local select=CreateFrame("Button",nil,frame,"UIPanelButtonTemplate")
        select:SetSize(130,25)
        select:SetPoint("BOTTOMLEFT",frame,"BOTTOMLEFT",18,16)
        select:SetText("Select report")
        select:SetScript("OnClick",function()reportBox:SetFocus();reportBox:HighlightText()end)
        local done=CreateFrame("Button",nil,frame,"UIPanelButtonTemplate")
        done:SetSize(90,25)
        done:SetPoint("BOTTOMRIGHT",frame,"BOTTOMRIGHT",-18,16)
        done:SetText("Close")
        done:SetScript("OnClick",function()frame:Hide()end)
        frame:SetScript("OnHide",function()reportBox:ClearFocus()end)
        if type(UISpecialFrames)=="table" then UISpecialFrames[#UISpecialFrames+1]="MeffortSuiteDiagnosticReport" end
    end
    local width,height=UIParent:GetWidth(),UIParent:GetHeight()
    if type(width)=="number" and type(height)=="number" and width>0 and height>0 then
        frame:SetScale(math.max(.1,math.min(1,(width-24)/600,(height-24)/460)))
    end
    reportBox:SetText(MeffortSuite.DiagnosticReport())
    frame:Show()
    reportBox:SetFocus()
    reportBox:HighlightText()
    scroll:SetVerticalScroll(0)
end

function MeffortSuiteExportDiagnostics()
    local ok,err=pcall(OpenReport)
    if not ok then
        MeffortSuite.ReportError("diagnostics","report window",err)
        MeffortSuite.Message("The report window could not open. Use /msuite diagnostics to review this session in chat.")
    end
end
