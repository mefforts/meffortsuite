MeffortSuiteFishingAudio={}
local M=MeffortSuiteFishingAudio
local keys={"Sound_MusicVolume","Sound_AmbienceVolume","Sound_DialogVolume"}
local active=false
local status="off"
local spellName

local function DB()
    if type(MeffortSuiteDB)~="table" then MeffortSuiteDB={} end
    return MeffortSuiteDB
end
local function Char()
    if type(MeffortSuiteCharDB)~="table" then MeffortSuiteCharDB={} end
    return MeffortSuiteCharDB
end
local function Number(value)
    if type(issecretvalue)=="function" and issecretvalue(value) then return end
    if type(value)~="string" and type(value)~="number" then return end
    local number=tonumber(value)
    if number and number==number and number>=0 and number<=1 then return number end
end
local function Read(key)
    local getter=C_CVar and C_CVar.GetCVar or GetCVar
    if type(getter)~="function" then return end
    local ok,value=pcall(getter,key)
    if ok and Number(value) then return tostring(value),Number(value) end
end
local function Write(key,value)
    local setter=C_CVar and C_CVar.SetCVar or SetCVar
    if type(setter)~="function" then return false end
    local ok,result=pcall(setter,key,value)
    return ok and result~=false
end
local function Recovery()
    local saved=DB().fishingAudioRestore
    return type(saved)=="table" and saved or nil
end
local function Restore()
    active=false
    local saved=Recovery()
    if not saved then DB().fishingAudioRestore=nil;return true end
    local pending={}
    for _,key in ipairs(keys) do
        local original=saved[key]
        if Number(original) then
            local _,current=Read(key)
            if current==nil then pending[key]=original
            elseif current==0 then
                Write(key,original)
                local _,after=Read(key)
                if after==nil or after~=Number(original) then pending[key]=original end
            end
        end
    end
    DB().fishingAudioRestore=next(pending) and pending or nil
    return next(pending)==nil
end
local function FishingName()
    if spellName then return spellName end
    if C_Spell and type(C_Spell.GetSpellInfo)=="function" then
        local ok,info=pcall(C_Spell.GetSpellInfo,7620)
        if ok and type(info)=="table" and type(info.name)=="string" then spellName=info.name end
    end
    if not spellName and type(GetSpellInfo)=="function" then
        local ok,name=pcall(GetSpellInfo,7620)
        if ok and type(name)=="string" then spellName=name end
    end
    return spellName or "Fishing"
end
local function Fishing()
    if type(UnitChannelInfo)~="function" then return false end
    local ok,name,_,_,_,_,_,_,id=pcall(UnitChannelInfo,"player")
    if not ok then return false end
    if type(issecretvalue)=="function" and (issecretvalue(name) or issecretvalue(id)) then return false end
    return id==7620 or (type(name)=="string" and name==FishingName())
end
function M.Enabled()return Char().fishingQuietAudio==true end
function M.Refresh()
    local enabled=M.Enabled() and (not MeffortSuite or not MeffortSuite.Active or MeffortSuite.Active())
    local combat=type(InCombatLockdown)=="function" and InCombatLockdown()
    local pole=enabled and not combat and MeffortSuiteFishing and MeffortSuiteFishing.IsPoleEquipped and MeffortSuiteFishing.IsPoleEquipped()
    if not enabled or combat or not pole or not Fishing() then
        local restored=Restore()
        status=not restored and "volume restoration pending" or M.Enabled() and "waiting for fishing" or "off"
        return
    end
    if active then return end
    if Recovery() and not Restore() then status="volume restoration pending";return end
    local saved={}
    DB().fishingAudioRestore=saved
    for _,key in ipairs(keys) do
        local original,value=Read(key)
        if value and value>0 then
            saved[key]=original
            Write(key,"0")
            local _,after=Read(key)
            if after~=nil and after~=0 then saved[key]=nil end
        end
    end
    if not next(saved) then DB().fishingAudioRestore=nil;status="already quiet or volume API unavailable"
    else status="quiet; sound effects unchanged" end
    active=true
end
function M.SetEnabled(value)
    Char().fishingQuietAudio=value==true
    M.Refresh()
end
function M.Status()return (M.Enabled() and "enabled; " or "disabled; ")..status end

local events=CreateFrame("Frame")
for _,event in ipairs({"PLAYER_LOGIN","PLAYER_LOGOUT","PLAYER_LEAVING_WORLD","PLAYER_ENTERING_WORLD",
    "PLAYER_REGEN_DISABLED","PLAYER_REGEN_ENABLED","PLAYER_EQUIPMENT_CHANGED","UNIT_INVENTORY_CHANGED",
    "UNIT_SPELLCAST_CHANNEL_START","UNIT_SPELLCAST_CHANNEL_STOP","UNIT_SPELLCAST_INTERRUPTED",
    "UNIT_SPELLCAST_FAILED","SPELLS_CHANGED"}) do events:RegisterEvent(event) end
events:SetScript("OnEvent",function(_,event,unit)
    if event=="PLAYER_LOGOUT" or event=="PLAYER_LEAVING_WORLD" then
        status=Restore() and "volumes restored" or "volume restoration pending";return
    end
    if (event=="UNIT_INVENTORY_CHANGED" or event:match("^UNIT_SPELLCAST")) and unit~="player" then return end
    if event=="PLAYER_LOGIN" then Restore() end
    if event=="SPELLS_CHANGED" then spellName=nil end
    if event=="UNIT_SPELLCAST_CHANNEL_STOP" or event=="UNIT_SPELLCAST_INTERRUPTED" or event=="UNIT_SPELLCAST_FAILED" then
        status=Restore() and "volumes restored" or "volume restoration pending";return
    end
    M.Refresh()
end)
