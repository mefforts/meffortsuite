MeffortSuiteMinimap={}
local M=MeffortSuiteMinimap
local watcher=CreateFrame("Frame")
local collected={}
local addonTitles={}
local launcher,menuAnchor,menuDescription,openMenu
local menuBlocked=false
local ready,elapsed=false,0
local nativeNames={
    AddonCompartmentFrame=true,GameTimeFrame=true,TimeManagerClockButton=true,
    ExpansionLandingPageMinimapButton=true,QueueStatusMinimapButton=true,
    MinimapZoomIn=true,MinimapZoomOut=true,MinimapZoneTextButton=true,
    MiniMapTracking=true,MiniMapTrackingButton=true,MiniMapWorldMapButton=true,
    MiniMapMailFrame=true,MiniMapBattlefieldFrame=true,MiniMapLFGFrame=true,
}

local function Plain(text)
    if type(text)~="string" then return end
    return text:gsub("|c%x%x%x%x%x%x%x%x",""):gsub("|r",""):match("^%s*(.-)%s*$")
end
local function Key(text)
    local name=Plain(text)
    return name and name:lower():gsub("[%s_%-]","")
end
local function ReadAddonTitles()
    if not C_AddOns or not C_AddOns.GetNumAddOns or not C_AddOns.GetAddOnInfo then return end
    for index=1,C_AddOns.GetNumAddOns() do
        local name,title=C_AddOns.GetAddOnInfo(index)
        if name and not name:find("^Blizzard_") then
            local label=Plain(title)
            if not label or label=="" then label=name end
            addonTitles[Key(name)]=label
            addonTitles[Key(label)]=label
        end
    end
end
local function Identify(button,name)
    local broker=name and name:match("^LibDBIcon10_(.+)$")
    local stem=name and name:gsub("[_-]?[Mm]ini[Mm]ap[_-]?[Bb]utton.*$","")
        :gsub("[_-]?[Mm]ini[Mm]ap[_-]?[Ii]con.*$",""):gsub("[_-]?[Bb]utton$","")
    local title=broker and (addonTitles[Key(broker)] or Plain(broker)) or addonTitles[Key(stem)]
    local data=broker and button.dataObject
    local icon=type(data)=="table" and data.icon
    if type(icon)~="string" and type(icon)~="number" then icon=nil end
    if title and icon then return title,icon end
    local normal=button:GetNormalTexture()
    for _,region in ipairs({button:GetRegions()}) do
        if region.GetTexture and not region:IsForbidden() then
            local texture=region:GetTexture()
            local path=region.GetTextureFilePath and region:GetTextureFilePath()
            local owner=type(path)=="string" and path:lower():gsub("/","\\"):match("^interface\\addons\\([^\\]+)\\")
            if owner and addonTitles[Key(owner)] then
                return title or addonTitles[Key(owner)],texture
            end
            if not icon and (region==normal or region:GetDrawLayer()=="ARTWORK") then icon=texture end
        end
    end
    return title,icon or (normal and normal:GetTexture())
end
local function IsClickable(button)
    return not button:IsForbidden() and not button:IsProtected()
        and button:IsObjectType("Button") and button:IsEnabled() and button:GetScript("OnClick")~=nil
end
local function Candidate(button)
    if button==launcher or not IsClickable(button) or not button:IsVisible() then return end
    local name=button:GetName()
    if nativeNames[name] or button==Minimap.ZoomIn or button==Minimap.ZoomOut
        or (MinimapCluster and (button==MinimapCluster.ZoneTextButton
            or MinimapCluster.Tracking and button==MinimapCluster.Tracking.Button))
        or (MinimapBackdrop and button==MinimapBackdrop.ExternalEventURLButton) then return end
    local current=collected[button]
    if not current and (not button:IsMouseClickEnabled()
        or (button:GetEffectiveAlpha()<=0 and not button.showOnMouseover)) then return end
    if current then return current.title,current.icon end
    return Identify(button,name)
end

-- Leave the addon's shown state, anchors and settings in its own hands.
local function Restore(button,state)
    if button:IsForbidden() then return end
    if button:GetAlpha()==0 then button:SetAlpha(state.alpha) end
    if not button:IsMouseClickEnabled() then button:SetMouseClickEnabled(state.clicks) end
    if not button:IsMouseMotionEnabled() then button:SetMouseMotionEnabled(state.motion) end
end
local function Suppress(button,state)
    local alpha=button:GetAlpha()
    if alpha~=0 then state.alpha=alpha;button:SetAlpha(0) end
    if button:IsMouseClickEnabled() then button:SetMouseClickEnabled(false) end
    if button:IsMouseMotionEnabled() then button:SetMouseMotionEnabled(false) end
end
local function Collect(button,title,icon)
    local state=collected[button]
    if not state then
        state={title=title,icon=icon,alpha=button:GetAlpha(),clicks=button:IsMouseClickEnabled(),
            motion=button:IsMouseMotionEnabled()}
        collected[button]=state
    end
    Suppress(button,state)
end
local function FindButtons(parent,depth,seen,found)
    if not parent or seen[parent] or parent:IsForbidden() then return end
    seen[parent]=true
    for _,child in ipairs({parent:GetChildren()}) do
        local title,icon=Candidate(child)
        if title and title~="" then
            found[child]={title=title,icon=icon}
        elseif depth>0 and not child:IsForbidden() and not child:IsObjectType("Button") then
            FindButtons(child,depth-1,seen,found)
        end
    end
end

function M.Enabled()
    return type(MeffortSuiteDB)=="table" and MeffortSuiteDB.collapseMinimapButtons==true
end
function M.SetEnabled(enabled)
    if type(MeffortSuiteDB)~="table" then MeffortSuiteDB={} end
    MeffortSuiteDB.collapseMinimapButtons=enabled==true
    menuBlocked=false
    M.Refresh()
end

local function CloseMenu()
    local menu=openMenu
    openMenu=nil
    if menu then pcall(menu.Close,menu) end
end
local function MenuFailed(reason)
    menuBlocked=true
    if MeffortSuite.ReportError then MeffortSuite.ReportError("minimap","AddOns menu",reason) end
end
local function SetupLauncher()
    if launcher then return end
    local button=CreateFrame("Button","MeffortSuiteMinimapMenuButton",Minimap,"UIPanelButtonTemplate")
    button:Hide()
    button:SetSize(76,24)
    button:SetPoint("RIGHT",Minimap,"LEFT",-6,0)
    button:SetClampedToScreen(true)
    button:SetFrameStrata("MEDIUM")
    button:SetFrameLevel(Minimap:GetFrameLevel()+8)
    button:SetText((ADDONS or "AddOns").." ▾")
    button:RegisterForClicks("LeftButtonUp")
    button:SetScript("OnClick",function() M.Open() end)
    launcher=button
end
local function LauncherAvailable()
    return launcher and launcher:IsVisible() and launcher:IsEnabled()
        and launcher:IsMouseClickEnabled() and launcher:GetEffectiveAlpha()>0
end
local function ClickAddon(button,input)
    if not collected[button] or not IsClickable(button) or not button:IsVisible() then return end
    local mouse=type(input)=="table" and input.buttonName or nil
    button:Click(mouse or "LeftButton")
end
local function MenuText(title,icon)
    if type(icon)=="number" or (type(icon)=="string" and not icon:find("[|:]")) then
        return "|T"..icon..":14:14:0:0|t "..title
    end
    return title
end
local function BuildMenu(found)
    if type(Menu.GetManager().OpenMenu)~="function" then error("Menu manager unavailable") end
    local root=MenuUtil.CreateRootMenuDescription(MenuVariants.GetDefaultMenuMixin())
    root:SetMinimumWidth(165)
    root:SetScrollMode(290)
    root:CreateButton(MenuText("MeffortSuite","Interface\\AddOns\\MeffortSuite\\Textures\\MeffortSuiteIcon"),
        function() MeffortSuiteOpenSettings() end)
    local rows={}
    for button,entry in pairs(found) do
        rows[#rows+1]={button=button,title=entry.title,icon=entry.icon}
    end
    table.sort(rows,function(a,b) return a.title:lower()<b.title:lower() end)
    if #rows>0 then root:CreateDivider() end
    for _,entry in ipairs(rows) do
        local row=root:CreateButton(MenuText(entry.title,entry.icon),ClickAddon,entry.button)
        row:AddInitializer(function(button) button:RegisterForClicks("AnyUp") end)
    end
    if not root:HasElements() then error("AddOns menu has no entries") end
    return root
end
local function MenuNeedsRefresh(found)
    if not menuDescription then return true end
    for button in pairs(found) do
        if not collected[button] then return true end
    end
    for button in pairs(collected) do
        if not found[button] then return true end
    end
    return false
end
local function PrepareMenu(found)
    if not MenuNeedsRefresh(found) then return end
    local description=BuildMenu(found)
    if openMenu then openMenu:SetMenuDescription(description) end
    menuAnchor=AnchorUtil.CreateAnchor("TOPRIGHT",launcher,"BOTTOMRIGHT",0,-2)
    menuDescription=description
end

local function Reconcile(active)
    local found={}
    if active and not menuBlocked and LauncherAvailable() then
        local seen={}
        FindButtons(Minimap,1,seen,found)
        FindButtons(MinimapBackdrop,1,seen,found)
        FindButtons(MinimapCluster,2,seen,found)
        local ok,err=pcall(PrepareMenu,found)
        if not ok then MenuFailed(err);found={} end
    end
    if not active or menuBlocked or not LauncherAvailable() then
        CloseMenu()
        menuDescription=nil
    end
    for button,state in pairs(collected) do
        if not found[button] then
            Restore(button,state)
            collected[button]=nil
        end
    end
    for button,candidate in pairs(found) do
        Collect(button,candidate.title,candidate.icon)
    end
end
function M.Open()
    if openMenu then CloseMenu();return true end
    if not M.Enabled() or not MeffortSuite.Active() then return false end
    menuBlocked=false
    M.Refresh()
    if not menuDescription or not LauncherAvailable() then return false end
    local ok,err=pcall(function()
        local menu=Menu.GetManager():OpenMenu(launcher,menuDescription,menuAnchor)
        if not menu then error("The client declined to open the AddOns menu") end
        openMenu=menu
        menu:SetClosedCallback(function() if openMenu==menu then openMenu=nil end end)
    end)
    if not ok then
        MenuFailed(err)
        M.Refresh()
    end
    return ok
end
local function Watch(_,dt)
    elapsed=elapsed+dt
    if elapsed<.5 then return end
    elapsed=0
    M.Refresh()
end
function M.Refresh()
    if not ready then return end
    if InCombatLockdown() then watcher:SetScript("OnUpdate",nil);return end
    local active=M.Enabled() and MeffortSuite.Active() and Minimap
        and Menu and MenuUtil and MenuVariants and AnchorUtil
    if active and not launcher and not menuBlocked then
        local ok,err=pcall(SetupLauncher)
        if not ok then MenuFailed(err) end
    end
    if launcher then launcher:SetShown(not not active) end
    watcher:SetScript("OnUpdate",active and Watch or nil)
    Reconcile(active)
end

watcher:RegisterEvent("PLAYER_LOGIN")
watcher:RegisterEvent("PLAYER_ENTERING_WORLD")
watcher:RegisterEvent("PLAYER_REGEN_ENABLED")
watcher:RegisterEvent("PLAYER_REGEN_DISABLED")
watcher:SetScript("OnEvent",function(_,event)
    if event=="PLAYER_LOGIN" then
        ReadAddonTitles()
        ready=true
    end
    M.Refresh()
end)
