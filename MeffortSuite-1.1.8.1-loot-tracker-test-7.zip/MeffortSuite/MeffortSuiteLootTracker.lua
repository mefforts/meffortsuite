MeffortSuiteLootTracker={}
local M=MeffortSuiteLootTracker
local prices=MeffortSuiteLootValue
local defaultWidth,defaultHeight,rowHeight=376,300,19
local minWidth,minHeight,maxWidth,maxHeight=320,270,680,620
local compactHeight=20
local maxTimerMinutes=1440
local compactNames={vendor="Vendor total",auctionator="Auctionator estimate",coins="Coins looted"}
local trackerStyles={parchment=true,transparent=true,blizzard=true}
local paperTexture="Interface\\AddOns\\MeffortSuite\\Textures\\LootJournal"
local blizzardBackground="Interface\\DialogFrame\\UI-DialogBox-Background"
local blizzardBorder="Interface\\DialogFrame\\UI-DialogBox-Border"
local session={byKey={},items={},coins=0,count=0}
local tracking,queued=false,false
local deadline,lastSecond,timerExpired
local panel,strip,stripAmount,status,startButton,timerButton,itemsButton,valuesButton,coinValue
local scroll,scrollBar,content,selection,empty,valuesPanel,vendorValue,auctionValue,priceNote
local rows={}
local layout,operation
local events=CreateFrame("Frame")

local function SuiteActive()
    return MeffortSuite.Active()
end
function M.IsTracking()
    return tracking and SuiteActive() and (not deadline or GetTime()<deadline)
end
function M.AutoStart()
    return MeffortSuiteDB.lootTrackerAutoStart~=false
end
function M.SetAutoStart(enabled)
    MeffortSuiteDB.lootTrackerAutoStart=enabled==true
end

local function Finite(value)
    return type(value)=="number" and math.abs(value)<math.huge
end
local function Clamp(value,lower,upper)
    return math.max(lower,math.min(upper,value))
end
local function SavedLayout()
    local saved=MeffortSuiteDB.lootTrackerLayout
    if type(saved)~="table" then saved={};MeffortSuiteDB.lootTrackerLayout=saved end
    saved.width=Finite(saved.width) and Clamp(saved.width,minWidth,maxWidth) or defaultWidth
    saved.height=Finite(saved.height) and Clamp(saved.height,minHeight,maxHeight) or defaultHeight
    saved.view=saved.view=="values" and "values" or "items"
    saved.compact=saved.compact~=false
    if saved.positionVersion~=1 then
        if saved.compact then saved.x,saved.y=nil,nil end
        saved.positionVersion=1
    end
    if not compactNames[saved.compactValue] then saved.compactValue="vendor" end
    return saved
end
local function ActiveWindow()
    if layout and layout.compact then return strip end
    return panel
end
local function PlaceWindow(window)
    window:ClearAllPoints()
    if not Finite(layout.x) or not Finite(layout.y) then
        local container=MinimapCluster and MinimapCluster.MinimapContainer
        local coordinates=container and container.PlayerCoords
        if coordinates then
            window:SetPoint("TOP",coordinates,"BOTTOM",0,-5)
        elseif Minimap then
            window:SetPoint("TOP",Minimap,"BOTTOM",0,-24)
        else
            window:SetPoint("CENTER",UIParent,"CENTER",0,0)
        end
        return
    end
    local screenWidth,screenHeight=UIParent:GetSize()
    local scale=window:GetScale()
    local w,h=window:GetWidth()*scale,window:GetHeight()*scale
    local x=Clamp(layout.x,0,math.max(0,screenWidth-w))
    local y=Clamp(layout.y,math.min(0,h-screenHeight),0)
    window:SetPoint("TOPLEFT",UIParent,"TOPLEFT",x/scale,y/scale)
end
local function SizeStrip()
    local measure=stripAmount.GetUnboundedStringWidth or stripAmount.GetStringWidth
    local textWidth=measure(stripAmount)
    local width=Finite(textWidth) and textWidth>0 and math.max(24,math.ceil(textWidth)+8) or 42
    local screenWidth,screenHeight=UIParent:GetSize()
    local scale=Clamp(math.min((screenWidth-8)/width,(screenHeight-8)/compactHeight),.1,1)
    if strip:GetWidth()~=width or strip:GetScale()~=scale then
        strip:SetScale(scale)
        strip:SetSize(width,compactHeight)
        PlaceWindow(strip)
    end
end
local function Readable(label,r,g,b)
    label:SetTextColor(r,g,b)
    label:SetShadowColor(.06,.033,.018,.95)
    label:SetShadowOffset(1,-1)
end
local function ShowingItems()
    return layout and not layout.compact and layout.view=="items"
end
local function RenderItems()
    if not panel or not ShowingItems() or not panel:IsShown() then return end
    local capacity=math.ceil(scroll:GetHeight()/rowHeight)+1
    for index=#rows+1,capacity do
        local name=content:CreateFontString(nil,"OVERLAY","GameFontHighlight")
        Readable(name,.98,.92,.81)
        name:SetJustifyH("LEFT")
        name:SetWordWrap(false)
        local quantity=content:CreateFontString(nil,"OVERLAY","GameFontHighlight")
        Readable(quantity,.99,.83,.57)
        rows[index]={name=name,quantity=quantity}
    end
    local first=math.floor(scroll:GetVerticalScroll()/rowHeight)+1
    local count=#session.items
    for offset,row in ipairs(rows) do
        local index=first+offset-1
        local item=offset<=capacity and session.items[count-index+1] or nil
        row.name:SetShown(item~=nil)
        row.quantity:SetShown(item~=nil)
        if item then
            local y=-(index-1)*rowHeight
            row.name:ClearAllPoints()
            row.name:SetPoint("TOPLEFT",content,"TOPLEFT",2,y)
            row.name:SetPoint("TOPRIGHT",content,"TOPRIGHT",-58,y)
            row.name:SetText(item.name)
            row.quantity:ClearAllPoints()
            row.quantity:SetPoint("TOPRIGHT",content,"TOPRIGHT",-5,y)
            row.quantity:SetText(tostring(item.count))
        end
    end
end
local function UpdateItemsLayout()
    if not panel or not ShowingItems() or not panel:IsShown() then return end
    local listWidth=math.max(1,scroll:GetWidth())
    local listHeight=math.max(1,#session.items*rowHeight)
    if content:GetWidth()~=listWidth or content:GetHeight()~=listHeight then
        content:SetSize(listWidth,listHeight)
        scroll:UpdateScrollChildRect()
    end
    local range=math.max(0,listHeight-scroll:GetHeight())
    scrollBar:SetMinMaxValues(0,range)
    scrollBar:SetShown(range>0)
    if scroll:GetVerticalScroll()>range then scroll:SetVerticalScroll(range) end
    RenderItems()
end
local function SessionValues()
    local vendorTotal,auctionTotal=session.coins,session.coins
    local missing,fallback=0,0
    for _,item in ipairs(session.items) do
        local vendor,auction=prices.TrackQuote(item)
        if vendor then vendorTotal=vendorTotal+vendor*item.count
        else missing=missing+item.count end
        if auction then
            auctionTotal=auctionTotal+auction*item.count
        elseif vendor then
            auctionTotal=auctionTotal+vendor*item.count
            fallback=fallback+item.count
        end
    end
    return vendorTotal,auctionTotal,missing,fallback
end
local function RenderValues()
    local vendorTotal,auctionTotal,missing,fallback=SessionValues()
    local auctionAvailable=prices.HasAuctionator()
    vendorValue:SetText(prices.FormatMoney(vendorTotal))
    auctionValue:SetText(auctionAvailable and prices.FormatMoney(auctionTotal) or "Unavailable")
    local note="Totals include coins."
    if not auctionAvailable then note=note.." Load Auctionator for AH estimates."
    elseif fallback>0 then note=note.." Items without an AH price use vendor value." end
    if missing>0 then note=note.." Partial totals. Waiting for prices on "..missing.." items." end
    priceNote:SetText(note)
end
local function CompactValue()
    local mode=layout.compactValue
    if mode=="auctionator" and not prices.HasAuctionator() then return "vendor" end
    return mode
end
local function RenderStrip()
    local mode=CompactValue()
    local amount=session.coins
    if mode~="coins" then
        local vendor,auction=SessionValues()
        amount=mode=="auctionator" and auction or vendor
    end
    stripAmount:SetText("+ "..prices.FormatMoney(amount,10))
    stripAmount:SetAlpha(M.IsTracking() and 1 or .72)
    if not operation then SizeStrip() end
end
local function SessionState()
    if not SuiteActive() then return "Suite off" end
    if M.IsTracking() then return "Tracking" end
    return timerExpired and "Time elapsed" or "Stopped"
end
local function RemainingTime()
    if not deadline then return end
    local seconds=math.max(0,math.ceil(deadline-GetTime()))
    return string.format("%d:%02d",math.floor(seconds/60),seconds%60)
end
local function RenderStatus()
    local count=session.count
    local remaining=RemainingTime()
    status:SetText(SessionState().."  ·  "..count..(count==1 and " item" or " items")
        ..(remaining and ("  ·  "..remaining.." left") or ""))
end
local function Render()
    local window=ActiveWindow()
    if not window or not window:IsShown() then return end
    if layout.compact then RenderStrip();return end
    local running=M.IsTracking()
    local count=session.count
    RenderStatus()
    coinValue:SetText(prices.FormatMoney(session.coins))
    startButton:SetText(running and "Stop tracking" or "Start tracking")
    local minutes=M.GetTimerMinutes()
    timerButton:SetText(minutes>0 and ("Timer: "..minutes.."m") or "Timer: Off")
    local active=SuiteActive()
    startButton:SetEnabled(active)
    startButton:SetAlpha(active and 1 or .55)
    local items=ShowingItems()
    local selected=items and itemsButton or valuesButton
    selection:ClearAllPoints()
    selection:SetPoint("TOPLEFT",selected,"BOTTOMLEFT",5,-1)
    selection:SetPoint("TOPRIGHT",selected,"BOTTOMRIGHT",-5,-1)
    itemsButton:SetAlpha(items and 1 or .76)
    valuesButton:SetAlpha(items and .76 or 1)
    scroll:SetShown(items)
    empty:SetShown(items and count==0)
    valuesPanel:SetShown(not items)
    if items then UpdateItemsLayout() else RenderValues() end
end
local function RefreshSoon()
    local window=ActiveWindow()
    if queued or not window or not window:IsShown() then return end
    if not (C_Timer and C_Timer.After) then Render();return end
    queued=true
    C_Timer.After(0,function()
        queued=false
        Render()
    end)
end
local function Label(parent,text,font,point,x,y)
    local label=parent:CreateFontString(nil,"OVERLAY",font or "GameFontHighlightSmall")
    label:SetPoint(point,parent,point,x,y)
    label:SetText(text)
    Readable(label,.99,.92,.79)
    return label
end
local function Button(parent,text,w,point,x,y,action)
    local button=CreateFrame("Button",nil,parent)
    button:SetSize(w,24)
    button:SetPoint(point,parent,point,x,y)
    button:EnableMouse(true)
    local face=button:CreateTexture(nil,"BACKGROUND")
    face:SetAllPoints(button)
    parent.trackerButtonFaces[#parent.trackerButtonFaces+1]=face
    local highlight=button:CreateTexture(nil,"HIGHLIGHT")
    highlight:SetAllPoints(face)
    highlight:SetColorTexture(1,.81,.55,.15)
    button:SetHighlightTexture(highlight,"BLEND")
    local label=Label(button,text,"GameFontHighlight","CENTER",0,0)
    button:SetFontString(label)
    button:SetText(text)
    button:SetScript("OnClick",action)
    return button
end
local function SetView(selected)
    layout.view=selected
    Render()
end
local function SavePosition(window)
    local x,y=window:GetLeft(),window:GetTop()
    local left,top=UIParent:GetLeft(),UIParent:GetTop()
    if Finite(x) and Finite(y) and Finite(left) and Finite(top) then
        local scale=window:GetScale()
        layout.x,layout.y=x*scale-left,y*scale-top
    end
end
local function StopGeometry(window)
    if not operation then return end
    window:StopMovingOrSizing()
    if operation=="size" then
        layout.width=window:GetWidth()
        layout.height=window:GetHeight()
    end
    operation=nil
    SavePosition(window)
    window:SetUserPlaced(false)
    PlaceWindow(window)
    if window==strip and strip:IsShown() then SizeStrip() end
end
function M.Dock()
    layout=layout or SavedLayout()
    local window=ActiveWindow()
    if window then StopGeometry(window) end
    layout.x,layout.y=nil,nil
    if window then PlaceWindow(window) end
end
local function ApplyLayout(window)
    if window==strip then
        SizeStrip()
    else
        local screenWidth,screenHeight=UIParent:GetSize()
        local scale=Clamp(math.min((screenWidth-24)/minWidth,(screenHeight-24)/minHeight),.1,1)
        local widthLimit=Clamp((screenWidth-24)/scale,minWidth,maxWidth)
        local heightLimit=Clamp((screenHeight-24)/scale,minHeight,maxHeight)
        window:SetScale(scale)
        window:SetResizeBounds(minWidth,minHeight,widthLimit,heightLimit)
        window:SetSize(Clamp(layout.width,minWidth,widthLimit),Clamp(layout.height,minHeight,heightLimit))
    end
    PlaceWindow(window)
end
local function StripTooltip(self)
    if not GameTooltip then return end
    GameTooltip:SetOwner(self,"ANCHOR_TOPLEFT")
    GameTooltip:SetText(compactNames[CompactValue()])
    local remaining=RemainingTime()
    GameTooltip:AddLine(SessionState()..(remaining and ("  ·  "..remaining.." left") or ""),1,1,1)
    GameTooltip:AddLine("Click to expand. Right-click to change the total.",1,1,1)
    GameTooltip:AddLine("Drag to move.",1,1,1)
    GameTooltip:Show()
end
local function HideStripTooltip(self)
    if GameTooltip and GameTooltip:GetOwner()==self then GameTooltip:Hide() end
end
local function RefreshStripTooltip()
    if strip and GameTooltip and GameTooltip:IsShown() and GameTooltip:GetOwner()==strip then
        StripTooltip(strip)
    end
end
local function JournalPaper(window)
    local rim=window:CreateTexture(nil,"BACKGROUND")
    rim:SetAllPoints(window)
    rim:SetColorTexture(.42,.32,.23,.94)
    local paper=window:CreateTexture(nil,"BACKGROUND",nil,1)
    paper:SetPoint("TOPLEFT",window,"TOPLEFT",1,-1)
    paper:SetPoint("BOTTOMRIGHT",window,"BOTTOMRIGHT",-1,1)
    window.trackerRim,window.trackerPaper=rim,paper
end
function M.GetStyle()
    local style=MeffortSuiteDB and MeffortSuiteDB.lootTrackerStyle
    return trackerStyles[style] and style or "parchment"
end
local function ApplyStyle(window,style)
    if not window or window.trackerStyle==style then return end
    local blizzard=style=="blizzard"
    local paper=style=="parchment" or (blizzard and not window.SetBackdrop)
    local transparent=style=="transparent"
    if window.SetBackdrop then
        if blizzard then
            local edge=window==strip and 8 or 16
            local inset=edge/4
            window:SetBackdrop({bgFile=blizzardBackground,edgeFile=blizzardBorder,edgeSize=edge,
                tile=true,tileSize=32,insets={left=inset,right=inset,top=inset,bottom=inset}})
        elseif window.trackerStyle=="blizzard" then
            window:SetBackdrop(nil)
        end
    end
    window.trackerRim:SetShown(paper)
    window.trackerPaper:SetShown(paper)
    if paper then window.trackerPaper:SetTexture(blizzard and blizzardBackground or paperTexture) end
    if window.trackerWell then window.trackerWell:SetShown(not transparent) end
    for _,face in ipairs(window.trackerButtonFaces) do
        face:SetShown(not transparent)
        if blizzard then
            face:SetTexture("Interface\\Buttons\\UI-Panel-Button-Up")
            face:SetTexCoord(0,.625,0,.6875)
        elseif not transparent then
            face:SetColorTexture(.91,.73,.51,.075)
            face:SetTexCoord(0,1,0,1)
        end
    end
    window.trackerStyle=style
    if window.timerEditor then ApplyStyle(window.timerEditor,transparent and "parchment" or style) end
end
function M.SetStyle(style)
    if not trackerStyles[style] then return end
    MeffortSuiteDB.lootTrackerStyle=style
    ApplyStyle(panel,style)
    ApplyStyle(strip,style)
end
local function SetupWindow(window)
    window:Hide()
    window:SetFrameStrata("FULLSCREEN_DIALOG")
    window:SetClampedToScreen(true)
    window:EnableMouse(true)
    window:SetMovable(true)
    window:RegisterForDrag("LeftButton")
    window:SetScript("OnDragStop",StopGeometry)
    window.trackerButtonFaces={}
end
local function CreateStrip()
    local window=CreateFrame("Button","MeffortSuiteLootTrackerStrip",UIParent,BackdropTemplateMixin and "BackdropTemplate" or nil)
    SetupWindow(window)
    window:SetSize(42,compactHeight)
    window:RegisterForClicks("LeftButtonUp","RightButtonUp")
    JournalPaper(window)
    stripAmount=Label(window,"",nil,"CENTER",0,0)
    stripAmount:SetWordWrap(false)
    local dragged=false
    window:SetScript("OnMouseDown",function(_,mouse)if mouse=="LeftButton" then dragged=false end end)
    window:SetScript("OnDragStart",function(self)
        dragged=true
        operation="move"
        HideStripTooltip(self)
        self:StartMoving()
    end)
    window:SetScript("OnEnter",StripTooltip)
    window:SetScript("OnLeave",HideStripTooltip)
    window:SetScript("OnHide",function(self)
        StopGeometry(self)
        HideStripTooltip(self)
    end)
    window:SetScript("OnClick",function(self,mouse)
        if mouse=="RightButton" then
            local mode=CompactValue()
            if mode=="vendor" and prices.HasAuctionator() then layout.compactValue="auctionator"
            else layout.compactValue=mode=="coins" and "vendor" or "coins" end
            RenderStrip()
            StripTooltip(self)
        elseif not dragged then
            M.Open(false)
        end
    end)
    return window
end
local function CreateTimerControl(window)
    local editor=CreateFrame("Frame",nil,window,BackdropTemplateMixin and "BackdropTemplate" or nil)
    editor:SetFrameLevel(window:GetFrameLevel()+8)
    editor:SetSize(222,62)
    editor:EnableMouse(true)
    editor:Hide()
    editor.trackerButtonFaces={}
    window.timerEditor=editor
    JournalPaper(editor)
    Label(editor,"Minutes","GameFontHighlight","TOPLEFT",12,-17)
    local field=CreateFrame("EditBox",nil,editor,"InputBoxTemplate")
    field:SetSize(52,24)
    field:SetPoint("TOPLEFT",editor,"TOPLEFT",76,-11)
    field:SetAutoFocus(false)
    field:SetMaxLetters(4)
    field:SetFontObject(GameFontHighlight)
    field:SetJustifyH("CENTER")
    Readable(field,.99,.92,.79)
    local hint=Label(editor,"",nil,"TOPLEFT",12,-41)
    hint:SetWidth(198)
    hint:SetJustifyH("LEFT")
    local function Save()
        local ok,why=M.SetTimerMinutes(field:GetText())
        if not ok then
            hint:SetText(why)
            return
        end
        editor:Hide()
        if MeffortSuiteSettingsUI then MeffortSuiteSettingsUI.Refresh() end
    end
    Button(editor,"Set",60,"TOPRIGHT",-12,-11,Save)
    field:SetScript("OnEnterPressed",Save)
    field:SetScript("OnEscapePressed",function()editor:Hide()end)
    editor:SetScript("OnHide",function()field:ClearFocus()end)
    timerButton=Button(window,"Timer: Off",88,"BOTTOMLEFT",205,15,function()
        if editor:IsShown() then editor:Hide();return end
        field:SetText(tostring(M.GetTimerMinutes()))
        hint:SetText("0 turns the timer off.")
        editor:Show()
        field:SetFocus()
        field:HighlightText()
    end)
    editor:SetPoint("BOTTOMRIGHT",timerButton,"TOPRIGHT",0,6)
end
local function CreateWindow()
    local window=CreateFrame("Frame","MeffortSuiteLootTrackerWindow",UIParent,BackdropTemplateMixin and "BackdropTemplate" or nil)
    SetupWindow(window)
    window:SetSize(layout.width,layout.height)
    PlaceWindow(window)
    window:SetResizable(true)
    window:SetScript("OnDragStart",function(self)operation="move";self:StartMoving()end)
    JournalPaper(window)
    local rule=window:CreateTexture(nil,"BORDER")
    rule:SetPoint("TOPLEFT",window,"TOPLEFT",16,-48)
    rule:SetPoint("TOPRIGHT",window,"TOPRIGHT",-16,-48)
    rule:SetHeight(1)
    rule:SetColorTexture(.87,.66,.42,.19)
    Button(window,"×",24,"TOPRIGHT",-10,-10,function()window:Hide()end)
    Button(window,"Compact",76,"TOPRIGHT",-40,-10,function()M.Open(true)end)
    local title=Label(window,"Loot Tracker","GameFontNormalLarge","TOPLEFT",16,-13)
    Readable(title,1,.84,.57)
    status=Label(window,"",nil,"TOPLEFT",17,-33)
    itemsButton=Button(window,"Items",70,"TOPLEFT",16,-60,function()SetView("items")end)
    valuesButton=Button(window,"Values",70,"TOPLEFT",92,-60,function()SetView("values")end)
    selection=window:CreateTexture(nil,"ARTWORK")
    selection:SetHeight(2)
    selection:SetColorTexture(.91,.69,.44,.70)
    Label(window,"Coins looted","GameFontNormal","TOPLEFT",17,-98)
    coinValue=Label(window,"","GameFontHighlight","TOPRIGHT",-21,-98)
    startButton=Button(window,"Start tracking",112,"BOTTOMLEFT",17,15,function()M.SetTracking(not M.IsTracking())end)
    Button(window,"Reset",62,"BOTTOMLEFT",136,15,function()M.Reset()end)
    CreateTimerControl(window)
    window:SetScript("OnHide",function(self)
        self.timerEditor:Hide()
        StopGeometry(self)
    end)

    local grip=CreateFrame("Button",nil,window)
    grip:SetSize(18,18)
    grip:SetPoint("BOTTOMRIGHT",window,"BOTTOMRIGHT",-4,4)
    grip:EnableMouse(true)
    grip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    grip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    grip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    grip:SetScript("OnMouseDown",function(_,mouse)
        if mouse=="LeftButton" then operation="size";window:StartSizing("BOTTOMRIGHT") end
    end)
    grip:SetScript("OnMouseUp",function(_,mouse)
        if mouse=="LeftButton" and operation=="size" then StopGeometry(window) end
    end)

    local well=window:CreateTexture(nil,"BORDER")
    well:SetPoint("TOPLEFT",window,"TOPLEFT",16,-116)
    well:SetPoint("BOTTOMRIGHT",window,"BOTTOMRIGHT",-16,45)
    well:SetColorTexture(.08,.05,.035,.24)
    window.trackerWell=well
    scroll=CreateFrame("ScrollFrame",nil,window)
    scroll:SetPoint("TOPLEFT",window,"TOPLEFT",22,-123)
    scroll:SetPoint("BOTTOMRIGHT",window,"BOTTOMRIGHT",-30,52)
    scroll:EnableMouseWheel(true)
    content=CreateFrame("Frame",nil,scroll)
    content:SetSize(defaultWidth-52,1)
    scroll:SetScrollChild(content)
    scrollBar=CreateFrame("Slider",nil,scroll)
    scrollBar:SetPoint("TOPLEFT",scroll,"TOPRIGHT",2,0)
    scrollBar:SetPoint("BOTTOMLEFT",scroll,"BOTTOMRIGHT",2,0)
    scrollBar:SetWidth(10)
    scrollBar:SetOrientation("VERTICAL")
    scrollBar:EnableMouse(true)
    scrollBar:SetMinMaxValues(0,0)
    scrollBar:Hide()
    local rail=scrollBar:CreateTexture(nil,"BACKGROUND")
    rail:SetPoint("TOP",scrollBar,"TOP")
    rail:SetPoint("BOTTOM",scrollBar,"BOTTOM")
    rail:SetWidth(2)
    rail:SetColorTexture(.88,.69,.46,.15)
    local thumb=scrollBar:CreateTexture(nil,"ARTWORK")
    thumb:SetSize(5,23)
    thumb:SetColorTexture(.88,.69,.46,.68)
    scrollBar:SetThumbTexture(thumb)
    scrollBar:SetScript("OnValueChanged",function(_,offset)
        if scroll:GetVerticalScroll()~=offset then scroll:SetVerticalScroll(offset) end
    end)
    scroll:SetScript("OnVerticalScroll",function(_,offset)
        if scrollBar:GetValue()~=offset then scrollBar:SetValue(offset) end
        RenderItems()
    end)
    scroll:SetScript("OnMouseWheel",function(_,delta)
        local offset=Clamp(scroll:GetVerticalScroll()-delta*rowHeight*3,0,scroll:GetVerticalScrollRange())
        scroll:SetVerticalScroll(offset)
    end)
    scroll:HookScript("OnSizeChanged",UpdateItemsLayout)
    empty=Label(window,"No loot recorded yet.",nil,"TOPLEFT",24,-129)
    valuesPanel=CreateFrame("Frame",nil,window)
    valuesPanel:SetPoint("TOPLEFT",window,"TOPLEFT",24,-129)
    valuesPanel:SetPoint("BOTTOMRIGHT",window,"BOTTOMRIGHT",-21,52)
    Label(valuesPanel,"Vendor total","GameFontNormal","TOPLEFT",0,0)
    vendorValue=Label(valuesPanel,"","GameFontHighlight","TOPRIGHT",0,0)
    Label(valuesPanel,"Auctionator estimate","GameFontNormal","TOPLEFT",0,-27)
    auctionValue=Label(valuesPanel,"","GameFontHighlight","TOPRIGHT",0,-27)
    priceNote=Label(valuesPanel,"",nil,"TOPLEFT",0,-56)
    priceNote:SetPoint("TOPRIGHT",valuesPanel,"TOPRIGHT",0,-56)
    priceNote:SetJustifyH("LEFT")
    priceNote:SetWordWrap(true)
    return window
end

function M.Open(compact)
    layout=layout or SavedLayout()
    if type(compact)~="boolean" then compact=layout.compact end
    local previous=ActiveWindow()
    if compact then
        strip=strip or CreateStrip()
    else
        panel=panel or CreateWindow()
    end
    local window=compact and strip or panel
    if previous and previous~=window then
        StopGeometry(previous)
        previous:Hide()
    end
    layout.compact=compact
    if compact then PlaceWindow(window) else ApplyLayout(window) end
    ApplyStyle(window,M.GetStyle())
    window:Show()
    if window.Raise then window:Raise() end
    Render()
end
local function EndTracking(expired)
    tracking,timerExpired=false,expired
    deadline,lastSecond=nil,nil
    events:SetScript("OnUpdate",nil)
    Render()
    RefreshStripTooltip()
    if MeffortSuiteSettingsUI then MeffortSuiteSettingsUI.Refresh() end
end
local function UpdateTimer()
    local seconds=math.ceil(deadline-GetTime())
    if seconds<=0 then
        EndTracking(true)
        local message="Loot tracker timer elapsed. Tracking stopped."
        MeffortSuite.Message(message)
        if UIErrorsFrame then UIErrorsFrame:AddMessage(message,1,.82,.48,1) end
        if PlaySound and SOUNDKIT and SOUNDKIT.UI_AUTO_QUEST_COMPLETE then
            PlaySound(SOUNDKIT.UI_AUTO_QUEST_COMPLETE)
        end
    elseif seconds~=lastSecond then
        lastSecond=seconds
        if panel and panel:IsShown() then RenderStatus() end
        RefreshStripTooltip()
    end
end
function M.GetTimerMinutes()
    local minutes=MeffortSuiteDB.lootTrackerMinutes
    if Finite(minutes) and minutes>=0 and minutes<=maxTimerMinutes and minutes==math.floor(minutes) then
        return minutes
    end
    return 0
end
local function RestartTimer()
    local minutes=M.GetTimerMinutes()
    deadline=tracking and minutes>0 and (GetTime()+minutes*60) or nil
    lastSecond=nil
    events:SetScript("OnUpdate",deadline and UpdateTimer or nil)
end
function M.SetTimerMinutes(value)
    local minutes=tonumber(value)
    if not Finite(minutes) or minutes<0 or minutes>maxTimerMinutes or minutes~=math.floor(minutes) then
        return false,"Enter a whole number from 0 to "..maxTimerMinutes.."."
    end
    if minutes~=M.GetTimerMinutes() then
        MeffortSuiteDB.lootTrackerMinutes=minutes
        if M.IsTracking() then
            RestartTimer()
            RefreshStripTooltip()
        end
        Render()
    end
    return true
end
local function ResetSession()
    session={byKey={},items={},coins=0,count=0}
    timerExpired=false
    if scroll then scroll:SetVerticalScroll(0) end
    RestartTimer()
end
function M.Reset()
    ResetSession()
    Render()
end
function M.SetTracking(enabled)
    if not enabled then EndTracking(false);return end
    if not SuiteActive() then return end
    if not M.IsTracking() then
        tracking=true
        ResetSession()
    end
    M.Open()
    if MeffortSuiteSettingsUI then MeffortSuiteSettingsUI.Refresh() end
end
function M.RefreshMaster()
    if not SuiteActive() and tracking then EndTracking(false) else Render() end
end
function M.RecordItem(key,id,link,quantity)
    local item=session.byKey[key]
    if not item then
        item={id=id,link=link,name=link:match("|h%[(.-)%]|h") or ("Item "..id),count=0,
            allItems=true,auctionator=true,both=true}
        session.byKey[key]=item
        session.items[#session.items+1]=item
    end
    item.count=item.count+quantity
    session.count=session.count+quantity
    RefreshSoon()
end
function M.RecordMoney(amount)
    session.coins=session.coins+amount
    RefreshSoon()
end
function M.ItemDataReady(id)
    if not id then return end
    for _,item in ipairs(session.items) do
        if item.id==id and item.vendor==nil then
            item.nextTry=nil
            if not ShowingItems() then RefreshSoon() end
        end
    end
end

events:RegisterEvent("PLAYER_ENTERING_WORLD")
events:RegisterEvent("PLAYER_REGEN_ENABLED")
events:RegisterEvent("ADDON_LOADED")
events:RegisterEvent("DISPLAY_SIZE_CHANGED")
events:RegisterEvent("UI_SCALE_CHANGED")
events:SetScript("OnEvent",function(self,event,addon)
    if event=="PLAYER_ENTERING_WORLD" then
        self:UnregisterEvent(event)
        if M.AutoStart() and not tracking then M.SetTracking(true) end
        return
    elseif event=="DISPLAY_SIZE_CHANGED" or event=="UI_SCALE_CHANGED" then
        local window=ActiveWindow()
        if window and window:IsShown() and not operation then ApplyLayout(window) end
    elseif event=="ADDON_LOADED" then
        if addon~="Auctionator" then return end
        for _,item in ipairs(session.items) do
            if item.source~="Auctionator" then
                item.auctionChecked,item.value,item.source,item.nextTry=nil,nil,nil,nil
            end
        end
    end
    RefreshSoon()
end)
