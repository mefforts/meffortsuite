-- Small, conservative out-of-range warning. WoW exposes discrete spell/item
-- range checks, not exact player/target world coordinates.
MeffortSuiteTargetDistance = {}
local module = MeffortSuiteTargetDistance
local suite = MeffortSuite
local min, max, floor = math.min, math.max, math.floor
local db, display, dot, hint, config
local RefreshConfig
local elapsedSinceUpdate = 0
local spellProbes = {harm = {}, help = {}}
local selectedSpells = {}
local MIN_FONT, MAX_FONT = 10, 26
local MIN_RANGE, MAX_RANGE = 1, 100

local function IsSecret(value)
    return type(issecretvalue) == "function" and issecretvalue(value)
end
local function Number(value)
    if not IsSecret(value) and type(value) == "number" and value == value
        and value ~= math.huge and value ~= -math.huge then return value end
end
local function Boolean(value)
    if IsSecret(value) then return nil end
    if value == true or value == 1 then return true end
    if value == false or value == 0 then return false end
end
local function Message(line)
    if suite and suite.Message then suite.Message("Target Distance: " .. line) end
end
local function Trim(line)
    return (line or ""):match("^%s*(.-)%s*$")
end
local function Settings()
    if type(MeffortSuiteCharDB) ~= "table" then MeffortSuiteCharDB = {} end
    if type(MeffortSuiteCharDB.targetDistance) ~= "table" then
        MeffortSuiteCharDB.targetDistance = {}
    end
    db = MeffortSuiteCharDB.targetDistance
    if type(db.enabled) ~= "boolean" then db.enabled = false end -- opt-in on existing installs
    if type(db.locked) ~= "boolean" then db.locked = true end
    if not Number(db.fontSize) then db.fontSize = 19 end
    db.fontSize = min(MAX_FONT, max(MIN_FONT, db.fontSize))
    if not Number(db.x) then db.x = 0 end
    if not Number(db.y) then db.y = -132 end
    if type(db.spellName) ~= "string" then db.spellName = "" end
    if not Number(db.rangeYards) then db.rangeYards = 30 end
    db.rangeYards = min(MAX_RANGE, max(MIN_RANGE, db.rangeYards))
    return db
end
local function Active()
    return db and db.enabled == true and (not suite or suite.Active())
end
local function SpellInfo(id)
    if not C_Spell or type(C_Spell.GetSpellInfo) ~= "function" then return end
    local ok, info = pcall(C_Spell.GetSpellInfo, id)
    if not ok or type(info) ~= "table" or IsSecret(info) then return end
    local name, low, high = info.name, Number(info.minRange), Number(info.maxRange)
    if IsSecret(name) or type(name) ~= "string" or not high then return end
    return name, low or 0, high
end
local function SpellInRange(id)
    if not C_Spell or type(C_Spell.IsSpellInRange) ~= "function" then return end
    local ok, answer = pcall(C_Spell.IsSpellInRange, id, "target")
    if ok then return Boolean(answer) end
end
local function ItemInRange(itemID)
    -- Forever's live client can report a protected-action violation if the
    -- item-range API is invoked during combat. pcall does not prevent this.
    -- Keep item probes for out-of-combat estimates; use spell probes in combat.
    if type(InCombatLockdown) == "function" and InCombatLockdown() then return end
    if not C_Item or type(C_Item.IsItemInRange) ~= "function" then return end
    local ok, answer = pcall(C_Item.IsItemInRange, itemID, "target")
    if ok then return Boolean(answer) end
end

local function ScanSpellBook()
    local probes = {harm = {}, help = {}}
    local choices = {}
    if not C_SpellBook or type(C_SpellBook.GetNumSpellBookSkillLines) ~= "function"
        or type(C_SpellBook.GetSpellBookSkillLineInfo) ~= "function"
        or type(C_SpellBook.GetSpellBookItemInfo) ~= "function" then
        spellProbes, selectedSpells = probes, choices
        return
    end
    local ok, tabs = pcall(C_SpellBook.GetNumSpellBookSkillLines)
    tabs = ok and Number(tabs) or nil
    if not tabs then return end
    local bank = Enum and Enum.SpellBookSpellBank and Enum.SpellBookSpellBank.Player or 0
    local normal = Enum and Enum.SpellBookItemType and Enum.SpellBookItemType.Spell or 1
    local seen = {harm = {}, help = {}}
    for tab = 1, min(tabs, 40) do
        local good, line = pcall(C_SpellBook.GetSpellBookSkillLineInfo, tab)
        if good and type(line) == "table" and not IsSecret(line) then
            local offset, count = Number(line.itemIndexOffset), Number(line.numSpellBookItems)
            if offset and count then
                for slot = offset + 1, offset + min(count, 400) do
                    local got, item = pcall(C_SpellBook.GetSpellBookItemInfo, slot, bank)
                    if got and type(item) == "table" and not IsSecret(item)
                        and not IsSecret(item.itemType) and item.itemType == normal
                        and item.isOffSpec ~= true and item.isPassive ~= true then
                        local id = Number(item.spellID) or Number(item.actionID)
                        if id then
                            local name, lower, yards = SpellInfo(id)
                            if name and yards and yards >= 3 and yards <= 100 and lower == 0 then
                                local harmful, helpful
                                if C_Spell and C_Spell.IsSpellHarmful then
                                    local valid, value = pcall(C_Spell.IsSpellHarmful, id)
                                    if valid then harmful = Boolean(value) end
                                end
                                if C_Spell and C_Spell.IsSpellHelpful then
                                    local valid, value = pcall(C_Spell.IsSpellHelpful, id)
                                    if valid then helpful = Boolean(value) end
                                end
                                -- The highest known rank's ID is sufficient for each distinct spell.
                                local key = name:lower()
                                choices[key] = {id = id, name = name, range = yards}
                                for _, kind in ipairs({"harm", "help"}) do
                                    if (kind == "harm" and harmful or kind == "help" and helpful)
                                        and not seen[kind][yards] then
                                        seen[kind][yards] = true
                                        probes[kind][#probes[kind] + 1] = {id = id, yards = yards}
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
    spellProbes, selectedSpells = probes, choices
end

-- The small set of item probes known to return range booleans on the Forever
-- client. These may return nil on a given target/client and are safely ignored.
local harmItems = {{25, 13289}, {35, 18904}}
local helpItems = {{15, 1251}, {20, 21519}, {30, 954}, {40, 18640}}

local function Bounds()
    local lower, upper = 0, nil
    local found = false
    local hostile, friendly = false, false
    if UnitCanAttack then
        local ok, value = pcall(UnitCanAttack, "player", "target")
        if ok then hostile = Boolean(value) == true end
    end
    if UnitCanAssist then
        local ok, value = pcall(UnitCanAssist, "player", "target")
        if ok then friendly = Boolean(value) == true end
    end
    local function Apply(range, within)
        if within == nil then return end
        found = true
        if within then upper = upper and min(upper, range) or range
        else lower = max(lower, range) end
    end
    local group = hostile and "harm" or (friendly and "help" or nil)
    if group then
        for _, probe in ipairs(spellProbes[group]) do
            Apply(probe.yards, SpellInRange(probe.id))
        end
        for _, probe in ipairs(group == "harm" and harmItems or helpItems) do
            Apply(probe[1], ItemInRange(probe[2]))
        end
    end
    -- The interaction check varies by race, reach, and client. Only a positive
    -- near-distance result is useful; don't infer >8yd from a negative.
    if type(CheckInteractDistance) == "function" then
        local ok, value = pcall(CheckInteractDistance, "target", 3)
        if ok and Boolean(value) == true then Apply(8, true) end
    end
    -- Avoid representing inconsistent / talent-modified thresholds as precise.
    if not found or (upper and upper <= lower) then return nil end
    return lower, upper
end

local function SelectedSpell()
    if not db then return nil end
    if db.spellName ~= "" then return selectedSpells[db.spellName:lower()] end
    -- Only use Frostbolt if its API-listed range exactly matches the user's
    -- chosen yard threshold; talents can extend its effective range.
    local frost = selectedSpells["frostbolt"]
    if frost and math.abs(frost.range - db.rangeYards) < 0.1 then return frost end
end

local function IsOutsideRange()
    local threshold = db.rangeYards
    local spell = SelectedSpell()
    if spell and math.abs(spell.range - threshold) < 0.1 then
        local matching = true
        if C_Spell and type(C_Spell.IsSpellHarmful) == "function" then
            local ok, harmful = pcall(C_Spell.IsSpellHarmful, spell.id)
            if ok and Boolean(harmful) == true then
                local hostile = UnitCanAttack and UnitCanAttack("player", "target")
                matching = Boolean(hostile) == true
            end
        end
        if matching then
            local canReach = SpellInRange(spell.id)
            if canReach ~= nil then return not canReach end
        end
    end
    local low, high = Bounds()
    -- A lower bound of N is derived from a probe being OUTSIDE N yards.
    -- An upper bound of N means the target was WITHIN N yards.
    -- If the threshold falls inside an uncertain interval, show nothing.
    return low ~= nil and low >= threshold or false
end

local function RefreshDisplay()
    if not display or not db then return end
    dot:SetSize(db.fontSize, db.fontSize)
    display:ClearAllPoints()
    display:SetPoint("CENTER", UIParent, "CENTER", db.x, db.y)
    display:EnableMouse(db.locked ~= true)
    hint:SetShown(db.locked ~= true)
end
local function Refresh()
    if not display then return end
    if not Active() then display:Hide(); return end
    if db.locked ~= true then
        -- Explicitly unlocked: show a movable dot preview even without a target.
        display:Show()
        return
    end
    local exists = UnitExists and UnitExists("target")
    if IsSecret(exists) or Boolean(exists) ~= true then display:Hide(); return end
    local isSelf = UnitIsUnit and UnitIsUnit("target", "player")
    if Boolean(isSelf) == true then display:Hide(); return end
    if IsOutsideRange() then display:Show() else display:Hide() end
end

local function CreateDisplay()
    if display then return end
    display = CreateFrame("Frame", "MeffortSuiteTargetDistanceHUD", UIParent)
    display:SetSize(42, 32)
    display:SetFrameStrata("HIGH")
    display:SetClampedToScreen(true)
    display:SetMovable(true)
    display:RegisterForDrag("LeftButton")
    -- A real RGBA texture, not a Unicode glyph: the Forever game font does
    -- not necessarily contain U+25CF and otherwise renders a missing-glyph box.
    dot = display:CreateTexture(nil, "ARTWORK")
    dot:SetPoint("CENTER", display, "CENTER", 0, 0)
    dot:SetTexture("Interface\\AddOns\\MeffortSuite\\Textures\\RangeDot.tga")
    hint = display:CreateTexture(nil, "BACKGROUND")
    hint:SetAllPoints(display)
    hint:SetColorTexture(0.40, 0.05, 0.05, 0.24)
    display:SetScript("OnDragStart", function(self)
        if db and db.locked ~= true then self:StartMoving() end
    end)
    display:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        if not db then return end
        local x, y = self:GetCenter()
        local cx, cy = UIParent:GetCenter()
        if Number(x) and Number(y) and Number(cx) and Number(cy) then
            db.x, db.y = floor(x - cx + .5), floor(y - cy + .5)
        end
        RefreshDisplay()
    end)
    display:Hide()
    RefreshDisplay()
end

function module.Enabled()
    if not db then Settings() end
    return db.enabled == true
end
function module.SetEnabled(value)
    if not db then Settings() end
    db.enabled = value == true
    if db.enabled then CreateDisplay(); Refresh() else if display then display:Hide() end end
    if RefreshConfig then RefreshConfig() end
end
function module.SetLocked(value)
    if not db then Settings() end
    db.locked = value == true
    if not db.locked then db.enabled = true end
    CreateDisplay()
    RefreshDisplay()
    Refresh()
    if RefreshConfig then RefreshConfig() end
end
function module.SetSize(size)
    size = tonumber(size)
    if not Number(size) or size < MIN_FONT or size > MAX_FONT then
        Message("Dot size must be between " .. MIN_FONT .. " and " .. MAX_FONT .. ".")
        return
    end
    if not db then Settings() end
    db.fontSize = floor(size + .5)
    if display then RefreshDisplay() end
end
function module.Reset()
    if not db then Settings() end
    db.x, db.y = 0, -132
    if display then RefreshDisplay() end
end
function module.SetYards(yards)
    yards = tonumber(yards)
    if not yards or yards ~= yards or yards < MIN_RANGE or yards > MAX_RANGE then
        Message("Range must be between 1 and 100 yards. Example: /msuite distance yards 30")
        return false
    end
    if not db then Settings() end
    db.rangeYards = floor(yards * 10 + 0.5) / 10
    db.spellName = ""
    Message("Red dot beyond " .. db.rangeYards .. " yd; hidden within range or when uncertain.")
    Refresh()
    if RefreshConfig then RefreshConfig() end
    return true
end
function module.SetSpell(name)
    if not db then Settings() end
    name = Trim(name)
    if name == "" or name:lower() == "auto" then
        db.spellName = ""
        Message("Spell cleared; using the configured " .. db.rangeYards .. " yd threshold.")
        return
    end
    local spell = selectedSpells[name:lower()]
    if not spell then
        Message("Can't find that ranged spell in your spellbook. Try /msuite distance spell auto")
        return
    end
    db.spellName = spell.name
    db.rangeYards = spell.range
    Message("Red dot when " .. spell.name .. " is out of its listed " .. spell.range .. " yd range.")
    Refresh()
end

local function OpenLegacyPanel()
    if not db then Settings() end
    CreateDisplay()
    if config then
        config:Show()
        return
    end
    config = CreateFrame("Frame", "MeffortSuiteDistanceSettings", UIParent,
        BackdropTemplateMixin and "BackdropTemplate" or nil)
    if type(UISpecialFrames) == "table" then
        local registered = false
        for _, name in ipairs(UISpecialFrames) do
            if name == "MeffortSuiteDistanceSettings" then registered = true; break end
        end
        if not registered then table.insert(UISpecialFrames, "MeffortSuiteDistanceSettings") end
    end
    config:SetSize(332, 234)
    config:SetPoint("CENTER", UIParent, "CENTER", 230, 20)
    config:SetFrameStrata("DIALOG")
    config:SetClampedToScreen(true)
    config:SetMovable(true)
    config:EnableMouse(true)
    config:RegisterForDrag("LeftButton")
    config:SetScript("OnDragStart", function(self) self:StartMoving() end)
    config:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
    if config.SetBackdrop then
        config:SetBackdrop({bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
            edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border", edgeSize = 18,
            insets = {left=5,right=5,top=5,bottom=5}})
    end
    local title = config:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
    title:SetPoint("TOPLEFT",config,"TOPLEFT",18,-16)
    title:SetText("Out-of-range dot")
    local info = config:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    info:SetWidth(280)
    info:SetJustifyH("LEFT")
    info:SetPoint("TOPLEFT",config,"TOPLEFT",18,-48)
    info:SetText("Red dot ONLY when target is known to be beyond your threshold. Unknown distance stays hidden. Default: 30 yd.")
    local function Button(label, x, y, width, onClick)
        local button=CreateFrame("Button", nil, config, "UIPanelButtonTemplate")
        button:SetSize(width, 25)
        button:SetPoint("TOPLEFT", config, "TOPLEFT", x, y)
        button:SetText(label)
        button:SetScript("OnClick", onClick)
        return button
    end
    local onButton, lockButton
    onButton = Button("Enabled",18,-106,128,function()
        module.SetEnabled(not module.Enabled())
        onButton:SetText(module.Enabled() and "Enabled: ON" or "Enabled: OFF")
    end)
    lockButton = Button("Unlock HUD",158,-106,140,function()
        module.SetLocked(not db.locked)
        lockButton:SetText(db.locked and "Unlock HUD" or "Lock HUD")
    end)
    Button("Smaller",18,-141,89,function() module.SetSize(db.fontSize-1) end)
    Button("Larger",113,-141,89,function() module.SetSize(db.fontSize+1) end)
    Button("Reset",208,-141,90,function() module.Reset() end)
    local yardsBox=CreateFrame("EditBox", nil, config, "InputBoxTemplate")
    yardsBox:SetSize(58, 22)
    yardsBox:SetPoint("TOPLEFT", config, "TOPLEFT", 74, -181)
    yardsBox:SetAutoFocus(false)
    yardsBox:SetNumeric(false)
    yardsBox:SetMaxLetters(5)
    yardsBox:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
        if RefreshConfig then RefreshConfig() end
    end)
    local yardsLabel=config:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    yardsLabel:SetPoint("TOPLEFT",config,"TOPLEFT",18,-185)
    yardsLabel:SetText("Yards:")
    local function ApplyYards()
        if module.SetYards(yardsBox:GetText()) then yardsBox:ClearFocus() end
    end
    yardsBox:SetScript("OnEnterPressed",ApplyYards)
    Button("Set",146,-177,57,ApplyYards)
    Button("Close",228,-177,78,function() config:Hide() end)
    local note=config:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    note:SetPoint("TOPLEFT",config,"TOPLEFT",18,-216)
    note:SetText("Optional: /msuite distance spell Frostbolt")
    RefreshConfig = function()
        onButton:SetText(module.Enabled() and "Enabled: ON" or "Enabled: OFF")
        lockButton:SetText(db.locked and "Unlock HUD" or "Lock HUD")
        if not yardsBox:HasFocus() then yardsBox:SetText(tostring(db.rangeYards)) end
    end
    config:SetScript("OnShow", RefreshConfig)
    config:Hide()
    config:Show()
end

function module.OpenPanel()
    if MeffortSuiteSettingsUI and type(MeffortSuiteOpenSettings) == "function" then
        MeffortSuiteOpenSettings("range")
        return
    end
    OpenLegacyPanel()
end
function module.Refresh()
    if not db then Settings() end
    if display then RefreshDisplay(); Refresh() end
    if RefreshConfig then RefreshConfig() end
end

function module.Command(line)
    if not db then Settings() end
    local cmd, arg = Trim(line):match("^(%S+)%s*(.-)$")
    cmd = (cmd or ""):lower()
    if cmd == "on" or cmd == "off" then
        module.SetEnabled(cmd == "on")
        Message("HUD " .. (db.enabled and "enabled" or "disabled") .. ".")
    elseif cmd == "unlock" or cmd == "lock" then
        module.SetLocked(cmd == "lock")
        Message(db.locked and "Locked and click-through." or "Unlocked: drag the red dot preview.")
    elseif cmd == "reset" then
        module.Reset(); Message("Position reset.")
    elseif cmd == "size" then
        module.SetSize(arg)
    elseif cmd == "yards" or cmd == "range" then
        module.SetYards(arg)
    elseif cmd == "spell" then
        module.SetSpell(arg)
    elseif cmd == "" or cmd == "settings" or cmd == "config" then
        module.OpenPanel()
    else
        Message("/msuite distance on|off|unlock|lock|reset|size 19|yards 30|spell Frostbolt|spell auto")
    end
end

local events=CreateFrame("Frame")
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("PLAYER_TARGET_CHANGED")
events:RegisterEvent("SPELLS_CHANGED")
events:SetScript("OnEvent",function(_, event)
    if event == "PLAYER_LOGIN" then
        Settings()
        ScanSpellBook()
        CreateDisplay()
    elseif event == "SPELLS_CHANGED" then
        ScanSpellBook()
    end
    if db then Refresh() end
end)
events:SetScript("OnUpdate",function(_, seconds)
    elapsedSinceUpdate = elapsedSinceUpdate + seconds
    if elapsedSinceUpdate < 0.15 then return end
    elapsedSinceUpdate = 0
    if Active() then Refresh()
    elseif display and display:IsShown() then display:Hide() end
end)
