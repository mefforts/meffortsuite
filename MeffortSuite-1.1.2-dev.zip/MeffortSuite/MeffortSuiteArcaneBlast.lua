-- Mage-only. Draws a separate mouse-transparent overlay: never alters secure
-- Blizzard buttons or reads combat-restricted aura details in combat.
MeffortSuiteArcaneBlast = {}
local M = MeffortSuiteArcaneBlast
local DURATION, MAX_STACKS = 18, 4
-- Keep the idle tracker lightweight; refresh the countdown more often only
-- while an Arcane Blast effect is active.
local ACTIVE_REFRESH, IDLE_REFRESH = 0.12, 0.8
local ACTIVE_ICON_SCAN, IDLE_ICON_SCAN = 0.8, 2.0
local SPELL_FIELDS = {"spellID", "overrideSpellID", "overrideTooltipSpellID"}
local ICON_SPELL_METHODS = {"GetAuraSpellID", "GetSpellID", "GetBaseSpellID"}
local CAST_RANK_ONE = 400574
local BUFF_AURA = 400573
local FONT = STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
local db, overlay, stackText, timerText, wheel
local mage = false
local activeName = "Arcane Blast"
local stacks, expiresAt, lastGUID = 0, 0, nil
local iconFrame, iconScanElapsed, refreshElapsed = nil, 0, 0
local lastPositionFrame, lastX, lastY, lastW, lastH, lastScale
local lastStackLabel, lastTimerLabel
local spellNameCache = {}

local function Readable(value)
    return not (type(issecretvalue) == "function" and issecretvalue(value))
end
local function SafeNumber(value)
    if Readable(value) and type(value) == "number" and value == value
        and value ~= math.huge and value ~= -math.huge then return value end
end
local function SafeString(value)
    if Readable(value) and type(value) == "string" then return value end
end
local function SafeCall(fn, ...)
    if type(fn) ~= "function" then return nil end
    local ok, result = pcall(fn, ...)
    if ok and Readable(result) then return result end
end
local function Now() return (type(GetTime) == "function" and GetTime()) or 0 end
local function InCombat()
    local value = SafeCall(InCombatLockdown)
    return value == true
end
local function Config()
    if type(MeffortSuiteCharDB) ~= "table" then MeffortSuiteCharDB = {} end
    if type(MeffortSuiteCharDB.arcaneBlast) ~= "table" then MeffortSuiteCharDB.arcaneBlast = {} end
    db = MeffortSuiteCharDB.arcaneBlast
    if type(db.enabled) ~= "boolean" then db.enabled = true end
    if type(db.stacks) ~= "boolean" then db.stacks = true end
    if type(db.timer) ~= "boolean" then db.timer = true end
    if type(db.wheel) ~= "boolean" then db.wheel = false end
    return db
end
local function Enabled()
    if not mage then return false end
    local settings = db or Config()
    return settings.enabled == true and
        (not MeffortSuite or not MeffortSuite.Active or MeffortSuite.Active())
end
function M.Enabled() return mage and Config().enabled == true end
function M.IsMage() return mage end
function M.GetOption(key)
    if key == "enabled" or key == "stacks" or key == "timer" or key == "wheel" then
        return Config()[key] == true
    end
    return false
end
function M.SetOption(key, value)
    if key ~= "enabled" and key ~= "stacks" and key ~= "timer" and key ~= "wheel" then return end
    Config()[key] = value == true
    iconScanElapsed = 100
    M.Refresh()
end

local function SpellName(id)
    if not SafeNumber(id) then return nil end
    local cached = spellNameCache[id]
    if cached ~= nil then return cached or nil end
    local name
    if C_Spell and type(C_Spell.GetSpellInfo) == "function" then
        local info = SafeCall(C_Spell.GetSpellInfo, id)
        if type(info) == "table" then name = SafeString(info.name) end
    end
    if not name and type(GetSpellInfo) == "function" then
        name = SafeString(SafeCall(GetSpellInfo, id))
    end
    -- Do not cache unavailable spell info: it may become available later.
    if name then spellNameCache[id] = name end
    return name
end
local function LearnName()
    -- Spell knowledge and localized data may change after SPELLS_CHANGED.
    spellNameCache = {}
    activeName = SpellName(CAST_RANK_ONE) or SpellName(BUFF_AURA) or "Arcane Blast"
end
local function IsArcaneSpell(id)
    if not SafeNumber(id) then return false end
    return id == CAST_RANK_ONE or id == BUFF_AURA or SpellName(id) == activeName
end

-- Read the real harmful/self aura only while outside combat. During combat,
-- casting is tracked from UNIT_SPELLCAST_SUCCEEDED and the first-cast timer
-- is never restarted by subsequent casts.
local function AuraData()
    if InCombat() then return nil, false end
    if C_UnitAuras and type(C_UnitAuras.GetAuraDataBySpellName) == "function" then
        local data = SafeCall(C_UnitAuras.GetAuraDataBySpellName, "player", activeName, "HARMFUL")
        if type(data) ~= "table" then
            data = SafeCall(C_UnitAuras.GetAuraDataBySpellName, "player", activeName, "HELPFUL")
        end
        if type(data) == "table" then return data, true end
        return nil, true
    end
    -- Older client fallback. Check both independently: UnitDebuff may be
    -- absent while UnitBuff is still available on a particular client.
    local function TryLegacy(method)
        if type(method) ~= "function" then return nil end
        local ok, name, _, count, _, duration, expiration = pcall(method, "player", activeName)
        if ok and SafeString(name) == activeName then
            return {applications = count, duration = duration, expirationTime = expiration}
        end
    end
    local data = TryLegacy(UnitDebuff) or TryLegacy(UnitBuff)
    return data, type(UnitDebuff) == "function" or type(UnitBuff) == "function"
end
local function ReconcileAura()
    if not mage or InCombat() then return end
    local aura, supported = AuraData()
    if not supported then return end
    if not aura then stacks, expiresAt = 0, 0; return end
    local count = SafeNumber(aura.applications) or SafeNumber(aura.stackCount)
    local expiration = SafeNumber(aura.expirationTime)
    if count and count >= 1 then stacks = math.min(MAX_STACKS, math.floor(count)) end
    if expiration and expiration > Now() then expiresAt = expiration end
    if count == 0 or (expiration and expiration <= Now()) then
        stacks, expiresAt = 0, 0
    end
end
local function AdvanceCast(guid)
    local now = Now()
    if SafeString(guid) and lastGUID == guid then return end
    lastGUID = SafeString(guid)
    if stacks == 0 or now >= expiresAt then
        stacks, expiresAt = 1, now + DURATION
    else
        stacks = math.min(MAX_STACKS, stacks + 1)
    end
end
local function TickExpiry()
    if stacks > 0 and Now() >= expiresAt then stacks, expiresAt = 0, 0 end
end

local function CooldownID(frame)
    if not frame then return nil end
    local id = SafeNumber(frame.cooldownID)
    if id then return id end
    local info = frame.cooldownInfo
    if type(info) == "table" and Readable(info) then
        id = SafeNumber(info.cooldownID)
        if id then return id end
    end
    return SafeNumber(SafeCall(frame.GetCooldownID, frame))
end
local function IsArcaneIcon(frame)
    local id = CooldownID(frame)
    if id and C_CooldownViewer and type(C_CooldownViewer.GetCooldownViewerCooldownInfo) == "function" then
        local info = SafeCall(C_CooldownViewer.GetCooldownViewerCooldownInfo, id)
        if type(info) == "table" then
            for _, field in ipairs(SPELL_FIELDS) do
                if IsArcaneSpell(info[field]) then return true end
            end
            if type(info.linkedSpellIDs) == "table" and Readable(info.linkedSpellIDs) then
                for _, spell in ipairs(info.linkedSpellIDs) do
                    if IsArcaneSpell(spell) then return true end
                end
            end
        end
    end
    -- Fallback to the icon's own spell info when Blizzard omits CDM metadata.
    for _, method in ipairs(ICON_SPELL_METHODS) do
        if type(frame[method]) == "function" and IsArcaneSpell(SafeCall(frame[method], frame)) then
            return true
        end
    end
    return false
end
local function FindIn(root, depth)
    if not root or depth > 4 then return nil end
    if depth > 0 and IsArcaneIcon(root) then return root end
    if type(root.GetChildren) ~= "function" then return nil end
    local children = {root:GetChildren()}
    for _, child in ipairs(children) do
        local found = FindIn(child, depth + 1)
        if found then return found end
    end
end
local function LocateIcon()
    return FindIn(_G.BuffIconCooldownViewer, 0)
end
local function EnsureOverlay()
    if overlay then return end
    overlay = CreateFrame("Frame", "MeffortSuiteArcaneBlastOverlay", UIParent)
    overlay:SetSize(40, 40)
    overlay:SetFrameStrata("MEDIUM")
    overlay:SetFrameLevel(10)
    overlay:EnableMouse(false)
    wheel = CreateFrame("Cooldown", nil, overlay, "CooldownFrameTemplate")
    wheel:SetAllPoints(overlay)
    if type(wheel.SetHideCountdownNumbers) == "function" then wheel:SetHideCountdownNumbers(true) end
    if type(wheel.SetDrawEdge) == "function" then wheel:SetDrawEdge(false) end
    if type(wheel.SetSwipeColor) == "function" then wheel:SetSwipeColor(.10, .10, .24, .48) end
    wheel:EnableMouse(false)
    stackText = overlay:CreateFontString(nil, "OVERLAY")
    stackText:SetFont(FONT, 19, "OUTLINE")
    stackText:SetTextColor(1, .96, .35, 1)
    stackText:SetPoint("BOTTOMRIGHT", overlay, "BOTTOMRIGHT", -2, 1)
    stackText:SetJustifyH("RIGHT")
    timerText = overlay:CreateFontString(nil, "OVERLAY")
    timerText:SetFont(FONT, 12, "OUTLINE")
    timerText:SetTextColor(1, 1, 1, 1)
    timerText:SetPoint("TOPLEFT", overlay, "TOPLEFT", 2, -1)
    timerText:SetJustifyH("LEFT")
    overlay:Hide()
end
-- A detached overlay must follow effective visibility, not only the icon's
-- own shown flag. Never parent to or modify Blizzard's protected icon.
local function IconVisible(frame)
    if not frame then return false end
    if type(frame.IsVisible) == "function" then
        return SafeCall(frame.IsVisible, frame) == true
    end
    local current = frame
    for _ = 1, 20 do
        if not current then return true end
        if SafeCall(current.IsShown, current) ~= true then return false end
        if type(current.GetParent) ~= "function" then return true end
        local ok, parent = pcall(current.GetParent, current)
        if not ok or not Readable(parent) then return false end
        current = parent
    end
    return false -- Unexpected/cyclic hierarchies must not leave floating text.
end
local function PositionOverIcon(frame)
    if not frame or type(frame.GetCenter) ~= "function" then return false end
    local ok, x, y = pcall(frame.GetCenter, frame)
    local width = SafeNumber(SafeCall(frame.GetWidth, frame))
    local height = SafeNumber(SafeCall(frame.GetHeight, frame))
    if not ok or not SafeNumber(x) or not SafeNumber(y) or not width or not height then return false end
    local sourceScale, parentScale = 1, 1
    if type(frame.GetEffectiveScale) == "function" then
        sourceScale = SafeNumber(SafeCall(frame.GetEffectiveScale, frame))
    end
    if type(UIParent.GetEffectiveScale) == "function" then
        parentScale = SafeNumber(SafeCall(UIParent.GetEffectiveScale, UIParent))
    end
    if not sourceScale or not parentScale or sourceScale <= 0 or parentScale <= 0 then return false end
    local ratio = sourceScale / parentScale
    if not SafeNumber(ratio) or width < 12 or height < 12 then return false end
    local scaledX, scaledY, scaledW, scaledH = x * ratio, y * ratio, width * ratio, height * ratio
    if not SafeNumber(scaledX) or not SafeNumber(scaledY)
        or not SafeNumber(scaledW) or not SafeNumber(scaledH) then return false end
    if frame ~= lastPositionFrame or x ~= lastX or y ~= lastY
        or width ~= lastW or height ~= lastH or ratio ~= lastScale then
        overlay:ClearAllPoints()
        overlay:SetPoint("CENTER", UIParent, "BOTTOMLEFT", scaledX, scaledY)
        overlay:SetSize(scaledW, scaledH)
        lastPositionFrame, lastX, lastY, lastW, lastH, lastScale = frame, x, y, width, height, ratio
    end
    -- Match the source layer so unrelated dialogs can cover the tracker.
    local strata = SafeString(SafeCall(frame.GetFrameStrata, frame))
    if strata then overlay:SetFrameStrata(strata) end
    local level = SafeNumber(SafeCall(frame.GetFrameLevel, frame))
    if level then overlay:SetFrameLevel(math.max(0, math.floor(level)) + 1) end
    return true
end
local wheelExpiry = nil
function M.Refresh()
    if not mage then return end
    TickExpiry()
    local enabled = Enabled()
    -- Cooldown metadata is safest to inspect outside combat. Use a slower
    -- heartbeat at idle, and scan faster only while stacks are actually up.
    if enabled and not InCombat() and iconScanElapsed >=
        (stacks > 0 and ACTIVE_ICON_SCAN or IDLE_ICON_SCAN) then
        iconScanElapsed = 0
        iconFrame = LocateIcon()
    end
    if not enabled or stacks == 0 then
        if overlay then overlay:Hide() end
        return
    end
    -- Never attempt a first-time icon tree traversal in combat.
    if not IconVisible(iconFrame) then
        if overlay then overlay:Hide() end
        return
    end
    EnsureOverlay()
    if not PositionOverIcon(iconFrame) then overlay:Hide(); return end
    local remaining = math.max(0, expiresAt - Now())
    local conf = Config()
    local stackLabel = conf.stacks and tostring(stacks) or ""
    local timerLabel = conf.timer and tostring(math.ceil(remaining)) or ""
    if stackLabel ~= lastStackLabel then
        stackText:SetText(stackLabel)
        lastStackLabel = stackLabel
    end
    if timerLabel ~= lastTimerLabel then
        timerText:SetText(timerLabel)
        lastTimerLabel = timerLabel
    end
    if conf.wheel then
        if wheelExpiry ~= expiresAt then
            wheelExpiry = expiresAt
            wheel:SetCooldown(expiresAt - DURATION, DURATION)
        end
        wheel:Show()
    else
        wheel:Hide()
    end
    if conf.stacks or conf.timer or conf.wheel then overlay:Show() else overlay:Hide() end
end

local events = CreateFrame("Frame")
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("PLAYER_ENTERING_WORLD")
events:RegisterEvent("SPELLS_CHANGED")
events:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
events:RegisterEvent("UNIT_AURA")
events:RegisterEvent("PLAYER_REGEN_ENABLED")
events:SetScript("OnEvent", function(_, event, ...)
    if event == "PLAYER_LOGIN" or event == "PLAYER_ENTERING_WORLD" then
        mage = SafeCall(UnitClassBase, "player") == "MAGE"
        if not mage and type(UnitClass) == "function" then
            local _, class = UnitClass("player")
            mage = class == "MAGE"
        end
        if not mage then return end
        Config(); LearnName(); ReconcileAura(); EnsureOverlay()
        iconScanElapsed = 100
    elseif not mage then return
    elseif event == "SPELLS_CHANGED" then
        LearnName(); iconScanElapsed = 100
    elseif event == "UNIT_SPELLCAST_SUCCEEDED" then
        local unit, guid, spellID = ...
        -- Keep cheap cast tracking while hidden. Toggling a display preference
        -- mid-combat must not resume an estimate that missed successful casts.
        if unit == "player" and IsArcaneSpell(spellID) then AdvanceCast(guid) end
    elseif event == "UNIT_AURA" then
        local unit = ...
        if unit == "player" and not InCombat() then ReconcileAura() end
    elseif event == "PLAYER_REGEN_ENABLED" then
        ReconcileAura()
        iconScanElapsed = 100
    end
    M.Refresh()
end)
events:SetScript("OnUpdate", function(_, elapsed)
    if not mage then return end
    if not Enabled() then
        -- The Suite master toggle can change without a dedicated event.
        if overlay and overlay:IsShown() then overlay:Hide() end
        return
    end
    refreshElapsed = refreshElapsed + elapsed
    iconScanElapsed = iconScanElapsed + elapsed
    local interval = stacks > 0 and ACTIVE_REFRESH or IDLE_REFRESH
    if refreshElapsed >= interval then
        refreshElapsed = 0
        M.Refresh()
    end
end)
