local ADDON = ...
local enabled, mode, registered = false, "replace", false
local stats = { matched=0, replaced=0, compared=0, fallback=0, skipped=0, errors=0 }
local recent = setmetatable({}, {__mode="k"})
local last = { spellID=nil, name=nil, result="No tooltip processed yet" }
local playerClass, playerRace
local comparePanel
local ENGLISH_ONLY = true
local SafeString
local function IsSecret(v) return issecretvalue and issecretvalue(v) end
SafeString = function(v)
    if v == nil or IsSecret(v) then return nil end
    if type(v) == "string" then return v end
end
local function SafeNumber(v)
    if v == nil or IsSecret(v) then return nil end
    if type(v) == "number" then return v end
end
local function Message(msg)
    if DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then
        DEFAULT_CHAT_FRAME:AddMessage("|cff60d9bdMeffortSuite|r: "..msg)
    end
end
local function Normalize(t)
    t = SafeString(t)
    if not t then return nil end
    return t:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("%s+", " "):match("^%s*(.-)%s*$")
end
local function Decorate(text, emph)
    if type(text) ~= "string" then return nil end
    if type(emph) ~= "string" or emph == "" then return text end
    local i,j = text:find(emph,1,true)
    if not i then return text end
    return text:sub(1,i-1).."|cff60e3bf"..text:sub(i,j).."|r"..text:sub(j+1)
end
local function SetMode(nextMode)
    mode = nextMode == "compare" and "compare" or "replace"
    if GameTooltip then recent[GameTooltip]=nil end
    if comparePanel and comparePanel.Hide then comparePanel:Hide() end
end
local function IsActive()
    return (not MeffortSuite or not MeffortSuite.StandaloneLoaded("MeffortBars"))
        and (not MeffortSuiteDB or MeffortSuiteDB.masterEnabled~=false)
end
function MeffortSuiteIsActive() return IsActive() end
local function CurrentLocaleOk()
    local locale = GetLocale and GetLocale() or "enUS"
    return not ENGLISH_ONLY or locale=="enUS" or locale=="enGB"
end
local function EnsurePlayer()
    if not playerClass and UnitClass then
        local _, c=UnitClass("player")
        if type(c)=="string" then playerClass=c end
    end
    if not playerRace and UnitRace then
        local _,r=UnitRace("player")
        if type(r)=="string" then
            r=r:upper()
            if r=="SCOURGE" then r="UNDEAD" end
            playerRace=r
        end
    end
end
local function BySpellID(id)
    if not MeffortSuiteData or not MeffortSuiteData.spells then return end
    local entry=MeffortSuiteData.spells[id]
    if entry and entry.byClass then return entry.byClass[playerClass] end
    return entry
end
local function TooltipTitle(data, tooltip)
    local title
    if type(data.lines)=="table" and not IsSecret(data.lines) then
        local marker=Enum and Enum.TooltipDataLineType and Enum.TooltipDataLineType.SpellName
        for _,line in ipairs(data.lines) do
            if type(line)=="table" and not IsSecret(line) then
                local ltype=line.type
                if not IsSecret(ltype) and (ltype==marker or ltype==13) then
                    title=Normalize(line.leftText)
                    if title and title~="" then return title end
                end
            end
        end
    end
    if tooltip and tooltip.GetName then
        local name=tooltip:GetName()
        if type(name)=="string" then
            local titleFont=_G[name.."TextLeft1"]
            if titleFont and titleFont.GetText then title=Normalize(titleFont:GetText()) end
        end
    end
    return title
end
local function SourceDescription(data)
    if type(data.lines)~="table" or IsSecret(data.lines) then return nil end
    local descType=Enum and Enum.TooltipDataLineType and Enum.TooltipDataLineType.SpellDescription
    if type(descType)~="number" then return nil end
    for _,line in ipairs(data.lines) do
        if type(line)=="table" and not IsSecret(line) then
            local ltype=line.type
            if not IsSecret(ltype) and ltype==descType then
                return SafeString(line.leftText)
            end
        end
    end
end
local function CleanName(name)
    if not name then return nil end
    return name:gsub("%s*%([Rr]ank%s+%d+%)%s*$", ""):gsub("%s+[Rr]ank%s+%d+%s*$", "")
end
local function NameMatches(name, expected)
    return CleanName(name)==expected
end
local function TooltipRank(data,tooltip)
    local function Check(t)
        t=SafeString(t)
        if not t then return end
        local n=t:match("[Rr]ank%s+(%d+)")
        return n and tonumber(n)
    end
    if type(data.lines)=="table" and not IsSecret(data.lines) then
        for _,line in ipairs(data.lines) do
            if type(line)=="table" and not IsSecret(line) then
                local n=Check(line.leftText) or Check(line.rightText)
                if n then return n end
            end
        end
    end
    if tooltip and tooltip.GetName then
        local name=tooltip:GetName()
        if type(name)=="string" then
            for i=1,3 do
                for _,side in ipairs({"TextLeft","TextRight"}) do
                    local font=_G[name..side..i]
                    if font and font.GetText then
                        local n=Check(font:GetText())
                        if n then return n end
                    end
                end
            end
        end
    end
end
local function ResolveRank(list,desc,rank)
    if type(list)~="table" then return nil end
    if #list==1 then return list[1] end
    if desc then
        local plain=Normalize(desc)
        local one
        for _,candidate in ipairs(list) do
            if Normalize(candidate.o)==plain then
                if one then return nil end
                one=candidate
            end
        end
        if one then return one end
    end
    if rank then
        for _,candidate in ipairs(list) do
            if candidate.r==rank then return candidate end
        end
    end
end
local function ByName(name,desc,rank)
    if not name or not MeffortSuiteData then return nil end
    local clean=CleanName(name)
    local learned=MeffortSuiteData.spellByName and MeffortSuiteData.spellByName[playerClass]
    local choice=ResolveRank(learned and learned[clean],desc,rank)
    if choice then return choice end
    local specific=MeffortSuiteData.byName and MeffortSuiteData.byName[playerClass]
    choice=ResolveRank(specific and specific[clean],desc,rank)
    if choice then return choice end
    local race=MeffortSuiteData.racial and MeffortSuiteData.racial[playerRace]
    choice=ResolveRank(race and race[clean],desc,rank)
    if choice then return choice end
    if playerClass=="PRIEST" then
        local pr=MeffortSuiteData.priest and MeffortSuiteData.priest[playerRace]
        choice=ResolveRank(pr and pr[clean],desc,rank)
        if choice then return choice end
    end
    return ResolveRank(MeffortSuiteData.legacy and MeffortSuiteData.legacy[clean],desc,rank)
end
local learnedHighestRanks = nil
local function ReadSpellbook()
    local ranks={}
    local scanned=0
    local function Record(name,subName,id)
        name=CleanName(Normalize(name))
        if not name or name=="" then return end
        local rank
        if type(subName)=="string" and not IsSecret(subName) then
            rank=tonumber(subName:match("[Rr]ank%s+(%d+)"))
        end
        if not rank and type(id)=="number" and not IsSecret(id) then
            local entry=BySpellID(id)
            if entry and entry.n==name then rank=SafeNumber(entry.r) end
        end
        if rank and rank>0 and rank<=30 then
            if not ranks[name] or rank>ranks[name] then ranks[name]=rank end
            scanned=scanned+1
        end
    end
    local modern=C_SpellBook and C_SpellBook.GetNumSpellBookSkillLines and
        C_SpellBook.GetSpellBookSkillLineInfo and C_SpellBook.GetSpellBookItemInfo
    if modern then
        local ok,count=pcall(C_SpellBook.GetNumSpellBookSkillLines)
        if ok and type(count)=="number" then
            local bank=Enum and Enum.SpellBookSpellBank and Enum.SpellBookSpellBank.Player or 0
            for tab=1,math.min(count,40) do
                local infoOk,line=pcall(C_SpellBook.GetSpellBookSkillLineInfo,tab)
                if infoOk and type(line)=="table" and not IsSecret(line) then
                    local offset=SafeNumber(line.itemIndexOffset)
                    local num=SafeNumber(line.numSpellBookItems)
                    if offset and num then
                        for slot=offset+1,offset+math.min(num,400) do
                            local itemOk,item=pcall(C_SpellBook.GetSpellBookItemInfo,slot,bank)
                            if itemOk and type(item)=="table" and not IsSecret(item) and item.isOffSpec~=true then
                                local spellType=SafeNumber(item.itemType)
                                local normalType=Enum and Enum.SpellBookItemType and Enum.SpellBookItemType.Spell or 1
                                if spellType==normalType then
                                    local name,sub=item.name,item.subName
                                    if (not sub or sub=="") and C_SpellBook.GetSpellBookItemName then
                                        local no,n,second=pcall(C_SpellBook.GetSpellBookItemName,slot,bank)
                                        if no then name=name or n;sub=second end
                                    end
                                    Record(name,sub,item.spellID or item.actionID)
                                end
                            end
                        end
                    end
                end
            end
        end
    elseif GetNumSpellTabs and GetSpellTabInfo and GetSpellBookItemName then
        local ok,count=pcall(GetNumSpellTabs)
        if ok and type(count)=="number" then
            for tab=1,math.min(count,40) do
                local tabOk,_,_,offset,num=pcall(GetSpellTabInfo,tab)
                if tabOk and type(offset)=="number" and type(num)=="number" then
                    for slot=offset+1,offset+math.min(num,400) do
                        local itemType="SPELL"
                        if GetSpellBookItemInfo then
                            local typeOk,t=pcall(GetSpellBookItemInfo,slot,BOOKTYPE_SPELL or "spell")
                            if typeOk then itemType=t end
                        end
                        if itemType=="SPELL" then
                            local itemOk,name,sub,id=pcall(GetSpellBookItemName,slot,BOOKTYPE_SPELL or "spell")
                            if itemOk then Record(name,sub,id) end
                        end
                    end
                end
            end
        end
    end
    learnedHighestRanks=ranks
    return scanned
end
local function RefreshSpellbook()
    learnedHighestRanks=nil
    if playerClass then pcall(ReadSpellbook) end
end
local function HigherRankKnown(name,current)
    if type(name)~="string" or type(current)~="number" or current<1 then return nil end
    if not learnedHighestRanks then pcall(ReadSpellbook) end
    local high=learnedHighestRanks and learnedHighestRanks[CleanName(name)]
    return high and high>current and high or nil
end
local function ShowHigherRankNotice(tip,title,candidate,currentRank)
    if not MeffortSuiteDB or MeffortSuiteDB.rankHint==false or not candidate then return end
    local rank=SafeNumber(currentRank) or SafeNumber(candidate.r)
    local high=HigherRankKnown(candidate.n,rank)
    if not high or not tip or not tip.GetName then return end
    local tipName=tip:GetName()
    if type(tipName)~="string" then return end
    local rankFont
    for i=1,3 do
        local font=_G[tipName.."TextRight"..i]
        local raw=font and font.GetText and Normalize(font:GetText())
        if raw and raw:match("^[Rr]ank%s+%d+$") then rankFont=font;break end
    end
    if not rankFont or not rankFont.SetText then return end
    local original=SafeString(rankFont:GetText())
    if not original then return end
    local width=tip.GetWidth and SafeNumber(tip:GetWidth()) or 320
    local titleFont=_G[tipName.."TextLeft1"]
    local titleWidth=titleFont and titleFont.GetStringWidth and SafeNumber(titleFont:GetStringWidth()) or 160
    local rankWidth=rankFont.GetStringWidth and SafeNumber(rankFont:GetStringWidth()) or 45
    local remaining=(width or 320)-(titleWidth or 160)-(rankWidth or 45)-18
    local suffix
    if remaining>=190 then
        suffix="  |cffffc35a↑ Rank "..high.." Available in Spellbook!!|r"
    elseif remaining>=94 then
        suffix="  |cffffc35a↑ R"..high.." AVAILABLE!|r"
    elseif remaining>=43 then
        suffix="  |cffffc35a↑ R"..high.."!|r"
    else return end
    rankFont:SetText(original..suffix)
    if rankFont.SetShadowColor then rankFont:SetShadowColor(0,0,0,1) end
    if rankFont.SetShadowOffset then rankFont:SetShadowOffset(1,-1) end
end

local headerBadges = {}
local function HideHeaderBadges()
    for _,badge in pairs(headerBadges) do
        if badge.left and badge.left.Hide then badge.left:Hide() end
        if badge.center and badge.center.Hide then badge.center:Hide() end
        if badge.right and badge.right.Hide then badge.right:Hide() end
    end
end

local DEFAULT_BADGE_HEX = {
    instant="e7851a", channel="9664cd", cast="e7851a", cooldown="ac00c7",
    range="00df81", Mana="1a82c7", Rage="a30016", Energy="cebf4f",
    Focus="d18c3f", Health="bf4963", Combo="bf4963", Reagent="379eac",
    Requirement="514744",
}
local DEFAULT_TEXT_HEX="e7dddc"
local function RGBHex(hex)
    return tonumber(hex:sub(1,2),16)/255,
           tonumber(hex:sub(3,4),16)/255,
           tonumber(hex:sub(5,6),16)/255
end
local headerPalette = {}
for category,hex in pairs(DEFAULT_BADGE_HEX) do
    local r,g,b=RGBHex(hex)
    headerPalette[category]={r,g,b,0.72,"|cff"..DEFAULT_TEXT_HEX}
end
local function DefaultBadgeTextHex(category)
    return DEFAULT_TEXT_HEX
end

local function ColorHex(n)
    return string.format("%02x",math.floor(math.max(0,math.min(1,n))*255+0.5))
end
local function SetBadgeColor(category,hex)
    if type(hex)~="string" or not headerPalette[category] then return false end
    hex=hex:gsub("^#","")
    if #hex~=6 or not hex:match("^%x%x%x%x%x%x$") then return false end
    local r=tonumber(hex:sub(1,2),16)/255
    local g=tonumber(hex:sub(3,4),16)/255
    local b=tonumber(hex:sub(5,6),16)/255
    local c=headerPalette[category]
    c[1],c[2],c[3]=r,g,b
    if type(MeffortSuiteDB)=="table" then
        if type(MeffortSuiteDB.colors)~="table" then MeffortSuiteDB.colors={} end
        MeffortSuiteDB.colors[category]=hex
    end
    return true
end
local function RestoreBadgeColors()
    if type(MeffortSuiteDB.colors)~="table" then return end
    for category,hex in pairs(MeffortSuiteDB.colors) do
        if headerPalette[category] then SetBadgeColor(category,hex) end
    end
end
local function CurrentBadgeHex(category)
    local c=headerPalette[category]
    return c and (ColorHex(c[1])..ColorHex(c[2])..ColorHex(c[3])) or "ffffff"
end
local function CurrentTextHex(category)
    local c=headerPalette[category]
    return c and c[5] and c[5]:match("^|cff(%x%x%x%x%x%x)$") or "ffffff"
end
local function SetBadgeTextColor(category,hex)
    if type(hex)~="string" or not headerPalette[category] then return false end
    hex=hex:gsub("^#",""):lower()
    if #hex~=6 or not hex:match("^%x%x%x%x%x%x$") then return false end
    headerPalette[category][5]="|cff"..hex
    if type(MeffortSuiteDB)=="table" then
        if type(MeffortSuiteDB.textColors)~="table" then MeffortSuiteDB.textColors={} end
        MeffortSuiteDB.textColors[category]=hex
    end
    return true
end
local function RestoreBadgeTextColors()
    if type(MeffortSuiteDB.textColors)~="table" then return end
    for category,hex in pairs(MeffortSuiteDB.textColors) do
        if headerPalette[category] then SetBadgeTextColor(category,hex) end
    end
end

local function ResetBadgePalette()
    if type(MeffortSuiteDB)~="table" then return end
    MeffortSuiteDB.colors={}
    MeffortSuiteDB.textColors={}
    for category,hex in pairs(DEFAULT_BADGE_HEX) do
        SetBadgeColor(category,hex)
        SetBadgeTextColor(category,DefaultBadgeTextHex(category))
    end
    HideHeaderBadges()
end

local function FillTexture(tex, r,g,b,a)
    if tex.SetColorTexture then tex:SetColorTexture(r,g,b,a); return true end
    if tex.SetTexture and tex.SetVertexColor then
        tex:SetTexture("Interface\\Buttons\\WHITE8X8")
        tex:SetVertexColor(r,g,b,a)
        return true
    end
end

local originalHeaderFonts=setmetatable({}, {__mode="k"})
local function RememberHeaderFont(line)
    if originalHeaderFonts[line] then return originalHeaderFonts[line] end
    local base={}
    if line.GetFont then
        local ok,path,size,flags=pcall(line.GetFont,line)
        if ok then base.path=SafeString(path);base.size=SafeNumber(size);base.flags=SafeString(flags) or "" end
    end
    if line.GetShadowOffset then
        local ok,x,y=pcall(line.GetShadowOffset,line)
        if ok then base.sx=SafeNumber(x);base.sy=SafeNumber(y) end
    end
    if line.GetShadowColor then
        local ok,r,g,b,a=pcall(line.GetShadowColor,line)
        if ok then
            base.sr=SafeNumber(r);base.sg=SafeNumber(g)
            base.sb=SafeNumber(b);base.sa=SafeNumber(a)
        end
    end
    if line.GetText then base.text=SafeString(line:GetText()) end
    if line.GetTextColor then
        local ok,r,g,b,a=pcall(line.GetTextColor,line)
        if ok then base.r=SafeNumber(r);base.g=SafeNumber(g);base.b=SafeNumber(b);base.a=SafeNumber(a) end
    end
    originalHeaderFonts[line]=base
    return base
end
local function SetHeaderText(line,text)
    local base=RememberHeaderFont(line)
    line:SetText(text)
    base.styledText=text
end
local function RestoreHeaderFontStyles()
    for line,base in pairs(originalHeaderFonts) do
        if base.styledText and base.text and line.GetText and line.SetText
            and SafeString(line:GetText())==base.styledText then
            pcall(line.SetText,line,base.text)
        end
        if base.r and base.g and base.b and base.styledR and line.GetTextColor and line.SetTextColor then
            local ok,r,g,b=pcall(line.GetTextColor,line)
            if ok and SafeNumber(r)==base.styledR and SafeNumber(g)==base.styledG
                and SafeNumber(b)==base.styledB then
                pcall(line.SetTextColor,line,base.r,base.g,base.b,base.a or 1)
            end
        end
        if base.path and base.size and line.SetFont then
            pcall(line.SetFont,line,base.path,base.size,base.flags)
        end
        if line.SetShadowColor then
            pcall(line.SetShadowColor,line,base.sr or 0,base.sg or 0,base.sb or 0,base.sa or 0)
        end
        if line.SetShadowOffset then
            pcall(line.SetShadowOffset,line,base.sx or 0,base.sy or 0)
        end
        originalHeaderFonts[line]=nil
    end
end
local function SetMasterEnabled(on)
    if type(MeffortSuiteDB)~="table" then MeffortSuiteDB={} end
    MeffortSuiteDB.masterEnabled=(on==true)
    local function Refresh(module, method)
        if module and type(module[method])=="function" then
            local ok,err=pcall(module[method])
            if not ok and MeffortSuite and MeffortSuite.ReportError then
                MeffortSuite.ReportError("master",method,err)
            end
        end
    end
    Refresh(MeffortSuiteQuestSpace,"Refresh")
    Refresh(MeffortSuiteWay,"Refresh")
    Refresh(MeffortSuiteRanged,"Refresh")
    Refresh(MeffortSuiteFishing,"Refresh")
    Refresh(MeffortSuiteEnchantQueue,"RefreshMaster")
    Refresh(MeffortSuiteTargetDistance,"Refresh")
    Refresh(MeffortSuiteArcaneBlast,"Refresh")
    if not on and MeffortSuiteBankSelective and MeffortSuiteBankSelective.Cancel then
        MeffortSuiteBankSelective.Cancel("Suite disabled")
    end
    Refresh(MeffortSuiteBank,"RefreshMaster")
    if on then Refresh(MeffortSuiteInventory,"RefreshMerchant") end
    if not on then
        HideHeaderBadges()
        RestoreHeaderFontStyles()
        if comparePanel then comparePanel:Hide() end
        if GameTooltip then recent[GameTooltip]=nil end
    elseif GameTooltip then
        recent[GameTooltip]=nil
    end
    if MeffortSuiteActionText and MeffortSuiteActionText.ApplyAll then
        MeffortSuiteActionText.ApplyAll()
    end
    Refresh(MeffortSuiteSettingsUI,"Refresh")
    Message(on and "Enabled. Your saved feature preferences are active."
        or "Disabled. Your feature preferences are retained.")
    if InCombatLockdown and InCombatLockdown() then
        Message("Protected input and display changes will finish after combat.")
    end
end

local function ApplyHeaderTextStyle(line, category, preserveNativeColor)
    if not line then return end
    local base=RememberHeaderFont(line)
    local hex=CurrentTextHex(category)
    local r=tonumber(hex:sub(1,2),16)/255
    local g=tonumber(hex:sub(3,4),16)/255
    local b=tonumber(hex:sub(5,6),16)/255
    if not preserveNativeColor and line.SetTextColor then
        line:SetTextColor(r,g,b)
        base.styledR,base.styledG,base.styledB=r,g,b
        if line.GetTextColor then
            local ok,actualR,actualG,actualB=pcall(line.GetTextColor,line)
            if ok and SafeNumber(actualR) and SafeNumber(actualG) and SafeNumber(actualB) then
                base.styledR,base.styledG,base.styledB=actualR,actualG,actualB
            end
        end
    end
    local outline=MeffortSuiteDB and MeffortSuiteDB.badgeTextOutline==true
    if base.path and base.size and line.SetFont then
        local flags=base.flags or ""
        if outline and not flags:find("OUTLINE",1,true) then
            flags=(flags=="" and "OUTLINE" or (flags..",OUTLINE"))
        end
        pcall(line.SetFont,line,base.path,base.size,flags)
    end
    if MeffortSuiteDB and MeffortSuiteDB.badgeTextShadow~=false then
        if line.SetShadowColor then line:SetShadowColor(0,0,0,0.95) end
        if line.SetShadowOffset then line:SetShadowOffset(1,-1) end
    else
        if line.SetShadowColor then
            line:SetShadowColor(base.sr or 0,base.sg or 0,base.sb or 0,base.sa or 0)
        end
        if line.SetShadowOffset then line:SetShadowOffset(base.sx or 0,base.sy or 0) end
    end
end
local BADGE_TEXTURE = "Interface\\AddOns\\MeffortSuite\\Textures\\SoftBadge.tga"
local BADGE_CAP = 6
local BADGE_PAD = 2
local function NewBadgePiece(tip, u1, u2)
    local piece = tip:CreateTexture(nil,"ARTWORK",nil,-7)
    if not piece then return end
    if piece.SetTexture then piece:SetTexture(BADGE_TEXTURE) end
    if piece.SetTexCoord then piece:SetTexCoord(u1,u2,0,1) end
    return piece
end
local function PlaceBadge(tip, line, key, category, side, geom)
    if not MeffortSuiteDB or MeffortSuiteDB.badges==false or not tip.CreateTexture then return end
    local color=headerPalette[category]
    if not color or not line or not line.GetStringWidth then return end
    local width=geom and geom.width or SafeNumber(line:GetStringWidth())
    local height=geom and geom.height or (line.GetStringHeight and SafeNumber(line:GetStringHeight()))
    if not height and line.GetHeight then height=SafeNumber(line:GetHeight()) end
    local maxHeight=(category=="Reagent") and 78 or 32
    if category=="Reagent" and width then
        local available=320
        local tipWidth=tip.GetWidth and SafeNumber(tip:GetWidth())
        if tipWidth and tipWidth>45 then available=math.min(available,tipWidth-28) end
        local left=line.GetLeft and SafeNumber(line:GetLeft())
        local right=tip.GetRight and SafeNumber(tip:GetRight())
        if left and right and right-left>18 then
            available=math.min(available,right-left-12)
        end
        if available<8 then return end
        width=math.min(width,available)
    end
    if not width or not height or width<8 or width>320 or height<6 or height>maxHeight then return end
    local badge=headerBadges[key]
    if not badge then
        local left=NewBadgePiece(tip,0,8/32)
        local center=NewBadgePiece(tip,8/32,24/32)
        local right=NewBadgePiece(tip,24/32,1)
        if not left or not center or not right then return end
        badge={left=left,center=center,right=right}
        headerBadges[key]=badge
    end
    local left,center,right=badge.left,badge.center,badge.right
    local pad=BADGE_PAD
    local alpha=0.90
    local totalWidth=width + pad*2
    local totalHeight=height + 2
    local coreWidth=math.max(1,totalWidth - BADGE_CAP*2)
    for _,tex in ipairs({left,center,right}) do
        if not tex.ClearAllPoints or not tex.SetSize or not tex.SetVertexColor then return end
        tex:Hide()
        tex:ClearAllPoints()
        tex:SetVertexColor(color[1],color[2],color[3],alpha)
    end
    left:SetSize(BADGE_CAP,totalHeight)
    center:SetSize(coreWidth,totalHeight)
    right:SetSize(BADGE_CAP,totalHeight)
    if geom and geom.rightAligned then
        right:SetPoint("RIGHT",line,"RIGHT",pad-(geom.rightOffset or 0),geom.y or 0)
        center:SetPoint("RIGHT",right,"LEFT",0,0)
        left:SetPoint("RIGHT",center,"LEFT",0,0)
    elseif geom then
        left:SetPoint("LEFT",line,"LEFT",(geom.x or 0)-pad,geom.y or 0)
        center:SetPoint("LEFT",left,"RIGHT",0,0)
        right:SetPoint("LEFT",center,"RIGHT",0,0)
    elseif side=="TextRight" then
        right:SetPoint("RIGHT",line,"RIGHT",pad,0)
        center:SetPoint("RIGHT",right,"LEFT",0,0)
        left:SetPoint("RIGHT",center,"LEFT",0,0)
    else
        left:SetPoint("LEFT",line,"LEFT",-pad,0)
        center:SetPoint("LEFT",left,"RIGHT",0,0)
        right:SetPoint("LEFT",center,"RIGHT",0,0)
    end
    left:Show(); center:Show(); right:Show()
end

local function ParseResourceCost(label)
    if type(label)~="string" then return nil end
    local lower=label:lower()
    local amount,resource
    if not amount then
        local n,word=lower:match("^([%d,]+)%s+([%a]+)$")
        if n and (word=="mana" or word=="rage" or word=="energy" or word=="focus" or word=="health") then
            amount,resource=n,word
        end
    end
    if not amount then
        local n,word=lower:match("^([%d,]+)%s+([%a]+)%s+cost$")
        if n and (word=="mana" or word=="rage" or word=="energy" or word=="focus" or word=="health") then
            amount,resource=n,word
        end
    end
    if not amount then
        amount=lower:match("^([%d,]+)%s+health%s*,%s*plus%s+[%d,]+%s+per%s+sec%.?$")
            or lower:match("^([%d,]+)%s+health%s*,%s*plus%s+[%d,]+%s+per%s+second%.?$")
            or lower:match("^([%d,]+)%s+health%s+plus%s+[%d,]+%s+per%s+sec%.?$")
        if amount then resource="health" end
    end
    if not amount then return nil end
    local aliases={mana="Mana",rage="Rage",energy="Energy",focus="Focus",health="Health"}
    local category=aliases[resource]
    if not category then return nil end
    return tonumber((amount:gsub(",",""))),category,label
end

local function NativeRed(line, original)
    if line.GetTextColor then
        local ok,r,g,b=pcall(line.GetTextColor,line)
        if ok and SafeNumber(r) and SafeNumber(g) and SafeNumber(b)
            and r>=0.55 and g<r*0.68 and b<r*0.68 then return true end
    end
    if type(original)=="string" then
        for hex in original:gmatch("|c(%x%x%x%x%x%x%x%x)") do
            local r,g,b=tonumber(hex:sub(3,4),16),tonumber(hex:sub(5,6),16),tonumber(hex:sub(7,8),16)
            if r and g and b and r>=145 and g<r*0.68 and b<r*0.68 then return true end
        end
    end
    return false
end

local function IsCombo(label)
    if type(label)~="string" then return false end
    local s=label:lower():match("^%s*(.-)%s*$")
    return s:match("^%d+%s+to%s+%d+%s+combo%s+points?$") ~= nil
        or s:match("^%d+%s*%-%s*%d+%s+combo%s+points?$") ~= nil
        or s:match("^%d+%s+combo%s+points?$") ~= nil
        or s:match("^combo%s+points?:%s*%d+%s*%-%s*%d+$") ~= nil
end
local function ParseExtraHeader(label)
    if type(label)~="string" then return nil end
    local lower=label:lower()
    if IsCombo(lower) then return "Combo" end
    if lower:match("^%d+%s+soul%s+shards?$")
        or lower:match("^soul%s+shards?$")
        or lower:match("^requires%s+%d*%s*soul%s+shards?$")
        or lower:match("^reagents?:%s*%S.*$")
        or lower:match("^reagents?%s+required:%s*%S.*$")
        or lower:match("^makes:%s*%S.*$") then return "Reagent" end
end

local SUPPORTED_REQUIREMENTS = {
    ["cat form"]=true,["bear form"]=true,["dire bear form"]=true,
    ["travel form"]=true,["aquatic form"]=true,["moonkin form"]=true,
    ["tree of life form"]=true,["flight form"]=true,["swift flight form"]=true,
    ["battle stance"]=true,["defensive stance"]=true,["berserker stance"]=true,
    ["shadowform"]=true,["ghost wolf"]=true,["stealth"]=true,
    ["shield"]=true,["a shield"]=true,["wand"]=true,["a wand"]=true,
    ["ranged weapon"]=true,["a ranged weapon"]=true,
    ["melee weapon"]=true,["a melee weapon"]=true,
    ["bow"]=true,["a bow"]=true,["gun"]=true,["a gun"]=true,
    ["crossbow"]=true,["a crossbow"]=true,["dagger"]=true,["daggers"]=true,
    ["sword"]=true,["axe"]=true,["mace"]=true,["polearm"]=true,
    ["staff"]=true,["fist weapon"]=true,["two-handed weapon"]=true,
    ["thrown weapon"]=true,["a thrown weapon"]=true,
    ["ranged"]=true,["a ranged"]=true,
    ["wands"]=true,["bows"]=true,["guns"]=true,["crossbows"]=true,
    ["thrown"]=true,["thrown weapons"]=true,["ranged weapons"]=true,
    ["melee weapons"]=true,["shields"]=true,
    ["swords"]=true,["axes"]=true,["maces"]=true,
    ["polearms"]=true,["staves"]=true,["fist weapons"]=true,
    ["two-handed weapons"]=true,
}
local TOTEM_TOOLS = {
    ["earth totem"]=true, ["fire totem"]=true,
    ["water totem"]=true, ["air totem"]=true,
    ["thieves' tools"]=true, ["thieves’ tools"]=true,
}
local function ParseTotemToolsHeader(label)
    if type(label)~="string" then return nil end
    local tools=label:lower():match("^tools:%s*(.-)%s*$")
    if not tools or #tools>85 then return nil end
    tools=tools:gsub("[%.!]+$", "")
        :gsub("%s+and%s+", "|"):gsub("%s+or%s+", "|")
        :gsub("%s*,%s*", "|")
    for tool in (tools.."|"):gmatch("(.-)|") do
        tool=tool:match("^%s*(.-)%s*$")
        if not TOTEM_TOOLS[tool] then return nil end
    end
    return "Requirement"
end

local function ParseRequirementHeader(label)
    if type(label)~="string" then return nil end
    local rest=label:lower():match("^requires%s+(.+)$")
    if not rest or #rest>65 then return nil end
    rest=rest:gsub("[%.:!]+$","")
        :gsub("%s+equipped$","")
        :gsub("%s+or%s+","|"):gsub("%s*,%s*","|")
    for term in (rest.."|"):gmatch("(.-)|") do
        term=term:match("^%s*(.-)%s*$")
        term=term:gsub("^an?%s+",""):gsub("^equipped%s+","")
        if not SUPPORTED_REQUIREMENTS[term] then return nil end
    end
    return "Requirement"
end

local function ParseCombinedCost(original)
    if type(original)~="string" then return nil end
    local plain=Normalize(original)
    if not plain then return nil end
    local first,second=plain:match("^(.-)%s+/%s+(.-)$")
    if not first then
        local _,nl=original:find("\n",1,true)
        if nl then
            local a,b=original:match("^(.-)\n(.-)$")
            first,second=Normalize(a),Normalize(b)
        end
    end
    if not first then
        first,second=plain:match("^(%d+%s+%a+)%s+(%d+%s+to%s+%d+%s+Combo Points?)$")
    end
    if first and second and IsCombo(second) then
        local _,resource=ParseResourceCost(first)
        if resource then return first,second,resource end
    end
end

local measureFont
local function MeasureSegment(tip,line,text)
    if not tip.CreateFontString or not line.GetFont then return nil end
    if not measureFont then
        measureFont=tip:CreateFontString(nil,"BACKGROUND")
        if not measureFont then return nil end
        if measureFont.Hide then measureFont:Hide() end
    end
    if not measureFont.SetFont or not measureFont.SetText or not measureFont.GetStringWidth then return nil end
    local ok,path,size,flags=pcall(line.GetFont,line)
    if not ok or not SafeString(path) or not SafeNumber(size) then return nil end
    local fontOk=pcall(measureFont.SetFont,measureFont,path,size,flags)
    if not fontOk then return nil end
    local textOk=pcall(measureFont.SetText,measureFont,text)
    if not textOk then return nil end
    local width=SafeNumber(measureFont:GetStringWidth())
    if width and width>0 and width<400 then return width end
end

local function PlaceCombinedCost(tip,line,key,side,first,second,resource)
    if not MeffortSuiteDB or MeffortSuiteDB.badges==false then return end
    local w1=MeasureSegment(tip,line,first)
    local w2=MeasureSegment(tip,line,second)
    if not w1 or not w2 then
        PlaceBadge(tip,line,key,resource,side)
        return
    end
    local raw=SafeString(line:GetText()) or ""
    local fullH=line.GetStringHeight and SafeNumber(line:GetStringHeight()) or 13
    local newline=raw:find("\n",1,true)
    local twoRows=newline or (fullH and fullH>21)
    if twoRows then
        local rowH=math.max(10,math.min(18,fullH/2))
        PlaceBadge(tip,line,key.."a",resource,side,{width=w1,height=rowH,x=0,y=fullH/2-rowH/2})
        PlaceBadge(tip,line,key.."b","Combo",side,{width=w2,height=rowH,x=0,y=-fullH/2+rowH/2})
    else
        local separator=raw:find(" / ",1,true) and " / " or " "
        local gap=MeasureSegment(tip,line,separator) or 9
        PlaceBadge(tip,line,key.."a",resource,side,{width=w1,height=fullH,x=0,y=0})
        PlaceBadge(tip,line,key.."b","Combo",side,{width=w2,height=fullH,x=w1+gap,y=0})
    end
end

local RANGE_TARGETS = {
    enemy=true, friendly=true, ally=true, hostile=true,
    harmful=true, helpful=true, friend=true,
    ["enemy target"]=true, ["friendly target"]=true,
}
local RANGE_TARGET_SPLITS = {
    "enemy:", "friendly:", "ally:", "hostile:",
    "harmful:", "helpful:", "friend:",
    "enemy target:", "friendly target:",
}
local function IsYardRange(label)
    if type(label)~="string" then return false end
    local t=label:lower()
    return t:match("^%d+%.?%d*%s+yds?%s+range$") ~= nil
        or t:match("^%d+%.?%d*%s*%-%s*%d+%.?%d*%s+yds?%s+range$") ~= nil
end
local function IsTargetRange(label)
    local prefix,distance=label:lower():match("^([%a%s]+):%s*(.-)%s*$")
    if not prefix or not distance then return false end
    prefix=prefix:match("^%s*(.-)%s*$")
    return RANGE_TARGETS[prefix]==true and IsYardRange(distance)
end
local function IsRangeHeader(label)
    if type(label)~="string" then return false end
    local text=Normalize(label)
    if not text or #text>96 then return false end
    text=text:lower()
    return IsYardRange(text) or IsTargetRange(text)
        or text=="melee range" or text=="self" or text=="unlimited range"
end
local function SplitTargetRanges(label)
    if type(label)~="string" then return nil end
    local original=Normalize(label)
    if not original or #original>96 then return nil end
    for i=1,#original do
        if original:sub(i,i)==" " then
            local first=original:sub(1,i-1)
            local second=original:sub(i+1)
            if IsTargetRange(first) and IsTargetRange(second) then
                return first,second
            end
        end
    end
end
local function PlaceDualRanges(tip,line,key,side,first,second)
    if not MeffortSuiteDB or MeffortSuiteDB.badges==false then return end
    local w1=MeasureSegment(tip,line,first)
    local w2=MeasureSegment(tip,line,second)
    if not w1 or not w2 then
        PlaceBadge(tip,line,key,"range",side)
        return
    end
    local raw=SafeString(line:GetText()) or ""
    local height=line.GetStringHeight and SafeNumber(line:GetStringHeight()) or 13
    local isTwoRows=raw:find("\n",1,true) or height>21
    if isTwoRows then
        local rowH=math.max(10,math.min(18,height/2))
        local y=height/2-rowH/2
        local right=side=="TextRight"
        PlaceBadge(tip,line,key.."a","range",side,{width=w1,height=rowH,x=0,y=y,rightAligned=right})
        PlaceBadge(tip,line,key.."b","range",side,{width=w2,height=rowH,x=0,y=-y,rightAligned=right})
    else
        local right=side=="TextRight"
        local gap=MeasureSegment(tip,line," ") or 6
        if right then
            PlaceBadge(tip,line,key.."a","range",side,{width=w1,height=height,y=0,rightAligned=true,rightOffset=w2+gap})
            PlaceBadge(tip,line,key.."b","range",side,{width=w2,height=height,y=0,rightAligned=true})
        else
            PlaceBadge(tip,line,key.."a","range",side,{width=w1,height=height,x=0,y=0})
            PlaceBadge(tip,line,key.."b","range",side,{width=w2,height=height,x=w1+gap,y=0})
        end
    end
end

local function StyleHeaders(tip)
    HideHeaderBadges()
    if not MeffortSuiteDB or MeffortSuiteDB.style==false or not tip or not tip.GetName or not tip.NumLines then return end
    local name=tip:GetName()
    if type(name)~="string" then return end
    local num=SafeNumber(tip:NumLines())
    if not num then return end
    local reagentTitleRow={TextLeft=nil,TextRight=nil}
    for i=2,math.min(num,30) do
        for _,side in ipairs({"TextLeft","TextRight"}) do
            local line=_G[name..side..i]
            if line and line.GetText and line.SetText then
                local original=SafeString(line:GetText())
                if original then
                    local plain=Normalize(original)
                    local lower=plain and plain:lower()
                    local isReagentTitle=lower and lower:match("^reagents?:%s*$")~=nil
                    local followsReagents=reagentTitleRow[side] and i-reagentTitleRow[side]<=2
                        and i>reagentTitleRow[side]
                    local withinLimit=#original<100 or
                        (#original<260 and (isReagentTitle or
                         (lower and lower:match("^reagents?:%s*%S")) or followsReagents))
                    if withinLimit and plain and plain~="" then
                    local category,display
                    local first,second,combinedResource=ParseCombinedCost(original)
                    local rangeA,rangeB=SplitTargetRanges(original)
                    if first and second and combinedResource then
                        ApplyHeaderTextStyle(line, combinedResource, true)
                        PlaceCombinedCost(tip,line,side..i,side,first,second,combinedResource)
                    elseif rangeA and rangeB then
                        local warning=NativeRed(line,original)
                        if not warning and not original:find("|c",1,true) then
                            SetHeaderText(line,headerPalette.range[5]..original.."|r")
                        end
                        ApplyHeaderTextStyle(line,"range",warning)
                        pcall(PlaceDualRanges,tip,line,side..i,side,rangeA,rangeB)
                    elseif lower=="instant" or lower=="instant cast" then
                        category,display="instant","INSTANT"
                    elseif lower=="channeled" or lower=="channeled cast" then
                        category,display="channel","CHANNELED"
                    elseif lower and (lower:match("^%d+%.?%d* sec cast$") or lower:match("^%d+%.?%d* min cast$")) then
                        category,display="cast",plain
                    elseif lower and (lower:match("^%d+%.?%d* sec cooldown$") or lower:match("^%d+%.?%d* min cooldown$") or lower:match("^%d+%.?%d* hour[s]? cooldown$")) then
                        category,display="cooldown",plain
                    elseif lower and IsRangeHeader(lower) then
                        category,display="range",plain
                    elseif lower=="next melee" or lower=="next melee attack" then
                        category,display="cast",plain
                    else
                        local required,resource,costText=ParseResourceCost(plain)
                        if required and resource then
                            category,display=resource,costText
                        elseif plain and plain:match("^%d+%.?%d*%%%s+[Hh]ealth$") then
                            category,display="Health",plain
                        elseif plain then
                            category=ParseExtraHeader(plain) or ParseRequirementHeader(plain) or ParseTotemToolsHeader(plain)
                            if category then display=plain end
                            if not category and isReagentTitle then
                                category,display="Reagent",plain
                            elseif not category and followsReagents
                                and not lower:match("^requires%s+")
                                and not lower:match("^classes:%s*")
                                and not lower:match("^use:%s*") then
                                local isGold=false
                                if line.GetTextColor then
                                    local ok,r,g,b=pcall(line.GetTextColor,line)
                                    isGold=ok and SafeNumber(r) and SafeNumber(g)
                                        and SafeNumber(b) and r>0.75 and g>0.45
                                        and g<0.98 and b<0.4
                                end
                                if not isGold then category,display="Reagent",plain end
                            end
                        end
                    end
                    if isReagentTitle then
                        reagentTitleRow[side]=i
                    elseif followsReagents and category~="Reagent" then
                        reagentTitleRow[side]=nil
                    end
                    if category then
                        local palette=headerPalette[category]
                        if palette then
                            local warning = NativeRed(line,original)
                            if not warning and not original:find("|c",1,true) then
                                SetHeaderText(line,palette[5]..display.."|r")
                            elseif Normalize(original)~=Normalize(display) then
                                category=nil
                            end
                            if category then
                                ApplyHeaderTextStyle(line, category, warning)
                                pcall(PlaceBadge,tip,line,side..i,category,side)
                            end
                        end
                    end
                    end
                end
            end
        end
    end
end

local function ScheduleHeaderRefresh(tip,token)
    if not C_Timer or not C_Timer.After then return end
    local function Refresh()
        if recent[tip]~=token or not IsActive() or not MeffortSuiteDB
            or MeffortSuiteDB.style==false or not CurrentLocaleOk() then return end
        if tip.IsShown and not tip:IsShown() then return end
        if InCombatLockdown and InCombatLockdown() then return end
        pcall(StyleHeaders,tip)
    end
    C_Timer.After(0,Refresh)
    C_Timer.After(0.08,Refresh)
end

local actionStyleSerial=setmetatable({}, {__mode="k"})
local function StyleActionTooltip(tip)
    if tip~=GameTooltip or not IsActive() or not MeffortSuiteDB or
        MeffortSuiteDB.style==false or not CurrentLocaleOk() or
        (InCombatLockdown and InCombatLockdown()) then return end
    actionStyleSerial[tip]=(actionStyleSerial[tip] or 0)+1
    local serial=actionStyleSerial[tip]
    pcall(StyleHeaders,tip)
    if C_Timer and C_Timer.After then
        C_Timer.After(0.08,function()
            if actionStyleSerial[tip]~=serial or not IsActive() or
                not MeffortSuiteDB or MeffortSuiteDB.style==false or
                (tip.IsShown and not tip:IsShown()) or
                (InCombatLockdown and InCombatLockdown()) then return end
            pcall(StyleHeaders,tip)
        end)
    end
end

local function ShowCompare(tip,title,rendered)
    if not comparePanel then
        if not UIParent then return false end
        comparePanel=CreateFrame("GameTooltip","MeffortSuiteCompareTooltip",UIParent,"GameTooltipTemplate")
    end
    if not comparePanel or not comparePanel.SetOwner then return false end
    comparePanel:Hide()
    comparePanel:SetOwner(UIParent,"ANCHOR_NONE")
    comparePanel:ClearLines()
    if comparePanel.SetWidth then comparePanel:SetWidth(285) end
    comparePanel:AddLine("MeffortSuite",0.38,0.87,0.75)
    comparePanel:AddLine(rendered,0.96,0.96,0.96,true)
    comparePanel:ClearAllPoints()
    comparePanel:SetPoint("TOPLEFT",tip,"TOPRIGHT",8,0)
    comparePanel:Show()
    if UIParent.GetRight and tip.GetLeft and comparePanel.GetRight then
        local screen=SafeNumber(UIParent:GetRight())
        local right=SafeNumber(comparePanel:GetRight())
        if screen and right and right>screen-8 then
            comparePanel:ClearAllPoints()
            comparePanel:SetPoint("TOPRIGHT",tip,"TOPLEFT",-8,0)
        end
    end
    return true
end

local function RenderedLine(tooltip,rawSource)
    if not rawSource or not tooltip or not tooltip.GetName or not tooltip.NumLines then return nil end
    local name=tooltip:GetName()
    if type(name)~="string" then return nil end
    local expected=Normalize(rawSource)
    if not expected or expected=="" then return nil end
    local count=tooltip:NumLines()
    if type(count)~="number" then return nil end
    for i=1,math.min(count,35) do
        local line=_G[name.."TextLeft"..i]
        if line and line.GetText and line.SetText and Normalize(line:GetText())==expected then
            return line
        end
    end
end
local function Key(data,id,name)
    local serial=SafeNumber(data.dataInstanceID)
    return tostring(serial or "")..":"..tostring(id or "")..":"..tostring(name or "")..":"..mode
end
local function Apply(tooltip,data,isPet,isMacro)
    if not registered or not IsActive() or not CurrentLocaleOk() then return end
    if tooltip~=GameTooltip or type(data)~="table" or IsSecret(data) then return end
    local wantsStyle = MeffortSuiteDB and MeffortSuiteDB.style~=false
    local wantsRank = MeffortSuiteDB and MeffortSuiteDB.rankHint~=false
    if not enabled and not wantsStyle and not wantsRank then return end
    EnsurePlayer()
    if not playerClass and (enabled or wantsRank) then return end
    if InCombatLockdown and InCombatLockdown() then stats.skipped=stats.skipped+1;return end
    local id=SafeNumber(data.id)
    if isMacro then
        if not GetMacroSpell then return end
        id=SafeNumber(GetMacroSpell(id))
    end
    local title=TooltipTitle(data,tooltip)
    local desc=SourceDescription(data)
    local token=Key(data,id,title)
    if recent[tooltip]==token then return end
    recent[tooltip]=token
    HideHeaderBadges()
    if wantsStyle then
        StyleHeaders(tooltip)
        ScheduleHeaderRefresh(tooltip,token)
    end
    if not enabled and not wantsRank then return end
    local rank=TooltipRank(data,tooltip)
    local candidate = not isPet and id and BySpellID(id) or nil
    if candidate and title and not NameMatches(title,candidate.n) then
        candidate=nil
    end
    if not candidate then candidate=ByName(title,desc,rank) end
    last.spellID=id; last.name=title; last.result="Unmapped"
    if not candidate or not SafeString(candidate.t) or candidate.t=="" then
        stats.skipped=stats.skipped+1; return
    end
    if wantsRank then pcall(ShowHigherRankNotice,tooltip,title,candidate,rank) end
    if not enabled then
        last.result="Original explanation kept; visual features active"
        return
    end
    local storedSource=Normalize(candidate.o)
    local liveSource=Normalize(desc)
    if not storedSource or storedSource=="" or (liveSource and storedSource~=liveSource) then
        stats.skipped=stats.skipped+1
        return
    end
    local line=RenderedLine(tooltip,desc) or (isMacro and RenderedLine(tooltip,candidate.o))
    if isMacro and not line then
        stats.skipped=stats.skipped+1
        last.result="Macro original text did not match; preserved"
        return
    end
    stats.matched=stats.matched+1
    local rendered=Decorate(candidate.t,candidate.e)
    if mode=="compare" then
        if ShowCompare(tooltip,title,rendered) then
            stats.compared=stats.compared+1
            last.result="Compared beside tooltip"
        else
            last.result="Compare panel unavailable; original preserved"
            stats.skipped=stats.skipped+1
        end
        return
    end
    if line then
        line:SetText(rendered)
        stats.replaced=stats.replaced+1
        last.result="Replaced description"
    else
        stats.skipped=stats.skipped+1
        last.result="Preserved original (line mismatch)"
    end
end
local function SafeApply(tooltip,data,isPet,isMacro)
    local ok,err=pcall(Apply,tooltip,data,isPet,isMacro)
    if not ok then
        stats.errors=stats.errors+1
        if MeffortSuite and MeffortSuite.ReportError then MeffortSuite.ReportError("tooltips","apply",err) end
    end
end
local function InspectActionMacro(tip,slot)
    if not registered or not IsActive() then return end
    if MeffortSuiteDB and MeffortSuiteDB.style~=false and tip==GameTooltip and not (InCombatLockdown and InCombatLockdown()) then
        pcall(StyleHeaders,tip)
    end
    if not enabled or not GetActionInfo or not GetMacroSpell then return end
    if tip~=GameTooltip or not SafeNumber(slot) then return end
    local kind,macroIndex=GetActionInfo(slot)
    if kind~="macro" or not SafeNumber(macroIndex) then return end
    local spellID=SafeNumber(GetMacroSpell(macroIndex))
    if not spellID then return end
    local font=_G["GameTooltipTextLeft1"]
    local title=font and font.GetText and Normalize(font:GetText())
    if not title then return end
    EnsurePlayer()
    local candidate=BySpellID(spellID)
    if not candidate or not NameMatches(title,candidate.n) then return end
    local spellLineType=Enum and Enum.TooltipDataLineType and Enum.TooltipDataLineType.SpellName or 13
    local lines={{type=spellLineType,leftText=title}}
    local liveDesc
    if C_TooltipInfo and C_TooltipInfo.GetAction then
        local ok,info=pcall(C_TooltipInfo.GetAction,slot)
        if ok and type(info)=="table" and not IsSecret(info) then
            liveDesc=SourceDescription(info)
        end
    end
    local matchedLive=liveDesc and RenderedLine(tip,liveDesc)
    local sourceLine=matchedLive or RenderedLine(tip,candidate.o)
    if not sourceLine then return end
    local original=matchedLive and liveDesc or candidate.o
    if Enum and Enum.TooltipDataLineType and Enum.TooltipDataLineType.SpellDescription then
        lines[#lines+1]={type=Enum.TooltipDataLineType.SpellDescription,leftText=original}
    end
    local synthetic={id=spellID,lines=lines,dataInstanceID=0}
    SafeApply(tip,synthetic,false,false)
end

local function Subscribe()
    if registered then return end
    if not TooltipDataProcessor or not TooltipDataProcessor.AddTooltipPostCall or
       not Enum or not Enum.TooltipDataType or not Enum.TooltipDataType.Spell then
        Message("Spell tooltip features are unavailable in this client. Other tools remain independent.")
        return
    end
    local interfaceVersion
    if type(GetBuildInfo)=="function" then
        local _,_,_,ver=GetBuildInfo()
        interfaceVersion=ver
    end
    if type(interfaceVersion)~="number" or interfaceVersion<16000 or interfaceVersion>=17000 then
        Message("Unsupported client interface. No tooltips have been changed.")
        return
    end
    TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Spell,function(tip,d) SafeApply(tip,d,false) end)
    if Enum.TooltipDataType.PetAction then
        TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.PetAction,function(tip,d) SafeApply(tip,d,true) end)
    end
    if Enum.TooltipDataType.Action then
        TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Action,function(tip)
            StyleActionTooltip(tip)
        end)
    end
    if GameTooltip and hooksecurefunc then
        hooksecurefunc(GameTooltip,"SetAction",function(tip,slot)
            local ok,err=pcall(InspectActionMacro,tip,slot)
            if not ok then
                stats.errors=stats.errors+1
                if MeffortSuite and MeffortSuite.ReportError then MeffortSuite.ReportError("tooltips","macro",err) end
            end
        end)
    end
    if Enum.TooltipDataType.Macro then
        TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Macro,function(tip,d)
            SafeApply(tip,d,false,true)
        end)
    end
    if GameTooltip and GameTooltip.HookScript then
        GameTooltip:HookScript("OnHide",function(tip) HideHeaderBadges(); RestoreHeaderFontStyles();recent[tip]=nil;actionStyleSerial[tip]=(actionStyleSerial[tip] or 0)+1; if comparePanel and comparePanel.Hide then comparePanel:Hide() end end)
        if GameTooltip.HasScript and GameTooltip:HasScript("OnTooltipCleared") then
            GameTooltip:HookScript("OnTooltipCleared",function(tip) HideHeaderBadges(); RestoreHeaderFontStyles();recent[tip]=nil;actionStyleSerial[tip]=(actionStyleSerial[tip] or 0)+1; if comparePanel and comparePanel.Hide then comparePanel:Hide() end end)
        end
    end
    registered=true
end
function MeffortSuiteSetMasterEnabled(on) SetMasterEnabled(on) end
-- The settings module owns the only settings window. Keep early callers safe.
function MeffortSuiteOpenSettings(page)
    if MeffortSuiteSettingsUI and MeffortSuiteSettingsUI.Open then
        MeffortSuiteSettingsUI.Open(page)
    else
        Message("Settings are unavailable. Use /msuite diagnostics for details.")
    end
end
local frame=CreateFrame("Frame")
frame:RegisterEvent("PLAYER_LOGIN")
frame:RegisterEvent("SPELLS_CHANGED")
frame:SetScript("OnEvent",function(_,event)
    if event=="SPELLS_CHANGED" then RefreshSpellbook();return end
    if event~="PLAYER_LOGIN" then return end
    if type(MeffortSuiteDB)~="table" then MeffortSuiteDB={} end
    if MeffortSuiteDB.enabled==nil then MeffortSuiteDB.enabled=false end
    enabled=MeffortSuiteDB.enabled==true
    if MeffortSuiteDB.style==nil then MeffortSuiteDB.style=true end
    if MeffortSuiteDB.badges==nil then MeffortSuiteDB.badges=true end
    if MeffortSuiteDB.rankHint==nil then MeffortSuiteDB.rankHint=true end
    if MeffortSuiteDB.questSpace==nil then MeffortSuiteDB.questSpace=true end
    if MeffortSuiteDB.wayEnabled==nil then MeffortSuiteDB.wayEnabled=true end
    if MeffortSuiteDB.wayTheme~= "treecko" then MeffortSuiteDB.wayTheme="teal" end
    if MeffortSuiteDB.badgeTextOutline==nil then MeffortSuiteDB.badgeTextOutline=true end
    if MeffortSuiteDB.badgeTextShadow==nil then MeffortSuiteDB.badgeTextShadow=true end
    RestoreBadgeColors()
    RestoreBadgeTextColors()
    SetMode(MeffortSuiteDB.tooltipMode)
    MeffortSuiteDB.tooltipMode=mode
    EnsurePlayer()
    Subscribe()
    if not CurrentLocaleOk() then
        Message("MeffortSuite currently supports English tooltips only.")
    end
end)


function MeffortSuiteShowColorPicker(hex, onChanged)
    if not ColorPickerFrame or type(onChanged)~="function" then return false end
    local clean=tostring(hex or "ffffff"):gsub("#","")
    if not clean:match("^%x%x%x%x%x%x$") then clean="ffffff" end
    local startR=tonumber(clean:sub(1,2),16)/255
    local startG=tonumber(clean:sub(3,4),16)/255
    local startB=tonumber(clean:sub(5,6),16)/255
    local function Update()
        if not ColorPickerFrame.GetColorRGB then return end
        local r,g,b=ColorPickerFrame:GetColorRGB()
        if type(r)=="number" and type(g)=="number" and type(b)=="number" then
            local function Byte(x) return math.max(0,math.min(255,math.floor(x*255+0.5))) end
            onChanged(string.format("%02x%02x%02x",Byte(r),Byte(g),Byte(b)))
        end
    end
    local function Cancel() onChanged(clean:lower()) end
    if ColorPickerFrame.SetupColorPickerAndShow then
        local options={r=startR,g=startG,b=startB,hasOpacity=false,swatchFunc=Update,cancelFunc=Cancel}
        local ok=pcall(ColorPickerFrame.SetupColorPickerAndShow,ColorPickerFrame,options)
        return ok
    end
    if ColorPickerFrame.SetColorRGB and ColorPickerFrame.Show then
        ColorPickerFrame.func=Update
        ColorPickerFrame.swatchFunc=Update
        ColorPickerFrame.cancelFunc=Cancel
        ColorPickerFrame.hasOpacity=false
        ColorPickerFrame.previousValues={r=startR,g=startG,b=startB}
        ColorPickerFrame:SetColorRGB(startR,startG,startB)
        ColorPickerFrame:Hide()
        ColorPickerFrame:Show()
        return true
    end
    return false
end

-- Public read/write bridge for the nested Suite settings UI.
-- Keeps the existing tooltip and badge implementation authoritative.
function MeffortSuiteSetTooltipsEnabled(value)
    if type(MeffortSuiteDB)~="table" then MeffortSuiteDB={} end
    enabled=(value==true)
    MeffortSuiteDB.enabled=enabled
    -- A visible tooltip must be processed again after the setting changes.
    if GameTooltip then recent[GameTooltip]=nil end
    if comparePanel and comparePanel.Hide then comparePanel:Hide() end
end
function MeffortSuiteSetTooltipMode(value)
    SetMode(value)
    if type(MeffortSuiteDB)~="table" then MeffortSuiteDB={} end
    MeffortSuiteDB.tooltipMode=mode
end
function MeffortSuiteGetTooltipMode()
    return mode
end
function MeffortSuiteBadgeThemeRead(category,kind)
    if kind=="text" then return CurrentTextHex(category) end
    return CurrentBadgeHex(category)
end
function MeffortSuiteBadgeThemeWrite(category,kind,hex)
    if kind=="text" then SetBadgeTextColor(category,hex)
    else SetBadgeColor(category,hex) end
    HideHeaderBadges()
end
function MeffortSuiteBadgeThemeReset()
    ResetBadgePalette()
    HideHeaderBadges()
end



function MeffortSuiteShowMainSettings()
    MeffortSuiteOpenSettings()
end
function MeffortSuiteHideMainSettings()
    if MeffortSuiteSettingsUI and MeffortSuiteSettingsUI.Hide then MeffortSuiteSettingsUI.Hide() end
end
function MeffortSuiteTooltipStatus()
    return {available=registered, enabled=enabled, mode=mode, localeSupported=CurrentLocaleOk(),
        errors=stats.errors, matched=stats.matched, replaced=stats.replaced, compared=stats.compared,
        lastResult=last.result}
end
