-- Manual world-map pins only. Does not modify quest super-tracking.

MeffortSuiteWay = {}
local module = MeffortSuiteWay
local PI2 = math.pi * 2
local atan2 = math.atan2 or function(y, x) return math.atan(y, x) end
local prefix = "|cff50e6d5MeffortSuite|r"
local db

local THEMES = {
    teal = { key = "teal", name = "Teal", r = 0.22, g = 0.98, b = 0.90 },
    treecko = { key = "treecko", name = "Treecko", r = 0.47, g = 0.84, b = 0.29 },
}

local waypointID, waypointX, waypointY
local targetContinent, targetWorldX, targetWorldY
local lastIssue = "No map pin set"
local lastDistance, lastBearing, lastRadius

-- Tint the built-in quest-arrow texture.
local marker = CreateFrame("Frame", "MeffortSuiteMinimapMarker", Minimap)
marker:SetSize(32, 32)
marker:SetFrameStrata(Minimap:GetFrameStrata())
marker:SetFrameLevel(Minimap:GetFrameLevel() + 25)
marker:EnableMouse(false)
marker:Hide()

local arrow = marker:CreateTexture(nil, "OVERLAY")
arrow:SetAllPoints(marker)
arrow:SetTexture("Interface\\MINIMAP\\MiniMap-QuestArrow")
arrow:SetDesaturated(true)

local function GetThemeKey()
    return (db and db.wayTheme == "treecko") and "treecko" or "teal"
end

local function ApplyTheme()
    local theme = THEMES[GetThemeKey()] or THEMES.teal
    arrow:SetVertexColor(theme.r, theme.g, theme.b, 1)
    return theme
end


local function EnsureDB()
    if type(MeffortSuiteDB) ~= "table" then
        MeffortSuiteDB = {}
    end
    db = MeffortSuiteDB
    if db.wayTheme ~= "treecko" then
        db.wayTheme = "teal"
    end
    ApplyTheme()
end

local function SetTheme(key, silent)
    EnsureDB()
    if key ~= "treecko" then
        key = "teal"
    end
    db.wayTheme = key
    local theme = ApplyTheme()
    if not silent then
        if key == "treecko" then
            print(prefix .. ": secret mode activated. |cff7ad64a" .. theme.name .. "|r arrow enabled.")
        else
            print(prefix .. ": arrow color set to |cff50e6d5" .. theme.name .. "|r.")
        end
    end
end

local function ToggleTreeckoMode()
    EnsureDB()
    if db.wayTheme == "treecko" then
        SetTheme("teal")
    else
        SetTheme("treecko")
    end
end

local function ReadXY(vector)
    if not vector then return nil end
    if type(vector.x) == "number" and type(vector.y) == "number" then
        return vector.x, vector.y
    end
    if type(vector.GetXY) == "function" then
        return vector:GetXY()
    end
    return nil
end

local function Hide(reason)
    lastIssue = reason
    marker:Hide()
end

local function UpdateWaypoint()
    if not C_Map or type(C_Map.GetUserWaypoint) ~= "function" then
        waypointID, targetContinent, targetWorldX, targetWorldY = nil, nil, nil, nil
        Hide("Waypoint API unavailable")
        return
    end

    local ok, point = pcall(C_Map.GetUserWaypoint)
    if not ok or not point then
        waypointID, waypointX, waypointY = nil, nil, nil
        targetContinent, targetWorldX, targetWorldY = nil, nil, nil
        Hide(ok and "No map pin set" or "Cannot read map pin")
        return
    end

    local good, mapID, x, y = pcall(function()
        local px, py = ReadXY(point.position)
        return point.uiMapID, px, py
    end)
    if not good or type(mapID) ~= "number" or type(x) ~= "number" or type(y) ~= "number" then
        waypointID, targetContinent, targetWorldX, targetWorldY = nil, nil, nil, nil
        Hide("Waypoint has no map coordinates")
        return
    end

    if mapID == waypointID and x == waypointX and y == waypointY and targetWorldX then
        return
    end
    waypointID, waypointX, waypointY = mapID, x, y
    targetContinent, targetWorldX, targetWorldY = nil, nil, nil

    if type(C_Map.GetWorldPosFromMapPos) ~= "function" then
        Hide("World-coordinate API unavailable")
        return
    end

    local converted, continent, pos = pcall(C_Map.GetWorldPosFromMapPos, mapID, point.position)
    if converted and continent and pos then
        local xyOK, wx, wy = pcall(ReadXY, pos)
        if xyOK and type(wx) == "number" and type(wy) == "number" then
            targetContinent, targetWorldX, targetWorldY = continent, wx, wy
            lastIssue = "Ready"
            return
        end
    end
    Hide("Pin map has no usable world coordinates")
end

local function ReadPlayerWorld()
    if not C_Map or not C_Map.GetBestMapForUnit or not C_Map.GetPlayerMapPosition
        or not C_Map.GetWorldPosFromMapPos then
        return nil, nil, "Player map APIs unavailable"
    end
    local playerMap = C_Map.GetBestMapForUnit("player")
    local function TryMap(id)
        if not id then return nil, nil end
        local pos = C_Map.GetPlayerMapPosition(id, "player")
        if not pos then return nil, nil end
        local continent, world = C_Map.GetWorldPosFromMapPos(id, pos)
        if not world or continent ~= targetContinent then return nil, nil end
        return ReadXY(world)
    end

    local x, y = TryMap(playerMap)
    if x and y then return x, y end
    if waypointID and waypointID ~= playerMap then
        x, y = TryMap(waypointID)
        if x and y then return x, y end
    end
    return nil, nil, "Different continent or position unavailable"
end

local function IsRotatingMinimap()
    if type(GetCVar) ~= "function" then return false end
    local good, value = pcall(GetCVar, "rotateMinimap")
    if not good or value ~= "1" then return false end
    -- In some map styles rotation is intentionally suppressed by the client.
    if C_Minimap and type(C_Minimap.IsRotateMinimapIgnored) == "function" then
        local valid, ignored = pcall(C_Minimap.IsRotateMinimapIgnored)
        if valid and ignored then return false end
    end
    return true
end

local function GetVisibleYards()
    if C_Minimap and type(C_Minimap.GetViewRadius) == "function" then
        local valid, radius = pcall(C_Minimap.GetViewRadius)
        if valid and type(radius) == "number" and radius > 1 then
            return radius
        end
    end
    return nil
end

local function Enabled()
    return MeffortSuiteDB and MeffortSuiteDB.wayEnabled~=false
        and (not MeffortSuite or MeffortSuite.Active())
        and (not MeffortSuite or not MeffortSuite.StandaloneLoaded("MeffortWay"))
end

local function PointArrow()
    if not Enabled() then Hide("Disabled or standalone MeffortWay loaded"); return end
    if not targetWorldX then
        marker:Hide()
        return
    end
    local valid, px, py, reason = pcall(ReadPlayerWorld)
    if not valid or type(px) ~= "number" or type(py) ~= "number" then
        Hide(valid and (reason or "Player position unavailable") or "Player position restricted")
        return
    end

    local dx, dy = targetWorldX - px, targetWorldY - py
    local distance = math.sqrt(dx * dx + dy * dy)
    local angle = atan2(dy, dx) -- north = 0, west = +pi/2
    if IsRotatingMinimap() then
        local facingOK, facing = pcall(GetPlayerFacing)
        if not facingOK or type(facing) ~= "number" then
            Hide("Facing unavailable for rotating minimap")
            return
        end
        angle = angle - facing
    end
    angle = angle % PI2

    -- Rotate with the map when minimap rotation is enabled.
    local ok = pcall(arrow.SetRotation, arrow, angle)
    if not ok then
        Hide("Arrow rotation unavailable")
        return
    end

    -- Position nearby pins within the minimap; clamp distant pins to the edge.
    local width, height = Minimap:GetWidth(), Minimap:GetHeight()
    if not width or width <= 0 or not height or height <= 0 then
        Hide("Minimap dimensions unavailable")
        return
    end
    local ringRadius = math.min(width, height) * 0.47
    local yardsRadius = GetVisibleYards()
    local r = ringRadius
    if yardsRadius then
        r = ringRadius * math.min(distance / yardsRadius, 1)
    end
    local x = -math.sin(angle) * r
    local y =  math.cos(angle) * r
    marker:ClearAllPoints()
    marker:SetPoint("CENTER", Minimap, "CENTER", x, y)

    lastIssue = "Ready"
    lastDistance, lastBearing, lastRadius = distance, angle, yardsRadius
    marker:Show()
end

local controller = CreateFrame("Frame")
controller:RegisterEvent("PLAYER_LOGIN")
controller:RegisterEvent("PLAYER_ENTERING_WORLD")
controller:RegisterEvent("ZONE_CHANGED_NEW_AREA")
pcall(controller.RegisterEvent, controller, "USER_WAYPOINT_UPDATED")
controller:SetScript("OnEvent", function(self, event)
    if event == "PLAYER_LOGIN" then
        EnsureDB()
    end
    module.Refresh()
end)

local elapsedSincePoll, elapsedSincePinCheck = 0, 0
controller:SetScript("OnUpdate", function(self, elapsed)
    elapsedSincePoll = elapsedSincePoll + (elapsed or 0)
    elapsedSincePinCheck = elapsedSincePinCheck + (elapsed or 0)
    if elapsedSincePoll < 0.12 then return end
    elapsedSincePoll = 0
    if not Enabled() then
        if marker:IsShown() then Hide("Disabled or standalone MeffortWay loaded") end
        return
    end
    -- Waypoint/zone events refresh immediately. A slow compatibility poll
    -- recovers missing events without rereading pin metadata every movement tick.
    if elapsedSincePinCheck >= 2 then
        elapsedSincePinCheck=0
        UpdateWaypoint()
    end
    if targetWorldX then PointArrow() end
end)

function module.Refresh()
    if not db then EnsureDB() end
    if not Enabled() then
        Hide("Disabled or standalone MeffortWay loaded")
        return
    end
    UpdateWaypoint()
    PointArrow()
end

function module.SetTheme(key, silent)
    SetTheme(key, silent)
    module.Refresh()
end

function module.ToggleTreecko()
    ToggleTreeckoMode()
    module.Refresh()
end

function module.Command(msg)
    msg = (msg or ""):lower():match("^%s*(.-)%s*$")
    EnsureDB()
    if msg == "on" or msg == "off" then
        db.wayEnabled=(msg=="on")
        module.Refresh()
        print(prefix..": waypoint arrow "..(db.wayEnabled and "enabled" or "disabled")..".")
    elseif msg == "252" then
        module.ToggleTreecko()
    elseif msg == "treecko" or msg == "teal" then
        module.SetTheme(msg)
    elseif msg == "status" or msg == "debug" then
        print(prefix .. " | interface=" .. tostring(select(4, GetBuildInfo())) .. " theme=" .. tostring(db.wayTheme))
        print(" pin=" .. tostring(waypointID) .. " x=" .. tostring(waypointX) .. " y=" .. tostring(waypointY) .. " continent=" .. tostring(targetContinent))
        print(" dist=" .. tostring(lastDistance) .. " bearing=" .. tostring(lastBearing) .. " minimapRadiusYd=" .. tostring(lastRadius))
        print(" state=" .. tostring(lastIssue) .. " visible=" .. tostring(marker:IsShown()) .. " rotatingMap=" .. tostring(IsRotatingMinimap()))
    else
        print(prefix .. ": Place/remove a manual world-map pin. /msuite way on|off|teal|treecko|252|status.")
    end
end
