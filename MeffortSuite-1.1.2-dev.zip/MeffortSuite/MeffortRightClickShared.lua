-- Shared macro ownership for MeffortWand and MeffortSuite.
-- Loaded by either addon; the second copy leaves the existing instance intact.
if type(MeffortRightClickShared)=="table" and MeffortRightClickShared.version>=6 then return end
local shared={version=6, name="MeffortAim", alternateName="MeffortRC"}
MeffortRightClickShared=shared

-- Keep compatibility between standalone and Suite regardless of load order.
-- Both addons must ship the same manager. Revision 4 recognizes older edits.
local SPELLS={"Shoot","Auto Shot","Throw","Shoot Bow","Shoot Gun","Shoot Crossbow"}
local SPELL_IDS={ ["Shoot"]=5019,["Auto Shot"]=75,["Throw"]=2764,
  ["Shoot Bow"]=2480,["Shoot Gun"]=7918,["Shoot Crossbow"]=7919 }
local SHOOT_FALLBACK={frFR="Tir",zhTW="射擊",zhCN="射击",esES="Disparar",esMX="Disparar"}
local function Normalize(s)
    if type(s)~="string" then return nil end
    return (s:gsub("\r\n","\n"):gsub("\r","\n"):gsub("^%s+",""):gsub("%s+$", ""))
end
local function Trim(s)
    return (s:gsub("^%s+", ""):gsub("%s+$", ""))
end
local function ClientSpellName(id)
    if C_Spell and type(C_Spell.GetSpellInfo)=="function" then
        local ok,info=pcall(C_Spell.GetSpellInfo,id)
        if ok and type(info)=="table" and type(info.name)=="string" and info.name~="" then return info.name end
    end
    if C_Spell and type(C_Spell.GetSpellName)=="function" then
        local ok,name=pcall(C_Spell.GetSpellName,id)
        if ok and type(name)=="string" and name~="" then return name end
    end
    if type(GetSpellInfo)=="function" then
        local ok,name=pcall(GetSpellInfo,id)
        if ok and type(name)=="string" and name~="" then return name end
    end
end
function shared.LocalizedName(english)
    local name=ClientSpellName(SPELL_IDS[english])
    if name then return name end
    if english=="Shoot" and type(GetLocale)=="function" then
        local ok,locale=pcall(GetLocale)
        if ok and SHOOT_FALLBACK[locale] then return SHOOT_FALLBACK[locale] end
    end
    return english
end
-- For SpamSafe guard BOTH the /target and /cast lines: targeting the
-- same mob again can cancel a channeled wand even if /cast is guarded.
function shared.Body(spell,startOnly)
    spell=spell or "Shoot"
    local localized=shared.LocalizedName(spell)
    local cast=spell=="Auto Shot" and "/cast [harm,nodead] !"..localized
        or spell=="Shoot" and "/cast [harm,nodead,nochanneling:"..localized.."] "..localized
        or "/cast [harm,nodead] "..localized
    local target=spell=="Shoot" and "/target [@mouseover,harm,nodead,nochanneling:"..localized.."]"
        or "/target [@mouseover,harm,nodead]"
    return "#showtooltip "..localized.."\n"..target.."\n"..cast
end
-- Recognize only safe Shoot/Auto Shot/Throw macros under addon-generated names.
-- In addition to older generated forms, accept simple user edits such as
-- /cast !Shoot, optional whitespace, and missing #showtooltip or /target.
-- Any unrelated /use, /script, /run or other custom line is PRESERVED.
local function IsGeneratedBody(body)
    body=Normalize(body)
    if not body or body=="" then return false end
    local lines={}
    for line in (body.."\n"):gmatch("(.-)\n") do
        line=Trim(line)
        if line~="" then lines[#lines+1]=line end
    end
    if #lines>3 or #lines==0 then return false end
    local tooltip, target, cast
    for _,line in ipairs(lines) do
        if line:match("^#showtooltip") then
            if tooltip then return false end
            tooltip=Trim(line:sub(13))
        elseif line:match("^/target%s") then
            if target then return false end
            target=line:match("^/target%s+(.+)$")
        elseif line:match("^/cast%s") then
            if cast then return false end
            cast=line:match("^/cast%s+(.+)$")
        else return false end
    end
    if not cast then return false end
    local conditions,castSpell=cast:match("^(%b[])%s*(.+)$")
    if not castSpell then castSpell=cast end
    castSpell=Trim(castSpell):gsub("^!", "")
    local known={}
    for _,spell in ipairs(SPELLS) do
        known[spell]=true
        known[shared.LocalizedName(spell)]=true
    end
    for _,translated in pairs(SHOOT_FALLBACK) do known[translated]=true end
    if not known[castSpell] then return false end
    if tooltip and tooltip~="" and tooltip~=castSpell then return false end
    if conditions then
        local clean=conditions:gsub("%s+", "")
        local legal={"[harm,nodead]","[harm,nodead,nochanneling:"..castSpell.."]",
            "[@mouseover,harm,nodead,nochanneling:"..castSpell.."]",
            "[harm,nochanneling:"..castSpell.."]", "[nochanneling:"..castSpell.."]",
            "[@mouseover,harm,nodead]"}
        local matches=false
        for _,allowed in ipairs(legal) do if clean==allowed then matches=true;break end end
        -- Some historical macros use the English condition but a localized spell.
        if not matches and castSpell~= "Shoot" then
            matches = clean=="[harm,nodead,nochanneling:Shoot]" or
                      clean=="[@mouseover,harm,nodead,nochanneling:Shoot]"
        end
        if not matches then return false end
    end
    if target then
        local clean=target:gsub("%s+", "")
        if clean~="[@mouseover,harm,nodead]" and
           clean~="[@mouseover,harm,nodead,nochanneling:"..castSpell.."]" and
           clean~="[@mouseover,harm,nodead,nochanneling:Shoot]" then return false end
    end
    return true
end
local function IsGeneratedName(name)
    if name==shared.name or name==shared.alternateName or name=="MWand_Target" or name=="MWand_Fire" then return true end
    if type(name)~="string" then return false end
    if name:match("^MWand_%d+$") then return true end
    if name:match("^MSuite_Wand%d*$") or name:match("^MSuite_Ranged%d*$") then return true end
    return false
end
local function IsManaged(name,body)
    return IsGeneratedName(name) and IsGeneratedBody(body)
end
local function Read(index)
    local ok,name,icon,body=pcall(GetMacroInfo,index)
    if not ok then return nil,nil end
    return name,Normalize(body)
end
local function CharStart()
    return (MAX_ACCOUNT_MACROS or 120)+1
end
local function Scan()
    local ok,account,count=pcall(GetNumMacros)
    if not ok or type(count)~="number" or type(account)~="number" then
        return nil,"macro API unavailable"
    end
    local first=CharStart()
    local matches={}
    local reserved={}
    -- Macro names used by account-wide macros belong to the player too.
    -- They must never be edited, deleted, or overwritten.
    for index=1,account do
        local name=Read(index)
        if name==shared.name or name==shared.alternateName then
            reserved[name]=true
        end
    end
    for index=first,first+count-1 do
        local name,body=Read(index)
        if IsManaged(name,body) then
            matches[#matches+1]={index=index,name=name,body=body}
        elseif name==shared.name or name==shared.alternateName then
            reserved[name]=true
        end
    end
    return matches,nil,reserved
end

-- Existing macro may live on the Account tab (or have survived a
-- previous addon revision). Reuse simple Shoot macros, read-only, before
-- trying to create a new macro that needs a free character slot.
-- Unrecognized/custom macro bodies are never edited or deleted.
local function ReuseCompatibleExisting(spell)
    if spell~="Shoot" then return nil end
    local accountCount,charCount=GetNumMacros()
    if type(accountCount)~="number" or type(charCount)~="number" then return nil end
    local candidates={}
    for i=1,accountCount do candidates[#candidates+1]=i end
    for i=CharStart(),CharStart()+charCount-1 do candidates[#candidates+1]=i end
    for _,i in ipairs(candidates) do
        local name,body=Read(i)
        if (name==shared.name or name==shared.alternateName) and IsGeneratedBody(body) then
            -- Only compatible with the ranged Shoot command, not another
            -- player's intentionally customized ranged attack macro.
            local normalized=body:gsub("^%s+", ""):gsub("%s+$", "")
            local localized=shared.LocalizedName("Shoot")
            local cast=normalized:match("/cast%s+([^\n]+)")
            if cast then
                -- Strip one recognized condition group and optional !, then
                -- compare the full localized spell. Shoot Gun is not Shoot.
                local _,spellName=cast:match("^(%b[])%s*(.+)$")
                spellName=Trim(spellName or cast):gsub("^!", "")
                if spellName=="Shoot" or spellName==localized then return i end
            end
        end
    end
end

-- Only ever deletes macros created by the two addons. Account-wide macros,
-- custom-edited macros, and unrelated character macros are never modified.
function shared.Acquire(spell,startOnly)
    if type(InCombatLockdown)=="function" and InCombatLockdown() then return nil,"combat lockdown" end
    if type(GetNumMacros)~="function" or type(GetMacroInfo)~="function"
       or type(EditMacro)~="function" or type(DeleteMacro)~="function"
       or type(CreateMacro)~="function" then return nil,"macro API unavailable" end
    local body=shared.Body(spell,startOnly)
    local matches,err,reserved=Scan()
    if not matches then return nil,err end
    local keeper
    for _,entry in ipairs(matches) do
        if not keeper or (entry.name==shared.name and keeper.name~=shared.name) then
            keeper=entry
        end
    end
    local removed=0
    if keeper then
        local keepIndex=keeper.index
        for pos=#matches,1,-1 do
            local index=matches[pos].index
            if index~=keepIndex then
                local beforeName,beforeBody=Read(index)
                if IsManaged(beforeName,beforeBody) then
                    local _,beforeCount=GetNumMacros()
                    local ok=pcall(DeleteMacro,index)
                    local _,afterCount=GetNumMacros()
                    -- Names/bodies may be identical across adjacent duplicates.
                    -- Confirm success by the reduced character macro count.
                    if ok and type(beforeCount)=="number" and
                       afterCount==beforeCount-1 then
                        removed=removed+1
                        if index<keepIndex then keepIndex=keepIndex-1 end
                    end
                end
            end
        end
        local currentName,currentBody=Read(keepIndex)
        if not IsManaged(currentName,currentBody) then
            return nil,"could not identify the retained macro after cleanup"
        end
        local newName=(not reserved[shared.name]) and shared.name or currentName
        if currentName~=newName or currentBody~=body then
            local ok=pcall(EditMacro,keepIndex,newName,nil,body)
            local nameAfter,bodyAfter=Read(keepIndex)
            if not ok or bodyAfter~=body then return nil,"could not update shared macro" end
            -- Some clients may ignore a rename; the index is still valid.
        end
        if removed>0 then
            print("|cff73d9ffMeffort input|r: Removed "..removed.." redundant addon macros; using one shared macro.")
        end
        return keepIndex
    end
    local existing=ReuseCompatibleExisting(spell)
    if existing then
        return existing
    end
    -- If MeffortAim is genuinely a custom macro, preserve it and choose one
    -- deterministic fallback instead of failing or creating numbered floods.
    local newName=not reserved[shared.name] and shared.name or
        (not reserved[shared.alternateName] and shared.alternateName or nil)
    if not newName then
        return nil,"both reserved names belong to other/custom macros; no safe reusable macro was found"
    end
    local ok,index=pcall(CreateMacro,newName,"INV_Misc_QuestionMark",body,true)
    if not ok or type(index)~="number" or index<=0 then
        return nil,"no available character macro slot"
    end
    local nameAfter,bodyAfter=Read(index)
    if bodyAfter~=body then return nil,"macro creation failed verification" end
    if newName~=shared.name then
        print("|cff73d9ffMeffort input|r: Preserved custom MeffortAim; using "..newName.." instead.")
    end
    return index
end

-- At login, compact old macros even when both input modes are disabled.
-- This never creates a macro if none of ours already exists.
function shared.CleanupOnly()
    if type(InCombatLockdown)=="function" and InCombatLockdown() then return nil,"combat lockdown" end
    if type(GetNumMacros)~="function" or type(GetMacroInfo)~="function" then
        return nil,"macro API unavailable"
    end
    local matches,err=Scan()
    if not matches then return nil,err end
    if #matches<=1 then return 0 end
    local label=matches[1].body and matches[1].body:match("^#showtooltip ([^\n]+)") or "Shoot"
    local spell="Shoot"
    for _,english in ipairs(SPELLS) do
        if label==english or label==shared.LocalizedName(english) then spell=english;break end
    end
    local before=#matches
    local index,reason=shared.Acquire(spell)
    if not index then return nil,reason end
    local remaining=Scan()
    return before-#remaining
end

local cleanupFrame=CreateFrame("Frame")
cleanupFrame:RegisterEvent("PLAYER_LOGIN")
cleanupFrame:SetScript("OnEvent",function()
    cleanupFrame:UnregisterEvent("PLAYER_LOGIN")
    shared.CleanupOnly()
end)

local function CameraAvailable(mode)
    return mode~="right" or (type(MouselookStart)=="function" and
        type(MouselookStop)=="function" and type(IsMouseButtonDown)=="function")
end
local function PoleEquipped()
    return MeffortSuiteFishing and type(MeffortSuiteFishing.IsPoleEquipped)=="function"
        and MeffortSuiteFishing.IsPoleEquipped()
end

-- When both addons are installed: standalone Wand first, Suite fallback.
-- A fishing pole suppresses both so Suite's fishing binding may run.
function shared.Owner()
    if PoleEquipped() then return nil end
    local _,class=UnitClass("player")
    local wandClass=class=="MAGE" or class=="PRIEST" or class=="WARLOCK"
    if wandClass and type(MeffortWandDB)=="table"
       and (MeffortWandDB.mode=="right" or MeffortWandDB.mode=="shift")
       and CameraAvailable(MeffortWandDB.mode)
       and type(MeffortWandRuntime)=="table" and MeffortWandRuntime.Ready
       and MeffortWandRuntime.Ready() then
        return "MeffortWand"
    end
    if type(MeffortSuite)=="table" and type(MeffortSuite.Active)=="function"
        and MeffortSuite.Active() and type(MeffortSuiteRanged)=="table"
        and type(MeffortSuiteRanged.Mode)=="function" then
        local mode=MeffortSuiteRanged.Mode()
        if (mode=="right" or mode=="shift") and CameraAvailable(mode) then
            return "MeffortSuite"
        end
    end
    return nil
end

function shared.RefreshPeer(source)
    if source~="MeffortWand" and MeffortWandRuntime and MeffortWandRuntime.Refresh then
        MeffortWandRuntime.Refresh()
    end
    if source~="MeffortSuite" and MeffortSuiteRanged and MeffortSuiteRanged.Refresh then
        MeffortSuiteRanged.Refresh()
    end
end
