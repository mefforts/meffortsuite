MeffortSuite 1.1.2-dev
World of Warcraft: Forever | Interface 16001

DEVELOPMENT CANDIDATE
This build includes regression-tested fixes and interface polish. Protected actions,
server timing, and rendering still require validation in the Forever client.
Retain a backup of your existing addon and SavedVariables while testing.

INSTALLATION
Extract the MeffortSuite directory into Interface/AddOns and replace the previous MeffortSuite directory. Do not rename the addon folder. Type /reload in game. Existing SavedVariables are retained.

SETTINGS
Type /msuite to open the nine-tile settings window. Each feature can be configured independently.

INVENTORY AND BANKING (Bags)
- Automatic bag sorting on opening bags, merchant junk selling, and automatic equipment repair.
- Automatic crafting reagent deposits when the character bank opens. The addon checks for remaining materials between passes and makes up to four deposit attempts when necessary, before sorting the bank. Exclusion changes stop pending selective steps; requests already sent cannot be undone.
- Automatic personal-bank sorting (independent of bag sorting).
- Optional comma-separated deposit exclusions, saved for each character. For example: Light Feather, Soul Shard. Exact item names (case-insensitive) or numeric item IDs are accepted.
- With no exclusions, reagent deposits use the built-in bulk deposit API. With exclusions, the addon uses selective transfers and conservatively skips items it cannot identify or safely move. A failed selective transfer never falls back to unrestricted bulk deposit.
- Optional Orgrimmar banker dialogue shortcut for Soran, Karus, and Koma. Hold Shift when talking to bypass the shortcut.

MAP
- Optional waypoint arrow with teal and Treecko styles.
- Flight-master dialogue shortcut opens the flight map, without selecting a destination or spending gold. Hold Shift to bypass.

PROFESSIONS
- Right-click fishing with a pole equipped (single/double-click modes). Double-click is the default for new characters; saved single-click preferences stay unchanged. Single-click casting prevents normal right-click camera turning. Use /msuite fishing status to troubleshoot pole detection and casting.
- Enchant Queue: open Enchanting and click the MeffortSuite side tab. Choose a recipe and target item, queue a repeat count, and press Next once per enchant/confirmation. The queue does not open on login or automatically with Enchanting, and it closes when Enchanting closes. Queued entries persist per character.
- Bind the Next button in Keybindings > AddOns > MeffortSuite.
- Verified recipe/target allocation is required before Next can craft. Missing verification APIs leave the action disabled; use Blizzard controls. Manual casts do not consume the saved queue. Long queues scroll, and Clear offers Undo.
- If a result cannot be confirmed, the queue pauses. Inspect the item, then use Check result to count a completed enchant or resume without changing the count. It never automatically retries an uncertain craft.

OTHER TOOLS
- Quest dialogue hotkeys (Space to accept/continue/complete, or select the first menu item; 1-9 select individual NPC quest and gossip options).
- Right-click wand/bow/gun/thrown attacks with shared macro ownership.
- Guns, bows, crossbows, and thrown weapons are detected from the equipped ranged slot; launcher labels and managed attack macros follow weapon changes.
- Optional conservative out-of-range indicator for targets.
- Mage-only Arcane Blast stacks (1-4) over Blizzard's Cooldown Manager tracked-buff icon. Optional countdown and timer wheel; turn them on or off in /msuite > Combat > Arcane Blast. Add Arcane Blast to Blizzard's Tracked Buffs first. During combat, the display tracks successful casts and reconciles the aura after combat. Does not alter Blizzard's protected buttons.
- Spell tooltip badges, simplified English descriptions, optional rank alerts and colors.
- Action bar keybinding text.

COMMANDS
/msuite                               Open settings
/msuite on | off                      Toggle the entire suite
/msuite bank now                      Deposit crafting reagents at an open bank
/msuite bank on | off                 Enable/disable automatic reagent deposits
/msuite bank sort on | off            Enable/disable automatic personal-bank sorting
/msuite bank gossip on | off          Enable/disable Orgrimmar banker dialogue shortcut
/msuite flight on | off               Enable/disable flight-master dialogue shortcut
/msuite professions                   Open Professions settings
/msuite arcane                        Open Mage Arcane Blast settings
/msuite fishing on | off              Toggle right-click fishing
/msuite enchant                       Toggle Enchant Queue (while Enchanting is open)
/msuite vendor                        Show merchant action status
/msuite help                          Show available commands
/msuite diagnostics                   Show client/tooltip state and recent errors

DEFAULTS AND COMPATIBILITY
Bank deposits, personal-bank sorting, Orgrimmar banker shortcuts, and flight-master shortcuts default ON unless the user has saved an explicit OFF. Deposit exclusions and enchant queues are character-specific. MeffortSuite can coexist with the standalone MeffortWand and migrates supported settings from older addons on first installation.

IMPORTANT
When a bank exclusion list is set, items are transferred individually. On a first use, verify the results with nonvaluable materials before relying on exclusions. If transfers are blocked, items remain in bags or, after a failed move, can remain on the cursor; check your cursor and bags. Enchanting requires manual input for every enchant and confirmation. The addon does not perform unattended enchanting. This is an unofficial addon not affiliated with Blizzard.

See ATTRIBUTION.txt, THIRD-PARTY-EnchantQueue-LICENSE.txt and LICENSE for credits and licensing.

DEVELOPMENT CHANGES
Settings retain the native Blizzard controls, with predictable Back navigation,
full-row toggles, character/account scope, category counts, color previews,
contextual actions, and draft/saved text feedback. Saved Compare mode is restored.
Native resource warnings are preserved. Protected input/display preference changes
requested during combat finish after combat; settings report pending input changes.
Selective deposits leave items with unknown or explicitly false reagent eligibility
in bags. Partial stacks are split only with supported APIs and confirmed updates.
English tooltip data is not translated; other features use localized spell lookups
and numeric identities where available. Other WoW clients are not claimed supported.
