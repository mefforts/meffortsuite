local suite = MeffortSuite
MeffortSuiteBankSelective = {}
local selective = MeffortSuiteBankSelective

local active = false
local jobID = 0
local cancelled

local function DB()
    if type(MeffortSuiteCharDB) ~= "table" then MeffortSuiteCharDB = {} end
    return MeffortSuiteCharDB
end

local function Trim(value)
    return (tostring(value or ""):match("^%s*(.-)%s*$"))
end

function selective.Exclusions()
    local value = DB().bankDepositExclusions
    return type(value) == "string" and value or ""
end

function selective.SetExclusions(value)
    local updated = Trim(value):sub(1, 250)
    if updated == selective.Exclusions() then return end
    DB().bankDepositExclusions = updated
    selective.Cancel("exclusions changed; deposit stopped")
end

local function ExclusionSet()
    local names, ids = {}, {}
    for token in (selective.Exclusions() .. ","):gmatch("(.-),") do
        local item = Trim(token)
        if item ~= "" then
            local id = tonumber(item)
            if id and id > 0 and id == math.floor(id) then
                ids[id] = true
            else
                names[item:lower()] = true
            end
        end
    end
    return names, ids
end

function selective.HasExclusions()
    local names, ids = ExclusionSet()
    return next(names) ~= nil or next(ids) ~= nil
end

local function ItemName(itemID, info)
    if info and type(info.itemName) == "string" and info.itemName ~= "" then
        return info.itemName
    end
    local get = (C_Item and C_Item.GetItemInfo) or GetItemInfo
    if type(get) ~= "function" then return nil end
    local ok, name = pcall(get, itemID)
    if ok and type(name) == "string" then return name end
    return nil
end

local function IsCraftingItem(itemID)
    local get = (C_Item and C_Item.GetItemInfo) or GetItemInfo
    if type(get) ~= "function" then return nil end
    local ok, name, _, _, _, _, _, _, stack, _, _, _, _, _, _, _, _, reagent = pcall(get, itemID)
    if not ok or not name then return nil end
    -- An explicit false must not be overridden by a broad item category.
    -- If this client does not expose eligibility, leave the item untouched.
    if type(reagent) ~= "boolean" then return nil end
    return reagent, math.max(1, math.floor(tonumber(stack) or 1))
end

-- Read-only inventory check.  Used between bank deposit passes so the addon
-- avoids requesting another deposit when there is nothing eligible left.
-- The second result counts items whose metadata has not loaded yet.
function selective.Pending()
    local c = C_Container
    if not c or type(c.GetContainerItemInfo) ~= "function"
        or type(c.GetContainerNumSlots) ~= "function" then return nil, 0 end
    local names, ids = ExclusionSet()
    local pending, unknown = 0, 0
    for bag = 0, 5 do
        local slots = c.GetContainerNumSlots(bag)
        if type(slots) == "number" then
            for slot = 1, slots do
                local info = c.GetContainerItemInfo(bag, slot)
                if info and type(info.itemID) == "number" and not ids[info.itemID] then
                    local name = ItemName(info.itemID, info)
                    if name and not names[name:lower()] then
                        local crafting = IsCraftingItem(info.itemID)
                        if crafting then pending = pending + 1
                        elseif crafting == nil then unknown = unknown + 1 end
                    elseif not name then
                        -- Treat uncached items as uncertain, never as proof that the
                        -- bank is empty; do not move them without identification.
                        unknown = unknown + 1
                    end
                end
            end
        end
    end
    return pending, unknown
end

local function CursorOccupied()
    return (type(GetCursorInfo) == "function" and GetCursorInfo() ~= nil)
        or (type(CursorHasItem) == "function" and CursorHasItem())
end

local function Containers()
    if not C_Bank or type(C_Bank.FetchPurchasedBankTabIDs) ~= "function" then return nil end
    local bankType = (Enum and Enum.BankType and Enum.BankType.Character) or 0
    local ok, tabs = pcall(C_Bank.FetchPurchasedBankTabIDs, bankType)
    if not ok or type(tabs) ~= "table" then return nil end
    local result = {}
    -- Forever character-bank tabs occupy IDs 6..14; -1 is the keyring.
    for _, id in ipairs(tabs) do
        if type(id) == "number" and id >= 6 and id <= 14 then
            result[#result+1] = id
        end
    end
    table.sort(result)
    return #result > 0 and result or nil
end

local function Destination(itemID, maxStack, sourceCount, tabs)
    local c = C_Container
    local emptyBag, emptySlot
    for _, bag in ipairs(tabs) do
        local slots = c.GetContainerNumSlots(bag)
        if type(slots) == "number" then
            for slot = 1, slots do
                local info = c.GetContainerItemInfo(bag, slot)
                if info and info.itemID == itemID and not info.isLocked then
                    local capacity = maxStack - (info.stackCount or 1)
                    if capacity > 0 and (capacity >= sourceCount or type(c.SplitContainerItem) == "function") then
                        return bag, slot, math.min(capacity, sourceCount), info.stackCount or 1
                    end
                end
                if not info and not emptyBag then emptyBag, emptySlot = bag, slot end
            end
        end
    end
    return emptyBag, emptySlot, sourceCount, 0
end

local function SafeToMove()
    if not active or not suite or not suite.Active() then return false end
    if type(InCombatLockdown) == "function" and InCombatLockdown() then return false end
    if CursorOccupied() then return false end
    return true
end

function selective.Cancel(reason)
    local notify = active and cancelled
    active = false
    cancelled = nil
    jobID = jobID + 1
    if notify then notify(reason or "deposit cancelled") end
end

function selective.Active()
    return active
end

function selective.Start(bankStillOpen, finish)
    selective.Cancel("deposit restarted")
    local c = C_Container
    if not c or type(c.GetContainerItemInfo) ~= "function"
        or type(c.GetContainerNumSlots) ~= "function"
        or type(c.PickupContainerItem) ~= "function"
        or type(GetCursorInfo) ~= "function" then
        return false, "selective transfer API unavailable"
    end
    if type(C_Timer) ~= "table" or type(C_Timer.After) ~= "function" then
        return false, "selective transfer timer unavailable"
    end
    local tabs = Containers()
    if not tabs then return false, "character bank tabs not ready" end
    if CursorOccupied() then return false, "cursor occupied" end

    local names, ids = ExclusionSet()
    local entries = {}
    local skipped = 0
    for bag = 0, 5 do
        local count = c.GetContainerNumSlots(bag)
        if type(count) == "number" then
            for slot = 1, count do
                local info = c.GetContainerItemInfo(bag, slot)
                if info and type(info.itemID) == "number" and not info.isLocked then
                    local name = ItemName(info.itemID, info)
                    if ids[info.itemID] or (name and names[name:lower()]) then
                        skipped = skipped + 1
                    elseif name then
                        local craft, maxStack = IsCraftingItem(info.itemID)
                        if craft then
                            entries[#entries+1] = {bag = bag, slot = slot, id = info.itemID, stack = maxStack}
                        end
                    end
                    -- Uncached/unknown items are never moved.
                end
            end
        end
    end

    active = true
    local token = jobID
    local index, moved = 1, 0
    local function Notify(message)
        if type(finish) == "function" then finish(moved, skipped, message) end
    end
    local function Done(message)
        if not active or token ~= jobID then return end
        active = false
        cancelled = nil
        Notify(message)
    end
    cancelled = Notify
    local function Schedule(delay, action)
        C_Timer.After(delay, function()
            if not active or token ~= jobID then return end
            local ok, err = pcall(action)
            if not ok then
                if suite and type(suite.ReportError) == "function" then
                    suite.ReportError("Bank", "selective transfer", err)
                end
                Done("transfer interrupted; check cursor before retrying")
            end
        end)
    end
    local function StillOpen()
        return type(bankStillOpen) == "function" and bankStillOpen()
    end
    local function ItemCount(info, itemID)
        if not info then return 0 end
        if info.itemID ~= itemID then return nil end
        return info.stackCount or 1
    end
    local Next
    Next = function()
        if not active or token ~= jobID then return end
        if not StillOpen() then Done("bank closed"); return end
        if not SafeToMove() then Done("paused: suite disabled, cursor occupied or combat"); return end
        local entry = entries[index]
        if not entry then Done(nil); return end
        local source = c.GetContainerItemInfo(entry.bag, entry.slot)
        if not source or source.itemID ~= entry.id then
            index = index + 1
            Schedule(0.16, Next)
            return
        end
        if source.isLocked then Done("source item locked; deposit stopped"); return end
        -- Apply the latest rules, even if another caller updates saved variables.
        local currentNames, currentIDs = ExclusionSet()
        local name = ItemName(entry.id, source)
        if currentIDs[entry.id] or (name and currentNames[name:lower()]) then
            skipped = skipped + 1
            index = index + 1
            Schedule(0.16, Next)
            return
        end
        local crafting = IsCraftingItem(entry.id)
        if not name or crafting ~= true then
            Done("item eligibility changed or unavailable; deposit stopped")
            return
        end
        local sourceCount = source.stackCount or 1
        local dstBag, dstSlot, amount, destinationCount = Destination(entry.id, entry.stack, sourceCount, tabs)
        if not dstBag then
            Done(type(c.SplitContainerItem) ~= "function" and "no usable bank space (partial transfers unavailable)"
                or "no free personal-bank space")
            return
        end
        -- Recheck destination immediately before pickup. Never use a stale empty slot.
        local destination = c.GetContainerItemInfo(dstBag, dstSlot)
        if (destination and (destination.itemID ~= entry.id or destination.isLocked))
            or ItemCount(destination, entry.id) ~= destinationCount then
            Done("destination changed; deposit stopped")
            return
        end
        local picked, err
        if amount < sourceCount then
            picked, err = pcall(c.SplitContainerItem, entry.bag, entry.slot, amount)
        else
            picked, err = pcall(c.PickupContainerItem, entry.bag, entry.slot)
        end
        local kind, cursorID = GetCursorInfo()
        if not picked or kind ~= "item" or cursorID ~= entry.id then
            Done(picked and "selective pickup unavailable; check cursor" or tostring(err))
            return
        end
        local placed, placementErr = pcall(c.PickupContainerItem, dstBag, dstSlot)
        if not placed or CursorOccupied() then
            -- Restore only to an empty/original compatible slot. Never swap another item.
            local original = c.GetContainerItemInfo(entry.bag, entry.slot)
            local restoreCount = ItemCount(original, entry.id)
            if CursorOccupied() and restoreCount ~= nil and not (original and original.isLocked)
                and restoreCount + amount <= entry.stack then
                pcall(c.PickupContainerItem, entry.bag, entry.slot)
            end
            Done(CursorOccupied() and "item left on cursor; restore manually"
                or ("bank placement failed: " .. tostring(placementErr or "transfer rejected")))
            return
        end
        -- Cursor clearance is not proof of a server-side transfer. Wait for both
        -- authoritative slot counts before touching another stack.
        local checks = 0
        local function Confirm()
            if not active or token ~= jobID then return end
            if not StillOpen() then Done("bank closed"); return end
            if not SafeToMove() then Done("paused: suite disabled, cursor occupied or combat"); return end
            checks = checks + 1
            local afterSource = c.GetContainerItemInfo(entry.bag, entry.slot)
            local afterDestination = c.GetContainerItemInfo(dstBag, dstSlot)
            if ItemCount(afterSource, entry.id) == sourceCount - amount
                and ItemCount(afterDestination, entry.id) == destinationCount + amount
                and not (afterSource and afterSource.isLocked)
                and not (afterDestination and afterDestination.isLocked) then
                if not entry.counted then moved = moved + 1; entry.counted = true end
                if sourceCount == amount then index = index + 1 end
                Schedule(0.16, Next)
            elseif checks >= 15 then
                Done("transfer not confirmed; check bags and bank before retrying")
            else
                Schedule(0.10, Confirm)
            end
        end
        Schedule(0.10, Confirm)
    end
    Schedule(0, Next)
    return true
end
