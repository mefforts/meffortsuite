-- A pole-equipped right-click in the 3D world triggers a *brief* secure spell
-- override.  GLOBAL_MOUSE_DOWN fires before the click is dispatched, so the
-- physical mouse release can cast Fishing. We NEVER keep BUTTON2 bound while
-- waiting for clicks: camera controls and ordinary interaction remain intact.
--
-- Alternative /msuite fishing double: only a double-right-click casts.
-- Casting and bobber looting each require the player's own click; no automation.
MeffortSuiteFishing = {}
local module = MeffortSuiteFishing
local tracker = CreateFrame("Frame")
local bindingOwner, castButton
local armGeneration=0
local UpdateArm
local castSpell
local armed = false
local armTime = 0
local armDuration = 0.85
local lastCast = -10
local previousDown = -10
local eventCount = 0
local lastResult = "no mouse click yet"
local lootOpen = false
local deferredClear = false
local releaseEventAvailable=false
local initializationAttempted=false

local function Message(message)
    if MeffortSuite and MeffortSuite.Message then
        MeffortSuite.Message("Fishing: "..message)
    end
end
local function InLockdown()
    return type(InCombatLockdown)=="function" and InCombatLockdown()==true
end
local function Settings()
    if type(MeffortSuiteCharDB)~="table" then MeffortSuiteCharDB={} end
    if MeffortSuiteCharDB.fishingRightClick==nil then
        MeffortSuiteCharDB.fishingRightClick=true
    end
    -- Default to double-click only when a character has no valid saved mode.
    if MeffortSuiteCharDB.fishingClickMode~="single" and
       MeffortSuiteCharDB.fishingClickMode~="double" then
        MeffortSuiteCharDB.fishingClickMode="double"
    end
    return MeffortSuiteCharDB
end
function module.Enabled() return Settings().fishingRightClick==true end
function module.Mode() return Settings().fishingClickMode end

-- Do not require GetInventoryItemLink to succeed before asking the other APIs:
-- in some client builds an uncached item link can be nil immediately after equip.
function module.IsPoleEquipped()
    if type(IsEquippedItemType)=="function" then
        local ok,yes=pcall(IsEquippedItemType,"Fishing Poles")
        if ok and yes then return true end
    end
    local link
    if type(GetInventoryItemLink)=="function" then
        local ok,value=pcall(GetInventoryItemLink,"player",16)
        if ok then link=value end
    end
    if not link and type(GetInventoryItemID)=="function" then
        local ok,value=pcall(GetInventoryItemID,"player",16)
        if ok then link=value end
    end
    if not link then return false end
    local instant = type(GetItemInfoInstant)=="function" and GetItemInfoInstant
        or (C_Item and type(C_Item.GetItemInfoInstant)=="function" and C_Item.GetItemInfoInstant)
    if instant then
        -- GetItemInfoInstant: itemID, itemType, itemSubType, equipLoc, icon,
        -- classID, subclassID. Fishing poles are weapon class 2 / subclass 20.
        local ok,_,_,_,_,_,classID,subclassID=pcall(instant,link)
        if ok and classID==2 and (subclassID==20 or subclassID==25) then return true end
    end
    if type(GetItemInfo)=="function" then
        local ok,_,_,_,_,_,_,subclass=pcall(GetItemInfo,link)
        if ok and type(subclass)=="string" and
            subclass:lower():find("fishing pole",1,true) then return true end
    end
    return false
end

local function FishingSpell()
    if castSpell then return castSpell end
    if C_Spell and type(C_Spell.GetSpellInfo)=="function" then
        local ok,info=pcall(C_Spell.GetSpellInfo,7620)
        if ok and type(info)=="table" and type(info.name)=="string" then
            castSpell=info.name
            return castSpell
        end
    end
    if C_Spell and type(C_Spell.GetSpellName)=="function" then
        local ok,name=pcall(C_Spell.GetSpellName,7620)
        if ok and type(name)=="string" and name~="" then
            castSpell=name
            return name
        end
    end
    if type(GetSpellInfo)=="function" then
        local ok,name=pcall(GetSpellInfo,7620)
        if ok and type(name)=="string" then castSpell=name;return name end
    end
    return "Fishing" -- enUS fallback (don't cache it so late loads can recover)
end
local function IsChanneling()
    if type(UnitChannelInfo)~="function" then return false end
    local ok,name=pcall(UnitChannelInfo,"player")
    return ok and type(name)=="string"
end
local function WorldClick()
    -- Do not steal right-clicks on settings, bags, NPC unit frames or menus.
    -- Unknown focus is not permission to capture a UI click.
    local focus
    -- The modern GetMouseFoci API returns a list of frames, not a frame.
    -- Prefer it so that clicking UI controls cannot be misread as a world click.
    if type(GetMouseFoci)=="function" then
        local ok,value=pcall(GetMouseFoci)
        if ok and type(value)=="table" then focus=value[1]
        elseif ok then focus=value end
    elseif type(GetMouseFocus)=="function" then
        local ok,value=pcall(GetMouseFocus)
        if ok then focus=value end
    end
    if not focus or not WorldFrame then return false end
    for _=1,8 do
        if focus==WorldFrame then return true end
        if type(focus.GetParent)~="function" then break end
        local ok,parent=pcall(focus.GetParent,focus)
        if not ok or not parent or parent==focus then break end
        focus=parent
    end
    return false
end
local function CanCast()
    return module.Enabled() and MeffortSuite and MeffortSuite.Active()
        and module.IsPoleEquipped() and not IsChanneling() and not lootOpen
end

local function ClearArm()
    if not armed and not deferredClear then return end
    armGeneration=armGeneration+1
    if InLockdown() then
        deferredClear=true
        armed=false
        tracker:SetScript("OnUpdate",nil)
        -- The restricted state driver clears the actual binding in combat.
        return
    end
    local ok=bindingOwner and pcall(bindingOwner.Execute,bindingOwner,[[self:ClearBindings()]])
    armed=false
    deferredClear=not ok
    tracker:SetScript("OnUpdate",nil)
end

-- No permanent override. Arm during physical down; the matching release
-- clicks a secure spell button. Binding creation and combat cleanup use the
-- same restricted owner, rather than mixing two binding ownership paths.
local function ArmCast()
    if not bindingOwner or not castButton then lastResult="secure binding API unavailable";return end
    ClearArm()
    if InLockdown() then lastResult="combat lockdown";return end
    local spell=FishingSpell()
    local ok=pcall(function()
        castButton:SetAttribute("spell",spell)
        bindingOwner:Execute([[self:SetBindingClick(true,"BUTTON2","MeffortSuiteFishingCastButton","RightButton")]])
    end)
    if not ok then
        pcall(bindingOwner.Execute,bindingOwner,[[self:ClearBindings()]])
        lastResult="binding rejected";return
    end
    armed=true
    armGeneration=armGeneration+1
    armTime=0
    tracker:SetScript("OnUpdate",UpdateArm)
    lastCast=type(GetTime)=="function" and GetTime() or 0
    lastResult="armed "..spell.." for mouse release"
end

function module.Refresh()
    if not bindingOwner then return end
    if deferredClear or (armed and not CanCast()) then ClearArm() end
end
function module.SetEnabled(value)
    Settings().fishingRightClick=value==true
    module.Refresh()
end
function module.SetMode(value)
    if value~="double" then value="single" end
    Settings().fishingClickMode=value
    previousDown=-10
    ClearArm()
end
function module.Command(argument)
    local cmd=(argument or ""):lower():match("^%s*(.-)%s*$")
    if cmd=="on" or cmd=="off" then
        module.SetEnabled(cmd=="on")
        Message("right-click casting "..(module.Enabled() and "enabled" or "disabled").." ("..module.Mode()..")")
    elseif cmd=="single" or cmd=="double" then
        module.SetMode(cmd)
        module.SetEnabled(true)
        Message(cmd.." right-click mode enabled with fishing pole")
    elseif cmd=="status" or cmd=="debug" or cmd=="" then
        Message((module.Enabled() and "on" or "off")..", mode "..module.Mode()
            ..", pole "..(module.IsPoleEquipped() and "recognized" or "NOT recognized")
            ..", spell "..FishingSpell()..", clicks "..eventCount
            ..", last: "..lastResult..". /msuite fishing on|off|single|double")
    else
        Message("/msuite fishing on|off|single|double|status")
    end
end

local function OnMouseDown(button)
    if button~="RightButton" then return end
    -- A new press must never inherit a failed/unfinished previous cast arm.
    ClearArm()
    eventCount=eventCount+1
    if type(IsMouseButtonDown)=="function" and IsMouseButtonDown("LeftButton") then previousDown=-10;return end
    if InLockdown() then previousDown=-10;lastResult="combat lockdown";return end
    if not CanCast() then previousDown=-10;lastResult="not ready (feature, pole, channel or loot)";return end
    if not WorldClick() then
        previousDown=-10
        lastResult="world-click focus unavailable or an interface frame was clicked"
        return
    end
    local now=type(GetTime)=="function" and GetTime() or 0
    if now-lastCast<0.6 then return end
    if module.Mode()=="double" then
        local gap=now-previousDown
        previousDown=now
        if gap<0.05 or gap>0.38 then return end
        previousDown=-10
    end
    ArmCast()
end
local function OnMouseUp(button)
    if button~="RightButton" or not armed then return end
    local generation=armGeneration
    -- GLOBAL_MOUSE_UP may precede protected click dispatch on a client build.
    -- Clear next frame so this release can complete, without stealing a later
    -- click when casting fails and no channel-start event arrives.
    C_Timer.After(0,function()
        if armed and generation==armGeneration then ClearArm() end
    end)
end
local function Initialize()
    Settings()
    if bindingOwner or initializationAttempted or InLockdown() then return end
    if not releaseEventAvailable or type(RegisterStateDriver)~="function"
        or not (C_Timer and type(C_Timer.After)=="function") then
        lastResult="secure state/timer API unavailable"
        Message("Secure right-click casting is unavailable; normal mouse controls remain active.")
        return
    end
    initializationAttempted=true
    local ok=pcall(function()
        local owner=CreateFrame("Frame","MeffortSuiteFishingSecureController",UIParent,"SecureHandlerStateTemplate")
        if type(owner.Execute)~="function" then error("restricted execution unavailable") end
        owner:SetAttribute("_onstate-fishcombat",[[
            if newstate == "off" then self:ClearBindings() end
        ]])
        RegisterStateDriver(owner,"fishcombat","[combat] off; on")
        local button=CreateFrame("Button","MeffortSuiteFishingCastButton",UIParent,"SecureActionButtonTemplate")
        button:RegisterForClicks("AnyUp")
        button:SetAttribute("useOnKeyDown",false)
        button:SetAttribute("type","spell")
        owner:Execute([[self:ClearBindings()]])
        bindingOwner,castButton=owner,button
    end)
    if not ok then
        lastResult="secure binding setup rejected"
        Message("Secure right-click casting could not initialize; normal mouse controls remain active.")
    end
end
function module.Available()
    if bindingOwner and castButton then return true end
    return false,InLockdown() and "Right-click fishing will initialize after combat."
        or "Secure right-click fishing is unavailable; normal mouse controls remain active."
end
UpdateArm=function(_,elapsed)
    if not armed then tracker:SetScript("OnUpdate",nil);return end
    armTime=armTime+(elapsed or 0)
    if armTime>armDuration then ClearArm() end
end

tracker:RegisterEvent("PLAYER_LOGIN")
tracker:RegisterEvent("GLOBAL_MOUSE_DOWN")
do
    local ok,result=pcall(tracker.RegisterEvent,tracker,"GLOBAL_MOUSE_UP")
    releaseEventAvailable=ok and result~=false
end
tracker:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
tracker:RegisterEvent("UNIT_INVENTORY_CHANGED")
tracker:RegisterEvent("PLAYER_REGEN_ENABLED")
tracker:RegisterEvent("PLAYER_REGEN_DISABLED")
tracker:RegisterEvent("UNIT_SPELLCAST_CHANNEL_START")
tracker:RegisterEvent("UNIT_SPELLCAST_CHANNEL_STOP")
tracker:RegisterEvent("UNIT_SPELLCAST_INTERRUPTED")
tracker:RegisterEvent("UNIT_SPELLCAST_STOP")
tracker:RegisterEvent("UNIT_SPELLCAST_FAILED")
tracker:RegisterEvent("SPELLS_CHANGED")
tracker:RegisterEvent("LOOT_OPENED")
tracker:RegisterEvent("LOOT_CLOSED")
tracker:SetScript("OnEvent",function(_,event,unit)
    if event=="PLAYER_LOGIN" then Initialize();return end
    if event=="GLOBAL_MOUSE_DOWN" then OnMouseDown(unit);return end
    if event=="GLOBAL_MOUSE_UP" then OnMouseUp(unit);return end
    if event=="SPELLS_CHANGED" then castSpell=nil end
    if event=="LOOT_OPENED" then lootOpen=true end
    if event=="LOOT_CLOSED" then lootOpen=false end
    if (event=="UNIT_INVENTORY_CHANGED" or event:match("^UNIT_SPELLCAST"))
        and unit~="player" then return end
    if event=="PLAYER_REGEN_DISABLED" then
        -- The secure state driver withdraws bindings during lockdown. This
        -- only reconciles Lua tracking and defers any ordinary cleanup.
        ClearArm()
    elseif event=="UNIT_SPELLCAST_CHANNEL_START" or event=="UNIT_SPELLCAST_FAILED"
        or event=="UNIT_SPELLCAST_INTERRUPTED" or event=="UNIT_SPELLCAST_STOP" or event=="LOOT_OPENED" then
        ClearArm()
    elseif event=="PLAYER_EQUIPMENT_CHANGED" or event=="UNIT_INVENTORY_CHANGED"
        or event=="PLAYER_REGEN_ENABLED" or event=="SPELLS_CHANGED" then
        if event=="PLAYER_REGEN_ENABLED" and not bindingOwner then Initialize() end
        module.Refresh()
    end
end)
