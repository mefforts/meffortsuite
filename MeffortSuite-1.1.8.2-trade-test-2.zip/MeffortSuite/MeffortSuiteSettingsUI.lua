local UI={}
MeffortSuiteSettingsUI=UI

local FONT=STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
local HOME_W,HOME_H=362,420
local DETAIL_W,MIN_DETAIL_H,MAX_DETAIL_H=452,220,560
local BODY_W=406
local C={
  mint={1,.81,.30,1}, gold={1,.82,.28,1}, red={.78,.73,.63,1},
  muted={.82,.77,.67,1}, white={1,.92,.74,1},
}
local frame,headerTitle,logo,backButton,infoButton,masterButton,masterText,statusTitle
local home,tiles,scroller,resetButton,homeButton
local pages={};local activePage="overview"
local history,inputDrafts={},{}
local OpenPage,RefreshUI
local function RGB(tex,c)
  tex:SetColorTexture(c[1],c[2],c[3],c[4] or 1)
end
local function WoWBackdrop(widget)
  local backdrop={
    bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",
    tile=true,tileSize=32,edgeSize=24,
    insets={left=7,right=7,top=7,bottom=7},
  }
  if widget.SetBackdrop then
    widget:SetBackdrop(backdrop)
    if widget.SetBackdropColor then widget:SetBackdropColor(.11,.085,.06,.98)end
    if widget.SetBackdropBorderColor then widget:SetBackdropBorderColor(.78,.62,.30,1)end
  else
    local bg=widget:CreateTexture(nil,"BACKGROUND")
    bg:SetAllPoints(widget)
    bg:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Background")
    bg:SetVertexColor(.72,.60,.44,1)
    local edge=widget:CreateTexture(nil,"BORDER")
    edge:SetAllPoints(widget)
    edge:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Border")
  end
end

local function ReadableText(widget,size)
  widget:SetFont(FONT,size,"OUTLINE")
  if widget.SetShadowColor then widget:SetShadowColor(0,0,0,1) end
  if widget.SetShadowOffset then widget:SetShadowOffset(1,-1) end
end
local function Font(parent,text,size,color)
  local t=parent:CreateFontString(nil,"OVERLAY","GameFontHighlight")
  ReadableText(t,size or 12)
  t:SetTextColor((color or C.white)[1],(color or C.white)[2],(color or C.white)[3],1)
  t:SetText(text or "")
  return t
end
local function DB()
  if type(MeffortSuiteDB)~="table" then MeffortSuiteDB={} end
  return MeffortSuiteDB
end
local function Char()
  if type(MeffortSuiteCharDB)~="table" then MeffortSuiteCharDB={} end
  return MeffortSuiteCharDB
end
local function Range()
  local char=Char()
  if type(char.targetDistance)~="table" then char.targetDistance={} end
  return char.targetDistance
end
local Action=MeffortSuiteActionText.GetSettings
local function IsActive() return not MeffortSuite or not MeffortSuite.Active or MeffortSuite.Active() end
local function OnOff(active) return active and "ON" or "OFF" end
local function Capability(module)
  if module and type(module.Available)=="function" then return module.Available() end
end
local function Features()
  local d=DB()
  local range,ranged=MeffortSuiteTargetDistance,MeffortSuiteRanged
  local fish,arcane,audio=MeffortSuiteFishing,MeffortSuiteArcaneBlast,MeffortSuiteFishingAudio
  local camera=MeffortSuiteFishingCamera
  local mode=ranged and ranged.Mode and ranged.Mode() or "off"
  local quietFishing=audio and audio.Enabled and audio.Enabled()
  return {
    range=(range and range.Enabled and range.Enabled()) or (arcane and arcane.Enabled and arcane.Enabled())
      or (ranged and ranged.Kind and ranged.Kind() and (mode=="right" or mode=="shift")),
    inventory=d.autoSortBags~=false or d.autoSellJunk~=false or d.autoRepair~=false or
      d.autoBankCrafting~=false or d.autoSortBank~=false or d.backpackFreeSlots~=false,
    loot=d.lootValue~=false or d.fastAutoLoot~=false or (MeffortSuiteMageScrolls and MeffortSuiteMageScrolls.Enabled())
      or (MeffortSuiteLootTracker and MeffortSuiteLootTracker.Enabled()),
    quest=d.questSpace~=false or d.questSpaceTrades==true,
    way=d.wayEnabled==true or d.autoOpenFlightMaster~=false or (MeffortSuiteMinimap and MeffortSuiteMinimap.Enabled()),
    tooltips=d.style~=false or d.badges~=false or d.rankHint~=false,
    action=Action().enabled or MeffortSuiteActionText.ManaCostsEnabled(),
    fishing=(fish and fish.Enabled and fish.Enabled()) or quietFishing or (camera and camera.Enabled()),
    audio=d.petSoundsMuted==true or d.petSoundFilesEnabled==true or quietFishing,
  }
end
local function Skin(button)
  local active=button:CreateTexture(nil,"OVERLAY")
  active:SetPoint("BOTTOMLEFT",button,"BOTTOMLEFT",7,4)
  active:SetPoint("BOTTOMRIGHT",button,"BOTTOMRIGHT",-7,4)
  active:SetHeight(2)
  active:SetTexture("Interface\\Buttons\\WHITE8X8")
  active:SetVertexColor(1,.79,.22)
  active:Hide()
  local obj={button=button,selected=false,active=active}
  function obj:Paint()
    if self.selected then self.active:Show() else self.active:Hide() end
  end
  return obj
end
local function PressButton(parent,label,width,height,fn)
  local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
  b:SetSize(width,height)
  b:SetText("")
  local skin=Skin(b)
  local text=Font(b,label,12,C.white)
  text:SetPoint("CENTER",b,"CENTER",0,1)
  text:SetJustifyH("CENTER")
  text:SetWidth(width-14)
  b:SetScript("OnClick",function() if fn then fn() end end)
  return {button=b,skin=skin,text=text}
end
local function Tips(widget,title,detail)
  local oldEnter=widget:GetScript("OnEnter")
  local oldLeave=widget:GetScript("OnLeave")
  widget:SetScript("OnEnter",function(self)
    if oldEnter then oldEnter(self) end
    if GameTooltip then
      GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
      GameTooltip:SetText(title,1,1,1)
      local body=type(detail)=="function" and detail() or detail
      if body and body~="" then GameTooltip:AddLine(body,.83,.79,.69,true) end
      GameTooltip:Show()
    end
  end)
  widget:SetScript("OnLeave",function(self)
    if oldLeave then oldLeave(self) end
    if GameTooltip then GameTooltip:Hide() end
  end)
end

local combatFallback="Interface\\Icons\\INV_Sword_04"
local entry={
  {"inventory","Bags","Interface\\Icons\\INV_Misc_Bag_08","Sorting, merchants and banking"},
  {"loot","Loot","Interface\\Icons\\INV_Misc_Coin_01","Loot tracker, fast auto loot and floating totals"},
  {"quest","Quests","Interface\\Icons\\INV_Misc_Note_01","Quest, confirmation and trade hotkeys"},
  {"range","Combat",combatFallback,"Ranged controls, range warnings and Arcane Blast"},
  {"way","Map","Interface\\Icons\\INV_Misc_Map_01","Minimap, waypoints and flight masters"},
  {"tooltips","Tooltips","Interface\\Icons\\INV_Misc_Book_09","Spell headers, badges and rank hints"},
  {"action","Bars","Interface\\Icons\\Spell_Frost_FrostBolt02","Keybind labels and mana costs"},
  {"fishing","Fishing","Interface\\Icons\\Trade_Fishing","Double right-click fishing, camera zoom, and quiet audio"},
  {"audio","Sounds","Interface\\Icons\\Spell_Holy_Silence","Native pet sounds, targeted files and fishing audio"},
}
local function EquippedTexture(slot)
  if type(GetInventoryItemTexture)~="function" then return end
  local ok,texture=pcall(GetInventoryItemTexture,"player",slot)
  if not ok or (issecretvalue and issecretvalue(texture)) then return end
  if (type(texture)=="number" and texture>0) or (type(texture)=="string" and texture~="") then
    return texture
  end
end
local function CombatIcon()
  local ranged=MeffortSuiteRanged
  if ranged and ranged.Kind and ranged.Kind() then
    local texture=EquippedTexture(18)
    if texture then return texture end
  end
  return EquippedTexture(16) or combatFallback
end
local function BuildHome()
  home=CreateFrame("Frame",nil,frame)
  home:SetPoint("TOPLEFT",frame,"TOPLEFT",10,-76)
  home:SetSize(HOME_W-20,HOME_H-82)
  tiles={}
  for index,data in ipairs(entry) do
    local id,label,icon,tip=data[1],data[2],data[3],data[4]
    local b=CreateFrame("Button",nil,home)
    b:SetSize(108,96)
    local column=(index-1)%3
    local row=math.floor((index-1)/3)
    b:SetPoint("TOPLEFT",home,"TOPLEFT",4+column*112,-3-row*101)
    local face=b:CreateTexture(nil,"BACKGROUND")
    face:SetAllPoints(b)
    face:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Background")
    face:SetVertexColor(.40,.37,.32,.98)
    local edges={}
    local function Edge(anchor1,thickness)
      local t=b:CreateTexture(nil,"BORDER")
      t:SetTexture("Interface\\Buttons\\WHITE8X8")
      t:SetVertexColor(.66,.52,.28,.90)
      if anchor1=="TOP" or anchor1=="BOTTOM" then
        t:SetPoint(anchor1.."LEFT",b,anchor1.."LEFT",1,0)
        t:SetPoint(anchor1.."RIGHT",b,anchor1.."RIGHT",-1,0)
        t:SetHeight(thickness)
      else
        t:SetPoint("TOP"..anchor1,b,"TOP"..anchor1,0,-1)
        t:SetPoint("BOTTOM"..anchor1,b,"BOTTOM"..anchor1,0,1)
        t:SetWidth(thickness)
      end
      edges[#edges+1]=t
    end
    Edge("TOP",1)
    Edge("BOTTOM",1)
    Edge("LEFT",1)
    Edge("RIGHT",1)

    local over=b:CreateTexture(nil,"HIGHLIGHT")
    over:SetAllPoints(b)
    over:SetTexture("Interface\\Buttons\\WHITE8X8")
    over:SetVertexColor(1,.77,.31,.10)

    local down=b:CreateTexture(nil,"ARTWORK")
    down:SetAllPoints(b)
    down:SetTexture("Interface\\Buttons\\WHITE8X8")
    down:SetVertexColor(.18,.13,.05,.30)
    down:Hide()

    local pict=b:CreateTexture(nil,"ARTWORK")
    pict:SetSize(46,46)
    pict:SetPoint("TOP",b,"TOP",0,-7)
    pict:SetTexture(icon)
    pict:SetTexCoord(.08,.92,.08,.92)
    local caption=Font(b,label,12,C.white)
    caption:SetPoint("TOP",b,"TOP",0,-56)
    caption:SetWidth(100)
    caption:SetJustifyH("CENTER")
    local badge=Font(b,"OFF",10,C.muted)
    badge:SetPoint("BOTTOM",b,"BOTTOM",0,9)
    badge:SetJustifyH("CENTER")
    b:SetScript("OnMouseDown",function()down:Show();pict:ClearAllPoints();pict:SetPoint("TOP",b,"TOP",0,-8)end)
    b:SetScript("OnMouseUp",function()down:Hide();pict:ClearAllPoints();pict:SetPoint("TOP",b,"TOP",0,-7)end)
    b:SetScript("OnLeave",function()down:Hide();pict:ClearAllPoints();pict:SetPoint("TOP",b,"TOP",0,-7)end)
    b:SetScript("OnClick",function() OpenPage(id) end)
    Tips(b,label,tip)
    tiles[#tiles+1]={id=id,pict=pict,badge=badge,edges=edges}
  end
end
local function UpdateHome()
  if not tiles then return end
  local status=Features()
  local active=IsActive()
  for _,t in ipairs(tiles) do
    if t.id=="range" then t.pict:SetTexture(CombatIcon()) end
    local off=not (active and status[t.id])
    t.badge:SetText(OnOff(not off))
    t.badge:SetTextColor(off and C.muted[1] or 1,off and C.muted[2] or .83,off and C.muted[3] or .33,1)
    for _,edge in ipairs(t.edges) do
      edge:SetVertexColor(off and .40 or .80,off and .37 or .64,off and .30 or .33,.92)
    end
    t.pict:SetDesaturated(off)
  end
end

local scopes={range="Character settings",rangeadvanced="Character settings",
  arcaneblast="Character settings | Mage only",inventory="Account settings | Bank lists: this character",
  quest="Account settings",way="Account settings",tooltips="Account settings",
  action="Account settings",fishing="Character settings",audio="Account settings | Fishing audio: this character",soundfiles="Account settings",defaults="Account preferences + this character",badges="Account settings"}
local guidance={
  rangeadvanced="Automatic detection is recommended. Enter an exact spellbook name to override it.",
  arcaneblast="Add Arcane Blast to Blizzard Tracked Buffs first.",
  defaults="Reset account preferences and this character's settings, then reload. Other characters, bank lists, sound-file lists, macros and keybindings are kept.",
}
local function Wrapped(p,message,size,color)
  local t=Font(p,message,size or 11,color or C.muted)
  t:SetPoint("TOPLEFT",p,"TOPLEFT",11,-p.height)
  t:SetWidth(BODY_W-24);t:SetJustifyH("LEFT")
  if type(t.SetWordWrap)=="function" then t:SetWordWrap(true)end
  local lines=0
  for line in (message.."\n"):gmatch("(.-)\n") do lines=lines+math.max(1,math.ceil(#line/65))end
  local h=type(t.GetStringHeight)=="function" and t:GetStringHeight()
  if type(h)~="number" or h~=h or h<=0 or h==math.huge then h=lines*14 end
  p.height=p.height+math.max(14,h)+9;p:SetHeight(math.max(130,p.height+10))
  return t
end
local function Page(key,heading)
  local p=CreateFrame("Frame",nil,scroller)
  p:SetSize(BODY_W,130)
  p.height=8
  local scopeText=scopes[key]
  if key=="loot" then
    local scrolls=MeffortSuiteMageScrolls
    scopeText=scrolls and scrolls.IsMage() and "Account settings | Mage scrolls: this character" or "Account settings"
  end
  if scopeText then
    local scope=Font(p,scopeText,10,C.muted)
    scope:SetPoint("TOPLEFT",p,"TOPLEFT",11,-8)
    scope:SetWidth(BODY_W-24);scope:SetJustifyH("LEFT")
    p.height=29
  end
  p.refreshers={}
  p.label=heading
  pages[key]=p
  if guidance[key] then Wrapped(p,guidance[key]) end
  return p
end
local function AddRefresh(p,fn) p.refreshers[#p.refreshers+1]=fn end
local function Reserve(p,h)
  local y=-p.height
  p.height=p.height+h
  p:SetHeight(math.max(130,p.height+10))
  return y
end
local function RowFrame(p,h)
  local y=Reserve(p,h+2)
  local f=CreateFrame("Frame",nil,p)
  f:SetPoint("TOPLEFT",p,"TOPLEFT",1,y)
  f:SetSize(BODY_W-5,h)
  local line=f:CreateTexture(nil,"BACKGROUND")
  line:SetPoint("BOTTOMLEFT",f,"BOTTOMLEFT",7,0)
  line:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",-7,0)
  line:SetHeight(1)
  line:SetTexture("Interface\\Buttons\\WHITE8X8")
  line:SetVertexColor(.35,.29,.20,.65)
  return f,line
end
local function TextRow(p,message,color)
  local row=RowFrame(p,30)
  local t=Font(row,message,11,color or C.muted)
  t:SetPoint("LEFT",row,"LEFT",10,0)
  t:SetWidth(BODY_W-22)
  t:SetJustifyH("LEFT")
  return t
end
local function Section(p,title)
  local row=RowFrame(p,27)
  local t=Font(row,title,12,C.gold)
  t:SetPoint("LEFT",row,"LEFT",10,0);t:SetJustifyH("LEFT")
  return t
end
local function Toggle(p,label,detail,read,write)
  local row=RowFrame(p,37)
  local check=CreateFrame("CheckButton",nil,row,"UICheckButtonTemplate")
  check:SetSize(29,29)
  check:SetPoint("LEFT",row,"LEFT",7,0)
  local txt=Font(row,label,12,C.white)
  txt:SetPoint("LEFT",check,"RIGHT",3,0)
  txt:SetWidth(BODY_W-100);txt:SetJustifyH("LEFT")
  local state=Font(row,"OFF",10,C.muted)
  state:SetPoint("RIGHT",row,"RIGHT",-9,0)
  state:SetWidth(48);state:SetJustifyH("RIGHT")
  local function Change(value) write(value);RefreshUI() end
  check:SetScript("OnClick",function(self)Change(self:GetChecked() and true or false)end)
  local hit=CreateFrame("Button",nil,row)
  hit:SetPoint("TOPLEFT",row,"TOPLEFT",39,0)
  hit:SetPoint("BOTTOMRIGHT",row,"BOTTOMRIGHT",0,0)
  hit:RegisterForClicks("LeftButtonUp")
  hit:SetScript("OnClick",function()Change(read()~=true)end)
  AddRefresh(p,function()
    local on=read()==true
    check:SetChecked(on)
    state:SetText(on and "ON" or "OFF")
    state:SetTextColor(on and 1 or C.muted[1],on and .82 or C.muted[2],on and .28 or C.muted[3])
  end)
  if detail then Tips(check,label,detail);Tips(hit,label,detail) end
  return check
end
local function Choice(p,label,options,read,write)
  local row=RowFrame(p,66)
  local l=Font(row,label,12,C.white);l:SetPoint("TOPLEFT",row,"TOPLEFT",11,-8)
  local list={}
  local w=(BODY_W-27-(#options-1)*5)/#options
  for i,o in ipairs(options) do
    local b=PressButton(row,o.label,w,29,function()write(o.value);RefreshUI()end)
    b.button:SetPoint("BOTTOMLEFT",row,"BOTTOMLEFT",9+(i-1)*(w+5),8)
    list[#list+1]={ui=b,item=o}
  end
  AddRefresh(p,function()
    local now=read()
    for _,o in ipairs(list) do
      local selected=o.item.value==now
      o.ui.skin.selected=selected
      o.ui.skin:Paint()
      o.ui.text:SetTextColor(selected and C.gold[1] or C.white[1],selected and C.gold[2] or C.white[2],selected and C.gold[3] or C.white[3])
    end
  end)
end
local function Stepper(p,label,lo,hi,step,read,write,unit)
  local row=RowFrame(p,52)
  local name=Font(row,label,12,C.white)
  name:SetPoint("TOPLEFT",row,"TOPLEFT",11,-7)
  local value=Font(row,"",19,C.gold)
  value:SetPoint("BOTTOMLEFT",row,"BOTTOMLEFT",12,7)
  value:SetWidth(150)
  local function change(delta)
    local n=tonumber(read()) or lo
    n=math.max(lo,math.min(hi,n+delta))
    write(n)
    RefreshUI()
  end
  local controls={ {"-5",-step*5},{"-",-step},{"+",step},{"+5",step*5}}
  for i,c in ipairs(controls) do
    local b=PressButton(row,c[1],46,29,function()change(c[2])end)
    b.button:SetPoint("RIGHT",row,"RIGHT",-(9+(4-i)*49),-8)
  end
  AddRefresh(p,function()
    local n=read() or lo
    value:SetText(tostring(n)..(unit or ""))
  end)
end
local function FishingDelay(p,camera)
  local row=RowFrame(p,55)
  local label=Font(row,"Zoom-out delay",12,C.white)
  label:SetPoint("TOPLEFT",row,"TOPLEFT",11,-7)
  local value=Font(row,"",12,C.gold)
  value:SetPoint("TOPRIGHT",row,"TOPRIGHT",-11,-7)
  local slider=CreateFrame("Slider",nil,row,"MinimalSliderTemplate")
  slider:SetPoint("BOTTOMLEFT",row,"BOTTOMLEFT",14,8)
  slider:SetPoint("BOTTOMRIGHT",row,"BOTTOMRIGHT",-14,8)
  local lo,hi,step=camera.ZoomOutDelayLimits()
  slider:SetMinMaxValues(lo,hi)
  slider:SetValueStep(step)
  slider:SetObeyStepOnDrag(true)
  local syncing
  local function Sync()
    syncing=true
    local delay=camera.ZoomOutDelay()
    slider:SetValue(delay)
    value:SetText(string.format("%g sec",delay))
    syncing=false
  end
  slider:SetScript("OnValueChanged",function(_,delay)
    if syncing then return end
    camera.SetZoomOutDelay(delay)
    Sync()
  end)
  Tips(slider,"Zoom-out delay","Seconds to wait after the cast ends before returning from first person.")
  AddRefresh(p,Sync)
end
local function Link(p,label,action,right,available)
  local row=RowFrame(p,available and 55 or 35)
  local b=PressButton(row,label,BODY_W-19,29,function()
    local ready=true
    if available then ready=available() end
    if ready then action() end
    RefreshUI()
  end)
  b.button:SetPoint(available and "TOP" or "CENTER",row,available and "TOP" or "CENTER",0,available and -2 or 1)
  b.text:SetJustifyH("LEFT")
  b.text:ClearAllPoints();b.text:SetPoint("LEFT",b.button,"LEFT",12,1)
  b.text:SetWidth(BODY_W-100)
  local suffix
  if right then
    suffix=Font(b.button,right,11,C.gold)
    suffix:SetPoint("RIGHT",b.button,"RIGHT",-12,1)
  end
  if available then
    local reason=Font(row,"",10,C.muted)
    reason:SetPoint("BOTTOMLEFT",row,"BOTTOMLEFT",12,6)
    reason:SetWidth(BODY_W-28);reason:SetJustifyH("LEFT")
    AddRefresh(p,function()
      local ready,why=available()
      if ready then b.button:Enable() else b.button:Disable() end
      b.text:SetTextColor(ready and C.white[1] or C.muted[1],ready and C.white[2] or C.muted[2],ready and C.white[3] or C.muted[3])
      reason:SetText(why or "")
    end)
  end
  return b
end
local function Input(p,label,get,apply,buttonName,maxLetters)
  local row=RowFrame(p,96)
  local l=Font(row,label,12,C.white)
  l:SetPoint("TOPLEFT",row,"TOPLEFT",11,-9)
  l:SetWidth(BODY_W-24);l:SetJustifyH("LEFT")
  local field=CreateFrame("EditBox",nil,row,"InputBoxTemplate")
  field:SetPoint("TOPLEFT",row,"TOPLEFT",17,-34)
  field:SetSize(240,26)
  field:SetAutoFocus(false)
  if field.SetFont then ReadableText(field,12) end
  field:SetMaxLetters(maxLetters or 60)
  Tips(field,label,"Enter saves. Esc discards. Maximum "..tostring(maxLetters or 60).." characters.")
  local feedback=Font(row,"Saved",10,C.muted)
  feedback:SetPoint("BOTTOMLEFT",row,"BOTTOMLEFT",12,9)
  feedback:SetWidth(BODY_W-28);feedback:SetJustifyH("LEFT")
  local dirty,loading=false,false
  local function Restore(message)
    loading=true;field:SetText(tostring(get() or ""));loading=false;dirty=false
    feedback:SetText(message or "Saved")
  end
  local function Save()
    local ok,result,why=pcall(apply,field:GetText())
    if not ok or result==false then
      feedback:SetText(why or "Could not save. Check the value and try again.")
      return
    end
    Restore("Saved");field:ClearFocus();RefreshUI()
  end
  field:SetScript("OnTextChanged",function()
    if loading then return end
    dirty=field:GetText()~=tostring(get() or "")
    feedback:SetText(dirty and ("Unsaved - Enter or "..(buttonName or "Apply").."; Esc discards") or "Saved")
    if frame and frame:IsShown() then RefreshUI() end
  end)
  field:SetScript("OnEnterPressed",Save)
  field:SetScript("OnEscapePressed",function(self)Restore("Changes discarded");self:ClearFocus();RefreshUI()end)
  local btn=PressButton(row,buttonName or "Apply",105,30,Save)
  btn.button:SetPoint("TOPRIGHT",row,"TOPRIGHT",-10,-32)
  inputDrafts[#inputDrafts+1]=function()return dirty end
  AddRefresh(p,function()
    -- Never replace an unapplied draft on blur, navigation, or status refresh.
    if not dirty and not field:HasFocus() and field:GetText()~=tostring(get() or "") then Restore() end
    if dirty then btn.button:Enable() else btn.button:Disable() end
  end)
  return function(message)Restore(message);field:ClearFocus()end
end
local function ColorHex(s)
  s=tostring(s or "ffffff"):gsub("#","")
  if not s:match("^%x%x%x%x%x%x$") then s="ffffff" end
  return {tonumber(s:sub(1,2),16)/255,tonumber(s:sub(3,4),16)/255,tonumber(s:sub(5,6),16)/255,1}
end
local function Swatch(p,title,category)
  local row=RowFrame(p,40)
  local preview=row:CreateTexture(nil,"ARTWORK")
  preview:SetPoint("TOPLEFT",row,"TOPLEFT",11,-7)
  preview:SetPoint("BOTTOMLEFT",row,"BOTTOMLEFT",11,7)
  preview:SetWidth(150)
  preview:SetTexture("Interface\\AddOns\\MeffortSuite\\Textures\\SoftBadge.tga")
  local text=Font(row,title,11,C.white)
  text:SetPoint("CENTER",preview,"CENTER",0,0)
  text:SetWidth(140);text:SetJustifyH("CENTER")
  local function chip(offset,kind)
    local b=CreateFrame("Button",nil,row,"UIPanelButtonTemplate")
    b:SetSize(66,25)
    b:SetPoint("RIGHT",row,"RIGHT",offset,0)
    local sample=b:CreateTexture(nil,"OVERLAY")
    sample:SetPoint("TOPLEFT",b,"TOPLEFT",5,-5)
    sample:SetPoint("BOTTOMRIGHT",b,"BOTTOMRIGHT",-5,5)
    b:SetScript("OnClick",function()
      if MeffortSuiteBadgeThemeRead and MeffortSuiteBadgeThemeWrite and MeffortSuiteShowColorPicker then
        MeffortSuiteShowColorPicker(MeffortSuiteBadgeThemeRead(category,kind),function(hex)
          MeffortSuiteBadgeThemeWrite(category,kind,hex);RefreshUI()
        end)
      end
    end)
    Tips(b,title..(kind=="background" and ": background" or ": text"),"Choose a color. The preview shows the two colors together. Esc in the color picker cancels.")
    AddRefresh(p,function()
      if MeffortSuiteBadgeThemeRead then RGB(sample,ColorHex(MeffortSuiteBadgeThemeRead(category,kind))) end
    end)
  end
  chip(-85,"background");chip(-9,"text")
  AddRefresh(p,function()
    if not MeffortSuiteBadgeThemeRead then return end
    local bg=ColorHex(MeffortSuiteBadgeThemeRead(category,"background"))
    local fg=ColorHex(MeffortSuiteBadgeThemeRead(category,"text"))
    preview:SetVertexColor(bg[1],bg[2],bg[3],.9)
    text:SetTextColor(fg[1],fg[2],fg[3],1)
    text:SetFont(FONT,11,DB().badgeTextOutline==true and "OUTLINE" or "")
    text:SetShadowColor(0,0,0,DB().badgeTextShadow~=false and .95 or 0)
    text:SetShadowOffset(DB().badgeTextShadow~=false and 1 or 0,DB().badgeTextShadow~=false and -1 or 0)
  end)
end
local function ApplyBar()
  if MeffortSuiteActionText and MeffortSuiteActionText.ApplyAll then MeffortSuiteActionText.ApplyAll() end
end
local function Build(key)
  local m=MeffortSuiteTargetDistance
  local fishing=MeffortSuiteFishing
  local ranged=MeffortSuiteRanged
  local p
  if key=="range" then
    p=Page(key,"Combat")
    local kind=ranged and ranged.Kind and ranged.Kind()
    if kind then
      Section(p,kind=="wand" and "Wand" or "Ranged attacks")
      Choice(p,"Right-click behavior",{{label="Off",value="off"},{label="Right-click",value="right"},{label="Shift + right-click",value="shift"}},function()return ranged and ranged.Mode() or "off"end,function(v)if ranged then ranged.SetMode(v)end end)
      local message=TextRow(p,"")
      AddRefresh(p,function()message:SetText("Detected: "..tostring(ranged and ranged.AbilityName() or "Unavailable"))end)
      local readiness=TextRow(p,"")
      AddRefresh(p,function()
        local available,why=Capability(ranged)
        local pending=ranged and ranged.Pending and ranged.Pending()
        readiness:SetText(pending and "Input settings will refresh after combat." or
          (available==false and (why or "Right-click controls unavailable; normal mouse controls retained.") or "Equip the matching weapon."))
      end)
      local owner=TextRow(p,"")
      AddRefresh(p,function()owner:SetText("Macro owner: "..tostring(MeffortRightClickShared and MeffortRightClickShared.Owner() or "None"))end)
      Link(p,"Clean up old duplicate macros",function()
        if ranged and ranged.CleanupMacros then
          local count,err=ranged.CleanupMacros()
          if MeffortSuite and MeffortSuite.Message then
            MeffortSuite.Message(count and ("Removed "..tostring(count).." duplicates.") or ("Macro cleanup: "..tostring(err)))
          end
        end
      end,"CLEAN")
      Section(p,"Range warning")
    end
    Toggle(p,"Out-of-range dot","Shows only when the target is known to be out of range.",function()return m and m.Enabled()end,function(v)if m then m.SetEnabled(v)end end)
    Stepper(p,"Warning distance",1,100,1,function()return Range().rangeYards or 30 end,function(n)if m then m.SetYards(n)end end," yd")
    Stepper(p,"Dot size",10,26,1,function()return Range().fontSize or 19 end,function(n)if m then m.SetSize(n)end end," px")
    Toggle(p,"Lock dot position","Unlock to drag the dot while the warning is enabled.",function()return Range().locked~=false end,function(v)if m then m.SetLocked(v)end end)
    Link(p,"Reset position",function()if m then m.Reset()end end,"RESET")
    Link(p,"Advanced spell detection",function()OpenPage("rangeadvanced")end," > ")
    if MeffortSuiteArcaneBlast and MeffortSuiteArcaneBlast.IsMage() then
      Link(p,"Arcane Blast stacks / timer",function()OpenPage("arcaneblast")end," > ")
    end
  elseif key=="rangeadvanced" then
    p=Page(key,"Range: Advanced")
    local restoreSpell=Input(p,"Spell name (exact spellbook text)",function()return Range().spellName or "" end,function(s)
      if m then return m.SetSpell(s) end
      return false,"Range checks are unavailable."
    end,"Use spell")
    Link(p,"Use automatic range checks",function()
      if m and m.SetSpell("auto") then restoreSpell("Automatic range checks") end
    end,"AUTO")
  elseif key=="arcaneblast" then
    p=Page(key,"Arcane Blast")
    local ab=MeffortSuiteArcaneBlast
    if not ab or not ab.IsMage or not ab.IsMage() then
      TextRow(p,"Arcane Blast tracking is available to Mages.")
      return p
    end
    Toggle(p,"Arcane Blast on Tracked Buffs","Show stacks and a timer on the Blizzard buff icon.",function()return ab and ab.GetOption("enabled")end,function(v)if ab then ab.SetOption("enabled",v)end end)
    Toggle(p,"Show stack count",nil,function()return ab and ab.GetOption("stacks")end,function(v)if ab then ab.SetOption("stacks",v)end end)
    Toggle(p,"Show remaining time",nil,function()return ab and ab.GetOption("timer")end,function(v)if ab then ab.SetOption("timer",v)end end)
    Toggle(p,"Show timer wheel",nil,function()return ab and ab.GetOption("wheel")end,function(v)if ab then ab.SetOption("wheel",v)end end)
  elseif key=="fishing" then
    p=Page(key,"Fishing")
    local camera=MeffortSuiteFishingCamera
    Toggle(p,"Double right-click fishing","Equip a pole to cast. Enable Interact Key in WoW, aim at the bobber and repeat when it splashes.",function()return fishing and fishing.Enabled()end,function(v)if fishing then fishing.SetEnabled(v)end end)
    Toggle(p,"Zoom fishing view","Quickly zoom into first person with a slight downward tilt. The view pauses for a quick recast, then zooms back out.",function()return camera and camera.Enabled()end,function(v)if camera then camera.SetEnabled(v)end end)
    if camera then FishingDelay(p,camera) end
    TextRow(p,"Enable Interact Key in WoW to show the native bobber cog.")
    Section(p,"Fishing audio")
    Toggle(p,"Quiet fishing audio","Mute music, ambience and dialogue while a pole is equipped. Keep sound effects audible.",function()return MeffortSuiteFishingAudio and MeffortSuiteFishingAudio.Enabled() or false end,function(v)if MeffortSuiteFishingAudio then MeffortSuiteFishingAudio.SetEnabled(v)end end)
    local audio=TextRow(p,"")
    AddRefresh(p,function()audio:SetText("Quiet audio: "..(MeffortSuiteFishingAudio and MeffortSuiteFishingAudio.Status() or "unavailable"))end)
    local equip=TextRow(p,"")
    AddRefresh(p,function()
      local available,why=Capability(fishing)
      equip:SetText(available==false and (why or "This client cannot safely enable right-click fishing.") or
        (fishing and fishing.IsPoleEquipped() and "Fishing pole equipped" or "Equip a fishing pole to use this feature"))
    end)
    Link(p,"Pet sounds and advanced audio",function()OpenPage("audio")end," > ")
  elseif key=="loot" then
    p=Page(key,"Loot")
    local tracker=MeffortSuiteLootTracker
    if tracker then
      Section(p,"Loot tracker")
      Toggle(p,"Track loot","Start or pause recording. Use Reset in the tracker to clear the log.",
        tracker.Enabled,tracker.SetTracking)
      Link(p,"Open loot tracker",tracker.Open,"SHOW")
      Toggle(p,"Track loot on login","Resume tracking and show the tracker on login or UI reload.",
        tracker.AutoStart,tracker.SetAutoStart)
      Input(p,"Session timer (minutes, 0 for off)",tracker.GetTimerMinutes,tracker.SetTimerMinutes,"Set timer",4)
      Link(p,"Dock under minimap",tracker.Dock)
      Choice(p,"Tracker style",{{label="Parchment",value="parchment"},{label="Transparent",value="transparent"},
        {label="Blizzard",value="blizzard"}},tracker.GetStyle,tracker.SetStyle)
    end
    local scrolls=MeffortSuiteMageScrolls
    if scrolls and scrolls.IsMage() then
      Section(p,"Mage scrolls")
      Toggle(p,"Right-click to comprehend scrolls","Use Comprehend Scroll on an untranslated scroll in your standard bags. Learn Comprehend Scroll first. Works outside combat.",
        scrolls.Enabled,scrolls.SetEnabled)
    end
    Section(p,"Auto-loot")
    Toggle(p,"Fast auto loot","Speeds up the game's Auto Loot and respects its modifier key.",function()return DB().fastAutoLoot~=false end,function(v)if MeffortSuiteFastLoot then MeffortSuiteFastLoot.SetEnabled(v)else DB().fastAutoLoot=v end end)
    Section(p,"Floating totals")
    Toggle(p,"Floating loot value","Show coins plus item value after looting. Area loot uses one combined total.",function()return DB().lootValue~=false end,function(v)if MeffortSuiteLootValue then MeffortSuiteLootValue.SetEnabled(v)else DB().lootValue=v end end)
    Toggle(p,"Include all item qualities","Turn off to count only grey items.",function()return DB().lootValueAllItems~=false end,function(v)if MeffortSuiteLootValue and MeffortSuiteLootValue.SetIncludeAllItems then MeffortSuiteLootValue.SetIncludeAllItems(v)else DB().lootValueAllItems=v end end)
    Toggle(p,"Use Auctionator AH values","Use cached Auctionator estimates, with vendor prices as fallback.",function()return DB().lootValueAuctionator==true end,function(v)if MeffortSuiteLootValue and MeffortSuiteLootValue.SetUseAuctionator then MeffortSuiteLootValue.SetUseAuctionator(v)else DB().lootValueAuctionator=v end end)
    Toggle(p,"Show vendor + AH together","Display both totals. Each includes the coins received. This setting takes priority over the AH-only display.",function()return DB().lootValueBoth==true end,function(v)if MeffortSuiteLootValue and MeffortSuiteLootValue.SetShowBothValues then MeffortSuiteLootValue.SetShowBothValues(v)else DB().lootValueBoth=v end end)
    Stepper(p,"Float duration",2,12,1,function()return MeffortSuiteLootValue and MeffortSuiteLootValue.Duration and MeffortSuiteLootValue.Duration() or DB().lootValueDuration or 6 end,function(n)if MeffortSuiteLootValue and MeffortSuiteLootValue.SetDuration then MeffortSuiteLootValue.SetDuration(n)else DB().lootValueDuration=n end end," sec")
    Link(p,"Preview loot value",function()if MeffortSuiteLootValue then MeffortSuiteLootValue.Preview()end end,"SHOW",function()
      local ready=IsActive() and DB().lootValue~=false and MeffortSuiteLootValue~=nil
      return ready,not ready and "Enable Floating loot value and MeffortSuite first." or nil
    end)
    local lootSummary=TextRow(p,"")
    AddRefresh(p,function()
      if DB().lootValueBoth==true then
        lootSummary:SetText(MeffortSuiteLootValue and MeffortSuiteLootValue.PricingStatus and
          MeffortSuiteLootValue.PricingStatus() or "Vendor + (AH estimates); vendor fallback")
      elseif DB().lootValueAuctionator==true then
        lootSummary:SetText(MeffortSuiteLootValue and MeffortSuiteLootValue.PricingStatus and
          MeffortSuiteLootValue.PricingStatus() or "Auctionator AH estimates; vendor fallback")
      else lootSummary:SetText(DB().lootValueAllItems~=false and
        "Coins + all item vendor values; AoE loot is combined." or
        "Coins + grey-item vendor value; AoE loot is combined.")end
    end)
  elseif key=="inventory" then
    p=Page(key,"Bags")
    Section(p,"Bags and merchants")
    Toggle(p,"Backpack free-slot count","Show the game's free-slot count on the backpack. Turning this off restores your prior game setting.",function()return DB().backpackFreeSlots~=false end,function(v)if MeffortSuiteBackpack then MeffortSuiteBackpack.SetEnabled(v)else DB().backpackFreeSlots=v end end)
    local backpackState=TextRow(p,"")
    AddRefresh(p,function()backpackState:SetText(MeffortSuiteBackpack and MeffortSuiteBackpack.Status() or "Native backpack count unavailable.")end)
    Toggle(p,"Auto-sort","Sort bags when opened.",function()return DB().autoSortBags~=false end,function(v)DB().autoSortBags=v;if MeffortSuiteInventory then MeffortSuiteInventory.RefreshBags()end end)
    Toggle(p,"Sell junk","Sell grey items when a merchant opens.",function()return DB().autoSellJunk~=false end,function(v)DB().autoSellJunk=v end)
    Toggle(p,"Auto-repair","Repair equipment at eligible merchants.",function()return DB().autoRepair~=false end,function(v)DB().autoRepair=v end)
    Section(p,"Personal banking")
    Toggle(p,"Auto-bank items","Deposit reagents and listed items when your personal bank opens.",function()return MeffortSuiteBank and MeffortSuiteBank.Enabled() or false end,function(v)if MeffortSuiteBank then MeffortSuiteBank.SetEnabled(v)end end)
    Toggle(p,"Auto-sort personal bank","Sort on bank open and after deposits.",function()return MeffortSuiteBank and MeffortSuiteBank.SortEnabled() or false end,function(v)if MeffortSuiteBank then MeffortSuiteBank.SetSortEnabled(v)end end)
    Input(p,"Keep in bags (comma-separated item names or IDs)",function()return MeffortSuiteBank and MeffortSuiteBank.Exclusions() or "" end,function(value)if MeffortSuiteBank and type(MeffortSuiteBank.SetExclusions)=="function" then return MeffortSuiteBank.SetExclusions(value)end;return false,"Bank item lists are unavailable." end,"Save list",250)
    Input(p,"Also deposit (comma-separated item names or IDs)",function()return MeffortSuiteBank and type(MeffortSuiteBank.Inclusions)=="function" and MeffortSuiteBank.Inclusions() or "" end,
      function(value)if MeffortSuiteBank and type(MeffortSuiteBank.SetInclusions)=="function" then return MeffortSuiteBank.SetInclusions(value)end;return false,"Bank item lists are unavailable." end,"Save list",250)
    TextRow(p,"Keep in bags takes priority.")
    TextRow(p,"After saving a list, choose Deposit items now or reopen the bank.")
    Link(p,"Deposit items now",function()if MeffortSuiteBank then MeffortSuiteBank.DepositNow(false)end end,"BANK",function()
      local bank=MeffortSuiteBank
      if not bank then return false,"Banking is unavailable." end
      if bank.CanDepositStatus then return bank.CanDepositStatus() end
      return false,"Open your personal bank to deposit reagents."
    end)
    Link(p,"Retry merchant actions",function()if MeffortSuiteInventory and MeffortSuiteInventory.VendorStatus then MeffortSuiteInventory.VendorStatus(true)end end,"RETRY",function()
      if not IsActive() then return false,"Enable MeffortSuite first." end
      local inv=MeffortSuiteInventory
      local ready=inv and inv.CanUseMerchant and inv.CanUseMerchant()
      return ready==true,ready and "Recheck junk sales and repairs at this merchant." or "Open a merchant first."
    end)
  elseif key=="quest" then
    p=Page(key,"Quests")
    Toggle(p,"Quest dialogue hotkeys","Space advances quests. Keys 1–9 select menu choices.",function()return DB().questSpace~=false end,function(v)DB().questSpace=v;if MeffortSuiteQuestSpace then MeffortSuiteQuestSpace.Refresh()end end)
    Toggle(p,"Space accepts confirmations","Use Space for eligible Yes/No and confirmation prompts. Requires quest hotkeys.",function()return DB().questSpaceConfirmations~=false end,function(v)DB().questSpaceConfirmations=v;if MeffortSuiteQuestSpace then MeffortSuiteQuestSpace.Refresh()end end)
    Toggle(p,"Space accepts trades","Tap Space for trade invites, the Trade button, and regular trade prompts. Click Accept for the final review.",function()return DB().questSpaceTrades==true end,function(v)
      DB().questSpaceTrades=v
      if MeffortSuiteQuestSpace then MeffortSuiteQuestSpace.Refresh() end
    end)
    local readiness=TextRow(p,"")
    AddRefresh(p,function()
      local q=MeffortSuiteQuestSpace
      local available,why=Capability(q)
      local standalone=MeffortSuite and MeffortSuite.StandaloneLoaded("MeffortBars")
      readiness:SetText(standalone and "Suite quest hotkeys pause while MeffortBars is loaded." or
        available==false and (why or "Quest hotkeys are unavailable in this client.") or "Quest hotkeys pause during combat.")
    end)
    TextRow(p,"SPACE   Available > Ready to turn in > Unfinished",C.gold)
    TextRow(p,"1-9   Menu order   |   * marks the Spacebar choice")
  elseif key=="way" then
    p=Page(key,"Map")
    local minimap=MeffortSuiteMinimap
    if minimap then
      Toggle(p,"Collapse addon minimap buttons","Click the MeffortSuite minimap icon to open the grouped menu.",
        minimap.Enabled,minimap.SetEnabled)
    end
    Toggle(p,"Suite waypoint arrow","Show the Suite arrow for native map pins and /way.",function()return DB().wayEnabled==true end,function(v)DB().wayEnabled=v;if MeffortSuiteWay then MeffortSuiteWay.Refresh()end end)
    TextRow(p,"/way 49.4 12.9 sets a pin on the open map, or your current zone.")
    TextRow(p,"/way Hillsbrad Foothills 87.3 49.6 sets a pin in a named zone.")
    TextRow(p,"Use /msuite way 49.4 12.9 if another addon provides /way.")
    Toggle(p,"Skip flight master dialogue","Open the flight map automatically. Hold Shift to see dialogue.",function()return MeffortSuiteFlightMasters and MeffortSuiteFlightMasters.Enabled() or false end,function(v)if MeffortSuiteFlightMasters then MeffortSuiteFlightMasters.SetEnabled(v)end end)
    Choice(p,"Arrow style",{{label="Teal",value="teal"},{label="Treecko",value="treecko"}},function()return DB().wayTheme or "teal"end,function(v)if MeffortSuiteWay then MeffortSuiteWay.SetTheme(v,true)end end)
  elseif key=="tooltips" then
    p=Page(key,"Tooltips")
    Toggle(p,"Highlight headers & costs","Increase contrast for spell details.",function()return DB().style~=false end,function(v)DB().style=v end)
    Toggle(p,"Spell badges","Show cast time, range and resource tags.",function()return DB().badges~=false end,function(v)DB().badges=v end)
    Toggle(p,"New-rank reminder","Show a notice when a new spell rank is available.",function()return DB().rankHint~=false end,function(v)DB().rankHint=v end)
    Link(p,"Customize badge colors",function()OpenPage("badges")end," > ")
    local status=TextRow(p,"")
    AddRefresh(p,function()
      local info=MeffortSuiteTooltipStatus and MeffortSuiteTooltipStatus()
      local standalone=MeffortSuite and MeffortSuite.StandaloneLoaded("MeffortBars")
      if standalone then status:SetText("Suite spell tooltips pause while MeffortBars is loaded.")
      elseif info and not info.available then status:SetText("Spell tooltip features are unavailable in this client.")
      elseif info and not info.localeSupported then status:SetText("Spell tooltip features require an English game client.")
      elseif DB().style==false then status:SetText("Enable Highlight headers & costs to use spell badges.")
      else status:SetText("") end
    end)
  elseif key=="badges" then
    p=Page(key,"Colors")
    TextRow(p,"Preview your palette; native warning colors stay unchanged.")
    Toggle(p,"Text outline",nil,function()return DB().badgeTextOutline==true end,function(v)DB().badgeTextOutline=v end)
    Toggle(p,"Text shadow",nil,function()return DB().badgeTextShadow~=false end,function(v)DB().badgeTextShadow=v end)
    TextRow(p,"PREVIEW                         BACKGROUND       TEXT",C.gold)
    local palette={{"instant","Instant"},{"channel","Channel"},{"cast","Cast"},{"cooldown","Cooldown"},
      {"range","Range"},{"Mana","Mana"},{"Rage","Rage"},{"Energy","Energy"},
      {"Focus","Focus"},{"Health","Health"},{"Combo","Combo"},{"Reagent","Reagent"},{"Requirement","Requirement"}}
    for _,pair in ipairs(palette) do Swatch(p,pair[2],pair[1])end
    Link(p,"Restore default colors",function()if MeffortSuiteBadgeThemeReset then MeffortSuiteBadgeThemeReset()end end,"RESET")
  elseif key=="action" then
    p=Page(key,"Bars")
    local bars=MeffortSuiteActionText
    local mana=bars.GetManaAppearance
    Section(p,"Mana cost labels")
    Toggle(p,"Mana cost percentage","Show how much of your maximum mana a spell costs.",
      bars.ManaCostsEnabled,bars.SetManaCostsEnabled)
    Stepper(p,"Mana label size",8,24,1,function()return mana().size end,function(n)bars.SetManaAppearance("size",n)end," px")
    Stepper(p,"Mana horizontal offset",-22,22,1,function()return mana().x end,function(n)bars.SetManaAppearance("x",n)end," px")
    Stepper(p,"Mana vertical offset",-22,22,1,function()return mana().y end,function(n)bars.SetManaAppearance("y",n)end," px")
    Link(p,"Pick mana label color",function()
      if MeffortSuiteShowColorPicker then MeffortSuiteShowColorPicker(mana().hex,function(hex)bars.SetManaAppearance("hex",hex);RefreshUI()end)end
    end,"COLOR")
    Link(p,"Reset mana label appearance",bars.ResetManaAppearance,"RESET")
    Section(p,"Keybind labels")
    if MeffortSuite and MeffortSuite.StandaloneLoaded("MeffortBars") then
      TextRow(p,"Suite keybind styling pauses while MeffortBars is loaded.",C.gold)
    end
    Toggle(p,"Custom keybind labels",nil,function()return Action().enabled end,function(v)Action().enabled=v;ApplyBar()end)
    Stepper(p,"Text size",8,24,1,function()return Action().size end,function(n)Action().size=n;ApplyBar()end," px")
    Stepper(p,"Horizontal offset",-22,22,1,function()return Action().x end,function(n)Action().x=n;ApplyBar()end,"")
    Stepper(p,"Vertical offset",-22,22,1,function()return Action().y end,function(n)Action().y=n;ApplyBar()end,"")
    Toggle(p,"Text outline",nil,function()return Action().outline end,function(v)Action().outline=v;ApplyBar()end)
    Toggle(p,"Text shadow",nil,function()return Action().shadow end,function(v)Action().shadow=v;ApplyBar()end)
    Link(p,"Pick text color",function()
      if MeffortSuiteShowColorPicker then MeffortSuiteShowColorPicker(Action().hex,function(hex)Action().hex=hex;ApplyBar();RefreshUI()end)end
    end,"COLOR")
    Link(p,"Reset appearance",function()MeffortSuiteActionText.ResetAppearance()end,"RESET")
  elseif key=="audio" then
    p=Page(key,"Sounds")
    Section(p,"Pets")
    Toggle(p,"Mute native pet sounds","Use the game's Pet Sounds setting. It can affect combat pets and leave shared footsteps audible.",function()return DB().petSoundsMuted==true end,function(v)if MeffortSuiteSound then MeffortSuiteSound.SetNativeEnabled(v)else DB().petSoundsMuted=v end end)
    local state=TextRow(p,"")
    AddRefresh(p,function()state:SetText(MeffortSuiteSound and MeffortSuiteSound.NativeStatus() or "Sound controls unavailable.")end)
    Link(p,"Advanced sound-file muting",function()OpenPage("soundfiles")end," > ")
    Section(p,"Fishing")
    Toggle(p,"Quiet fishing audio","Mute music, ambience and dialogue while a pole is equipped. Keep sound effects audible.",function()return MeffortSuiteFishingAudio and MeffortSuiteFishingAudio.Enabled() or false end,function(v)if MeffortSuiteFishingAudio then MeffortSuiteFishingAudio.SetEnabled(v)end end)
    Link(p,"Right-click fishing settings",function()OpenPage("fishing")end," > ")
  elseif key=="soundfiles" then
    p=Page(key,"Sounds: Files")
    Toggle(p,"Mute selected sound files","Mute every source that uses the listed sound files.",function()return DB().petSoundFilesEnabled==true end,function(v)if MeffortSuiteSound then MeffortSuiteSound.SetFilesEnabled(v)else DB().petSoundFilesEnabled=v end end)
    Wrapped(p,"Use verified sound-file IDs.")
    Input(p,"Sound-file IDs (comma-separated)",function()return MeffortSuiteSound and MeffortSuiteSound.Files() or ""end,function(value)if MeffortSuiteSound then return MeffortSuiteSound.SetFiles(value)end;return false,"Sound controls unavailable."end,"Save list",500)
    local state=TextRow(p,"")
    AddRefresh(p,function()state:SetText(MeffortSuiteSound and MeffortSuiteSound.FileStatus() or "Sound controls unavailable.")end)
    Link(p,"Pet and fishing sounds",function()OpenPage("audio")end," > ")
  elseif key=="defaults" then
    p=Page(key,"Restore Defaults")
    local feedback
    Link(p,"Restore defaults & reload",function()
      local ok,why=MeffortSuiteDefaults.Restore()
      feedback:SetText(why or (ok and "Reloading to apply defaults." or "Defaults were not changed."))
    end,"RESET",function()
      if not MeffortSuiteDefaults then return false,"Defaults controls unavailable." end
      return MeffortSuiteDefaults.CanRestore()
    end)
    feedback=TextRow(p,"")
    Link(p,"Reload UI",function()local _,why=MeffortSuiteDefaults.Reload();feedback:SetText(why or "")end,"RELOAD",function()
      if not MeffortSuiteDefaults then return false,"Defaults controls unavailable." end
      return MeffortSuiteDefaults.CanReload()
    end)
  elseif key=="help" then
    p=Page(key,"Setup & help")
    Link(p,"Set up the loot tracker and values",function()OpenPage("loot")end," > ")
    Link(p,"Configure quest shortcuts",function()OpenPage("quest")end," > ")
    Link(p,"Set up fishing",function()OpenPage("fishing")end," > ")
    Link(p,"Configure pet and fishing sounds",function()OpenPage("audio")end," > ")
    Link(p,"Manage personal-bank item lists",function()OpenPage("inventory")end," > ")
    Link(p,"Place custom keybind labels",function()OpenPage("action")end," > ")
    Section(p,"Saving and scope")
    Wrapped(p,"Changes save immediately. In text fields, Enter saves and Esc discards.")
    Section(p,"Share a problem with Mefforts")
    Wrapped(p,"Copy the diagnostic report before reloading. Include what you clicked and the NPC or window involved.")
    Link(p,"Open diagnostic report",function()MeffortSuiteExportDiagnostics()end,"OPEN",function()
      return type(MeffortSuiteExportDiagnostics)=="function","Copy before reloading or logging out."
    end)
    Link(p,"Restore Defaults",function()OpenPage("defaults")end," > ")
    Link(p,"About and login message",function()OpenPage("about")end," > ")
  elseif key=="about" then
    p=Page(key,"About")
    TextRow(p,"MeffortSuite "..MeffortSuite.Version,C.gold)
    Toggle(p,"Show login message",nil,function()return DB().showLoginMessage~=false end,function(v)DB().showLoginMessage=v end)
    Link(p,"Restore Defaults",function()OpenPage("defaults")end," > ")
    TextRow(p,"/msuite   Open feature launcher")
    TextRow(p,"/msuite diagnostics   Module status and recent errors")
    Link(p,"Open diagnostic report",function()if MeffortSuiteExportDiagnostics then MeffortSuiteExportDiagnostics()end end,"OPEN")
    TextRow(p,"/msuite distance   Range command")
    TextRow(p,"/msuite arcane   Mage Tracked Buffs settings")
    TextRow(p,"/msuite fishing   Fishing command")
    TextRow(p,"/msuite bank now   Deposit listed items and reagents")
    TextRow(p,"/msuite bank sort on/off   Bank auto-sort")
    TextRow(p,"/msuite flight on/off   Flight master dialogue")
  else return nil end
  return p
end
local names={audio="Sounds",soundfiles="Sounds: Files",defaults="Restore Defaults",loot="Loot",help="Setup & help",overview="MeffortSuite",range="Combat",arcaneblast="Arcane Blast",rangeadvanced="Advanced range",inventory="Bags",quest="Quests",way="Map",tooltips="Tooltips",action="Bars",fishing="Fishing",badges="Colors",about="About"}
local aliases={sounds="audio",sound="audio",looting="loot",support="help",home="overview",combat="range",interface="tooltips",appearance="tooltips",convenience="inventory",distance="range",arcane="arcaneblast",ranged="range",wand="range",shoot="range",throw="range",bags="inventory",quests="quest",dialogue="quest",map="way",bars="action",colors="badges",professions="fishing",profession="fishing"}
local parentPages={rangeadvanced="range",arcaneblast="range",badges="tooltips",soundfiles="audio"}
local function GoBack()
  local previous=table.remove(history)
  if previous then OpenPage(previous.id,true,previous.scroll)
  else OpenPage(parentPages[activePage] or "overview",true,0) end
end
local function HasDrafts()
  for _,dirty in ipairs(inputDrafts) do if dirty() then return true end end
  return false
end
local function FitToScreen()
  if not frame or not frame.SetScale or not UIParent or not UIParent.GetWidth or not UIParent.GetHeight then return end
  local w,h=UIParent:GetWidth(),UIParent:GetHeight()
  if type(w)~="number" or type(h)~="number" or w<=0 or h<=0 then return end
  local widthScale=math.max(.1,math.min(1,(w-24)/frame:GetWidth()))
  local page=pages[activePage]
  if page then frame:SetHeight(math.max(MIN_DETAIL_H,math.min(MAX_DETAIL_H,page.height+96,(h-24)/widthScale))) end
  frame:SetScale(math.max(.1,math.min(widthScale,(h-24)/frame:GetHeight())))
end
RefreshUI=function()
  if not frame then return end
  local on=IsActive()
  masterText:SetText(on and "Suite ON" or "Suite OFF")
  masterText:SetTextColor(on and C.mint[1] or C.red[1],on and C.mint[2] or C.red[2],on and C.mint[3] or C.red[3])
  masterButton.skin.selected=on;masterButton.skin:Paint()
  local resetPending=MeffortSuiteDefaults and MeffortSuiteDefaults.Pending()
  if resetPending then masterButton.button:Disable()else masterButton.button:Enable()end
  local ranged=MeffortSuiteRanged
  local pending=ranged and ranged.Pending and ranged.Pending() and
    type(InCombatLockdown)=="function" and InCombatLockdown()
  statusTitle:SetText(resetPending and "Reload to apply defaults." or pending and "Right-click changes apply after combat." or
    HasDrafts() and "Unsaved text. Enter saves. Esc discards." or
    not on and "Turn Suite on to use your saved settings." or
    (activePage=="overview" and "Choose a category." or "Hover a setting for details."))
  statusTitle:SetTextColor(on and C.gold[1] or C.muted[1],on and C.gold[2] or C.muted[2],on and C.gold[3] or C.muted[3])
  if activePage=="overview" then UpdateHome() end
  local page=pages[activePage]
  if page then for _,fn in ipairs(page.refreshers) do fn()end end
end
OpenPage=function(id,goingBack,scroll)
  if not frame then return end
  id=aliases[id] or id or "overview"
  if id~="overview" and not names[id] then id="overview" end
  local same=id==activePage
  if not same and not goingBack and id~="overview" then
    for i=#history,1,-1 do
      if history[i].id==id then
        scroll=history[i].scroll
        for j=#history,i,-1 do history[j]=nil end
        break
      end
    end
    if not scroll and (#history>0 or parentPages[activePage]~=id) then
      history[#history+1]={id=activePage,scroll=scroller:GetVerticalScroll() or 0}
    end
  end
  local isHome=id=="overview"
  activePage=id
  if isHome then
    history={}
    frame:SetSize(HOME_W,HOME_H)
    headerTitle:SetText("MeffortSuite")
    headerTitle:ClearAllPoints();headerTitle:SetPoint("TOPLEFT",frame,"TOPLEFT",53,-16)
    headerTitle:SetWidth(144)
    logo:Show();infoButton:Show();backButton:Hide();homeButton:Hide()
    scroller:Hide();home:Show();if resetButton then resetButton:Show()end
  else
    local page=pages[id] or Build(id)
    if not page then return OpenPage("overview") end
    frame:SetSize(DETAIL_W,math.max(MIN_DETAIL_H,math.min(MAX_DETAIL_H,page.height+96)))
    headerTitle:SetText(names[id] or "Settings")
    headerTitle:ClearAllPoints();headerTitle:SetPoint("TOPLEFT",frame,"TOPLEFT",135,-16)
    headerTitle:SetWidth(155)
    logo:Hide();infoButton:Show();backButton:Show();homeButton:Show()
    home:Hide();scroller:Show();if resetButton then resetButton:Hide()end
    for key,v in pairs(pages) do if key~=id then v:Hide()end end
    if not same then scroller:SetScrollChild(page) end
    page:Show()
  end
  RefreshUI()
  FitToScreen()
  if not isHome and (scroll or not same) then
    if scroller.UpdateScrollChildRect then scroller:UpdateScrollChildRect() end
    scroller:SetVerticalScroll(scroll or 0)
  end
end
local function CreatePanel()
  if frame then return frame end
  local backdropTemplate=BackdropTemplateMixin and "BackdropTemplate" or nil
  frame=CreateFrame("Frame","MeffortSuiteSettingsV2",UIParent,backdropTemplate)
  frame:SetSize(HOME_W,HOME_H)
  frame:SetPoint("CENTER",UIParent,"CENTER",0,0)
  frame:SetFrameStrata("DIALOG")
  frame:SetClampedToScreen(true)
  frame:EnableMouse(true)
  frame:SetMovable(true)
  frame:RegisterForDrag("LeftButton")
  frame:SetScript("OnDragStart",function(self)self:StartMoving()end)
  frame:SetScript("OnDragStop",function(self)self:StopMovingOrSizing()end)
  WoWBackdrop(frame)
  local hdr=frame:CreateTexture(nil,"ARTWORK")
  hdr:SetPoint("TOPLEFT",frame,"TOPLEFT",11,-7)
  hdr:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-11,-7)
  hdr:SetHeight(40)
  hdr:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Background")
  hdr:SetVertexColor(.55,.42,.21,.89)
  local line=frame:CreateTexture(nil,"ARTWORK")
  line:SetPoint("TOPLEFT",frame,"TOPLEFT",12,-47)
  line:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-12,-47)
  line:SetHeight(1)
  line:SetTexture("Interface\\Buttons\\WHITE8X8")
  line:SetVertexColor(.83,.67,.32,1)
  logo=frame:CreateTexture(nil,"ARTWORK")
  logo:SetTexture("Interface\\AddOns\\MeffortSuite\\Textures\\MeffortSuiteIcon.tga")
  logo:SetPoint("TOPLEFT",frame,"TOPLEFT",15,-12)
  logo:SetSize(29,29)
  headerTitle=Font(frame,"MeffortSuite",16,C.gold)
  headerTitle:SetPoint("TOPLEFT",frame,"TOPLEFT",53,-16)
  headerTitle:SetJustifyH("LEFT")
  if headerTitle.SetWordWrap then headerTitle:SetWordWrap(false) end
  local close=CreateFrame("Button",nil,frame,"UIPanelCloseButton")
  close:SetSize(29,29)
  close:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-10,-11)
  close:SetScript("OnClick",function()frame:Hide()end)
  masterButton=PressButton(frame,"",86,26,function()
    if MeffortSuiteSetMasterEnabled then MeffortSuiteSetMasterEnabled(not IsActive())end
    RefreshUI()
  end)
  masterButton.button:SetPoint("RIGHT",close,"LEFT",-1,0)
  masterText=masterButton.text
  Tips(masterButton.button,"Enable MeffortSuite","Turn the suite on or off. Your settings stay saved.")
  statusTitle=Font(frame,"",11,C.gold)
  statusTitle:SetPoint("TOPLEFT",frame,"TOPLEFT",16,-55)
  statusTitle:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-16,-55)
  statusTitle:SetJustifyH("LEFT")
  infoButton=PressButton(frame,"?",24,24,function()OpenPage("help")end).button
  Tips(infoButton,"Setup & help","Get setup and troubleshooting help.")
  infoButton:SetPoint("RIGHT",masterButton.button,"LEFT",-2,0)
  backButton=PressButton(frame,"< Back",60,25,GoBack).button
  backButton:SetPoint("TOPLEFT",frame,"TOPLEFT",11,-11)
  homeButton=PressButton(frame,"Home",52,25,function()OpenPage("overview")end).button
  homeButton:SetPoint("LEFT",backButton,"RIGHT",3,0)
  Tips(homeButton,"Home","Return to the feature launcher.")
  if frame.GetFrameLevel and backButton.SetFrameLevel then backButton:SetFrameLevel(frame:GetFrameLevel()+9)end
  scroller=CreateFrame("ScrollFrame",nil,frame,"UIPanelScrollFrameTemplate")
  scroller:SetPoint("TOPLEFT",frame,"TOPLEFT",14,-79)
  scroller:SetPoint("BOTTOMRIGHT",frame,"BOTTOMRIGHT",-29,16)
  scroller:Hide()
  BuildHome()
  resetButton=PressButton(frame,"Restore Defaults",150,23,function()OpenPage("defaults")end).button
  resetButton:SetPoint("BOTTOMLEFT",frame,"BOTTOMLEFT",14,10)
  Tips(resetButton,"Restore Defaults","Review which settings will reset.")
  if type(UISpecialFrames)=="table" then
    local found=false
    for _,v in ipairs(UISpecialFrames) do if v=="MeffortSuiteSettingsV2" then found=true;break end end
    if not found then table.insert(UISpecialFrames,"MeffortSuiteSettingsV2")end
  end
  local evt=CreateFrame("Frame",nil,frame)
  evt:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
  evt:RegisterEvent("SPELLS_CHANGED")
  for _,event in ipairs({"PLAYER_REGEN_ENABLED","PLAYER_REGEN_DISABLED","BANKFRAME_OPENED","BANKFRAME_CLOSED","MERCHANT_SHOW","MERCHANT_CLOSED","TRADE_SKILL_SHOW","TRADE_SKILL_CLOSE","UI_SCALE_CHANGED","DISPLAY_SIZE_CHANGED"}) do
    pcall(evt.RegisterEvent,evt,event)
  end
  local refreshQueued=false
  evt:SetScript("OnEvent",function()
    if frame and frame:IsShown() then
      RefreshUI();FitToScreen()
      -- Modules may receive the same event after the settings frame does.
      if not refreshQueued and C_Timer and C_Timer.After then
        refreshQueued=true
        C_Timer.After(0,function()
          refreshQueued=false
          if frame and frame:IsShown() then RefreshUI();FitToScreen() end
        end)
      end
    end
  end)
  frame:Hide()
  return frame
end
function UI.Open(id)
  local win=CreatePanel()
  local fresh=not win:IsShown()
  if fresh then history={};activePage="overview" end
  win:Show()
  OpenPage(id or "overview",fresh)
end
function UI.Hide()if frame then frame:Hide()end end
function UI.Refresh()RefreshUI()end
function UI.HasUnsavedChanges()return HasDrafts()end
function UI.CurrentPage()return activePage end
function MeffortSuiteOpenSettings(page)UI.Open(page or "overview")end
function MeffortSuiteShowMainSettings()UI.Open(activePage=="action" and "action" or "overview")end
function MeffortSuiteHideMainSettings()UI.Hide()end

local function CreateOptionsPage()
  local panel=CreateFrame("Frame",nil,UIParent)
  panel.name="MeffortSuite"
  panel:Hide()
  local title=Font(panel,"MeffortSuite",20,C.gold)
  title:SetPoint("TOPLEFT",panel,"TOPLEFT",16,-16)
  local version=Font(panel,"Version "..tostring(MeffortSuite and MeffortSuite.Version or ""),12,C.muted)
  version:SetPoint("TOPLEFT",title,"BOTTOMLEFT",0,-8)
  local open=PressButton(panel,"Open MeffortSuite",200,26,function()
    if SettingsPanel and SettingsPanel:IsShown() and type(SettingsPanel.Close)=="function" then
      SettingsPanel:Close(true)
      if SettingsPanel:IsShown() then return end
    elseif InterfaceOptionsFrame and InterfaceOptionsFrame:IsShown() and type(HideUIPanel)=="function" then
      HideUIPanel(InterfaceOptionsFrame)
    end
    UI.Open("overview")
  end).button
  open:SetPoint("TOPLEFT",panel,"TOPLEFT",16,-72)
  local check=CreateFrame("CheckButton",nil,panel,"UICheckButtonTemplate")
  check:SetSize(29,29)
  check:SetPoint("TOPLEFT",panel,"TOPLEFT",12,-114)
  local label=Font(panel,"Show login message",12,C.white)
  label:SetPoint("LEFT",check,"RIGHT",3,0)
  local detail=Font(panel,"Show a message at login and after reload.",12,C.muted)
  detail:SetPoint("TOPLEFT",panel,"TOPLEFT",16,-198)
  detail:SetPoint("TOPRIGHT",panel,"TOPRIGHT",-16,-198)
  detail:SetJustifyH("LEFT")
  check:SetScript("OnClick",function(self)DB().showLoginMessage=self:GetChecked() and true or false end)
  panel:SetScript("OnShow",function()check:SetChecked(DB().showLoginMessage~=false)end)
  return panel
end

local optionsRegistered=false
local optionsEvents=CreateFrame("Frame")
optionsEvents:RegisterEvent("ADDON_LOADED")
optionsEvents:RegisterEvent("PLAYER_LOGIN")
optionsEvents:SetScript("OnEvent",function(self)
  if optionsRegistered then return end
  if Settings and type(Settings.RegisterCanvasLayoutCategory)=="function" and type(Settings.RegisterAddOnCategory)=="function" then
    local panel=CreateOptionsPage()
    local category=Settings.RegisterCanvasLayoutCategory(panel,"MeffortSuite")
    Settings.RegisterAddOnCategory(category)
  elseif type(InterfaceOptions_AddCategory)=="function" then
    InterfaceOptions_AddCategory(CreateOptionsPage())
  else return end
  optionsRegistered=true
  self:UnregisterEvent("ADDON_LOADED")
  self:UnregisterEvent("PLAYER_LOGIN")
end)
