local ADDON = ...
MeffortSuite = MeffortSuite or {}
local suite = MeffortSuite
suite.Version = "1.1.4"

function suite.StandaloneLoaded(name)
    if C_AddOns and type(C_AddOns.IsAddOnLoaded)=="function" then
        local ok, loaded=pcall(C_AddOns.IsAddOnLoaded,name)
        if ok then return loaded==true end
    end
    if type(IsAddOnLoaded)=="function" then
        local ok, loaded=pcall(IsAddOnLoaded,name)
        if ok then return loaded==true end
    end
    return false
end

function suite.Active()
    return type(MeffortSuiteDB)~="table" or MeffortSuiteDB.masterEnabled~=false
end

function suite.Message(text)
    print("|cff60d9bdMeffortSuite|r: "..text)
end

local function Secret(value)
    if type(issecretvalue)~="function" then return false end
    local ok,result=pcall(issecretvalue,value)
    return not ok or result==true
end
local function Clean(value,fallback,limit)
    if Secret(value) then return fallback or "restricted value" end
    if type(value)=="number" and value==value and value~=math.huge and value~=-math.huge then value=tostring(value) end
    if type(value)~="string" then return fallback or "unavailable" end
    return value:gsub("|c%x%x%x%x%x%x%x%x",""):gsub("|r",""):gsub("[\r\n%z]"," "):sub(1,limit or 180)
end
local function State(frame)
    if not frame then return "closed" end
    local fn=frame.IsVisible or frame.IsShown
    if type(fn)~="function" then return "unknown" end
    local ok,value=pcall(fn,frame)
    if not ok or Secret(value) then return "unknown" end
    return (value==true or value==1) and "open" or "closed"
end
local actions,actionCount,actionNotice={},0,false
local function ActionContext()
    local combat="unknown"
    if type(InCombatLockdown)=="function" then
        local ok,value=pcall(InCombatLockdown)
        if ok and not Secret(value) then combat=value and "yes" or "no" end
    end
    return "combat "..combat.."; dialogue "..State(GossipFrame).."; quest "..State(QuestFrame)..
        "; bank "..State(BankFrame).."; professions "..State(ProfessionsFrame or TradeSkillFrame)
end
local function RecordAction(event,source,action)
    source,action=Clean(source,"not reported",80),Clean(action,"not reported")
    local context=ActionContext()
    local key=event.."|"..source.."|"..action.."|"..context
    actionCount=actionCount+1
    local latest=actions[#actions]
    if latest and latest.key==key then latest.count=latest.count+1
    else
        actions[#actions+1]={event=event,source=source,action=action,context=context,key=key,count=1}
        if #actions>16 then table.remove(actions,1) end
    end
    if not actionNotice and (source=="MeffortSuite" or source=="MeffortWand" or event=="UI_ERROR_MESSAGE") then
        actionNotice=true
        suite.Message("A blocked interface action was recorded. Use /msuite export to copy the diagnostic report before reloading.")
    end
end
local function LockedOut(errorType,message)
    if Secret(errorType) or Secret(message) then return false end
    if type(LE_GAME_ERR_CLIENT_LOCKED_OUT)=="number" and errorType==LE_GAME_ERR_CLIENT_LOCKED_OUT then return true end
    if type(ERR_CLIENT_LOCKED_OUT)=="string" and type(message)=="string" then return message==ERR_CLIENT_LOCKED_OUT end
    if type(errorType)=="number" and type(GetGameMessageInfo)=="function" then
        local ok,name=pcall(GetGameMessageInfo,errorType)
        if ok and not Secret(name) then return name=="ERR_CLIENT_LOCKED_OUT" end
    end
    return false
end

local errors = {}
function suite.ReportError(module, operation, detail)
    if Secret(detail) then detail="restricted value" end
    module,operation,detail=Clean(module,"module",60),Clean(operation,"operation",80),Clean(detail,"operation failed")
    local key=module..":"..operation..":"..detail
    local latest=errors[#errors]
    if latest and latest.key==key then latest.count=latest.count+1;return end
    errors[#errors+1]={key=key,module=module,operation=operation,detail=detail,count=1}
    if #errors>8 then table.remove(errors,1) end
end
function suite.DiagnosticLines()
    local lines={}
    local function Line(text)lines[#lines+1]=text end
    local version=type(GetBuildInfo)=="function" and select(4,GetBuildInfo()) or "unknown"
    local locale=type(GetLocale)=="function" and GetLocale() or "unknown"
    Line("Version "..suite.Version.."; interface "..tostring(version).."; locale "..tostring(locale).."; suite "..(suite.Active() and "enabled" or "disabled")..".")
    if type(MeffortSuiteTooltipStatus)=="function" then
        local ok,t=pcall(MeffortSuiteTooltipStatus)
        if ok and not Secret(t) and type(t)=="table" then
            Line("Tooltips: API "..(t.available and "available" or "unavailable")..", mode "..Clean(t.mode)..", English support "..(t.localeSupported and "yes" or "no")..", errors "..Clean(t.errors).."; "..Clean(t.lastResult)..".")
        else
            suite.ReportError("tooltips","diagnostics",t)
            Line("Tooltip diagnostics are unavailable.")
        end
    end
    if MeffortSuiteQuestSpace and type(MeffortSuiteQuestSpace.InlineStatus)=="function" then
        local ok,q=pcall(MeffortSuiteQuestSpace.InlineStatus)
        if ok and type(q)=="table" then
            local state=q.configured and "enabled" or (q.standalone and "standalone owns hotkeys" or "disabled")
            Line("Quest keys: "..state.."; choices "..tostring(q.choices or 0)..
                "; native rows "..tostring(q.discovered or 0).."; matched "..tostring(q.matched or 0)..
                "; labels "..tostring(q.shown or 0).."; visible "..tostring(q.visible or 0)..
                "; positioned "..tostring(q.positioned or 0).."; duplicates "..tostring(q.duplicates or 0)..
                "; unpositioned rows "..tostring(q.unpositioned or 0).."; layout "..tostring(q.layout or "unknown")..
                "; "..tostring(q.render or "not inspected").."; fallbacks "..tostring(q.fallbacks or 0)..
                "; "..tostring(q.reason or "not inspected")..
                (q.skipReason and ("; skipped: "..tostring(q.skipReason)) or "")..
                (q.measurementReason and ("; measurement: "..tostring(q.measurementReason)) or "")..".")
        elseif not ok then suite.ReportError("quests","label diagnostics",q) end
    end
    if actionCount>0 then
        Line("Blocked interface events: "..actionCount.."; recent entries "..#actions..".")
        for _,entry in ipairs(actions) do
            Line(entry.event.."; reported source "..entry.source.."; action "..entry.action..
                "; "..entry.context..(entry.count>1 and ("; repeated "..entry.count.." times") or "")..".")
        end
    end
    if #errors==0 then Line("No Lua errors recorded in this session.") end
    for _,e in ipairs(errors) do
        Line(e.module.." / "..e.operation..": "..e.detail..(e.count>1 and (" ("..e.count.." times)") or ""))
    end
    return lines
end
function suite.Diagnostics()
    for _,line in ipairs(suite.DiagnosticLines()) do suite.Message(line) end
end
function suite.DiagnosticReport()
    local lines={"MeffortSuite diagnostic report","Events recorded since the last UI reload.",""}
    for _,line in ipairs(suite.DiagnosticLines()) do lines[#lines+1]=line end
    if actionCount==0 then lines[#lines+1]="No blocked interface events recorded in this session." end
    local db=type(MeffortSuiteDB)=="table" and MeffortSuiteDB or {}
    local char=type(MeffortSuiteCharDB)=="table" and MeffortSuiteCharDB or {}
    lines[#lines+1]=""
    lines[#lines+1]="Preferences: quest shortcuts "..(db.questSpace==false and "off" or "on")..
        "; single-option services "..(db.autoOpenSingleService==false and "off" or "on")..
        "; ranged mode "..Clean(char.rangedMode,"default").."."
    lines[#lines+1]="Standalone MeffortWand loaded: "..(suite.StandaloneLoaded("MeffortWand") and "yes" or "no").."."
    lines[#lines+1]=""
    lines[#lines+1]="Reported sources are supplied by the client; they do not identify every step in a taint chain."
    lines[#lines+1]="Keep this report when reviewing interface problems. Reloading clears the recorded events."
    return table.concat(lines,"\n")
end
local function Help()
    suite.Message("/msuite opens settings. /msuite on | off controls the suite without resetting preferences.")
    suite.Message("Tools: way, ranged, distance, arcane, fishing, professions, enchant, bank, flight, services.")
    suite.Message("/msuite vendor [retry] checks merchant actions; /msuite diagnostics shows recent errors; /msuite export opens a copyable report.")
end

SLASH_MEFFORTSUITE1="/meffortsuite"
SLASH_MEFFORTSUITE2="/meffsuite"
SLASH_MEFFORTSUITE3="/msuite"
SLASH_MEFFORTSUITE4="/mfsuite"
SlashCmdList.MEFFORTSUITE=function(line)
    local command=(line or ""):lower():match("^%s*(.-)%s*$")
    local action,args=command:match("^(%S+)%s*(.-)$")
    if command=="" or command=="settings" then
        if MeffortSuiteOpenSettings then MeffortSuiteOpenSettings() end
    elseif command=="on" or command=="off" then
        if MeffortSuiteSetMasterEnabled then MeffortSuiteSetMasterEnabled(command=="on") end
    elseif command=="252" then
        if MeffortSuiteWay then MeffortSuiteWay.ToggleTreecko() end
    elseif action=="way" or action=="waypoint" then
        if MeffortSuiteWay then MeffortSuiteWay.Command(args) end
    elseif action=="wand" or action=="ranged" or action=="shoot" or action=="throw" then
        if MeffortSuiteRanged then MeffortSuiteRanged.Command(action,args) end
    elseif action=="distance" or action=="dist" then
        if MeffortSuiteTargetDistance then MeffortSuiteTargetDistance.Command(args) end
    elseif action=="arcane" or action=="arcaneblast" then
        if MeffortSuiteOpenSettings then MeffortSuiteOpenSettings("arcaneblast") end
    elseif action=="fishing" or action=="fish" then
        if MeffortSuiteFishing then MeffortSuiteFishing.Command(args) end
    elseif action=="enchant" or action=="enchanting" or action=="eq" then
        if MeffortSuiteEnchantQueue then MeffortSuiteEnchantQueue.Toggle() end
    elseif action=="professions" then
        if MeffortSuiteOpenSettings then MeffortSuiteOpenSettings("fishing") end
    elseif action=="bank" then
        if MeffortSuiteBank then MeffortSuiteBank.Command(args) end
    elseif action=="flight" or action=="taxi" then
        if MeffortSuiteFlightMasters then MeffortSuiteFlightMasters.Command(args) end
    elseif action=="services" or action=="service" or action=="gossip" then
        if MeffortSuiteGossipServices then MeffortSuiteGossipServices.Command(args) end
    elseif action=="vendor" or action=="merchant" then
        if MeffortSuiteInventory and MeffortSuiteInventory.VendorStatus then
            MeffortSuiteInventory.VendorStatus(args=="retry")
        end
    elseif command=="export" or command=="report" then
        if type(MeffortSuiteExportDiagnostics)=="function" then MeffortSuiteExportDiagnostics()
        else suite.Message("The report window is unavailable. Use /msuite diagnostics to review this session in chat.") end
    elseif command=="diagnostics" or command=="debug" then
        suite.Diagnostics()
    elseif command=="help" or command=="status" then
        suite.Message("Suite "..(suite.Active() and "ON" or "OFF").."; standalone MeffortWand takes priority when enabled.")
        Help()
    else
        Help()
    end
end

local newInstall, newCharacter = false, false
local function CopyTable(value, seen)
    if type(value)~="table" then return value end
    seen=seen or {}
    if seen[value] then return seen[value] end
    local copied={};seen[value]=copied
    for k,v in pairs(value) do copied[k]=CopyTable(v,seen) end
    return copied
end
local function NormalizeSettings()
    if type(MeffortSuiteDB)~="table" then MeffortSuiteDB={} end
    if type(MeffortSuiteCharDB)~="table" then MeffortSuiteCharDB={} end
    local db,char=MeffortSuiteDB,MeffortSuiteCharDB
    for _,key in ipairs({"masterEnabled","enabled","style","badges","rankHint","questSpace",
        "badgeTextOutline","badgeTextShadow","wayEnabled","autoSortBags","autoSellJunk",
        "autoRepair","autoBankCrafting","autoSortBank","autoOpenOrgBank","autoOpenFlightMaster",
        "autoOpenSingleService"}) do
        if db[key]~=nil and type(db[key])~="boolean" then db[key]=nil end
    end
    for _,key in ipairs({"colors","textColors","actionText"}) do
        if db[key]~=nil and type(db[key])~="table" then db[key]=nil end
    end
    local action=db.actionText
    if type(action)=="table" then
        local function Number(value,fallback,lo,hi)
            value=tonumber(value)
            if not value or value~=value or value==math.huge or value==-math.huge then return fallback end
            return math.max(lo,math.min(hi,value))
        end
        action.size=Number(action.size,18,8,24)
        action.x=Number(action.x,0,-22,22)
        action.y=Number(action.y,0,-22,22)
        for _,key in ipairs({"enabled","outline","shadow"}) do
            if action[key]~=nil and type(action[key])~="boolean" then action[key]=nil end
        end
        if type(action.hex)~="string" or not action.hex:match("^%x%x%x%x%x%x$") then action.hex="fff0c2" end
    end
    for _,name in ipairs({"targetDistance","arcaneBlast"}) do
        local options=char[name]
        if type(options)=="table" then
            for _,key in ipairs({"enabled","locked","stacks","timer","wheel"}) do
                if options[key]~=nil and type(options[key])~="boolean" then options[key]=nil end
            end
        end
    end
    if db.tooltipMode~="compare" then db.tooltipMode="replace" end
    if char.bankDepositExclusions~=nil and type(char.bankDepositExclusions)~="string" then char.bankDepositExclusions="" end
    if char.bankDepositInclusions~=nil and type(char.bankDepositInclusions)~="string" then char.bankDepositInclusions="" end
    db.schemaVersion=2
end

local frame=CreateFrame("Frame")
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("PLAYER_LOGIN")
for _,event in ipairs({"ADDON_ACTION_BLOCKED","ADDON_ACTION_FORBIDDEN","MACRO_ACTION_BLOCKED","MACRO_ACTION_FORBIDDEN","UI_ERROR_MESSAGE"}) do
    pcall(frame.RegisterEvent,frame,event)
end
frame:SetScript("OnEvent",function(_,event,name,action)
    if event=="ADDON_ACTION_BLOCKED" or event=="ADDON_ACTION_FORBIDDEN" then
        RecordAction(event,name,action);return
    elseif event=="MACRO_ACTION_BLOCKED" or event=="MACRO_ACTION_FORBIDDEN" then
        RecordAction(event,"macro",name);return
    elseif event=="UI_ERROR_MESSAGE" then
        if LockedOut(name,action) then RecordAction(event,"not reported",action) end
        return
    end
    if event=="ADDON_LOADED" and name==ADDON then
        if type(MeffortSuiteDB)~="table" then MeffortSuiteDB={} end
        if type(MeffortSuiteCharDB)~="table" then MeffortSuiteCharDB={} end
        newInstall=MeffortSuiteDB.initialized~=true
        newCharacter=MeffortSuiteCharDB.initialized~=true
        NormalizeSettings()
    elseif event=="PLAYER_LOGIN" then
        if newInstall and type(MeffortBarsDB)=="table" then
            local keys={"enabled","style","badges","rankHint","questSpace",
                "badgeTextOutline","badgeTextShadow","colors","textColors","actionText"}
            for _,key in ipairs(keys) do
                if MeffortSuiteDB[key]==nil and MeffortBarsDB[key]~=nil then
                    MeffortSuiteDB[key]=CopyTable(MeffortBarsDB[key])
                end
            end
        end
        if newInstall and type(MeffortWayDB)=="table" and MeffortSuiteDB.wayTheme==nil then
            MeffortSuiteDB.wayTheme=MeffortWayDB.theme
        end
        if newCharacter and type(MeffortWandDB)=="table" and MeffortSuiteCharDB.rangedMode==nil then
            local class=type(UnitClass)=="function" and select(2,UnitClass("player")) or nil
            if class=="MAGE" or class=="PRIEST" or class=="WARLOCK" then
                MeffortSuiteCharDB.rangedMode=MeffortWandDB.mode
            end
        end
        NormalizeSettings()
        MeffortSuiteDB.initialized=true
        MeffortSuiteCharDB.initialized=true
        if newInstall then suite.Message("Use /msuite to configure your tools. Settings are retained across reloads.") end
        newInstall,newCharacter=false,false
    end
    if event=="PLAYER_LOGIN" and type(MeffortSuiteDB)=="table" then
        if MeffortSuiteDB.wayEnabled==nil then MeffortSuiteDB.wayEnabled=true end
        if MeffortSuiteDB.wayTheme~="treecko" then MeffortSuiteDB.wayTheme="teal" end
    end
end)
