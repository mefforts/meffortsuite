local ADDON = ...
MeffortSuite = MeffortSuite or {}
local suite = MeffortSuite
suite.Version = "1.1.8"

function suite.StandaloneLoaded(name)
    if C_AddOns and type(C_AddOns.IsAddOnLoaded)=="function" then
        local ok, loaded=pcall(C_AddOns.IsAddOnLoaded,name)
        if ok then return loaded==true end
    end
    if type(IsAddOnLoaded)=="function" then
        local ok, loaded=pcall(IsAddOnLoaded,name)
        if ok then return loaded==true end
    end
    return false
end

function suite.Active()
    return type(MeffortSuiteDB)~="table" or MeffortSuiteDB.masterEnabled~=false
end

function suite.Message(text)
    print("|cff60d9bdMeffortSuite|r: "..text)
end

local function Secret(value)
    if type(issecretvalue)~="function" then return false end
    local ok,result=pcall(issecretvalue,value)
    return not ok or result==true
end
local function Clean(value,fallback,limit)
    if Secret(value) then return fallback or "restricted value" end
    if type(value)=="number" and value==value and value~=math.huge and value~=-math.huge then value=tostring(value) end
    if type(value)~="string" then return fallback or "unavailable" end
    return value:gsub("|c%x%x%x%x%x%x%x%x",""):gsub("|r",""):gsub("[\r\n%z]"," "):sub(1,limit or 180)
end
local function State(frame)
    if not frame then return "closed" end
    local fn=frame.IsVisible or frame.IsShown
    if type(fn)~="function" then return "unknown" end
    local ok,value=pcall(fn,frame)
    if not ok or Secret(value) then return "unknown" end
    return (value==true or value==1) and "open" or "closed"
end
local actions,actionCount,actionNotice={},0,false
local activeClientCall
local suspendedClientCalls={}
local recentClientCalls={}
local function SessionTime()
    if type(GetTime)~="function" then return end
    local ok,value=pcall(GetTime)
    if ok and not Secret(value) and type(value)=="number" and value==value
        and value~=math.huge and value~=-math.huge then return value end
end
local function CombatState()
    if type(InCombatLockdown)~="function" then return "unknown" end
    local ok,value=pcall(InCombatLockdown)
    if not ok or Secret(value) then return "unknown" end
    return value and "combat" or "outside combat"
end
function suite.TryClientCall(module,operation,fn,...)
    if type(fn)~="function" then return false end
    local label=Clean(module,"module",60).." / "..Clean(operation,"operation",80)
    local state=CombatState()
    local key=label.." / "..state
    if suspendedClientCalls[key] then return false end
    local latest=recentClientCalls[#recentClientCalls]
    if latest and latest.key==key then latest.at=SessionTime()
    else
        recentClientCalls[#recentClientCalls+1]={key=key,at=SessionTime()}
        if #recentClientCalls>8 then table.remove(recentClientCalls,1) end
    end
    local previous=activeClientCall
    local scope={label=label,key=key}
    activeClientCall=scope
    local ok,value=pcall(fn,...)
    activeClientCall=previous
    if scope.blocked then return false end
    return ok,value
end
local function NearbyClientCalls()
    local now=SessionTime()
    local result={}
    for i=#recentClientCalls,math.max(1,#recentClientCalls-2),-1 do
        local entry=recentClientCalls[i]
        local age=now and entry.at and math.max(0,now-entry.at)
        if age and age<=1 then
            result[#result+1]=entry.key..string.format("; %.2fs before event",age)
        end
    end
    if #result>0 then return result end
end
local function CaptureActionStack()
    if type(debugstack)~="function" then return end
    local ok,value=pcall(debugstack,3,10,0)
    if not ok or Secret(value) or type(value)~="string" then return end
    local lines={}
    for line in value:sub(1,3000):gmatch("[^\r\n]+") do
        lines[#lines+1]=Clean(line,"unavailable",180)
        if #lines>=6 then break end
    end
    if #lines>0 then return lines end
end
local function ActionContext()
    local combat="unknown"
    if type(InCombatLockdown)=="function" then
        local ok,value=pcall(InCombatLockdown)
        if ok and not Secret(value) then combat=value and "yes" or "no" end
    end
    return "combat "..combat.."; dialogue "..State(GossipFrame).."; quest "..State(QuestFrame)..
        "; bank "..State(BankFrame).."; professions "..State(ProfessionsFrame or TradeSkillFrame)
end
local function RecordAction(event,source,action)
    source,action=Clean(source,"not reported",80),Clean(action,"not reported")
    local operation
    if activeClientCall then
        operation=activeClientCall.label
        activeClientCall.blocked=true
        suspendedClientCalls[activeClientCall.key]=true
    end
    local context=ActionContext()
    local key=event.."|"..source.."|"..action.."|"..context.."|"..(operation or "")
    actionCount=actionCount+1
    local latest=actions[#actions]
    if latest and latest.key==key then latest.count=latest.count+1
    else
        actions[#actions+1]={event=event,source=source,action=action,context=context,key=key,count=1,
            operation=operation,stack=CaptureActionStack(),nearby=not operation and NearbyClientCalls() or nil}
        if #actions>16 then table.remove(actions,1) end
    end
    if not actionNotice and (source=="MeffortSuite" or source=="MeffortWand" or operation or event=="UI_ERROR_MESSAGE") then
        actionNotice=true
        suite.Message("A blocked interface action was recorded. Export the log before reloading or logging out:\n"..
            "1. Type /msuite export to open the report.\n"..
            "2. Click Select report, then press Ctrl+C (Command+C on Mac).\n"..
            "3. Switch out of the game and paste it into your bug report to Mefforts with Ctrl+V (Command+V on Mac). "..
            "Include what you clicked or pressed and the NPC or window involved.")
    end
end
local function LockedOut(errorType,message)
    if Secret(errorType) or Secret(message) then return false end
    if type(LE_GAME_ERR_CLIENT_LOCKED_OUT)=="number" and errorType==LE_GAME_ERR_CLIENT_LOCKED_OUT then return true end
    if type(ERR_CLIENT_LOCKED_OUT)=="string" and type(message)=="string" then return message==ERR_CLIENT_LOCKED_OUT end
    if type(errorType)=="number" and type(GetGameMessageInfo)=="function" then
        local ok,name=pcall(GetGameMessageInfo,errorType)
        if ok and not Secret(name) then return name=="ERR_CLIENT_LOCKED_OUT" end
    end
    return false
end

local errors = {}
function suite.ReportError(module, operation, detail)
    if Secret(detail) then detail="restricted value" end
    module,operation,detail=Clean(module,"module",60),Clean(operation,"operation",80),Clean(detail,"operation failed")
    local key=module..":"..operation..":"..detail
    local latest=errors[#errors]
    if latest and latest.key==key then latest.count=latest.count+1;return end
    errors[#errors+1]={key=key,module=module,operation=operation,detail=detail,count=1}
    if #errors>8 then table.remove(errors,1) end
end
function suite.DiagnosticLines()
    local lines={}
    local function Line(text)lines[#lines+1]=text end
    local _,_,_,_,version=pcall(GetBuildInfo)
    local okLocale,locale=pcall(GetLocale)
    Line("Version "..suite.Version.."; interface "..Clean(version,"unknown").."; locale "..(okLocale and Clean(locale,"unknown") or "unknown")..
        "; suite "..(suite.Active() and "enabled" or "disabled")..".")
    if MeffortSuiteLootValue and type(MeffortSuiteLootValue.Status)=="function" then
        local ok,status=pcall(MeffortSuiteLootValue.Status)
        if ok and type(status)=="string" and not Secret(status) then Line("Loot value: "..Clean(status,"unavailable",320)..".") end
    end
    if MeffortSuiteMageScrolls and MeffortSuiteMageScrolls.Enabled() then
        Line("Mage scrolls: "..MeffortSuiteMageScrolls.Status()..".")
    end
    if MeffortSuiteFastLoot and type(MeffortSuiteFastLoot.Status)=="function" then
        local ok,status=pcall(MeffortSuiteFastLoot.Status)
        if ok and type(status)=="string" and not Secret(status) then Line("Fast loot: "..Clean(status,"unavailable",180)..".") end
    end
    if MeffortSuiteBackpack and type(MeffortSuiteBackpack.Status)=="function" then
        local ok,status=pcall(MeffortSuiteBackpack.Status)
        if ok and type(status)=="string" and not Secret(status) then Line("Backpack count: "..Clean(status,"unavailable",180)..".") end
    end
    if MeffortSuiteFishingAudio and type(MeffortSuiteFishingAudio.Status)=="function" then
        local ok,status=pcall(MeffortSuiteFishingAudio.Status)
        if ok and type(status)=="string" and not Secret(status) then Line("Fishing audio: "..Clean(status,"unavailable",200)..".") end
    end
    if MeffortSuiteFishingCamera and MeffortSuiteFishingCamera.Status then
        local ok,status=pcall(MeffortSuiteFishingCamera.Status)
        if ok and type(status)=="string" and not Secret(status) then Line("Fishing camera: "..Clean(status,"unavailable",180)..".") end
    end
    if MeffortSuiteSound and type(MeffortSuiteSound.Status)=="function" then
        local ok,status=pcall(MeffortSuiteSound.Status)
        if ok and type(status)=="string" and not Secret(status) then Line("Sound: "..Clean(status,"unavailable",240)..".") end
    end
    if type(MeffortSuiteTooltipStatus)=="function" then
        local ok,t=pcall(MeffortSuiteTooltipStatus)
        if ok and not Secret(t) and type(t)=="table" then
            Line("Tooltips: API "..(t.available and "available" or "unavailable")..", English support "..(t.localeSupported and "yes" or "no")..", errors "..Clean(t.errors).."; "..Clean(t.lastResult)..".")
        else
            suite.ReportError("tooltips","diagnostics",t)
            Line("Tooltip diagnostics are unavailable.")
        end
    end
    if MeffortSuiteQuestSpace and type(MeffortSuiteQuestSpace.InlineStatus)=="function" then
        local ok,q=pcall(MeffortSuiteQuestSpace.InlineStatus)
        if ok and type(q)=="table" then
            local state=q.configured and "enabled" or (q.standalone and "standalone owns hotkeys" or "disabled")
            Line("Quest keys: "..state.."; Space confirmations "..(q.confirmations and "on" or "off").."; choices "..tostring(q.choices or 0)..
                "; native rows "..tostring(q.discovered or 0).."; matched "..tostring(q.matched or 0)..
                "; labels "..tostring(q.shown or 0).."; visible "..tostring(q.visible or 0)..
                "; positioned "..tostring(q.positioned or 0).."; duplicates "..tostring(q.duplicates or 0)..
                "; unpositioned rows "..tostring(q.unpositioned or 0).."; layout "..tostring(q.layout or "unknown")..
                "; "..tostring(q.render or "not inspected").."; fallbacks "..tostring(q.fallbacks or 0)..
                "; "..tostring(q.reason or "not inspected")..
                (q.skipReason and ("; skipped: "..tostring(q.skipReason)) or "")..
                (q.measurementReason and ("; measurement: "..tostring(q.measurementReason)) or "")..".")
        elseif not ok then suite.ReportError("quests","label diagnostics",q) end
    end
    if actionCount>0 then
        Line("Blocked interface events: "..actionCount.."; recent entries "..#actions..".")
        for _,entry in ipairs(actions) do
            Line(entry.event.."; reported source "..entry.source.."; action "..entry.action..
                "; "..entry.context..(entry.count>1 and ("; repeated "..entry.count.." times") or "")..".")
            if entry.operation then Line("Suite call at event: "..entry.operation..".") end
            if entry.nearby then
                Line("Nearby Suite calls (correlation only):")
                for _,part in ipairs(entry.nearby) do Line("  "..part) end
            end
            if entry.stack then
                Line("Lua stack at event:")
                for _,part in ipairs(entry.stack) do Line("  "..part) end
            end
        end
    end
    local suspended={}
    for key in pairs(suspendedClientCalls) do suspended[#suspended+1]=key end
    table.sort(suspended)
    for _,key in ipairs(suspended) do Line("Client call paused until UI reload: "..key..".") end
    if #errors==0 then Line("No Lua errors recorded in this session.") end
    for _,e in ipairs(errors) do
        Line(e.module.." / "..e.operation..": "..e.detail..(e.count>1 and (" ("..e.count.." times)") or ""))
    end
    return lines
end
function suite.Diagnostics()
    for _,line in ipairs(suite.DiagnosticLines()) do suite.Message(line) end
end
function suite.DiagnosticReport()
    local lines={"MeffortSuite diagnostic report","Events recorded since the last UI reload.",""}
    for _,line in ipairs(suite.DiagnosticLines()) do lines[#lines+1]=line end
    if actionCount==0 then lines[#lines+1]="No blocked interface events recorded in this session." end
    local db=type(MeffortSuiteDB)=="table" and MeffortSuiteDB or {}
    local char=type(MeffortSuiteCharDB)=="table" and MeffortSuiteCharDB or {}
    lines[#lines+1]=""
    lines[#lines+1]="Preferences: quest shortcuts "..(db.questSpace==false and "off" or "on")..
        "; ranged mode "..Clean(char.rangedMode,"default").."."
    local range=type(char.targetDistance)=="table" and char.targetDistance or {}
    lines[#lines+1]="Target range warning: "..(range.enabled==true and "on" or "off").."."
    if MeffortSuiteRanged and type(MeffortSuiteRanged.RuntimeStatus)=="function" then
        local ok,status=pcall(MeffortSuiteRanged.RuntimeStatus)
        if ok and not Secret(status) and type(status)=="string" then lines[#lines+1]="Ranged input: "..Clean(status,"unavailable",240).."." end
    end
    lines[#lines+1]="Standalone MeffortWand loaded: "..(suite.StandaloneLoaded("MeffortWand") and "yes" or "no").."."
    lines[#lines+1]=""
    lines[#lines+1]="Reported sources are supplied by the client; they do not identify every step in a taint chain."
    lines[#lines+1]="Captured calls and stacks describe event-time activity, not necessarily the original taint source."
    lines[#lines+1]="Share this report with Mefforts and describe what you clicked or pressed, the NPC or window involved, and whether the issue repeats."
    lines[#lines+1]="Reloading or logging out clears the recorded events. Export before doing either."
    return table.concat(lines,"\n")
end
local function Help()
    suite.Message("Use /msuite to open settings or /msuite help for setup guidance.")
    suite.Message("Type /msuite followed by Bags, Loot, Quests, Combat, Map, Tooltips, Bars, Sounds, or About to open that page.")
    suite.Message("Open fishing settings with /msuite fishing settings.")
    suite.Message("Use /msuite on or /msuite off to control the suite and keep your saved settings. Review a reset with /msuite defaults.")
    suite.Message("Use /msuite diagnostics for status or /msuite export to copy a report.")
end

local settingsPages={
    sounds="audio",audio="audio",defaults="defaults",loot="loot",quests="quest",
    bags="inventory",combat="range",map="way",tooltips="tooltips",bars="action",about="about",
}
SLASH_MEFFORTSUITE1="/meffortsuite"
SLASH_MEFFORTSUITE2="/meffsuite"
SLASH_MEFFORTSUITE3="/msuite"
SLASH_MEFFORTSUITE4="/mfsuite"
SlashCmdList.MEFFORTSUITE=function(line)
    local input=(line or ""):match("^%s*(.-)%s*$")
    local command=input:lower()
    local action,args=input:match("^(%S+)%s*(.-)$")
    if action then action=action:lower() end
    if command=="" or command=="settings" then
        if MeffortSuiteOpenSettings then MeffortSuiteOpenSettings() end
    elseif settingsPages[command] then
        if MeffortSuiteOpenSettings then MeffortSuiteOpenSettings(settingsPages[command]) end
    elseif command=="on" or command=="off" then
        if MeffortSuiteSetMasterEnabled then MeffortSuiteSetMasterEnabled(command=="on") end
    elseif command=="252" then
        if MeffortSuiteWay then MeffortSuiteWay.ToggleTreecko() end
    elseif action=="way" or action=="waypoint" then
        if MeffortSuiteWay then MeffortSuiteWay.Command(args) end
    elseif action=="wand" or action=="ranged" or action=="shoot" or action=="throw" then
        if args:lower()=="settings" then
            if MeffortSuiteOpenSettings then MeffortSuiteOpenSettings("range") end
        elseif MeffortSuiteRanged then MeffortSuiteRanged.Command(action,args) end
    elseif action=="distance" or action=="dist" then
        if MeffortSuiteTargetDistance then MeffortSuiteTargetDistance.Command(args) end
    elseif action=="arcane" or action=="arcaneblast" then
        if MeffortSuiteOpenSettings then MeffortSuiteOpenSettings("arcaneblast") end
    elseif action=="fishing" or action=="fish" then
        if args:lower()=="settings" then
            if MeffortSuiteOpenSettings then MeffortSuiteOpenSettings("fishing") end
        elseif MeffortSuiteFishing then MeffortSuiteFishing.Command(args) end
    elseif action=="enchant" or action=="enchanting" or action=="eq" then
        suite.Message("Enchant Queue is no longer included. Use the game's Enchanting window.")
    elseif action=="professions" then
        if MeffortSuiteOpenSettings then MeffortSuiteOpenSettings("fishing") end
    elseif action=="scrolls" and MeffortSuiteMageScrolls and MeffortSuiteMageScrolls.IsMage() then
        suite.Message("Mage scrolls: "..MeffortSuiteMageScrolls.Status()..".")
    elseif action=="bank" then
        if MeffortSuiteBank then MeffortSuiteBank.Command(args) end
    elseif action=="flight" or action=="taxi" then
        if MeffortSuiteFlightMasters then MeffortSuiteFlightMasters.Command(args) end
    elseif action=="vendor" or action=="merchant" then
        if MeffortSuiteInventory and MeffortSuiteInventory.VendorStatus then
            MeffortSuiteInventory.VendorStatus(args:lower()=="retry")
        end
    elseif command=="export" or command=="report" then
        if type(MeffortSuiteExportDiagnostics)=="function" then MeffortSuiteExportDiagnostics()
        else suite.Message("The report window is unavailable. Use /msuite diagnostics to review this session in chat.") end
    elseif command=="diagnostics" or command=="debug" then
        suite.Diagnostics()
    elseif command=="help" and MeffortSuiteOpenSettings then
        MeffortSuiteOpenSettings("help")
    elseif command=="help" or command=="status" then
        suite.Message("Suite "..(suite.Active() and "ON" or "OFF").."; standalone MeffortWand takes priority when enabled.")
        Help()
    else
        Help()
    end
end

local newInstall, newCharacter, loginAnnounced = false, false, false
local function CopyTable(value, seen)
    if type(value)~="table" then return value end
    seen=seen or {}
    if seen[value] then return seen[value] end
    local copied={};seen[value]=copied
    for k,v in pairs(value) do copied[k]=CopyTable(v,seen) end
    return copied
end
local function NormalizeSettings()
    if type(MeffortSuiteDB)~="table" then MeffortSuiteDB={} end
    if type(MeffortSuiteCharDB)~="table" then MeffortSuiteCharDB={} end
    local db,char=MeffortSuiteDB,MeffortSuiteCharDB
    for _,key in ipairs({"masterEnabled","style","badges","rankHint","questSpace","questSpaceConfirmations",
        "badgeTextOutline","badgeTextShadow","wayEnabled","autoSortBags","autoSellJunk",
        "autoRepair","autoBankCrafting","autoSortBank","autoOpenFlightMaster",
        "showLoginMessage","lootValue","lootValueAllItems","lootValueAuctionator",
        "lootValueBoth","fastAutoLoot","petSoundsMuted","petSoundFilesEnabled","backpackFreeSlots"}) do
        if db[key]~=nil and type(db[key])~="boolean" then db[key]=nil end
    end
    for _,key in ipairs({"colors","textColors","actionText"}) do
        if db[key]~=nil and type(db[key])~="table" then db[key]=nil end
    end
    local duration=db.lootValueDuration
    if duration~=nil and (type(duration)~="number" or duration~=duration or duration<2 or duration>12) then
        db.lootValueDuration=nil
    end
    if type(db.actionText)=="table" and MeffortSuiteActionText and type(MeffortSuiteActionText.GetSettings)=="function" then
        MeffortSuiteActionText.GetSettings()
    end
    for _,name in ipairs({"targetDistance","arcaneBlast"}) do
        local options=char[name]
        if type(options)=="table" then
            for _,key in ipairs({"enabled","locked","stacks","timer","wheel"}) do
                if options[key]~=nil and type(options[key])~="boolean" then options[key]=nil end
            end
        end
    end
    db.enabled=nil
    db.tooltipMode=nil
    if char.bankDepositExclusions~=nil and type(char.bankDepositExclusions)~="string" then char.bankDepositExclusions="" end
    if char.bankDepositInclusions~=nil and type(char.bankDepositInclusions)~="string" then char.bankDepositInclusions="" end
    db.autoOpenOrgBank=nil
    db.autoOpenSingleService=nil
    db.questRewardVendor=nil
    if type(char.fishingCameraZoom)~="boolean" then
        char.fishingCameraZoom=char.fishingBobberZoom==true or nil
    end
    for _,key in ipairs({"fishingClickMode","fishingBobberHighlight","fishingBobberMotion",
        "fishingBobberSize","fishingBobberOffset","fishingBobberZoom"}) do
        char[key]=nil
    end
    char.enchantQueue=nil
    char.rangedStartOnly=nil
    db.schemaVersion=2
end

local frame=CreateFrame("Frame")
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("PLAYER_LOGIN")
for _,event in ipairs({"ADDON_ACTION_BLOCKED","ADDON_ACTION_FORBIDDEN","MACRO_ACTION_BLOCKED","MACRO_ACTION_FORBIDDEN","UI_ERROR_MESSAGE"}) do
    pcall(frame.RegisterEvent,frame,event)
end
frame:SetScript("OnEvent",function(_,event,name,action)
    if event=="ADDON_ACTION_BLOCKED" or event=="ADDON_ACTION_FORBIDDEN" then
        RecordAction(event,name,action);return
    elseif event=="MACRO_ACTION_BLOCKED" or event=="MACRO_ACTION_FORBIDDEN" then
        RecordAction(event,"macro",name);return
    elseif event=="UI_ERROR_MESSAGE" then
        if LockedOut(name,action) then RecordAction(event,"not reported",action) end
        return
    end
    if event=="ADDON_LOADED" and name==ADDON then
        if type(MeffortSuiteDB)~="table" then MeffortSuiteDB={} end
        if type(MeffortSuiteCharDB)~="table" then MeffortSuiteCharDB={} end
        if MeffortSuiteDefaults then MeffortSuiteDefaults.ApplyPending() end
        newInstall=MeffortSuiteDB.initialized~=true
        newCharacter=MeffortSuiteCharDB.initialized~=true
        NormalizeSettings()
    elseif event=="PLAYER_LOGIN" then
        if newInstall and type(MeffortBarsDB)=="table" then
            local keys={"style","badges","rankHint","questSpace",
                "badgeTextOutline","badgeTextShadow","colors","textColors","actionText"}
            for _,key in ipairs(keys) do
                if MeffortSuiteDB[key]==nil and MeffortBarsDB[key]~=nil then
                    MeffortSuiteDB[key]=CopyTable(MeffortBarsDB[key])
                end
            end
        end
        if newInstall and type(MeffortWayDB)=="table" and MeffortSuiteDB.wayTheme==nil then
            MeffortSuiteDB.wayTheme=MeffortWayDB.theme
        end
        if newCharacter and type(MeffortWandDB)=="table" and MeffortSuiteCharDB.rangedMode==nil then
            local class=type(UnitClass)=="function" and select(2,UnitClass("player")) or nil
            if class=="MAGE" or class=="PRIEST" or class=="WARLOCK" then
                MeffortSuiteCharDB.rangedMode=MeffortWandDB.mode
            end
        end
        NormalizeSettings()
        MeffortSuiteDB.initialized=true
        MeffortSuiteCharDB.initialized=true
        if not loginAnnounced then
            loginAnnounced=true
            if MeffortSuiteDB.showLoginMessage~=false then
                suite.Message("Version "..suite.Version.." loaded; suite "..(suite.Active() and "enabled" or "disabled")..". Use /msuite or Options > AddOns > MeffortSuite for settings.")
            end
        end
        newInstall,newCharacter=false,false
    end
    if event=="PLAYER_LOGIN" and type(MeffortSuiteDB)=="table" then
        if MeffortSuiteDB.wayTheme~="treecko" then MeffortSuiteDB.wayTheme="teal" end
    end
end)
