# 1.0.1

- Added a Blizzard-style settings window for `/mthrow` that shares the AddOns page's Throw shortcut setting.
- Added a `/mthrow` reminder in chat for Rogues and Warriors. You can turn it off in the settings window.

# 1.0.0

Initial release for World of Warcraft: Forever. Rogues and Warriors can Throw at the enemy under the cursor with right-click or Shift + right-click. Each character can choose its own shortcut in Settings.
