MeffortSuiteMageScrolls={}
local M=MeffortSuiteMageScrolls
local tracker=CreateFrame("Frame")
local spellID=1296017
local untranslated={
    [211780]=true,[211784]=true,[211785]=true,[211786]=true,[211787]=true,
    [211853]=true,[211854]=true,[211855]=true,[213543]=true,[213544]=true,
    [213545]=true,[213546]=true,[213547]=true,[281015]=true,[281016]=true,
    [281017]=true,[281018]=true,
}
local transferPanels={"MerchantFrame","BankFrame","GuildBankFrame","TradeFrame",
    "MailFrame","AuctionHouseFrame","AuctionFrame","ItemSocketingFrame"}
local overlay,hovered,armed
local clicking=false
local watchElapsed=0
local UpdateTarget
local setupAttempted=false
local status="off"

local function Public(value)
    return not issecretvalue or not issecretvalue(value)
end
local function Number(value)
    if Public(value) and type(value)=="number" and value==value
        and value~=math.huge and value~=-math.huge then return value end
end
local function Locked()
    return type(InCombatLockdown)=="function" and InCombatLockdown()
end
function M.IsMage()
    if type(UnitClass)~="function" then return false end
    local _,class=UnitClass("player")
    return Public(class) and class=="MAGE"
end
function M.Enabled()
    return M.IsMage() and type(MeffortSuiteCharDB)=="table" and MeffortSuiteCharDB.mageScrollRightClick==true
end
local function KnowsSpell()
    local getter=C_SpellBook and C_SpellBook.IsSpellKnown or IsPlayerSpell or IsSpellKnown
    if type(getter)~="function" then return false end
    local ok,known=pcall(getter,spellID)
    return ok and Public(known) and known==true
end
local function UsingBagItem()
    if type(IsModifierKeyDown)=="function" and IsModifierKeyDown() then return true end
    if type(SpellIsTargeting)=="function" and SpellIsTargeting() then return true end
    if type(SpellCanTargetItem)=="function" and SpellCanTargetItem() then return true end
    if type(SpellCanTargetItemID)=="function" and SpellCanTargetItemID() then return true end
    if type(GetCursorInfo)=="function" then
        local cursor=GetCursorInfo()
        if not Public(cursor) or cursor~=nil then return true end
    end
    for _,name in ipairs(transferPanels) do
        local panel=_G[name]
        if panel and panel.IsShown and panel:IsShown() then return true end
    end
    return false
end
local function ScrollAt(button)
    if not button or not button:IsVisible() or not button:IsMouseOver() or UsingBagItem() then return end
    local bag,slot=Number(button:GetBagID()),Number(button:GetID())
    if not bag or bag<0 or bag>4 or not slot or slot<1 then return end
    local info=C_Container.GetContainerItemInfo(bag,slot)
    if not Public(info) or type(info)~="table" then return end
    local id=Number(info.itemID)
    if not id or not untranslated[id] or not Public(info.isLocked) or info.isLocked
        or not Public(info.isFiltered) or info.isFiltered then return end
    return bag,slot,id
end
local function Disarm()
    if clicking or not armed then return end
    armed=nil
    tracker:SetScript("OnUpdate",nil)
    overlay:Hide()
    overlay:SetAttribute("type2",nil)
    overlay:SetAttribute("target-bag",nil)
    overlay:SetAttribute("target-slot",nil)
end

local function WatchTarget(_,elapsed)
    watchElapsed=watchElapsed+elapsed
    if watchElapsed>=.05 then
        watchElapsed=0
        UpdateTarget()
    end
end
UpdateTarget=function()
    if clicking or Locked() then return end
    if not M.Enabled() or not MeffortSuite.Active() or not KnowsSpell() then Disarm();return end
    local bag,slot,id=ScrollAt(hovered)
    if not bag then Disarm();return end
    local x,y,w,h=hovered:GetRect()
    x,y,w,h=Number(x),Number(y),Number(w),Number(h)
    local scale,rootScale=Number(hovered:GetEffectiveScale()),Number(UIParent:GetEffectiveScale())
    if not x or not y or not w or w<=0 or not h or h<=0
        or not scale or scale<=0 or not rootScale or rootScale<=0 then Disarm();return end
    local ratio=scale/rootScale
    x,y,w,h=x*ratio,y*ratio,w*ratio,h*ratio
    local strata,level=hovered:GetFrameStrata(),hovered:GetFrameLevel()
    if armed and armed.bag==bag and armed.slot==slot and armed.id==id
        and armed.x==x and armed.y==y and armed.w==w and armed.h==h
        and armed.strata==strata and armed.level==level then return end
    armed={bag=bag,slot=slot,id=id,x=x,y=y,w=w,h=h,strata=strata,level=level}
    -- Keep protected anchors on UIParent so bag buttons can move and recycle in combat.
    overlay:ClearAllPoints()
    overlay:SetPoint("BOTTOMLEFT",UIParent,"BOTTOMLEFT",x,y)
    overlay:SetSize(w,h)
    overlay:SetFrameStrata(strata)
    overlay:SetFrameLevel(level+1)
    overlay:SetAttribute("target-bag",bag)
    overlay:SetAttribute("target-slot",slot)
    overlay:SetAttribute("type2","spell")
    watchElapsed=0
    tracker:SetScript("OnUpdate",WatchTarget)
    overlay:Show()
end

local function Initialize()
    if setupAttempted then return end
    setupAttempted=true
    if not (C_Container and type(C_Container.GetContainerItemInfo)=="function" and
        EventRegistry and type(EventRegistry.RegisterCallback)=="function" and
        type(RegisterStateDriver)=="function" and UIParent) then
        status="native bag controls unavailable"
        return
    end
    local root,button
    local ok=pcall(function()
        root=CreateFrame("Frame",nil,UIParent,"SecureHandlerStateTemplate")
        button=CreateFrame("Button",nil,root,"SecureActionButtonTemplate")
        button:Hide()
        button:EnableMouse(true)
        button:SetMouseMotionEnabled(false)
        button:SetPassThroughButtons("LeftButton","MiddleButton","Button4","Button5")
        button:RegisterForClicks("RightButtonUp")
        button:SetAttribute("useOnKeyDown",false)
        button:SetAttribute("spell",spellID)
        button:SetScript("PreClick",function()
            if Locked() then return end
            local bag,slot,id=ScrollAt(hovered)
            if not armed or not M.Enabled() or not MeffortSuite.Active() or not KnowsSpell()
                or bag~=armed.bag or slot~=armed.slot or id~=armed.id then
                Disarm()
            else
                clicking=true
            end
        end)
        button:SetScript("PostClick",function()
            -- Cursor changes during the cast must preserve the target until WoW applies it.
            clicking=false
            UpdateTarget()
        end)
        if RegisterStateDriver(root,"visibility","[combat][mod] hide; show")==false then
            error("secure bag visibility unavailable")
        end
        EventRegistry:RegisterCallback("ContainerFrameItemButton.EnterButton",function(_,item)
            hovered=item
            if overlay then UpdateTarget() end
        end,tracker)
        EventRegistry:RegisterCallback("ContainerFrameItemButton.ExitButton",function(_,item)
            if hovered==item then
                hovered=nil
                if overlay and not Locked() then Disarm() end
            end
        end,tracker)
        EventRegistry:RegisterCallback("ContainerFrame.CloseBag",function()
            if hovered and not hovered:IsVisible() then hovered=nil end
            if overlay then UpdateTarget() end
        end,tracker)
    end)
    if ok then overlay=button
    else status="secure bag controls unavailable" end
end
function M.Refresh()
    if not M.IsMage() or Locked() then return end
    if M.Enabled() and MeffortSuite.Active() then Initialize() end
    if overlay then UpdateTarget() end
end
function M.SetEnabled(value)
    if not M.IsMage() then return end
    if type(MeffortSuiteCharDB)~="table" then MeffortSuiteCharDB={} end
    MeffortSuiteCharDB.mageScrollRightClick=value==true
    M.Refresh()
end
function M.Status()
    if not M.Enabled() then return "off" end
    if not MeffortSuite.Active() then return "suite off" end
    if Locked() then return "paused during combat" end
    if not overlay then return status end
    return KnowsSpell() and "ready in standard bags" or "requires Comprehend Scroll"
end

tracker:RegisterEvent("PLAYER_LOGIN")
tracker:SetScript("OnEvent",function(_,event)
    if event=="PLAYER_LOGIN" then
        tracker:UnregisterEvent(event)
        if not M.IsMage() then return end
        for _,name in ipairs({"PLAYER_REGEN_ENABLED","SPELLS_CHANGED","MODIFIER_STATE_CHANGED","BAG_UPDATE_DELAYED",
            "CURSOR_CHANGED","CURRENT_SPELL_CAST_CHANGED","ITEM_LOCK_CHANGED","MERCHANT_SHOW","MERCHANT_CLOSED",
            "BANKFRAME_OPENED","BANKFRAME_CLOSED","TRADE_SHOW","TRADE_CLOSED","MAIL_SHOW","MAIL_CLOSED",
            "AUCTION_HOUSE_SHOW","AUCTION_HOUSE_CLOSED","PLAYER_LEAVING_WORLD"}) do
            pcall(tracker.RegisterEvent,tracker,name)
        end
    elseif event=="PLAYER_LEAVING_WORLD" then
        hovered=nil
    end
    M.Refresh()
end)
