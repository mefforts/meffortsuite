local suite = MeffortSuite
MeffortSuiteBank = {}
local bank = MeffortSuiteBank

local open = false
local serial = 0
local attempted = false
local autoPasses = 0
local autoChecks = 0
local MAX_AUTO_PASSES = 4
local MAX_AUTO_CHECKS = 12
local status = "bank closed"
local sortDone = false
local selective = MeffortSuiteBankSelective
local ORGRIMMAR_BANKERS = { [3309] = true, [3318] = true, [3320] = true }
local BANKER_ICON = 132050
local gossipSelectedGUID

local function TalkingToOrgrimmarBanker()
    if type(UnitGUID) ~= "function" then return nil end
    local guid = UnitGUID("npc")
    if type(guid) ~= "string" then return nil end
    local npcID = tonumber(guid:match("^Creature%-[^%-]+%-[^%-]+%-[^%-]+%-[^%-]+%-(%d+)%-"))
    if npcID and ORGRIMMAR_BANKERS[npcID] then return guid end
    return nil
end

local function Database()
    if type(MeffortSuiteDB) ~= "table" then MeffortSuiteDB = {} end
    return MeffortSuiteDB
end

local function Enabled()
    return suite and suite.Active() and Database().autoBankCrafting ~= false
end

local function BankReady()
    if not open then return false end
    -- BankFrame may be created after BANKFRAME_OPENED.
    local frame = _G.BankFrame
    return not frame or (frame.IsShown and frame:IsShown())
end

local function BankType()
    return (Enum and Enum.BankType and Enum.BankType.Character) or 0
end

local function CanDeposit()
    if not BankReady() then return false, "bank window not ready" end
    if not suite or not suite.Active() then return false, "Suite disabled" end
    if type(InCombatLockdown) == "function" and InCombatLockdown() then
        return false, "combat lockdown"
    end
    if (type(CursorHasItem) == "function" and CursorHasItem())
        or (type(GetCursorInfo) == "function" and GetCursorInfo()) then
        return false, "cursor occupied"
    end
    local filtered = selective and selective.HasExclusions()
    if filtered then
        if not C_Bank or type(C_Bank.FetchPurchasedBankTabIDs) ~= "function"
            or not C_Container or type(C_Container.GetContainerItemInfo) ~= "function"
            or type(C_Container.GetContainerNumSlots) ~= "function"
            or type(C_Container.PickupContainerItem) ~= "function" or type(GetCursorInfo) ~= "function"
            or not C_Timer or type(C_Timer.After) ~= "function" then
            return false, "selective bank transfer API unavailable"
        end
    elseif not C_Bank or type(C_Bank.AutoDepositItemsIntoBank) ~= "function" then
        return false, "native bank deposit API unavailable"
    end
    if type(C_Bank.DoesBankTypeSupportAutoDeposit) == "function" then
        local ok, supported = pcall(C_Bank.DoesBankTypeSupportAutoDeposit, BankType())
        if not ok then return false, "bank permission check failed" end
        if supported == false then return false, "personal bank does not support deposits" end
    end
    return true
end

function bank.CanDepositStatus()
    if selective and selective.Active() then return false, "a deposit is already in progress" end
    return CanDeposit()
end

function bank.Ready()
    return BankReady()
end

function bank.RefreshMaster()
    if suite and not suite.Active() then
        attempted = true
        serial = serial + 1
        if selective then selective.Cancel("Suite disabled") end
        status = "Suite disabled"
    end
end

function bank.Enabled()
    return Database().autoBankCrafting ~= false
end

function bank.SortEnabled()
    return Database().autoSortBank ~= false
end

function bank.SetSortEnabled(value)
    Database().autoSortBank = value == true
    suite.Message("Auto-sort personal bank " .. (bank.SortEnabled() and "ON" or "OFF") .. ".")
end

function bank.Exclusions()
    return selective and selective.Exclusions() or ""
end

function bank.SetExclusions(value)
    if selective and tostring(value or "") ~= selective.Exclusions() then
        attempted = true
        selective.SetExclusions(value)
    end
    suite.Message("Bank deposit exclusions saved for this character.")
end

function bank.GossipEnabled()
    return Database().autoOpenOrgBank ~= false
end

function bank.SetGossipEnabled(value)
    Database().autoOpenOrgBank = value == true
    suite.Message("Skip Orgrimmar banker dialogue " .. (bank.GossipEnabled() and "ON" or "OFF") ..
        ". " .. (bank.GossipEnabled() and "Shift-click to see the original dialogue." or ""))
end

local function AutoSelectBankerGossip()
    if open or not suite or not suite.Active() or not bank.GossipEnabled() then return end
    local shortcuts=MeffortSuiteGossipServices
    if shortcuts and shortcuts.Selected and shortcuts.Selected() then return end
    if type(IsShiftKeyDown) == "function" and IsShiftKeyDown() then return end
    if type(InCombatLockdown) == "function" and InCombatLockdown() then return end
    local guid = TalkingToOrgrimmarBanker()
    if not guid or gossipSelectedGUID == guid then return end
    if not C_GossipInfo or type(C_GossipInfo.GetOptions) ~= "function"
        or type(C_GossipInfo.SelectOption) ~= "function" then return end

    local ok, options = pcall(C_GossipInfo.GetOptions)
    if not ok or type(options) ~= "table" then return end
    local choice, matches
    matches = 0
    for _, option in ipairs(options) do
        if type(option) == "table" and tonumber(option.icon) == BANKER_ICON
            and type(option.gossipOptionID) == "number"
            and (option.status == nil or option.status == 0) then
            matches = matches + 1
            choice = option.gossipOptionID
        end
    end
    if matches ~= 1 then return end
    gossipSelectedGUID = guid
    local selected, err
    if shortcuts and shortcuts.SelectOption then selected,err=shortcuts.SelectOption(choice)
    else selected,err=pcall(C_GossipInfo.SelectOption,choice) end
    if selected then
        suite.Message("Orgrimmar banker: opening bank.")
    else
        suite.Message("Orgrimmar banker option failed: " .. tostring(err))
    end
end

function bank.SetEnabled(value)
    Database().autoBankCrafting = value == true
    suite.Message("Auto-bank crafting reagents " .. (bank.Enabled() and "ON" or "OFF") ..
        ". " .. (bank.Enabled() and "Opening your personal bank will trigger a deposit." or ""))
    if not value then
        attempted = true
        if selective then selective.Cancel("automatic deposit disabled") end
    end
end

local function QueueSort(ticket, delay)
    if not bank.SortEnabled() then return end
    local function Sort()
        if ticket ~= serial or not open or sortDone or not BankReady()
            or not suite or not suite.Active() or not bank.SortEnabled() then return end
        if selective and selective.Active() then return end
        if type(InCombatLockdown) == "function" and InCombatLockdown() then return end
        if (type(CursorHasItem) == "function" and CursorHasItem())
            or (type(GetCursorInfo) == "function" and GetCursorInfo()) then return end
        local containers = C_Container
        if not containers then return end
        local method, argument
        if type(containers.SortBank) == "function" then
            method, argument = containers.SortBank, BankType()
        elseif type(containers.SortBankBags) == "function" then
            method = containers.SortBankBags
        else
            status = "bank sorting unavailable"
            return
        end
        local ok, err = pcall(method, argument)
        if ok then
            sortDone = true
        else
            status = "bank sort failed: " .. tostring(err)
            suite.Message("Auto-sort bank: " .. status)
        end
    end
    if C_Timer and type(C_Timer.After) == "function" then
        C_Timer.After(delay, Sort)
    else
        Sort()
    end
end

function bank.DepositNow(quiet, deferSort, onFinished)
    local ok, why = bank.CanDepositStatus()
    if not ok then
        status = why
        if not quiet then suite.Message("Auto-bank: " .. why) end
        return false
    end
    if selective and selective.HasExclusions() then
        local ticket = serial
        local callOK, success, reason = pcall(selective.Start, function()
            return open and serial == ticket and BankReady()
        end, function(moved, excluded, err)
            if ticket ~= serial or not open then return end
            status = err or ("selectively deposited " .. moved .. " stack(s)")
            if err then
                suite.Message("Auto-bank: " .. status .. ".")
            elseif not quiet then
                suite.Message("Auto-bank: deposited " .. moved .. " stack(s), protected "
                    .. excluded .. " excluded stack(s).")
            end
            if not deferSort and not err then QueueSort(ticket, 0.6) end
            if type(onFinished) == "function" then onFinished(moved, err) end
        end)
        if not callOK then
            reason, success = success, false
            selective.Cancel("deposit startup failed; check cursor")
            if suite and type(suite.ReportError) == "function" then
                suite.ReportError("Bank", "selective deposit startup", reason)
            end
        end
        if not success then
            status = "selective deposit not started: " .. tostring(reason)
            if not quiet then suite.Message("Auto-bank: " .. status) end
            -- Never run the unfiltered native deposit with exclusions enabled.
            return false
        end
        status = "selective deposit in progress"
        return true
    end
    local success, err = pcall(C_Bank.AutoDepositItemsIntoBank, BankType())
    if success then
        status = "deposit requested"
        if not quiet then suite.Message("Auto-bank: requested crafting reagent deposit.") end
        if not deferSort then QueueSort(serial, 1.3) end
        return true
    end
    status = "deposit rejected: " .. tostring(err)
    suite.Message("Auto-bank: " .. status .. ". Try the bank's Deposit Reagents button.")
    return false
end

function bank.Status()
    suite.Message("Bank: " .. (open and "open" or "closed") ..
        "; auto crafting deposit: " .. (bank.Enabled() and "ON" or "OFF") ..
        "; auto-sort bank: " .. (bank.SortEnabled() and "ON" or "OFF") ..
        "; exclusions: " .. (bank.Exclusions() ~= "" and bank.Exclusions() or "none") ..
        "; skip Orgrimmar gossip: " .. (bank.GossipEnabled() and "ON" or "OFF") ..
        "; last action: " .. status)
end

function bank.Command(arg)
    arg = (arg or ""):lower():match("^%s*(.-)%s*$")
    local gossipAction = arg:match("^gossip%s+(%a+)$")
    local sortAction = arg:match("^sort%s+(%a+)$")
    if sortAction == "on" then
        bank.SetSortEnabled(true)
    elseif sortAction == "off" then
        bank.SetSortEnabled(false)
    elseif gossipAction == "on" then
        bank.SetGossipEnabled(true)
    elseif gossipAction == "off" then
        bank.SetGossipEnabled(false)
    elseif arg == "on" then
        bank.SetEnabled(true)
    elseif arg == "off" then
        bank.SetEnabled(false)
    elseif arg == "now" or arg == "deposit" then
        bank.DepositNow(false)
    else
        bank.Status()
        suite.Message("/msuite bank on | off | now | sort on/off | gossip on/off")
    end
end

local function FinishAuto(ticket)
    if ticket ~= serial or not open or attempted then return end
    attempted = true
    -- Sort only after the last deposit and its resulting inventory updates.
    QueueSort(ticket, 1.1)
end

local AutoTry
local function QueueTry(ticket, delay)
    if not C_Timer or type(C_Timer.After) ~= "function" then
        if autoPasses == 0 then AutoTry(ticket) else FinishAuto(ticket) end
        return
    end
    C_Timer.After(delay, function() AutoTry(ticket) end)
end

AutoTry = function(ticket)
    if ticket ~= serial or not open or attempted or not Enabled() then return end
    autoChecks = autoChecks + 1
    if autoChecks > MAX_AUTO_CHECKS then
        status = "deposit retry limit reached"
        FinishAuto(ticket)
        return
    end
    if not BankReady() or (type(InCombatLockdown) == "function" and InCombatLockdown()) then
        status = "waiting for bank"
        QueueTry(ticket, 0.65)
        return
    end
    if (type(CursorHasItem) == "function" and CursorHasItem())
        or (type(GetCursorInfo) == "function" and GetCursorInfo()) then
        status = "cursor occupied; waiting to deposit"
        QueueTry(ticket, 0.65)
        return
    end

    if autoPasses > 0 and selective and type(selective.Pending) == "function" then
        local pending, unknown = selective.Pending()
        if pending == 0 and unknown == 0 then
            status = "crafting deposit complete (" .. autoPasses .. " pass(es))"
            FinishAuto(ticket)
            return
        end
        if pending == 0 and unknown > 0 and autoPasses >= 2 then
            -- Unknown items cannot safely be classified by the selective path.
            status = "deposit finished; some item data not ready"
            FinishAuto(ticket)
            return
        end
    end
    if autoPasses >= MAX_AUTO_PASSES then
        status = "deposit retry limit reached (" .. autoPasses .. " passes)"
        FinishAuto(ticket)
        return
    end

    autoPasses = autoPasses + 1
    local pass = autoPasses
    local hasExclusions = selective and selective.HasExclusions()
    local succeeded = bank.DepositNow(pass > 1, true, function(_, err)
        if ticket ~= serial or not open or attempted then return end
        if err then
            FinishAuto(ticket)
            return
        end
        QueueTry(ticket, 0.85)
    end)
    if not succeeded then
        FinishAuto(ticket)
        return
    end
    -- Selective transfers schedule their follow-up; native deposits need a settle interval.
    if not hasExclusions then QueueTry(ticket, 1.05) end
end

local frame = CreateFrame("Frame")
frame:RegisterEvent("PLAYER_LOGIN")
frame:RegisterEvent("BANKFRAME_OPENED")
frame:RegisterEvent("BANKFRAME_CLOSED")
frame:RegisterEvent("GOSSIP_SHOW")
frame:RegisterEvent("GOSSIP_CLOSED")
frame:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        local db = Database()
        if db.autoBankCrafting == nil then db.autoBankCrafting = true end
        if db.autoOpenOrgBank == nil then db.autoOpenOrgBank = true end
        if db.autoSortBank == nil then db.autoSortBank = true end
    elseif event == "GOSSIP_SHOW" then
        AutoSelectBankerGossip()
    elseif event == "GOSSIP_CLOSED" then
        gossipSelectedGUID = nil
    elseif event == "BANKFRAME_OPENED" then
        gossipSelectedGUID = nil
        open = true
        attempted = false
        autoPasses = 0
        autoChecks = 0
        sortDone = false
        serial = serial + 1
        status = "bank open"
        local ticket = serial
        if not Enabled() then
            QueueSort(ticket, 0.5)
            return
        end
        QueueTry(ticket, 0.35)
    elseif event == "BANKFRAME_CLOSED" then
        open = false
        if selective then selective.Cancel() end
        serial = serial + 1
        attempted = false
        autoPasses = 0
        autoChecks = 0
        status = "bank closed"
    end
end)
