local suite = MeffortSuite
local services = {}
MeffortSuiteGossipServices = services

local serviceIcons = {
    [132060] = "vendor", [132058] = "trainer", [132050] = "bank",
    [132057] = "taxi",
}
local orgBankers = { [3309] = true, [3318] = true, [3320] = true }
local open, selected, selecting, continuing = false, false, false, false
local recentSelection, dispatchSerial = false, 0
local events
local status = "not used"

local function Secret(value)
    return type(issecretvalue) == "function" and issecretvalue(value)
end
local function Number(value)
    if not Secret(value) and type(value) == "number" and value == value
        and value ~= math.huge and value ~= -math.huge then return value end
end
local function DB()
    if type(MeffortSuiteDB) ~= "table" then MeffortSuiteDB = {} end
    return MeffortSuiteDB
end
local function Ready()
    if not suite or not suite.Active() then return false, "Suite disabled" end
    if type(InCombatLockdown) == "function" and InCombatLockdown() then return false, "in combat" end
    if type(IsShiftKeyDown) == "function" and IsShiftKeyDown() then return false, "Shift bypass" end
    if not C_GossipInfo or type(C_GossipInfo.SelectOption) ~= "function" then
        return false, "gossip selection unavailable"
    end
    return true
end
function services.Enabled() return DB().autoOpenSingleService ~= false end
function services.SetEnabled(value)
    DB().autoOpenSingleService = value == true
    if suite and suite.Message then
        suite.Message("Single-option service shortcuts " .. (services.Enabled() and "ON" or "OFF") .. ". Hold Shift for normal dialogue.")
    end
end
function services.Selected() return selected or selecting or recentSelection end
local function GuardDispatch()
    recentSelection = true
    dispatchSerial = dispatchSerial + 1
    local serial = dispatchSerial
    local function ClearGuard()
        if dispatchSerial == serial then recentSelection = false end
    end
    if C_Timer and type(C_Timer.After) == "function" then
        C_Timer.After(0, ClearGuard)
    else
        events:SetScript("OnUpdate", function(self)
            self:SetScript("OnUpdate", nil)
            ClearGuard()
        end)
    end
end

function services.SelectOption(optionID)
    if services.Selected() then return false, "a service was already selected" end
    local ready, why = Ready()
    if not ready then return false, why end
    optionID = Number(optionID)
    if not optionID or optionID <= 0 or optionID ~= math.floor(optionID) then return false, "invalid option" end
    selected, selecting = true, true
    GuardDispatch()
    local ok, result = pcall(C_GossipInfo.SelectOption, optionID)
    selecting = false
    if not ok or result == false then
        status = "selection refused"
        return false, status
    end
    status = "service interface requested"
    return true
end

local function ReadList(method)
    local fn = C_GossipInfo and C_GossipInfo[method]
    if type(fn) ~= "function" then return nil end
    local ok, value = pcall(fn)
    if ok and not Secret(value) and type(value) == "table" then return value end
end
local function NoQuests()
    for _, method in ipairs({"GetActiveQuests", "GetAvailableQuests"}) do
        local list = ReadList(method)
        if not list or next(list) ~= nil then return false end
    end
    return true
end
local function SingleOption()
    local options = ReadList("GetOptions")
    if not options then return nil end
    local option, count = nil, 0
    for _, value in pairs(options) do
        count = count + 1
        if count > 1 or Secret(value) or type(value) ~= "table" then return nil end
        option = value
    end
    return option
end
local function IsOrgBanker()
    if type(UnitGUID) ~= "function" then return nil end
    local ok, guid = pcall(UnitGUID, "npc")
    if not ok or Secret(guid) or type(guid) ~= "string" then return nil end
    local id = tonumber(guid:match("^Creature%-[^%-]+%-[^%-]+%-[^%-]+%-[^%-]+%-(%d+)%-"))
    return id and orgBankers[id] == true
end
local function ZeroOrAbsent(value)
    if Secret(value) then return false end
    if value == nil then return true end
    return Number(value) == 0
end
local function FalseOrAbsent(value)
    if Secret(value) then return false end
    if value == nil then return true end
    return not Secret(value) and (value == false or value == 0)
end
local function EmptyOrAbsent(value)
    if Secret(value) then return false end
    if value == nil then return true end
    return not Secret(value) and type(value) == "string" and value == ""
end
local function Eligible(option)
    if not option then return nil end
    local id, icon = Number(option.gossipOptionID), Number(option.icon)
    local kind = icon and serviceIcons[icon]
    if not id or id <= 0 or id ~= math.floor(id) or not kind then return nil end
    if not ZeroOrAbsent(option.status) then return nil end
    if Secret(option.overrideIconID) then return nil end
    if option.overrideIconID ~= nil and Number(option.overrideIconID) ~= icon then return nil end
    for _, key in ipairs({"cost", "money", "boxMoney", "spellID", "flags"}) do
        if not ZeroOrAbsent(option[key]) then return nil end
    end
    for _, key in ipairs({"isCoded", "coded", "isConfirmation", "requiresConfirmation", "hasCost"}) do
        if not FalseOrAbsent(option[key]) then return nil end
    end
    for _, key in ipairs({"boxText", "confirmationText", "confirmText"}) do
        if not EmptyOrAbsent(option[key]) then return nil end
    end
    if Secret(option.rewards) then return nil end
    if option.rewards ~= nil then
        if type(option.rewards) ~= "table" or next(option.rewards) ~= nil then return nil end
    end
    if kind == "taxi" and DB().autoOpenFlightMaster == false then return nil end
    if kind == "bank" and DB().autoOpenOrgBank == false then
        local org = IsOrgBanker()
        if org ~= false then return nil end
    end
    return id, kind
end
function services.TrySingleService()
    if not open or services.Selected() or not services.Enabled() then return false end
    local ready, why = Ready()
    if not ready then status = why; return false end
    if not NoQuests() then status = "quest choices or metadata unavailable"; return false end
    local optionID, kind = Eligible(SingleOption())
    if not optionID then status = "no unambiguous service choice"; return false end
    -- Recheck the complete menu before dispatch, including client API changes.
    local freshID, freshKind = Eligible(SingleOption())
    if freshID ~= optionID or freshKind ~= kind or not NoQuests() then
        status = "dialogue changed"; return false
    end
    local ok, reason = services.SelectOption(optionID)
    if ok then status = kind .. " interface requested" end
    return ok, reason
end
function services.Command(argument)
    local value = type(argument) == "string" and argument:lower():match("^%s*(.-)%s*$") or ""
    if value == "on" or value == "off" then services.SetEnabled(value == "on"); return end
    if suite and suite.Message then
        suite.Message("Single-option service shortcuts: " .. (services.Enabled() and "ON" or "OFF") .. "; " .. status .. ". /msuite services on | off | status")
    end
end

events = CreateFrame("Frame")
for _, event in ipairs({"PLAYER_LOGIN", "GOSSIP_SHOW", "GOSSIP_CLOSED", "GOSSIP_OPTIONS_REFRESHED"}) do
    pcall(events.RegisterEvent, events, event)
end
events:SetScript("OnEvent", function(_, event, interactionIsContinuing)
    if event == "PLAYER_LOGIN" then
        if DB().autoOpenSingleService == nil then DB().autoOpenSingleService = true end
    elseif event == "GOSSIP_SHOW" then
        if selecting then open = true; return end
        if recentSelection then return end
        if not open and not continuing then selected = false end
        open, continuing = true, false
        services.TrySingleService()
    elseif event == "GOSSIP_OPTIONS_REFRESHED" then
        services.TrySingleService()
    elseif event == "GOSSIP_CLOSED" then
        open = false
        continuing = not Secret(interactionIsContinuing) and interactionIsContinuing == true
        if not selecting and not continuing then selected = false end
    end
end)
