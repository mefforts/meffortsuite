local module = {}
MeffortSuiteActionText = module

local buttonPrefixes = {
    "ActionButton", "MultiBarBottomLeftButton", "MultiBarBottomRightButton",
    "MultiBarLeftButton", "MultiBarRightButton",
    "MultiBar5Button", "MultiBar6Button", "MultiBar7Button",
    "PetActionButton", "StanceButton", "BonusActionButton",
}
local original = setmetatable({}, { __mode = "k" })
local pending = false
local panel, previewText, previewSquare, stateText, controls, xSlider, ySlider
local fontFallback = STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
local applying, syncingControls = false, false
local positionPending = false
local lastError

local function Clamp(v,lo,hi)
    v=tonumber(v)
    if not v or v~=v or v==math.huge or v==-math.huge then v=0 end
    return math.max(lo,math.min(hi,v))
end
local function DB()
    if type(MeffortSuiteDB)~="table" then MeffortSuiteDB={} end
    local s=MeffortSuiteDB.actionText
    if type(s)~="table" then s={};MeffortSuiteDB.actionText=s end
    if type(s.enabled)~="boolean" then s.enabled=true end
    if type(s.size)~="number" or s.size~=s.size then s.size=18 end
    s.size=Clamp(s.size,8,24)
    s.x=math.floor(Clamp(s.x,-22,22)+0.5)
    s.y=math.floor(Clamp(s.y,-22,22)+0.5)
    if type(s.hex)~="string" or not s.hex:match("^%x%x%x%x%x%x$") then s.hex="fff0c2" end
    if type(s.outline)~="boolean" then s.outline=true end
    if type(s.shadow)~="boolean" then s.shadow=true end
    if type(s.position)~="string" then s.position="center" end
    return s
end
local function InCombat()
    return InCombatLockdown and InCombatLockdown() or false
end
local function MasterActive()
    return not MeffortSuiteIsActive or MeffortSuiteIsActive()
end
local function Info(msg)
    if DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then
        DEFAULT_CHAT_FRAME:AddMessage("|cff60d9bdMeffortSuite|r: "..msg)
    end
end
local function FromHex(raw)
    if type(raw)~="string" then return end
    local hex=raw:gsub("#",""):gsub("%s+","")
    if not hex:match("^%x%x%x%x%x%x$") then return end
    hex=hex:lower()
    return hex,tonumber(hex:sub(1,2),16)/255,tonumber(hex:sub(3,4),16)/255,tonumber(hex:sub(5,6),16)/255
end
local function Capture(hotkey)
    if original[hotkey] then return end
    local src={ points={} }
    if hotkey.GetNumPoints and hotkey.GetPoint then
        local n=hotkey:GetNumPoints() or 0
        for i=1,math.min(n,4) do
            local point,relative,relativePoint,x,y=hotkey:GetPoint(i)
            if point then src.points[#src.points+1]={point,relative,relativePoint,x,y} end
        end
    end
    if hotkey.GetFont then src.font,src.size,src.flags=hotkey:GetFont() end
    if hotkey.GetTextColor then src.r,src.g,src.b,src.a=hotkey:GetTextColor() end
    if hotkey.GetShadowColor then src.sr,src.sg,src.sb,src.sa=hotkey:GetShadowColor() end
    if hotkey.GetShadowOffset then src.sx,src.sy=hotkey:GetShadowOffset() end
    if hotkey.GetJustifyH then src.justify=hotkey:GetJustifyH() end
    original[hotkey]=src
end
local function Restore(hotkey)
    local src=original[hotkey]
    if not src then return end
    if hotkey.SetFont and src.font then hotkey:SetFont(src.font,src.size or 12,src.flags or "") end
    if hotkey.ClearAllPoints then
        hotkey:ClearAllPoints()
        for _,point in ipairs(src.points) do
            hotkey:SetPoint(point[1],point[2],point[3],point[4],point[5])
        end
    end
    if src.r and hotkey.SetTextColor then hotkey:SetTextColor(src.r,src.g,src.b,src.a or 1) end
    if src.sr and hotkey.SetShadowColor then hotkey:SetShadowColor(src.sr,src.sg,src.sb,src.sa or 1) end
    if src.sx and hotkey.SetShadowOffset then hotkey:SetShadowOffset(src.sx,src.sy) end
    if src.justify and hotkey.SetJustifyH then hotkey:SetJustifyH(src.justify) end
    original[hotkey]=nil
end
local function Hotkey(button)
    if not button then return end
    if button.HotKey then return button.HotKey end
    local name=button.GetName and button:GetName()
    return name and _G[name.."HotKey"]
end
local function StyleButton(button)
    if not button then return end
    local hotkey=Hotkey(button)
    if not hotkey or not hotkey.SetFont or not hotkey.SetPoint then return end
    if InCombat() then pending=true;return end
    local s=DB()
    if not s.enabled or not MasterActive() then Restore(hotkey);return end
    Capture(hotkey)
    local src=original[hotkey]
    local color,r,g,b=FromHex(s.hex)
    if not color then color,r,g,b=FromHex("fff0c2") end
    local font=src.font or fontFallback
    local flags=s.outline and "OUTLINE" or ""
    hotkey:SetFont(font,Clamp(s.size,8,24),flags)
    hotkey:ClearAllPoints()
    hotkey:SetPoint("CENTER",button,"CENTER",Clamp(s.x,-22,22),Clamp(s.y,-22,22))
    if hotkey.SetJustifyH then hotkey:SetJustifyH("CENTER") end
    if hotkey.SetTextColor then hotkey:SetTextColor(r,g,b,1) end
    if hotkey.SetShadowColor then
        if s.shadow then hotkey:SetShadowColor(0,0,0,0.96) else hotkey:SetShadowColor(0,0,0,0) end
    end
    if hotkey.SetShadowOffset then hotkey:SetShadowOffset(s.shadow and 1 or 0,s.shadow and -1 or 0) end
end
function module.ApplyAll()
    if InCombat() then pending=true;return false end
    if applying then return false end
    applying=true
    local succeeded=true
    lastError=nil
    for _,prefix in ipairs(buttonPrefixes) do
        for i=1,12 do
            local button=_G[prefix..i]
            if button then
                local ok,err=pcall(StyleButton,button)
                if not ok then
                    succeeded=false
                    pending=true
                    lastError=tostring(err)
                end
            end
        end
    end
    applying=false
    return succeeded
end
function module.LastError() return lastError end
function module.SetEnabled(value)
    DB().enabled=(value==true)
    module.ApplyAll()
end

local function Label(parent,text,x,y,template)
    local f=parent:CreateFontString(nil,"OVERLAY",template or "GameFontHighlight")
    f:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
    if f.SetWidth then f:SetWidth(math.max(30,465-x-20)) end
    if f.SetJustifyH then f:SetJustifyH("LEFT") end
    f:SetText(text)
    return f
end
local function Button(parent,text,w,h,x,y,fn)
    local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
    b:SetSize(w,h);b:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
    b:SetText(text);b:SetScript("OnClick",fn)
    return b
end
local function UpdatePreview()
    if not panel then return end
    local s=DB()
    local _,r,g,b=FromHex(s.hex)
    if previewText then
        previewText:SetFont(fontFallback,Clamp(s.size,8,24),s.outline and "OUTLINE" or "")
        previewText:SetTextColor(r or 1,g or 1,b or 1)
        if previewText.SetShadowColor then
            previewText:SetShadowColor(0,0,0,s.shadow and 1 or 0)
            previewText:SetShadowOffset(s.shadow and 1 or 0,s.shadow and -1 or 0)
        end
        previewText:ClearAllPoints()
        previewText:SetPoint("CENTER",previewSquare,"CENTER",s.x,s.y)
    end
    if stateText then
        stateText:SetText(not MasterActive() and "MeffortSuite is OFF — /meffsuite on to enable"
            or (s.enabled and "Enabled for Blizzard action bars" or "Off — Blizzard labels unchanged"))
    end
    syncingControls=true
    if controls then for _,entry in ipairs(controls) do entry() end end
    syncingControls=false
end
local function ChangePosition(x,y,kind,deferApply)
    local s=DB()
    local nextX=math.floor(Clamp(x,-22,22)+0.5)
    local nextY=math.floor(Clamp(y,-22,22)+0.5)
    s.position=kind or "custom"
    if nextX==s.x and nextY==s.y then return false end
    s.x,s.y=nextX,nextY
    UpdatePreview()
    if deferApply then positionPending=true else module.ApplyAll() end
    return true
end
local function MakeSlider(parent,title,y,min,max,get,set)
    Label(parent,title,26,y,"GameFontNormal")
    local slider=CreateFrame("Slider",nil,parent,"OptionsSliderTemplate")
    slider:SetPoint("TOPLEFT",parent,"TOPLEFT",26,y-23)
    slider:SetSize(270,17)
    slider:SetMinMaxValues(min,max)
    if slider.SetValueStep then slider:SetValueStep(1) end
    if slider.SetObeyStepOnDrag then slider:SetObeyStepOnDrag(true) end
    local value=Label(parent,"",310,y-23,"GameFontHighlight")
    slider:SetScript("OnValueChanged",function(self,v)
        local rounded=math.floor((tonumber(v) or 0)+0.5)
        value:SetText(tostring(rounded))
        if syncingControls or rounded==get() then return end
        set(rounded)
        UpdatePreview()
        module.ApplyAll()
    end)
    controls[#controls+1]=function()
        local v=get()
        if slider:GetValue()~=v then slider:SetValue(v) end
        value:SetText(tostring(v))
    end
    return slider
end
local function MakeCheck(parent,text,x,y,get,set,labelWidth)
    local check=CreateFrame("CheckButton",nil,parent,"UICheckButtonTemplate")
    check:SetSize(24,24)
    check:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
    local caption=check:CreateFontString(nil,"OVERLAY","GameFontHighlight")
    caption:SetPoint("LEFT",check,"RIGHT",5,0)
    local remaining=465-x-24-5-18
    if caption.SetWidth then caption:SetWidth(math.max(40,math.min(labelWidth or remaining,remaining))) end
    if caption.SetJustifyH then caption:SetJustifyH("LEFT") end
    if caption.SetWordWrap then caption:SetWordWrap(false) end
    caption:SetText(text)
    check:SetScript("OnClick",function(self)
        set(self:GetChecked()==true)
        module.ApplyAll()
        UpdatePreview()
    end)
    controls[#controls+1]=function() check:SetChecked(get()) end
    return {widget=check,caption=caption}
end
local function CreatePanel()
    if panel then return panel end
    panel=CreateFrame("Frame","MeffortSuiteActionTextSettings",UIParent)
    panel:SetSize(465,575)
    panel:SetPoint("CENTER",UIParent,"CENTER",0,0)
    panel:SetFrameStrata("DIALOG")
    if panel.SetClampedToScreen then panel:SetClampedToScreen(true) end
    if type(UISpecialFrames)=="table" then
        local found=false
        for _,frameName in ipairs(UISpecialFrames) do
            if frameName=="MeffortSuiteActionTextSettings" then found=true;break end
        end
        if not found then table.insert(UISpecialFrames,"MeffortSuiteActionTextSettings") end
    end
    panel:SetMovable(true);panel:EnableMouse(true);panel:RegisterForDrag("LeftButton")
    panel:SetScript("OnDragStart",function(self)self:StartMoving()end)
    panel:SetScript("OnDragStop",function(self)self:StopMovingOrSizing()end)
    local bg=panel:CreateTexture(nil,"BACKGROUND")
    bg:SetAllPoints()
    bg:SetTexture("Interface\\AddOns\\MeffortSuite\\Textures\\ParchmentPanel.tga")
    Label(panel,"Action Bar Text",22,-20,"GameFontNormalLarge")
    Label(panel,"Customize the keybind text on your action buttons.",22,-50,"GameFontHighlightSmall")
    Button(panel,"Close",65,23,376,-16,function()panel:Hide()end)
    Button(panel,"Back to Bars",135,23,227,-16,function()
        panel:Hide()
        if MeffortSuiteOpenSettings then MeffortSuiteOpenSettings("action") end
    end)
    controls={}
    MakeCheck(panel,"Customize keybind labels",20,-82,
        function()return DB().enabled end,function(v)DB().enabled=v end,302)
    stateText=Label(panel,"",24,-115,"GameFontHighlightSmall")
    Label(panel,"PLACEMENT",24,-145,"GameFontNormal")
    Button(panel,"Top-right",90,25,23,-171,function()ChangePosition(12,12,"topright")end)
    Button(panel,"Center",90,25,120,-171,function()ChangePosition(0,0,"center")end)
    Button(panel,"Custom",90,25,218,-171,function()DB().position="custom";UpdatePreview()end)
    Label(panel,"Drag the example label, or use X/Y offsets below.",23,-210,"GameFontHighlightSmall")

    local sample=CreateFrame("Frame",nil,panel)
    sample:SetSize(90,70)
    sample:SetPoint("TOPRIGHT",panel,"TOPRIGHT",-24,-156)
    local surface=sample:CreateTexture(nil,"BACKGROUND")
    surface:SetAllPoints();surface:SetColorTexture(0.29,0.20,0.11,1)
    previewSquare=sample
    local border=sample:CreateTexture(nil,"BORDER")
    border:SetPoint("TOPLEFT",sample,"TOPLEFT",-1,1)
    border:SetPoint("TOPRIGHT",sample,"TOPRIGHT",1,1)
    border:SetHeight(1);border:SetColorTexture(0.66,0.49,0.26,1)
    previewText=sample:CreateFontString(nil,"OVERLAY","GameFontNormal")
    previewText:SetText("SHIFT-Q")
    previewText:SetJustifyH("CENTER")
    local drag=CreateFrame("Button",nil,sample)
    drag:SetAllPoints(sample)
    drag:EnableMouse(true);drag:RegisterForDrag("LeftButton")
    drag:SetScript("OnDragStart",function(self)
        self.dragging=true
        self:SetScript("OnUpdate",function(obj)
            if not obj.dragging or not GetCursorPosition or not previewSquare.GetCenter then return end
            local cx,cy=previewSquare:GetCenter()
            if not cx or not cy then return end
            local scale=previewSquare.GetEffectiveScale and previewSquare:GetEffectiveScale() or 1
            local mx,my=GetCursorPosition()
            if not mx or not my then return end
            if type(scale)~="number" or scale<=0 then return end
            ChangePosition((mx/scale)-cx,(my/scale)-cy,"custom",true)
        end)
    end)
    local function FinishDrag(self)
        self.dragging=false
        self:SetScript("OnUpdate",nil)
        if positionPending then
            positionPending=false
            module.ApplyAll()
        end
    end
    drag:SetScript("OnDragStop",FinishDrag)
    drag:SetScript("OnHide",FinishDrag)

    xSlider=MakeSlider(panel,"Horizontal offset",-248,-22,22,
        function()return DB().x end,function(v)DB().x=v;DB().position="custom" end)
    ySlider=MakeSlider(panel,"Vertical offset",-303,-22,22,
        function()return DB().y end,function(v)DB().y=v;DB().position="custom" end)
    MakeSlider(panel,"Font size",-358,8,24,
        function()return DB().size end,function(v)DB().size=v end)
    MakeCheck(panel,"Text outline",22,-415,
        function()return DB().outline end,function(v)DB().outline=v end,142)
    MakeCheck(panel,"Text shadow",220,-415,
        function()return DB().shadow end,function(v)DB().shadow=v end,144)
    Label(panel,"TEXT COLOR",24,-458,"GameFontNormal")
    local color=CreateFrame("EditBox",nil,panel,"InputBoxTemplate")
    color:SetSize(100,22);color:SetPoint("TOPLEFT",panel,"TOPLEFT",26,-484)
    color:SetAutoFocus(false);color:SetMaxLetters(7)
    Button(panel,"Apply hex",86,24,145,-484,function()
        local hex=FromHex(color:GetText())
        if hex then DB().hex=hex;module.ApplyAll();UpdatePreview() end
        color:ClearFocus()
    end)
    color:SetScript("OnEnterPressed",function(self)
        local hex=FromHex(self:GetText())
        if hex then DB().hex=hex;module.ApplyAll();UpdatePreview() end
        self:ClearFocus()
    end)
    color:SetScript("OnEscapePressed",function(self)self:ClearFocus()end)
    Button(panel,"Pick color...",113,24,244,-484,function()
        local ok=MeffortSuiteShowColorPicker and MeffortSuiteShowColorPicker(DB().hex,function(hex)
            DB().hex=hex
            module.ApplyAll()
            UpdatePreview()
            if color and not color:HasFocus() then color:SetText("#"..hex) end
        end)
        if not ok then Info("The native color picker is unavailable.") end
    end)
    Button(panel,"Reset appearance",138,24,302,-516,function()
        local cfg=DB()
        cfg.x,cfg.y,cfg.size=0,0,18
        cfg.hex,cfg.outline,cfg.shadow="fff0c2",true,true
        cfg.position="center"
        module.ApplyAll()
        UpdatePreview()
    end)
    controls[#controls+1]=function()
        if not color:HasFocus() then color:SetText("#"..DB().hex) end
    end
    Label(panel,"Changes save automatically. During combat they apply afterward.",23,-542,"GameFontHighlightSmall")
    panel:SetScript("OnShow",UpdatePreview)
    panel:Hide()
    return panel
end
function module.OpenPreview()
    local ok,win=pcall(CreatePanel)
    if not ok or not win then Info("Action Bar Text settings could not open.");return end
    if MeffortSuiteHideMainSettings then MeffortSuiteHideMainSettings() end
    win:Show()
end
function module.HidePanel()
    if panel then panel:Hide() end
end
function module.OpenPanel()
    if MeffortSuiteSettingsUI and type(MeffortSuiteOpenSettings)=="function" then
        module.HidePanel()
        MeffortSuiteOpenSettings("action")
        return
    end
    module.OpenPreview()
end
function module.TogglePanel()
    if MeffortSuiteSettingsUI and type(MeffortSuiteOpenSettings)=="function" then
        module.OpenPanel()
        return
    end
    local ok,win=pcall(CreatePanel)
    if not ok or not win then Info("Action Bar Text settings could not open.");return end
    if win:IsShown() then win:Hide() else module.OpenPanel() end
end

local events=CreateFrame("Frame")
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("PLAYER_ENTERING_WORLD")
events:RegisterEvent("PLAYER_REGEN_ENABLED")
events:RegisterEvent("UPDATE_BINDINGS")
events:RegisterEvent("ACTIONBAR_PAGE_CHANGED")
events:RegisterEvent("UPDATE_SHAPESHIFT_FORM")
events:RegisterEvent("PET_BAR_UPDATE")
events:SetScript("OnEvent",function(_,event)
    if event=="PLAYER_LOGIN" then
        DB()
        if hooksecurefunc and type(ActionButton_UpdateHotkeys)=="function" then
            hooksecurefunc("ActionButton_UpdateHotkeys",function(button)
                if button and not InCombat() then pcall(StyleButton,button)
                elseif InCombat() then pending=true end
            end)
        end
    end
    if event=="PLAYER_REGEN_ENABLED" and pending then pending=false end
    module.ApplyAll()
end)
