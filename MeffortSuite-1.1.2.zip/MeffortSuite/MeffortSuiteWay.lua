
MeffortSuiteWay = {}
local module = MeffortSuiteWay
local PI2 = math.pi * 2
local atan2 = math.atan2 or function(y, x) return math.atan(y, x) end
local prefix = "|cff50e6d5MeffortSuite|r"
local db

local THEMES = {
    teal = { key = "teal", name = "Teal", r = 0.22, g = 0.98, b = 0.90 },
    treecko = { key = "treecko", name = "Treecko", r = 0.47, g = 0.84, b = 0.29 },
}

local waypointID, waypointX, waypointY
local targetContinent, targetWorldX, targetWorldY
local lastIssue = "No map pin set"
local lastDistance, lastBearing, lastRadius
local RegisterWayCommand

local marker = CreateFrame("Frame", "MeffortSuiteMinimapMarker", Minimap)
marker:SetSize(32, 32)
marker:SetFrameStrata(Minimap:GetFrameStrata())
marker:SetFrameLevel(Minimap:GetFrameLevel() + 25)
marker:EnableMouse(false)
marker:Hide()

local arrow = marker:CreateTexture(nil, "OVERLAY")
arrow:SetAllPoints(marker)
arrow:SetTexture("Interface\\MINIMAP\\MiniMap-QuestArrow")
arrow:SetDesaturated(true)

local function GetThemeKey()
    return (db and db.wayTheme == "treecko") and "treecko" or "teal"
end

local function ApplyTheme()
    local theme = THEMES[GetThemeKey()] or THEMES.teal
    arrow:SetVertexColor(theme.r, theme.g, theme.b, 1)
    return theme
end

local function EnsureDB()
    if type(MeffortSuiteDB) ~= "table" then
        MeffortSuiteDB = {}
    end
    db = MeffortSuiteDB
    if db.wayTheme ~= "treecko" then
        db.wayTheme = "teal"
    end
    ApplyTheme()
end

local function SetTheme(key, silent)
    EnsureDB()
    if key ~= "treecko" then
        key = "teal"
    end
    db.wayTheme = key
    local theme = ApplyTheme()
    if not silent then
        if key == "treecko" then
            print(prefix .. ": arrow color set to |cff7ad64a" .. theme.name .. "|r.")
        else
            print(prefix .. ": arrow color set to |cff50e6d5" .. theme.name .. "|r.")
        end
    end
end

local function ToggleTreeckoMode()
    EnsureDB()
    if db.wayTheme == "treecko" then
        SetTheme("teal")
    else
        SetTheme("treecko")
    end
end

local function ReadXY(vector)
    if not vector then return nil end
    if type(vector.x) == "number" and type(vector.y) == "number" then
        return vector.x, vector.y
    end
    if type(vector.GetXY) == "function" then
        return vector:GetXY()
    end
    return nil
end

local function Hide(reason)
    lastIssue = reason
    marker:Hide()
end

local function UpdateWaypoint()
    if not C_Map or type(C_Map.GetUserWaypoint) ~= "function" then
        waypointID, targetContinent, targetWorldX, targetWorldY = nil, nil, nil, nil
        Hide("Waypoint API unavailable")
        return
    end

    local ok, point = pcall(C_Map.GetUserWaypoint)
    if not ok or not point then
        waypointID, waypointX, waypointY = nil, nil, nil
        targetContinent, targetWorldX, targetWorldY = nil, nil, nil
        Hide(ok and "No map pin set" or "Cannot read map pin")
        return
    end

    local good, mapID, x, y = pcall(function()
        local px, py = ReadXY(point.position)
        return point.uiMapID, px, py
    end)
    if not good or type(mapID) ~= "number" or type(x) ~= "number" or type(y) ~= "number" then
        waypointID, targetContinent, targetWorldX, targetWorldY = nil, nil, nil, nil
        Hide("Waypoint has no map coordinates")
        return
    end

    if mapID == waypointID and x == waypointX and y == waypointY and targetWorldX then
        return
    end
    waypointID, waypointX, waypointY = mapID, x, y
    targetContinent, targetWorldX, targetWorldY = nil, nil, nil

    if type(C_Map.GetWorldPosFromMapPos) ~= "function" then
        Hide("World-coordinate API unavailable")
        return
    end

    local converted, continent, pos = pcall(C_Map.GetWorldPosFromMapPos, mapID, point.position)
    if converted and continent and pos then
        local xyOK, wx, wy = pcall(ReadXY, pos)
        if xyOK and type(wx) == "number" and type(wy) == "number" then
            targetContinent, targetWorldX, targetWorldY = continent, wx, wy
            lastIssue = "Ready"
            return
        end
    end
    Hide("Pin map has no usable world coordinates")
end

local function ReadPlayerWorld()
    if not C_Map or not C_Map.GetBestMapForUnit or not C_Map.GetPlayerMapPosition
        or not C_Map.GetWorldPosFromMapPos then
        return nil, nil, "Player map APIs unavailable"
    end
    local playerMap = C_Map.GetBestMapForUnit("player")
    local function TryMap(id)
        if not id then return nil, nil end
        local pos = C_Map.GetPlayerMapPosition(id, "player")
        if not pos then return nil, nil end
        local continent, world = C_Map.GetWorldPosFromMapPos(id, pos)
        if not world or continent ~= targetContinent then return nil, nil end
        return ReadXY(world)
    end

    local x, y = TryMap(playerMap)
    if x and y then return x, y end
    if waypointID and waypointID ~= playerMap then
        x, y = TryMap(waypointID)
        if x and y then return x, y end
    end
    return nil, nil, "Different continent or position unavailable"
end

local function IsRotatingMinimap()
    if type(GetCVar) ~= "function" then return false end
    local good, value = pcall(GetCVar, "rotateMinimap")
    if not good or value ~= "1" then return false end
    if C_Minimap and type(C_Minimap.IsRotateMinimapIgnored) == "function" then
        local valid, ignored = pcall(C_Minimap.IsRotateMinimapIgnored)
        if valid and ignored then return false end
    end
    return true
end

local function GetVisibleYards()
    if C_Minimap and type(C_Minimap.GetViewRadius) == "function" then
        local valid, radius = pcall(C_Minimap.GetViewRadius)
        if valid and type(radius) == "number" and radius > 1 then
            return radius
        end
    end
    return nil
end

local function Enabled()
    return MeffortSuiteDB and MeffortSuiteDB.wayEnabled~=false
        and (not MeffortSuite or MeffortSuite.Active())
        and (not MeffortSuite or not MeffortSuite.StandaloneLoaded("MeffortWay"))
end

local function PointArrow()
    if not Enabled() then Hide("Disabled or standalone MeffortWay loaded"); return end
    if not targetWorldX then
        marker:Hide()
        return
    end
    local valid, px, py, reason = pcall(ReadPlayerWorld)
    if not valid or type(px) ~= "number" or type(py) ~= "number" then
        Hide(valid and (reason or "Player position unavailable") or "Player position restricted")
        return
    end

    local dx, dy = targetWorldX - px, targetWorldY - py
    local distance = math.sqrt(dx * dx + dy * dy)
    local angle = atan2(dy, dx) -- north = 0, west = +pi/2
    if IsRotatingMinimap() then
        local facingOK, facing = pcall(GetPlayerFacing)
        if not facingOK or type(facing) ~= "number" then
            Hide("Facing unavailable for rotating minimap")
            return
        end
        angle = angle - facing
    end
    angle = angle % PI2

    local ok = pcall(arrow.SetRotation, arrow, angle)
    if not ok then
        Hide("Arrow rotation unavailable")
        return
    end

    local width, height = Minimap:GetWidth(), Minimap:GetHeight()
    if not width or width <= 0 or not height or height <= 0 then
        Hide("Minimap dimensions unavailable")
        return
    end
    local ringRadius = math.min(width, height) * 0.47
    local yardsRadius = GetVisibleYards()
    local r = ringRadius
    if yardsRadius then
        r = ringRadius * math.min(distance / yardsRadius, 1)
    end
    local x = -math.sin(angle) * r
    local y =  math.cos(angle) * r
    marker:ClearAllPoints()
    marker:SetPoint("CENTER", Minimap, "CENTER", x, y)

    lastIssue = "Ready"
    lastDistance, lastBearing, lastRadius = distance, angle, yardsRadius
    marker:Show()
end

local controller = CreateFrame("Frame")
controller:RegisterEvent("PLAYER_LOGIN")
controller:RegisterEvent("PLAYER_ENTERING_WORLD")
controller:RegisterEvent("ZONE_CHANGED_NEW_AREA")
pcall(controller.RegisterEvent, controller, "USER_WAYPOINT_UPDATED")
controller:SetScript("OnEvent", function(self, event)
    if event == "PLAYER_LOGIN" then
        EnsureDB()
        RegisterWayCommand()
    end
    module.Refresh()
end)

local elapsedSincePoll, elapsedSincePinCheck = 0, 0
controller:SetScript("OnUpdate", function(self, elapsed)
    elapsedSincePoll = elapsedSincePoll + (elapsed or 0)
    elapsedSincePinCheck = elapsedSincePinCheck + (elapsed or 0)
    if elapsedSincePoll < 0.12 then return end
    elapsedSincePoll = 0
    if not Enabled() then
        if marker:IsShown() then Hide("Disabled or standalone MeffortWay loaded") end
        return
    end
    -- Slow polling recovers missed waypoint events without increasing movement work.
    if elapsedSincePinCheck >= 2 then
        elapsedSincePinCheck=0
        UpdateWaypoint()
    end
    if targetWorldX then PointArrow() end
end)

function module.Refresh()
    if not db then EnsureDB() end
    if not Enabled() then
        Hide("Disabled or standalone MeffortWay loaded")
        return
    end
    UpdateWaypoint()
    PointArrow()
end

function module.SetTheme(key, silent)
    SetTheme(key, silent)
    module.Refresh()
end

function module.ToggleTreecko()
    ToggleTreeckoMode()
    module.Refresh()
end

local function Finite(value)
    return not (issecretvalue and issecretvalue(value)) and type(value)=="number"
        and value==value and value~=math.huge and value~=-math.huge
end
local function Message(text) print(prefix..": "..text) end
local function Coordinate(token)
    if not token or not (token:match("^%d+%.?%d*$") or token:match("^%.%d+$")) then return end
    local value=tonumber(token)
    if Finite(value) and value>=0 and value<=100 then return value end
end
local function SelectedMap()
    if WorldMapFrame and type(WorldMapFrame.IsShown)=="function" and WorldMapFrame:IsShown() then
        if type(WorldMapFrame.GetMapID)=="function" then
            local ok,id=pcall(WorldMapFrame.GetMapID,WorldMapFrame)
            if ok and Finite(id) and id>0 and id==math.floor(id) then return id end
        end
        return
    end
    if C_Map and type(C_Map.GetBestMapForUnit)=="function" then
        local ok,id=pcall(C_Map.GetBestMapForUnit,"player")
        if ok and Finite(id) and id>0 and id==math.floor(id) then return id end
    end
end
local function MapID(value)
    return Finite(value) and value>0 and value==math.floor(value) and value or nil
end
local function ZoneKey(name)
    return name:gsub("^%s+",""):gsub("%s+$",""):gsub("%s+"," "):lower()
end
local function NamedMap(zone)
    if type(C_Map.GetMapInfo)~="function" then return nil,"Map names are unavailable in this client." end
    local explicit=zone:match("^#(%d+)$")
    if explicit then
        local id=MapID(tonumber(explicit))
        local ok,info=pcall(C_Map.GetMapInfo,id)
        if id and ok and type(info)=="table" then return id end
        return nil,"That map ID is unavailable."
    end
    if type(C_Map.GetMapChildrenInfo)~="function" then
        return nil,"Zone lookup is unavailable. Open the zone map and use /way x y."
    end
    local key=ZoneKey(zone)
    local matches,seen,roots={},{},{[0]=true}
    local function Add(info)
        if type(info)~="table" then return end
        local id=MapID(info.mapID)
        if not id or seen[id] then return end
        seen[id]=true
        if type(info.name)~="string" or ZoneKey(info.name)~=key then return end
        if type(C_Map.CanSetUserWaypointOnMap)=="function" then
            local ok,allowed=pcall(C_Map.CanSetUserWaypointOnMap,id)
            if not ok or (allowed~=true and allowed~=1) then return end
        end
        matches[#matches+1]=id
    end
    local function Root(start)
        local visited={}
        local id=MapID(start)
        for _=1,32 do
            if not id or visited[id] then break end
            visited[id]=true
            local ok,info=pcall(C_Map.GetMapInfo,id)
            if not ok or type(info)~="table" then break end
            Add(info)
            roots[id]=true
            local parent=MapID(info.parentMapID)
            if not parent then return end
            roots[id]=nil
            id=parent
        end
    end
    Root(SelectedMap())
    if type(C_Map.GetBestMapForUnit)=="function" then
        local ok,id=pcall(C_Map.GetBestMapForUnit,"player")
        if ok then Root(id) end
    end
    -- Native ancestry finds the client world root without fixed expansion-specific IDs.
    local readAny=false
    local queue={}
    for root in pairs(roots) do queue[#queue+1]=root end
    local head=1
    while queue[head] do
        local root=queue[head];head=head+1
        local ok,list=pcall(C_Map.GetMapChildrenInfo,root,nil,true)
        if ok and type(list)=="table" then
            readAny=true
            for _,info in ipairs(list) do
                Add(info)
                if type(info)=="table" and info.parentMapID==0 then
                    local id=MapID(info.mapID)
                    if id and not roots[id] then roots[id]=true;queue[#queue+1]=id end
                end
            end
        end
    end
    if #matches==1 then return matches[1] end
    if #matches>1 then
        table.sort(matches)
        local options={}
        for i=1,math.min(#matches,6) do options[#options+1]="#"..matches[i] end
        return nil,"Several maps are named '"..zone.."'. Use /way #mapID x y: "..table.concat(options,", ").."."
    end
    return nil,readAny and ("Zone '"..zone.."' was not found or does not support pins. Use the zone name shown by your client.")
        or "Map names are not ready. Open the zone map and try again."
end
function module.SetCoordinates(text)
    EnsureDB()
    if MeffortSuite and not MeffortSuite.Active() then
        Message("Enable MeffortSuite before setting a waypoint.");return false
    end
    local parts={}
    for token in (text or ""):gsub(","," "):gmatch("%S+") do parts[#parts+1]=token end
    local first,second=parts[#parts-1],parts[#parts]
    local x,y=Coordinate(first),Coordinate(second)
    if not x or not y then
        Message("Use /way [zone name] x y, for example /way Hillsbrad Foothills 87.3 49.6. Coordinates must be 0 to 100.");return false
    end
    if not C_Map or type(C_Map.SetUserWaypoint)~="function" or not UiMapPoint
        or type(UiMapPoint.CreateFromCoordinates)~="function" then
        Message("Native map pins are unavailable in this client.");return false
    end
    local zone=#parts>2 and table.concat(parts," ",1,#parts-2) or nil
    if zone and ((zone:sub(1,1)=='"' and zone:sub(-1)=='"') or
        (zone:sub(1,1)=="'" and zone:sub(-1)=="'")) then zone=zone:sub(2,-2) end
    local mapID,lookupError
    if zone then mapID,lookupError=NamedMap(zone) else mapID=SelectedMap() end
    if lookupError then Message(lookupError);return false end
    if not mapID then Message("No usable map is available. Open a zone map and try again.");return false end
    if type(C_Map.CanSetUserWaypointOnMap)=="function" then
        local ok,allowed=pcall(C_Map.CanSetUserWaypointOnMap,mapID)
        if not ok or (allowed~=true and allowed~=1) then
            Message("This map does not support pins. Open a supported zone map and try again.");return false
        end
    end
    local made,point=pcall(UiMapPoint.CreateFromCoordinates,mapID,x/100,y/100)
    if not made or not point then Message("The client could not create the map pin.");return false end
    local ok,wasSet=pcall(C_Map.SetUserWaypoint,point)
    if ok and wasSet==nil and type(C_Map.GetUserWaypoint)=="function" then
        local read,current=pcall(C_Map.GetUserWaypoint)
        local coords,id,cx,cy=pcall(function()
            local px,py=ReadXY(current and current.position)
            return current and current.uiMapID,px,py
        end)
        wasSet=read and coords and id==mapID and Finite(cx) and Finite(cy)
            and math.abs(cx-x/100)<.000001 and math.abs(cy-y/100)<.000001
    end
    if not ok or (wasSet~=true and wasSet~=1) then
        Message("The client could not set that waypoint.");return false
    end
    module.Refresh()
    local name
    if type(C_Map.GetMapInfo)=="function" then
        local read,info=pcall(C_Map.GetMapInfo,mapID)
        if read and type(info)=="table" and type(info.name)=="string" then name=info.name end
    end
    Message(string.format("Waypoint set: %.2f, %.2f",x,y)..(name and (" ("..name..").") or "."))
    return true
end
RegisterWayCommand=function()
    if type(SlashCmdList)~="table" then return end
    for key,value in pairs(_G) do
        if type(key)=="string" and key:match("^SLASH_.+%d+$") and type(value)=="string"
            and value:lower()=="/way" then return end
    end
    SLASH_MEFFORTSUITEWAY1="/way"
    SlashCmdList.MEFFORTSUITEWAY=module.Command
end

function module.Command(msg)
    msg = (msg or ""):lower():match("^%s*(.-)%s*$")
    EnsureDB()
    if msg == "on" or msg == "off" then
        db.wayEnabled=(msg=="on")
        module.Refresh()
        print(prefix..": waypoint arrow "..(db.wayEnabled and "enabled" or "disabled")..".")
    elseif msg == "252" then
        module.ToggleTreecko()
    elseif msg == "treecko" or msg == "teal" then
        module.SetTheme(msg)
    elseif msg == "status" or msg == "debug" then
        print(prefix .. " | interface=" .. tostring(select(4, GetBuildInfo())) .. " theme=" .. tostring(db.wayTheme))
        print(" pin=" .. tostring(waypointID) .. " x=" .. tostring(waypointX) .. " y=" .. tostring(waypointY) .. " continent=" .. tostring(targetContinent))
        print(" dist=" .. tostring(lastDistance) .. " bearing=" .. tostring(lastBearing) .. " minimapRadiusYd=" .. tostring(lastRadius))
        print(" state=" .. tostring(lastIssue) .. " visible=" .. tostring(marker:IsShown()) .. " rotatingMap=" .. tostring(IsRotatingMinimap()))
    elseif msg~="" and msg~="help" then
        return module.SetCoordinates(msg)
    else
        print(prefix .. ": /way [zone name] x y sets a map pin. Without a zone, it uses the open map or your current zone. /msuite way also supports coordinates; on|off|teal|treecko|252|status.")
    end
end
