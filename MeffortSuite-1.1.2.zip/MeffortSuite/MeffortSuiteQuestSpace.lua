-- One restricted owner permits binding cleanup on combat entry and dialogue hide.
local owner
local secureReady=false
local controllerAttempted=false
local addon={}
MeffortSuiteQuestSpace=addon
local activeMode=nil
local boundSignature=nil
local warningShown=false
local hooks=setmetatable({},{__mode="k"})
local menuChoices={}
local spaceChoice
local menuButtons={}
local MAX_CHOICES=200

local function InCombat() return InCombatLockdown and InCombatLockdown() end
local function Secret(v) return issecretvalue and issecretvalue(v) end
local function Number(v)
    if not Secret(v) and type(v)=="number" and v==v and v~=math.huge and v~=-math.huge then return v end
end
local function Text(v) if not Secret(v) and type(v)=="string" then return v end end
local function Boolean(v)
    if Secret(v) then return nil end
    if v==true or v==1 then return true end
    if v==false or v==0 then return false end
end
local function Visible(f)
    if not f then return false end
    if f.IsVisible then local ok,v=pcall(f.IsVisible,f);if ok then return Boolean(v)==true end end
    if f.IsShown then local ok,v=pcall(f.IsShown,f);if ok then return Boolean(v)==true end end
    return false
end
local function Enabled(f)
    if not Visible(f) then return false end
    if f.IsEnabled then local ok,v=pcall(f.IsEnabled,f);return ok and Boolean(v)==true end
    return true
end
local function Configured()
    return type(MeffortSuiteDB)=="table" and MeffortSuiteDB.masterEnabled~=false
        and (not MeffortSuite or not MeffortSuite.StandaloneLoaded("MeffortBars"))
        and MeffortSuiteDB.questSpace==true
end
local function Warn(message)
    if warningShown then return end
    warningShown=true
    if DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then
        DEFAULT_CHAT_FRAME:AddMessage("|cff60d9bdMeffortSuite|r: "..message)
    end
end
local function Add(list,kind,id,title,ready)
    id=Number(id)
    if #list>=MAX_CHOICES or not id or id<1 or id~=math.floor(id) then return end
    list[#list+1]={kind=kind,id=id,title=Text(title) or "Option",ready=ready==true}
end
local function PreferredIndex(choices)
    local selected,rank
    for i,choice in ipairs(choices) do
        local priority=4
        if choice.kind=="gossipAvailable" or choice.kind=="greetingAvailable" then
            priority=1
        elseif choice.kind=="gossipActive" or choice.kind=="greetingActive" then
            priority=choice.ready and 2 or 3
        end
        if not rank or priority<rank then selected,rank=i,priority end
    end
    return selected
end

local function GossipChoices()
    if not Visible(GossipFrame) or not C_GossipInfo then return {} end
    local result={}
    local function Get(functionName)
        local fn=C_GossipInfo[functionName]
        if type(fn)~="function" then return {} end
        local ok,list=pcall(fn)
        return ok and not Secret(list) and type(list)=="table" and list or {}
    end
    if type(C_GossipInfo.SelectActiveQuest)=="function" then
        for _,entry in ipairs(Get("GetActiveQuests")) do
            if not Secret(entry) and type(entry)=="table" and Boolean(entry.isIgnored)~=true then
                Add(result,"gossipActive",entry.questID,entry.title,Boolean(entry.isComplete))
            end
        end
    end
    if type(C_GossipInfo.SelectAvailableQuest)=="function" then
        for _,entry in ipairs(Get("GetAvailableQuests")) do
            if not Secret(entry) and type(entry)=="table" and Boolean(entry.isIgnored)~=true then
                Add(result,"gossipAvailable",entry.questID,entry.title,false)
            end
        end
    end
    if type(C_GossipInfo.SelectOption)=="function" then
        for _,entry in ipairs(Get("GetOptions")) do
            if not Secret(entry) and type(entry)=="table" then
                local status=Number(entry.status)
                if status==nil or status==0 then
                    Add(result,"gossipOption",entry.gossipOptionID,entry.name,false)
                end
            end
        end
    end
    return result
end

local function GreetingChoices()
    if not Visible(QuestFrameGreetingPanel) then return {} end
    if not GetNumActiveQuests or not GetNumAvailableQuests then return {} end
    local okA,active=pcall(GetNumActiveQuests)
    local okB,available=pcall(GetNumAvailableQuests)
    if not okA or not okB or not Number(active) or not Number(available) then return {} end
    local result={}
    if type(GetActiveTitle)=="function" and type(SelectActiveQuest)=="function" then
        for i=1,math.min(40,active) do
            local ok,title,complete=pcall(GetActiveTitle,i)
            if ok and Text(title) then
                Add(result,"greetingActive",i,title,Boolean(complete))
            end
        end
    end
    if type(SelectAvailableQuest)=="function" then
        for i=1,math.min(40,available) do
            local title
            if type(GetAvailableTitle)=="function" then
                local ok,value=pcall(GetAvailableTitle,i)
                if ok then title=Text(value) end
            end
            if not title and type(GetAvailableQuestInfo)=="function" then
                local ok,value=pcall(GetAvailableQuestInfo,i)
                if ok then title=Text(value) end
            end
            Add(result,"greetingAvailable",i,title or "Available quest",false)
        end
    end
    return result
end

local function MenuChoices()
    -- Visible panels take precedence over stale quest-event state.
    if Visible(GossipFrame) then return GossipChoices() end
    if Visible(QuestFrameGreetingPanel) then return GreetingChoices() end
    return {}
end
local function SelectChoice(choice)
    if not choice or not Configured() or InCombat() then return end
    if not (Visible(GossipFrame) or Visible(QuestFrameGreetingPanel)) then return end
    local selections={
        gossipActive=C_GossipInfo and C_GossipInfo.SelectActiveQuest,
        gossipAvailable=C_GossipInfo and C_GossipInfo.SelectAvailableQuest,
        gossipOption=C_GossipInfo and C_GossipInfo.SelectOption,
        greetingActive=SelectActiveQuest,
        greetingAvailable=SelectAvailableQuest,
    }
    local fn=selections[choice.kind]
    if type(fn)=="function" then
        local ok=pcall(fn,choice.id)
        if not ok then Warn("The client refused a quest-menu selection.") end
    end
end
local function MakeProxy(index)
    local name=index and ("MeffortSuiteQuestMenuKey"..index) or "MeffortSuiteQuestSpaceKey"
    local f=CreateFrame("Button",name,UIParent)
    if not f then return end
    if f.Show then f:Show() end
    if f.SetScript then
        f:SetScript("OnClick",function()
            local displayed=spaceChoice
            if index then displayed=menuChoices[index] end
            if not displayed then return end
            local current=MenuChoices()
            local fresh
            if index then fresh=current[index] else fresh=current[PreferredIndex(current)] end
            if not fresh or fresh.kind~=displayed.kind or fresh.id~=displayed.id then
                addon.Refresh()
                return
            end
            SelectChoice(fresh)
        end)
    end
    return name
end
for i=1,9 do menuButtons[i]=MakeProxy(i) end
local spaceButton=MakeProxy()

local badges={}
local ownedRegions={}
local RestoreGutters
local badgeCount=0
local inlineTicker=CreateFrame("Frame")
local inlineElapsed=0
local inlineStatus={choices=0,discovered=0,matched=0,shown=0,reason="not refreshed",layout="none"}
function addon.InlineStatus()
    local result={}
    for key,value in pairs(inlineStatus) do result[key]=value end
    result.configured=Configured()==true
    result.master=type(MeffortSuiteDB)~="table" or MeffortSuiteDB.masterEnabled~=false
    result.standalone=MeffortSuite and type(MeffortSuite.StandaloneLoaded)=="function"
        and MeffortSuite.StandaloneLoaded("MeffortBars")==true or false
    result.secureReady=secureReady
    return result
end
local function Field(object,key)
    if not object or Secret(object) then return end
    local ok,value=pcall(function()return object[key]end)
    if ok and not Secret(value) then return value end
end
local function Call(object,key,...)
    local fn=Field(object,key)
    if type(fn)~="function" then return end
    local ok,value=pcall(fn,object,...)
    if ok and not Secret(value) then return value end
end
local MAX_SCAN=400
local function Results(object,key)
    local fn=Field(object,key)
    if type(fn)~="function" then return {} end
    local function Pack(...)return {n=select("#",...),...}end
    local result=Pack(pcall(fn,object))
    local values={}
    if not result[1] then return values end
    for i=2,math.min(result.n,MAX_SCAN+1) do
        local value=result[i]
        if value and not Secret(value) then values[#values+1]=value end
    end
    return values
end
local function ClearBadge(badge)
    -- Clear addon-owned text without hiding protected frames.
    badge.number:SetText("")
end
local function HideBadges()
    for _,badge in pairs(badges) do ClearBadge(badge) end
end
local function StopInline(reason)
    inlineTicker:SetScript("OnUpdate",nil)
    inlineElapsed=0
    HideBadges()
    if RestoreGutters then RestoreGutters() end
    inlineStatus.shown=0
    inlineStatus.positioned=0
    if reason then inlineStatus.reason=reason end
end
local function CleanTitle(value)
    value=Text(value)
    if not value then return end
    return value:gsub("|c%x%x%x%x%x%x%x%x",""):gsub("|r","")
        :gsub("|T.-|t",""):gsub("|A.-|a",""):gsub("%s+"," "):match("^%s*(.-)%s*$")
end
local function Kind(value,scope)
    if type(value)=="number" then
        if value==(GOSSIP_BUTTON_TYPE_OPTION or 3) then return "gossipOption" end
        if value==(GOSSIP_BUTTON_TYPE_ACTIVE_QUEST or 4) then return "gossipActive" end
        if value==(GOSSIP_BUTTON_TYPE_AVAILABLE_QUEST or 5) then return "gossipAvailable" end
    end
    value=Text(value)
    if not value then return end
    value=value:lower()
    if value=="active" or value=="activequest" then return scope.."Active" end
    if value=="available" or value=="availablequest" then return scope.."Available" end
    if scope=="gossip" and (value=="gossip" or value=="option") then return "gossipOption" end
end
local function RowTitle(row,choices)
    local title=CleanTitle(Call(row,"GetText") or Call(Call(row,"GetFontString"),"GetText"))
    if title and title~="" then return title end
    for _,key in ipairs({"Text","text"}) do
        local label=Field(row,key)
        title=CleanTitle(Text(label) or Call(label,"GetText"))
        if title and title~="" then return title end
    end
    local name=Text(Call(row,"GetName"))
    if name then
        title=CleanTitle(Call(_G[name.."Text"],"GetText"))
        if title and title~="" then return title end
    end
    local found
    for _,region in ipairs(Results(row,"GetRegions")) do
        local text=not ownedRegions[region] and CleanTitle(Call(region,"GetText")) or nil
        if text and text~="" then
            for _,choice in ipairs(choices) do
                if CleanTitle(choice.title)==text then
                    if found and found~=text then return end
                    found=text
                end
            end
        end
    end
    return found
end
local function MatchRow(row,scope,choices,legacy,discovered)
    local data=Call(row,"GetElementData") or Field(row,"elementData")
    if type(data)~="table" then data=nil end
    local info=data and Field(data,"info")
    if type(info)~="table" then info=data end
    local kind=Kind(data and Field(data,"buttonType"),scope) or Kind(Field(row,"type"),scope)
    if scope=="greeting" then
        local active=Boolean(Field(row,"isActive"))
        if active~=nil then kind=active and "greetingActive" or "greetingAvailable" end
    end
    local optionID=Number(info and Field(info,"gossipOptionID")) or Number(Field(row,"gossipOptionID"))
    local questID=scope=="gossip" and
        (Number(info and Field(info,"questID")) or Number(Field(row,"questID"))) or nil
    local explicitID=optionID or questID
    if not legacy and not data and not kind and not explicitID then return end
    local id=explicitID or Number(Call(row,"GetID"))
    local title=RowTitle(row,choices)
    local function Compatible(choice)
        return choice.kind:sub(1,#scope)==scope and (not kind or choice.kind==kind)
            and (not optionID or choice.kind=="gossipOption")
            and (not questID or choice.kind~="gossipOption")
    end
    local found
    if id then
        for index,choice in ipairs(choices) do
            if Compatible(choice) and choice.id==id and
                (explicitID or (not discovered and not title) or CleanTitle(choice.title)==title) then
                if found then return end
                found=index
            end
        end
        if found then return found end
        if explicitID then return end
    end
    if not title or title=="" or not (legacy or kind) then return end
    for index,choice in ipairs(choices) do
        if Compatible(choice) and CleanTitle(choice.title)==title then
            if found then return end
            found=index
        end
    end
    return found
end
local function Enumerate(container,method,add)
    local fn=Field(container,method)
    if type(fn)~="function" then return end
    local ok,iterator,state,key=pcall(fn,container)
    if not ok or type(iterator)~="function" then return end
    for _=1,MAX_CHOICES do
        local got,a,b=pcall(iterator,state,key)
        if not got or a==nil then return end
        key=a
        local candidate=(type(a)=="table" or type(a)=="userdata") and a or b
        add(candidate)
    end
end
local function Frames(container,add)
    local frames=Call(container,"GetFrames")
    if type(frames)=="table" and not Secret(frames) then
        for i=1,math.min(#frames,MAX_SCAN) do add(frames[i]) end
    end
    Enumerate(container,"EnumerateFrames",add)
end
local function Rect(object)
    local fn=Field(object,"GetRect")
    if type(fn)~="function" then return end
    local ok,left,bottom,width,height=pcall(fn,object)
    left,bottom,width,height=Number(left),Number(bottom),Number(width),Number(height)
    if ok and left and bottom and width and height and width>0 and height>0 then
        return left,bottom,width,height
    end
end
local function IsButton(row)
    return Boolean(Call(row,"IsObjectType","Button"))==true
        or Text(Call(row,"GetObjectType"))=="Button"
        or Text(Call(row,"GetObjectType"))=="CheckButton"
end
local function InViewport(row,viewport)
    if not viewport then return true end
    local top,bottom=Number(Call(row,"GetTop")),Number(Call(row,"GetBottom"))
    local upper,lower=Number(Call(viewport,"GetTop")),Number(Call(viewport,"GetBottom"))
    if not top or not bottom or not upper or not lower then return true end
    local rowScale=Number(Call(row,"GetEffectiveScale")) or 1
    local viewScale=Number(Call(viewport,"GetEffectiveScale")) or 1
    local center=(top+bottom)*rowScale/2
    return center<=upper*viewScale and center>=lower*viewScale
end
local GUTTER_WIDTH=24
local gutterRows={}
local gutterViews={}
local gutterFailures={}
local function Near(a,b)
    return a and b and math.abs(a-b)<=.05
end
local horizontalFraction={LEFT=0,TOPLEFT=0,BOTTOMLEFT=0,CENTER=.5,TOP=.5,BOTTOM=.5,
    RIGHT=1,TOPRIGHT=1,BOTTOMRIGHT=1}
local function Region(value)
    if type(value)=="table" or type(value)=="userdata" then return value end
end
local function ResolveIcon(row)
    local icon=Region(Field(row,"Icon")) or Region(Field(row,"icon"))
    if icon then return icon end
    local name=Text(Call(row,"GetName"))
    if name then
        return Region(_G[name.."QuestIcon"]) or Region(_G[name.."Icon"])
            or Region(_G[name.."GossipIcon"])
    end
end
local function Anchors(region,row)
    local count=Number(Call(region,"GetNumPoints"))
    if not count or count<1 or count>4 or count~=math.floor(count) then return end
    local fn=Field(region,"GetPoint")
    if type(fn)~="function" then return end
    local points={}
    for i=1,count do
        local ok,point,relative,relativePoint,x,y=pcall(fn,region,i)
        point,relativePoint,x,y=Text(point),Text(relativePoint),Number(x),Number(y)
        if not ok or horizontalFraction[point]==nil or horizontalFraction[relativePoint]==nil
            or not x or not y
            or not (relative==row or (relative==nil and Call(region,"GetParent")==row)) then return end
        points[i]={point,relative,relativePoint,x,y}
    end
    return points
end
local function SameAnchors(region,row,expected)
    local current=Anchors(region,row)
    if not current or #current~=#expected then return false end
    for i,point in ipairs(current) do
        for j=1,5 do
            local actual,wanted=point[j],expected[i][j]
            if j==2 then actual,wanted=actual or row,wanted or row end
            if j==4 or j==5 then
                if not Near(actual,wanted) then return false end
            elseif actual~=wanted then return false end
        end
    end
    return true
end
local function PutAnchors(region,points)
    region:ClearAllPoints()
    for _,point in ipairs(points) do
        region:SetPoint(point[1],point[2],point[3],point[4],point[5])
    end
end
local function ShiftedAnchors(points,narrowed,direction)
    local shifted={}
    for i,point in ipairs(points) do
        local offset=(direction or 1)*GUTTER_WIDTH*(narrowed and (1-horizontalFraction[point[1]]) or 1)
        shifted[i]={point[1],point[2],point[3],point[4]+offset,point[5]}
    end
    return shifted
end
local function LeftEdge(points,width,rowWidth)
    local left
    for _,point in ipairs(points) do
        local value=rowWidth*horizontalFraction[point[3]]+point[4]-width*horizontalFraction[point[1]]
        if left and math.abs(value-left)>1 then return end
        left=value
    end
    return left
end
local function HorizontalMatch(current,expected)
    if not current then return false end
    for _,point in ipairs(current) do
        local found=false
        for _,wanted in ipairs(expected) do
            if horizontalFraction[point[1]]==horizontalFraction[wanted[1]]
                and horizontalFraction[point[3]]==horizontalFraction[wanted[3]]
                and Near(point[4],wanted[4]) then found=true;break end
        end
        if not found then return false end
    end
    return true
end
local function RestoreAnchors(region,row,applied,original,narrowed)
    if SameAnchors(region,row,applied) then
        pcall(PutAnchors,region,original)
        return
    end
    local current=Anchors(region,row)
    if HorizontalMatch(current,applied) then
        -- Native setup can change vertical anchors after the inset was applied.
        pcall(PutAnchors,region,ShiftedAnchors(current,narrowed,-1))
    end
end
local function RestoreRowGutter(row,state,partial)
    if partial then
        -- A rejected SetPoint may leave no anchors to compare; roll back the attempted inset.
        pcall(PutAnchors,state.icon,state.iconOriginal)
        pcall(PutAnchors,state.caption,state.captionOriginal)
        pcall(state.caption.SetWidth,state.caption,state.width)
        Call(row,"Resize")
        return
    end
    local restoreWidth=Near(Number(Call(state.caption,"GetWidth")),state.appliedWidth)
    RestoreAnchors(state.icon,row,state.iconShifted,state.iconOriginal,false)
    RestoreAnchors(state.caption,row,state.captionShifted,state.captionOriginal,true)
    if restoreWidth then pcall(state.caption.SetWidth,state.caption,state.width);Call(row,"Resize") end
end
local function PrepareGutter(row,allowReflow)
    if InCombat() then return false,"combat" end
    if not row or Boolean(Call(row,"IsForbidden"))==true then return false,"unavailable row" end
    local icon=ResolveIcon(row)
    local caption=Region(Call(row,"GetFontString"))
    if not icon then return false,"native icon missing" end
    if not caption then return false,"native caption missing" end
    local state=gutterRows[row]
    if state then
        local captionText=Text(Call(caption,"GetText"))
        if state.icon==icon and state.caption==caption and SameAnchors(icon,row,state.iconShifted)
            and SameAnchors(caption,row,state.captionShifted)
            and Near(Number(Call(caption,"GetWidth")),state.appliedWidth)
            and (allowReflow or (state.allowReflow==false and captionText
                and captionText==state.captionText)) then return true end
        RestoreRowGutter(row,state)
        gutterRows[row]=nil
    end
    local iconPoints,captionPoints=Anchors(icon,row),Anchors(caption,row)
    if not iconPoints then return false,"unsupported icon anchors" end
    if not captionPoints then return false,"unsupported caption anchors" end
    local width=Number(Call(caption,"GetWidth"))
    local rowWidth=Number(Call(row,"GetWidth"))
    local iconWidth=Number(Call(icon,"GetWidth"))
    if not width or width<=GUTTER_WIDTH*2 or not rowWidth or rowWidth<=0
        or not iconWidth or iconWidth<=0 then return false,"invalid native widths" end
    local iconLeft=LeftEdge(iconPoints,iconWidth,rowWidth)
    local captionLeft=LeftEdge(captionPoints,width,rowWidth)
    if not iconLeft then return false,"inconsistent icon anchors" end
    if not captionLeft then return false,"inconsistent caption anchors" end
    if iconLeft<-.05 then return false,"negative icon offset" end
    if captionLeft<-.05 then return false,"negative caption offset" end
    local oldHeight=Number(Call(caption,"GetStringHeight"))
    if not allowReflow and not oldHeight then return false,"caption height unavailable" end
    if allowReflow and type(Field(row,"Resize"))~="function" then return false,"native resize unavailable" end
    state={icon=icon,caption=caption,width=width,appliedWidth=width-GUTTER_WIDTH,allowReflow=allowReflow==true,
        captionText=Text(Call(caption,"GetText")),
        iconOriginal=iconPoints,captionOriginal=captionPoints,
        iconShifted=ShiftedAnchors(iconPoints,false),captionShifted=ShiftedAnchors(captionPoints,true)}
    local ok=pcall(function()
        PutAnchors(icon,state.iconShifted)
        PutAnchors(caption,state.captionShifted)
        caption:SetWidth(width-GUTTER_WIDTH)
        -- Native initializers run after extent layout; resize new rows at the same text width.
        if allowReflow then row:Resize() end
    end)
    if not ok then RestoreRowGutter(row,state,true);return false,"native inset rejected" end
    local appliedIcon,appliedCaption=Anchors(icon,row),Anchors(caption,row)
    local appliedWidth=Number(Call(caption,"GetWidth"))
    if not appliedIcon or not appliedCaption or not appliedWidth or appliedWidth<=0 then
        RestoreRowGutter(row,state,true)
        return false,"native inset readback unavailable"
    end
    state.iconShifted,state.captionShifted,state.appliedWidth=appliedIcon,appliedCaption,appliedWidth
    if not allowReflow then
        local newHeight=Number(Call(caption,"GetStringHeight"))
        if not newHeight or newHeight>oldHeight then
            RestoreRowGutter(row,state,true)
            return false,"caption needs measured reflow"
        end
    end
    gutterRows[row]=state
    return true
end
local function HasMeasuredGutter(row)
    local data=Call(row,"GetElementData") or Field(row,"elementData")
    local prototype=Field(data,"titleOptionButton") or Field(data,"availableQuestButton")
        or Field(data,"activeQuestButton")
    local state=prototype and gutterRows[prototype]
    return state and state.icon==ResolveIcon(prototype)
        and state.caption==Call(prototype,"GetFontString")
        and SameAnchors(state.icon,prototype,state.iconShifted)
        and SameAnchors(state.caption,prototype,state.captionShifted)
        and Near(Number(Call(state.caption,"GetWidth")),state.appliedWidth)
end
local function PrepareGutterView(scroll)
    if InCombat() then return false,"combat" end
    local view=Call(scroll,"GetView")
    local calculator=Call(view,"GetElementExtentCalculator")
    if type(calculator)~="function" or type(Field(view,"SetElementExtentCalculator"))~="function"
        or type(Field(scroll,"FullUpdate"))~="function" then return false,"scroll measurement API unavailable" end
    if gutterFailures[view]==calculator then return false,"scroll measurement refresh failed" end
    local current=gutterViews[scroll]
    if current and current.view==view and current.wrapper==calculator then return true end
    if current then
        current.enabled=false
        if Call(current.view,"GetElementExtentCalculator")==current.wrapper then
            pcall(current.view.SetElementExtentCalculator,current.view,current.original)
        end
    end
    local existingRows={}
    for row in pairs(gutterRows) do existingRows[row]=true end
    local state={view=view,original=calculator,enabled=true}
    state.wrapper=function(index,data)
        if state.enabled and Configured() and not InCombat() and type(data)=="table" then
            local prototype=Field(data,"titleOptionButton") or Field(data,"availableQuestButton")
                or Field(data,"activeQuestButton")
            if prototype then PrepareGutter(prototype,true) end
        end
        return calculator(index,data)
    end
    local ok=pcall(function()
        view:SetElementExtentCalculator(state.wrapper)
        scroll:FullUpdate(true)
    end)
    if not ok then
        state.enabled=false
        for row,saved in pairs(gutterRows) do
            if not existingRows[row] then RestoreRowGutter(row,saved);gutterRows[row]=nil end
        end
        if Call(view,"GetElementExtentCalculator")==state.wrapper then
            pcall(view.SetElementExtentCalculator,view,calculator)
        end
        gutterFailures[view]=calculator
        Call(scroll,"FullUpdate",true)
        gutterViews[scroll]=nil
        return false,"scroll measurement refresh failed"
    end
    gutterViews[scroll]=state
    return true
end
RestoreGutters=function()
    if InCombat() then return false end
    for row,state in pairs(gutterRows) do RestoreRowGutter(row,state);gutterRows[row]=nil end
    for scroll,state in pairs(gutterViews) do
        state.enabled=false
        if Call(state.view,"GetElementExtentCalculator")==state.wrapper then
            pcall(state.view.SetElementExtentCalculator,state.view,state.original)
            if Visible(scroll) then Call(scroll,"FullUpdate",true) end
        end
        gutterViews[scroll]=nil
    end
    gutterFailures={}
    return true
end
local function BadgeFor(row)
    if badges[row] then return badges[row] end
    badgeCount=badgeCount+1
    local name="MeffortSuiteQuestInlineKey"..badgeCount
    local number=row:CreateFontString(name,"OVERLAY","GameFontNormal")
    ownedRegions[number]=true
    number:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",11,"OUTLINE")
    number:SetSize(22,20)
    number:SetWordWrap(false)
    number:SetNonSpaceWrap(false)
    number:SetMaxLines(1)
    number:SetTextColor(1,.82,.28,1)
    number:SetJustifyH("LEFT");number:SetJustifyV("MIDDLE")
    number:SetShadowColor(0,0,0,1);number:SetShadowOffset(1,-1)
    number:SetPoint("LEFT",row,"LEFT",2,0)
    local badge={number=number}
    badges[row]=badge
    if type(Field(row,"HookScript"))=="function" and Call(row,"HasScript","OnHide")~=false then
        pcall(row.HookScript,row,"OnHide",function()ClearBadge(badge)end)
    end
    return badge
end
local function UpdateInline(choices)
    inlineStatus.choices=#choices
    inlineStatus.discovered,inlineStatus.visible,inlineStatus.matched,inlineStatus.shown=0,0,0,0
    inlineStatus.positioned,inlineStatus.duplicates,inlineStatus.unpositioned=0,0,0
    inlineStatus.fallbacks,inlineStatus.skipReason=0,nil
    inlineStatus.measurementReason=nil
    inlineStatus.containers,inlineStatus.scanned=0,0
    inlineStatus.layout,inlineStatus.reason="none","scanning"
    inlineStatus.render="left key column"
    inlineStatus.error=nil
    if InCombat() then StopInline("combat");return end
    if not Configured() then StopInline("disabled or standalone owner");return end
    if #choices==0 then StopInline("no menu choices");return end
    HideBadges()
    local scope,root
    if Visible(GossipFrame) then scope,root="gossip",GossipFrame
    elseif Visible(QuestFrameGreetingPanel) then scope,root="greeting",QuestFrameGreetingPanel end
    if not root then StopInline("NPC menu hidden");return end
    local selected=PreferredIndex(choices)
    local gutterViewReady=false
    local seen,usedChoices={},{}
    local function AddRow(row,viewport,legacy)
        if not row or Secret(row) or (type(row)~="table" and type(row)~="userdata") or seen[row] then return end
        seen[row]=true
        if Boolean(Call(row,"IsForbidden"))==true or not IsButton(row) then return end
        inlineStatus.discovered=inlineStatus.discovered+1
        if not Enabled(row) or not InViewport(row,viewport) then return end
        inlineStatus.visible=inlineStatus.visible+1
        if not Rect(row) then inlineStatus.unpositioned=inlineStatus.unpositioned+1;return end
        local index=MatchRow(row,scope,choices,legacy,true)
        if not index then return end
        if usedChoices[index] then inlineStatus.duplicates=inlineStatus.duplicates+1;return end
        usedChoices[index]=true
        inlineStatus.matched=inlineStatus.matched+1
        local measured=viewport and gutterViewReady and HasMeasuredGutter(row) or false
        local placed,reason=PrepareGutter(row,measured)
        if not placed then
            inlineStatus.unpositioned=inlineStatus.unpositioned+1
            inlineStatus.skipReason=inlineStatus.skipReason or reason or "unsupported native layout"
            return
        end
        if viewport and not measured then inlineStatus.fallbacks=inlineStatus.fallbacks+1 end
        if index>9 and index~=selected then return end
        local badge=BadgeFor(row)
        local number=badge.number
        number:SetText(index<=9 and (tostring(index)..(index==selected and "*" or "")) or "*")
        inlineStatus.shown=inlineStatus.shown+1
        if Rect(number) then inlineStatus.positioned=inlineStatus.positioned+1 end
    end
    local greeting=Field(root,"GreetingPanel")
    if type(greeting)~="table" and type(greeting)~="userdata" then greeting=nil end
    local scroll=Field(greeting,"ScrollBox") or Field(root,"ScrollBox")
    if type(scroll)~="table" and type(scroll)~="userdata" then scroll=nil end
    local function Scan(container,viewport)
        local queue={{frame=container,depth=0}}
        local visited,head={},1
        while queue[head] and inlineStatus.scanned<MAX_SCAN do
            local item=queue[head];head=head+1
            local object=item.frame
            if object and not visited[object] then
                visited[object]=true;inlineStatus.scanned=inlineStatus.scanned+1
                if Boolean(Call(object,"IsForbidden"))~=true and Visible(object) then
                    local name=Text(Call(object,"GetName")) or ""
                    local control=object==Field(root,"CloseButton") or object==Field(greeting,"GoodbyeButton")
                        or name=="GossipFrameCloseButton" or name=="QuestFrameGoodbyeButton"
                    if not control and not name:match("^MeffortSuite") then
                        if IsButton(object) then AddRow(object,viewport,true) end
                        if item.depth<8 then
                            for _,child in ipairs(Results(object,"GetChildren")) do
                                if #queue<MAX_SCAN then queue[#queue+1]={frame=child,depth=item.depth+1} end
                            end
                        end
                    end
                end
            end
        end
    end
    if scroll then
        inlineStatus.containers=1
        gutterViewReady,inlineStatus.measurementReason=PrepareGutterView(scroll)
        local count=0
        local function AddNative(row)
            if row and not seen[row] then count=count+1 end
            AddRow(row,scroll,true)
        end
        Frames(scroll,AddNative)
        Frames(Call(scroll,"GetView"),AddNative)
        -- Only live ScrollBox members are authoritative; root children include sizing prototypes.
        if count==0 then Scan(scroll,scroll) end
        inlineStatus.layout="scrollbox"
    else
        local count=0
        local function AddPooled(row)
            count=count+1;AddRow(row,nil,true)
        end
        Enumerate(Field(root,"titleButtonPool"),"EnumerateActive",AddPooled)
        Enumerate(Field(greeting,"titleButtonPool"),"EnumerateActive",AddPooled)
        if count==0 then
            local prefix=scope=="gossip" and "GossipTitleButton" or "QuestTitleButton"
            for i=1,MAX_CHOICES do AddRow(_G[prefix..i],nil,true) end
            Scan(root,nil)
        end
        inlineStatus.layout=count>0 and "native pool" or "native buttons"
    end
    inlineStatus.reason=inlineStatus.shown>0 and "left-column labels assigned"
        or (inlineStatus.discovered==0 and "no native rows found" or "no positioned visible identity match")
    if not inlineTicker:GetScript("OnUpdate") then
        inlineTicker:SetScript("OnUpdate",function(_,elapsed)
            inlineElapsed=inlineElapsed+elapsed
            if inlineElapsed<.15 then return end
            inlineElapsed=0
            if InCombat() or not Configured() or not (Visible(GossipFrame) or Visible(QuestFrameGreetingPanel)) then StopInline("menu hidden, disabled or combat")
            else addon.Refresh() end
        end)
    end
end
local function VisibleButton(names)
    for _,name in ipairs(names) do if Enabled(_G[name]) then return name end end
end
local function QuestTarget()
    if activeMode=="detail" then
        return VisibleButton({"QuestFrameAcceptButton","QuestInfoAcceptButton"})
    elseif activeMode=="progress" then
        return VisibleButton({"QuestFrameCompleteButton","QuestInfoCompleteButton"})
    elseif activeMode=="reward" then
        return VisibleButton({"QuestFrameCompleteQuestButton","QuestInfoCompleteQuestButton"})
    end
    if Visible(QuestFrame) then
        if Visible(QuestFrameRewardPanel) then
            return VisibleButton({"QuestFrameCompleteQuestButton","QuestInfoCompleteQuestButton"})
        elseif Visible(QuestFrameProgressPanel) then
            return VisibleButton({"QuestFrameCompleteButton","QuestInfoCompleteButton"})
        elseif Visible(QuestFrameDetailPanel) then
            return VisibleButton({"QuestFrameAcceptButton","QuestInfoAcceptButton"})
        end
    end
end
local function EnsureController()
    if secureReady then return true end
    if InCombat() or type(RegisterStateDriver)~="function" then return false end
    if controllerAttempted then return false end
    controllerAttempted=true
    local ok,created=pcall(CreateFrame,"Frame","MeffortSuiteQuestBindingOwner",UIParent,
        "SecureHandlerStateTemplate,SecureHandlerShowHideTemplate")
    if not ok or not created or type(created.Execute)~="function" then return false end
    local ready=pcall(function()
        created:SetAttribute("_onhide",[[self:ClearBindings()]])
        created:SetAttribute("_onstate-questcombat",[[
            if newstate == "off" then self:ClearBindings() end
        ]])
        RegisterStateDriver(created,"questcombat","[combat] off; on")
        created:Execute([[self:ClearBindings()]])
        created:Hide()
    end)
    if not ready then return false end
    owner,secureReady=created,true
    return true
end
function addon.Available()
    if secureReady then return true end
    return false,InCombat() and "Quest shortcuts will initialize after combat."
        or "Secure quest shortcuts are unavailable; normal controls remain active."
end
local function BindingPlan()
    local plan={}
    if not Configured() then return plan,{} end
    local questButton=QuestTarget()
    if questButton then
        plan[1]={key="SPACE",button=questButton}
        return plan,{}
    end
    local choices=MenuChoices()
    if #choices>0 then
        if spaceButton then plan[#plan+1]={key="SPACE",button=spaceButton} end
        for i=1,math.min(9,#choices) do
            if menuButtons[i] then plan[#plan+1]={key=tostring(i),button=menuButtons[i]} end
        end
    end
    return plan,choices
end
local function Signature(plan,choices)
    local parts={}
    for _,b in ipairs(plan) do parts[#parts+1]=b.key.."="..b.button end
    for _,c in ipairs(choices) do parts[#parts+1]=c.kind..":"..tostring(c.id)..":"..(c.ready and "1" or "0") end
    return table.concat(parts,"|")
end
function addon.Refresh()
    if InCombat() then
        -- The secure state driver withdraws bindings during lockdown.
        boundSignature=nil
        menuChoices={}
        spaceChoice=nil
        StopInline("combat")
        return
    end
    if not EnsureController() then
        StopInline("secure input unavailable")
        if Configured() then Warn("Quest keyboard shortcuts require secure state handling; normal controls remain active.") end
        return
    end
    local plan,choices=BindingPlan()
    local signature=Signature(plan,choices)
    menuChoices=choices
    spaceChoice=choices[PreferredIndex(choices)]
    local updated,err=pcall(UpdateInline,choices)
    if not updated then
        StopInline("rendering error")
        inlineStatus.error=Text(err) and err:sub(1,180) or "unreadable error"
        if MeffortSuite and MeffortSuite.ReportError then MeffortSuite.ReportError("quests","inline keys",err) end
    end
    if signature==boundSignature then return end
    local ok=pcall(owner.Execute,owner,[[self:ClearBindings()]])
    boundSignature=nil
    if not ok then return end
    if #plan==0 then owner:Hide();return end
    -- Inherit dialogue visibility so secure OnHide also handles combat closure.
    local parent=(#choices>0 and (Visible(GossipFrame) and GossipFrame or QuestFrameGreetingPanel))
        or _G[plan[1].button]
    if not parent then owner:Hide();return end
    local statements={}
    for _,b in ipairs(plan) do
        statements[#statements+1]=string.format("self:SetBindingClick(true,%q,%q,\"LeftButton\")",b.key,b.button)
    end
    local applied=pcall(function()
        owner:SetParent(parent)
        owner:Show()
        owner:Execute(table.concat(statements,"\n"))
    end)
    if not applied then
        pcall(owner.Execute,owner,[[self:ClearBindings()]])
        owner:Hide()
        Warn("Could not activate quest keyboard shortcuts; normal controls remain active.")
        return
    end
    boundSignature=signature
end
local pendingChecks=false
local function ScheduleChecks()
    addon.Refresh()
    if pendingChecks or not (C_Timer and C_Timer.After) then return end
    pendingChecks=true
    for i,delay in ipairs({0.08,0.22,0.45}) do
        local final=i==3
        C_Timer.After(delay,function()
            if final then pendingChecks=false end
            addon.Refresh()
        end)
    end
end
local function Hook(frame,onShow,onHide)
    if not frame or hooks[frame] or not frame.HookScript then return end
    hooks[frame]=true
    if onShow then frame:HookScript("OnShow",onShow) end
    if onHide then frame:HookScript("OnHide",onHide) end
end
local function HookQuestUI()
    Hook(QuestFrameDetailPanel,function()activeMode="detail";ScheduleChecks()end,
        function()if activeMode=="detail"then activeMode=nil end;addon.Refresh()end)
    Hook(QuestFrameProgressPanel,function()activeMode="progress";ScheduleChecks()end,
        function()if activeMode=="progress"then activeMode=nil end;addon.Refresh()end)
    Hook(QuestFrameRewardPanel,function()activeMode="reward";ScheduleChecks()end,
        function()if activeMode=="reward"then activeMode=nil end;addon.Refresh()end)
    Hook(QuestFrameGreetingPanel,function()activeMode=nil;ScheduleChecks()end,
        function()addon.Refresh()end)
    Hook(GossipFrame,function()activeMode=nil;ScheduleChecks()end,
        function()addon.Refresh()end)
    for _,name in ipairs({"QuestFrameAcceptButton","QuestInfoAcceptButton",
        "QuestFrameCompleteButton","QuestInfoCompleteButton",
        "QuestFrameCompleteQuestButton","QuestInfoCompleteQuestButton"}) do
        Hook(_G[name],function()ScheduleChecks()end,function()addon.Refresh()end)
    end
    Hook(QuestFrame,nil,function()activeMode=nil;addon.Refresh()end)
end
local watcher=CreateFrame("Frame")
for _,event in ipairs({"PLAYER_LOGIN","PLAYER_REGEN_ENABLED","PLAYER_REGEN_DISABLED","QUEST_DETAIL",
    "QUEST_FINISHED","QUEST_ACCEPTED","QUEST_GREETING","QUEST_PROGRESS",
    "QUEST_COMPLETE","GOSSIP_SHOW","GOSSIP_CLOSED","QUEST_LOG_UPDATE"}) do
    watcher:RegisterEvent(event)
end
watcher:SetScript("OnEvent",function(_,event)
    if event=="PLAYER_REGEN_DISABLED" then addon.Refresh();return end
    if event=="PLAYER_LOGIN" then
        if type(MeffortSuiteDB)=="table" and MeffortSuiteDB.questSpace==nil then
            MeffortSuiteDB.questSpace=true
        end
    elseif event=="QUEST_DETAIL" then activeMode="detail"
    elseif event=="QUEST_PROGRESS" then activeMode="progress"
    elseif event=="QUEST_COMPLETE" then activeMode="reward"
    elseif event=="QUEST_FINISHED" or event=="QUEST_ACCEPTED"
        or event=="QUEST_GREETING" or event=="GOSSIP_SHOW"
        or event=="GOSSIP_CLOSED" then activeMode=nil end
    HookQuestUI()
    if event=="PLAYER_REGEN_ENABLED" or event=="QUEST_LOG_UPDATE" then
        addon.Refresh()
    else
        ScheduleChecks()
    end
end)
