local ADDON = ...
MeffortSuite = MeffortSuite or {}
local suite = MeffortSuite
suite.Version = "1.1.2"

function suite.StandaloneLoaded(name)
    if C_AddOns and type(C_AddOns.IsAddOnLoaded)=="function" then
        local ok, loaded=pcall(C_AddOns.IsAddOnLoaded,name)
        if ok then return loaded==true end
    end
    if type(IsAddOnLoaded)=="function" then
        local ok, loaded=pcall(IsAddOnLoaded,name)
        if ok then return loaded==true end
    end
    return false
end

function suite.Active()
    return type(MeffortSuiteDB)~="table" or MeffortSuiteDB.masterEnabled~=false
end

function suite.Message(text)
    print("|cff60d9bdMeffortSuite|r: "..text)
end

local errors = {}
function suite.ReportError(module, operation, detail)
    if type(issecretvalue)=="function" and issecretvalue(detail) then detail="restricted value" end
    if type(detail)~="string" then detail="operation failed" end
    detail=detail:gsub("[\r\n]"," "):sub(1,180)
    local key=tostring(module)..":"..tostring(operation)..":"..detail
    local latest=errors[#errors]
    if latest and latest.key==key then latest.count=latest.count+1;return end
    errors[#errors+1]={key=key,module=tostring(module),operation=tostring(operation),detail=detail,count=1}
    if #errors>8 then table.remove(errors,1) end
end
function suite.Diagnostics()
    local version=type(GetBuildInfo)=="function" and select(4,GetBuildInfo()) or "unknown"
    local locale=type(GetLocale)=="function" and GetLocale() or "unknown"
    suite.Message("Version "..suite.Version.."; interface "..tostring(version).."; locale "..tostring(locale).."; suite "..(suite.Active() and "enabled" or "disabled")..".")
    if MeffortSuiteTooltipStatus then
        local t=MeffortSuiteTooltipStatus()
        suite.Message("Tooltips: API "..(t.available and "available" or "unavailable")..", mode "..t.mode..", English support "..(t.localeSupported and "yes" or "no")..", errors "..tostring(t.errors).."; "..tostring(t.lastResult)..".")
    end
    if MeffortSuiteQuestSpace and type(MeffortSuiteQuestSpace.InlineStatus)=="function" then
        local ok,q=pcall(MeffortSuiteQuestSpace.InlineStatus)
        if ok and type(q)=="table" then
            local state=q.configured and "enabled" or (q.standalone and "standalone owns hotkeys" or "disabled")
            suite.Message("Quest keys: "..state.."; choices "..tostring(q.choices or 0)..
                "; native rows "..tostring(q.discovered or 0).."; matched "..tostring(q.matched or 0)..
                "; labels "..tostring(q.shown or 0).."; visible "..tostring(q.visible or 0)..
                "; positioned "..tostring(q.positioned or 0).."; duplicates "..tostring(q.duplicates or 0)..
                "; unpositioned rows "..tostring(q.unpositioned or 0).."; layout "..tostring(q.layout or "unknown")..
                "; "..tostring(q.render or "not inspected").."; fallbacks "..tostring(q.fallbacks or 0)..
                "; "..tostring(q.reason or "not inspected")..
                (q.skipReason and ("; skipped: "..tostring(q.skipReason)) or "")..
                (q.measurementReason and ("; measurement: "..tostring(q.measurementReason)) or "")..".")
        elseif not ok then suite.ReportError("quests","label diagnostics",q) end
    end
    if #errors==0 then suite.Message("No errors recorded in this session.") end
    for _,e in ipairs(errors) do
        suite.Message(e.module.." / "..e.operation..": "..e.detail..(e.count>1 and (" ("..e.count.." times)") or ""))
    end
end
local function Help()
    suite.Message("/msuite opens settings. /msuite on | off controls the suite without resetting preferences.")
    suite.Message("Tools: way, ranged, distance, arcane, fishing, professions, enchant, bank, flight, services.")
    suite.Message("/msuite vendor [retry] checks merchant actions; /msuite diagnostics shows compatibility and recent errors.")
end

SLASH_MEFFORTSUITE1="/meffortsuite"
SLASH_MEFFORTSUITE2="/meffsuite"
SLASH_MEFFORTSUITE3="/msuite"
SLASH_MEFFORTSUITE4="/mfsuite"
SlashCmdList.MEFFORTSUITE=function(line)
    local command=(line or ""):lower():match("^%s*(.-)%s*$")
    local action,args=command:match("^(%S+)%s*(.-)$")
    if command=="" or command=="settings" then
        if MeffortSuiteOpenSettings then MeffortSuiteOpenSettings() end
    elseif command=="on" or command=="off" then
        if MeffortSuiteSetMasterEnabled then MeffortSuiteSetMasterEnabled(command=="on") end
    elseif command=="252" then
        if MeffortSuiteWay then MeffortSuiteWay.ToggleTreecko() end
    elseif action=="way" or action=="waypoint" then
        if MeffortSuiteWay then MeffortSuiteWay.Command(args) end
    elseif action=="wand" or action=="ranged" or action=="shoot" or action=="throw" then
        if MeffortSuiteRanged then MeffortSuiteRanged.Command(action,args) end
    elseif action=="distance" or action=="dist" then
        if MeffortSuiteTargetDistance then MeffortSuiteTargetDistance.Command(args) end
    elseif action=="arcane" or action=="arcaneblast" then
        if MeffortSuiteOpenSettings then MeffortSuiteOpenSettings("arcaneblast") end
    elseif action=="fishing" or action=="fish" then
        if MeffortSuiteFishing then MeffortSuiteFishing.Command(args) end
    elseif action=="enchant" or action=="enchanting" or action=="eq" then
        if MeffortSuiteEnchantQueue then MeffortSuiteEnchantQueue.Toggle() end
    elseif action=="professions" then
        if MeffortSuiteOpenSettings then MeffortSuiteOpenSettings("fishing") end
    elseif action=="bank" then
        if MeffortSuiteBank then MeffortSuiteBank.Command(args) end
    elseif action=="flight" or action=="taxi" then
        if MeffortSuiteFlightMasters then MeffortSuiteFlightMasters.Command(args) end
    elseif action=="services" or action=="service" or action=="gossip" then
        if MeffortSuiteGossipServices then MeffortSuiteGossipServices.Command(args) end
    elseif action=="vendor" or action=="merchant" then
        if MeffortSuiteInventory and MeffortSuiteInventory.VendorStatus then
            MeffortSuiteInventory.VendorStatus(args=="retry")
        end
    elseif command=="diagnostics" or command=="debug" then
        suite.Diagnostics()
    elseif command=="help" or command=="status" then
        suite.Message("Suite "..(suite.Active() and "ON" or "OFF").."; standalone MeffortWand takes priority when enabled.")
        Help()
    else
        Help()
    end
end

local newInstall, newCharacter = false, false
local function CopyTable(value, seen)
    if type(value)~="table" then return value end
    seen=seen or {}
    if seen[value] then return seen[value] end
    local copied={};seen[value]=copied
    for k,v in pairs(value) do copied[k]=CopyTable(v,seen) end
    return copied
end
local function NormalizeSettings()
    if type(MeffortSuiteDB)~="table" then MeffortSuiteDB={} end
    if type(MeffortSuiteCharDB)~="table" then MeffortSuiteCharDB={} end
    local db,char=MeffortSuiteDB,MeffortSuiteCharDB
    for _,key in ipairs({"masterEnabled","enabled","style","badges","rankHint","questSpace",
        "badgeTextOutline","badgeTextShadow","wayEnabled","autoSortBags","autoSellJunk",
        "autoRepair","autoBankCrafting","autoSortBank","autoOpenOrgBank","autoOpenFlightMaster",
        "autoOpenSingleService"}) do
        if db[key]~=nil and type(db[key])~="boolean" then db[key]=nil end
    end
    for _,key in ipairs({"colors","textColors","actionText"}) do
        if db[key]~=nil and type(db[key])~="table" then db[key]=nil end
    end
    local action=db.actionText
    if type(action)=="table" then
        local function Number(value,fallback,lo,hi)
            value=tonumber(value)
            if not value or value~=value or value==math.huge or value==-math.huge then return fallback end
            return math.max(lo,math.min(hi,value))
        end
        action.size=Number(action.size,18,8,24)
        action.x=Number(action.x,0,-22,22)
        action.y=Number(action.y,0,-22,22)
        for _,key in ipairs({"enabled","outline","shadow"}) do
            if action[key]~=nil and type(action[key])~="boolean" then action[key]=nil end
        end
        if type(action.hex)~="string" or not action.hex:match("^%x%x%x%x%x%x$") then action.hex="fff0c2" end
    end
    for _,name in ipairs({"targetDistance","arcaneBlast"}) do
        local options=char[name]
        if type(options)=="table" then
            for _,key in ipairs({"enabled","locked","stacks","timer","wheel"}) do
                if options[key]~=nil and type(options[key])~="boolean" then options[key]=nil end
            end
        end
    end
    if db.tooltipMode~="compare" then db.tooltipMode="replace" end
    if char.bankDepositExclusions~=nil and type(char.bankDepositExclusions)~="string" then char.bankDepositExclusions="" end
    db.schemaVersion=2
end

local frame=CreateFrame("Frame")
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("PLAYER_LOGIN")
frame:SetScript("OnEvent",function(_,event,name)
    if event=="ADDON_LOADED" and name==ADDON then
        if type(MeffortSuiteDB)~="table" then MeffortSuiteDB={} end
        if type(MeffortSuiteCharDB)~="table" then MeffortSuiteCharDB={} end
        newInstall=MeffortSuiteDB.initialized~=true
        newCharacter=MeffortSuiteCharDB.initialized~=true
        NormalizeSettings()
    elseif event=="PLAYER_LOGIN" then
        if newInstall and type(MeffortBarsDB)=="table" then
            local keys={"enabled","style","badges","rankHint","questSpace",
                "badgeTextOutline","badgeTextShadow","colors","textColors","actionText"}
            for _,key in ipairs(keys) do
                if MeffortSuiteDB[key]==nil and MeffortBarsDB[key]~=nil then
                    MeffortSuiteDB[key]=CopyTable(MeffortBarsDB[key])
                end
            end
        end
        if newInstall and type(MeffortWayDB)=="table" and MeffortSuiteDB.wayTheme==nil then
            MeffortSuiteDB.wayTheme=MeffortWayDB.theme
        end
        if newCharacter and type(MeffortWandDB)=="table" and MeffortSuiteCharDB.rangedMode==nil then
            local class=type(UnitClass)=="function" and select(2,UnitClass("player")) or nil
            if class=="MAGE" or class=="PRIEST" or class=="WARLOCK" then
                MeffortSuiteCharDB.rangedMode=MeffortWandDB.mode
            end
        end
        NormalizeSettings()
        MeffortSuiteDB.initialized=true
        MeffortSuiteCharDB.initialized=true
        if newInstall then suite.Message("Use /msuite to configure your tools. Settings are retained across reloads.") end
        newInstall,newCharacter=false,false
    end
    if event=="PLAYER_LOGIN" and type(MeffortSuiteDB)=="table" then
        if MeffortSuiteDB.wayEnabled==nil then MeffortSuiteDB.wayEnabled=true end
        if MeffortSuiteDB.wayTheme~="treecko" then MeffortSuiteDB.wayTheme="teal" end
    end
end)
