-- Each enchant and each confirmation requires a real player click/key press.
-- Recipe targets are tracked by item GUID, so bag moves do not retarget enchants.
MeffortSuiteEnchantQueue = {}
local M = MeffortSuiteEnchantQueue
local ENCHANTING = 333
local MAX_COUNT = 999
local VISIBLE_ROWS = 6
local pending, undoClear, normalizedData
local queueScroll, queueBody, clearButton
local refreshBusy, refreshAgain = false, false
local lastStatus = ''
local SetStatus
_G.BINDING_HEADER_MEFFORTSUITE = 'MeffortSuite'
_G['BINDING_NAME_CLICK MeffortSuiteEnchantNextButton:LeftButton'] = 'Cast next queued enchant'
local panel, nextButton, targetButton, targetLabel, recipeLabel, countInput, statusLabel, toggleButton
local listRows = {}
local selectedRecipe, replacementButton, replacementDialog, isCasting = nil, nil, nil, false
local hookedRecipeEvent = false
local lastPress = -100
local replacePopups = {REPLACE_TRADESKILL_ENCHANT=true, REPLACE_ENCHANT=true}

local function Data()
    if type(MeffortSuiteCharDB) ~= 'table' then MeffortSuiteCharDB = {} end
    local data = MeffortSuiteCharDB.enchantQueue
    if type(data) ~= 'table' then
        data = { enabled=true, hidden=true, entries={}, target=nil }
        MeffortSuiteCharDB.enchantQueue = data
    end
    if data.enabled == nil then data.enabled = true end
    if type(data.entries) ~= 'table' then data.entries = {} end
    if normalizedData ~= data then
        local clean = {}
        for _,entry in ipairs(data.entries) do
            if type(entry)=='table' and type(entry.recipeID)=='number'
                and entry.recipeID>0 and entry.recipeID<math.huge and entry.recipeID==math.floor(entry.recipeID)
                and type(entry.remaining)=='number' and entry.remaining>0
                and entry.remaining<math.huge then
                entry.remaining=math.min(MAX_COUNT,math.floor(entry.remaining))
                if entry.remaining>0 then clean[#clean+1]=entry end
            end
        end
        data.entries=clean
        if type(data.target)~='table' or type(data.target.guid)~='string' then data.target=nil end
        local target=data.target
        if target then
            local function Integer(v,lo,hi) return type(v)=='number' and v>=lo and v<=hi and v==math.floor(v) end
            if not Integer(target.equipSlot,1,INVSLOT_LAST_EQUIPPED or 19) then target.equipSlot=nil end
            if not Integer(target.bag,0,NUM_TOTAL_EQUIPPED_BAG_SLOTS or NUM_BAG_SLOTS or 4)
                or not Integer(target.slot,1,1000) then target.bag,target.slot=nil,nil end
            if type(target.link)~='string' then target.link=nil end
            if type(target.icon)~='number' and type(target.icon)~='string' then target.icon=nil end
        end
        normalizedData=data
    end
    return data
end
local function Say(message)
    if MeffortSuite and MeffortSuite.Message then MeffortSuite.Message('Enchanting: '..message) end
end
local function InCombat()
    return type(InCombatLockdown)=='function' and InCombatLockdown()
end
local function Secret(v)
    return type(issecretvalue)=='function' and issecretvalue(v)
end
local function Now() return type(GetTime)=='function' and GetTime() or 0 end
local function Effective()
    return not MeffortSuite or not MeffortSuite.Active or MeffortSuite.Active()
end
local function ResetAttempt()
    pending,replacementButton,replacementDialog,isCasting=nil,nil,nil,false
end
local function Disarm()
    if not nextButton then return end
    if InCombat() then return end
    nextButton:SetAttribute('type',nil)
    nextButton:SetAttribute('clickbutton',nil)
end
local function ProfessionIsEnchanting()
    if not (C_TradeSkillUI and C_TradeSkillUI.GetBaseProfessionInfo) then return false end
    local ok,info = pcall(C_TradeSkillUI.GetBaseProfessionInfo)
    if not ok or type(info)~='table' then return false end
    return info.professionID == ENCHANTING or (Enum and Enum.Profession and Enum.Profession.Enchanting and info.profession == Enum.Profession.Enchanting)
end
local function ProfessionsVisible()
    return ProfessionsFrame and ProfessionsFrame.IsShown and ProfessionsFrame:IsShown()
end
local function CurrentRecipe(requireActual)
    local form=ProfessionsFrame and ProfessionsFrame.CraftingPage and ProfessionsFrame.CraftingPage.SchematicForm
    if form and form.GetRecipeInfo then
        local ok,info=pcall(form.GetRecipeInfo,form)
        if ok and info and info.recipeID then return info.recipeID end
    end
    return not requireActual and selectedRecipe or nil
end
local function RecipeName(id)
    if not id then return nil end
    local ok,info=false,nil
    if C_TradeSkillUI and C_TradeSkillUI.GetRecipeInfo then ok,info=pcall(C_TradeSkillUI.GetRecipeInfo,id) end
    return ok and type(info)=='table' and info.name or ('Recipe '..tostring(id))
end
local function AtLocation(loc)
    return loc and loc.IsValid and loc:IsValid() and C_Item and C_Item.DoesItemExist and C_Item.DoesItemExist(loc)
end
local function GUID(loc)
    return AtLocation(loc) and C_Item.GetItemGUID and C_Item.GetItemGUID(loc) or nil
end
local function SaveLocation(target,loc)
    target.equipSlot,target.bag,target.slot=nil,nil,nil
    if loc:IsEquipmentSlot() then
        target.equipSlot=loc:GetEquipmentSlot()
    else
        target.bag,target.slot=loc:GetBagAndSlot()
    end
end
local function MakeLocation(target)
    if not (target and ItemLocation) then return nil end
    if target.equipSlot then return ItemLocation:CreateFromEquipmentSlot(target.equipSlot) end
    if target.bag and target.slot then return ItemLocation:CreateFromBagAndSlot(target.bag,target.slot) end
end
local function FindTarget()
    local target=Data().target
    if not (target and target.guid and ItemLocation and C_Container) then return nil end
    local loc=MakeLocation(target)
    if GUID(loc)==target.guid then return loc end
    for slot=INVSLOT_FIRST_EQUIPPED or 1, INVSLOT_LAST_EQUIPPED or 19 do
        loc=ItemLocation:CreateFromEquipmentSlot(slot)
        if GUID(loc)==target.guid then SaveLocation(target,loc); return loc end
    end
    for bag=0,NUM_TOTAL_EQUIPPED_BAG_SLOTS or NUM_BAG_SLOTS or 4 do
        local slots=C_Container.GetContainerNumSlots(bag) or 0
        for slot=1,slots do
            loc=ItemLocation:CreateFromBagAndSlot(bag,slot)
            if GUID(loc)==target.guid then SaveLocation(target,loc); return loc end
        end
    end
    return nil
end
local function Total()
    local count=0
    for _,entry in ipairs(Data().entries) do count=count+(entry.remaining or 0) end
    return count
end
function M.Configured() return Data().enabled ~= false end
function M.Enabled() return Effective() and M.Configured() end
function M.CanOpen()
    if not Effective() then return false,'Enable MeffortSuite first.' end
    if not M.Configured() then return false,'Enable Enchant Queue first.' end
    if InCombat() then return false,'Enchant Queue is unavailable during combat.' end
    if not ProfessionsVisible() or not ProfessionIsEnchanting() then
        return false,'Open your Enchanting profession window first.'
    end
    return true
end
function M.SetEnabled(v)
    Data().enabled = v==true
    if not v then ResetAttempt();Disarm();if panel and not InCombat() then panel:Hide() end end
    if M.SyncTab then M.SyncTab() end
    M.Refresh()
end
function M.QueueCount() return Total() end
function M.SetTarget(loc)
    if isCasting then SetStatus('Wait for the current enchant to finish before changing the target.');return false end
    if not AtLocation(loc) or not GUID(loc) then
        if statusLabel then statusLabel:SetText('That item cannot be selected.') end
        return false
    end
    local target={ guid=GUID(loc),itemID=C_Item.GetItemID(loc),link=C_Item.GetItemLink(loc),icon=C_Item.GetItemIcon(loc) }
    SaveLocation(target,loc)
    ResetAttempt();Disarm();undoClear=nil
    Data().target=target
    M.Refresh()
    return true
end
function M.Clear()
    if isCasting then SetStatus('Wait for the current enchant to finish before clearing the queue.');return false end
    local data=Data()
    if #data.entries>0 or data.target then undoClear={entries=data.entries,target=data.target} end
    ResetAttempt();Disarm()
    data.entries={};data.target=nil
    M.Refresh();return true
end
function M.UndoClear()
    if isCasting then return false end
    local data=Data()
    if not undoClear or #data.entries>0 or data.target then return false end
    data.entries,data.target=undoClear.entries,undoClear.target
    undoClear=nil;M.Refresh()
    return true
end
function M.Add(recipeID,count)
    count=tonumber(count)
    if type(recipeID)~='number' or recipeID<=0 or recipeID==math.huge or recipeID~=math.floor(recipeID) or not count or count<1 or count==math.huge or count~=math.floor(count) then
        return false,'Choose an enchant and enter a whole-number count.'
    end
    undoClear=nil
    count=math.min(count,MAX_COUNT)
    local entries=Data().entries
    local tail=entries[#entries]
    if tail and tail.recipeID==recipeID then
        tail.remaining=math.min(MAX_COUNT,tail.remaining+count)
    else
        entries[#entries+1]={recipeID=recipeID,name=RecipeName(recipeID),remaining=count}
    end
    M.Refresh()
    return true
end
function M.Remove(index)
    if type(index)~='number' or index<1 or index>#Data().entries or index~=math.floor(index) then return end
    if index==1 and isCasting then SetStatus('Wait for the current enchant to finish before removing it.');return false end
    if index==1 then ResetAttempt();Disarm() end
    undoClear=nil
    table.remove(Data().entries,index)
    M.Refresh()
end
local function Head()
    return Data().entries[1]
end
SetStatus=function(message)
    lastStatus=message or ''
    if statusLabel then statusLabel:SetText(lastStatus) end
end
local function CraftButton()
    local page=ProfessionsFrame and ProfessionsFrame.CraftingPage
    return page and page.CreateButton
end
local function CurrentAllocationGUID()
    local ok,guid=pcall(function()
        local form=ProfessionsFrame and ProfessionsFrame.CraftingPage and ProfessionsFrame.CraftingPage.SchematicForm
        local transaction=form and form.GetTransaction and form:GetTransaction()
        local allocated=transaction and transaction.GetEnchantAllocation and transaction:GetEnchantAllocation()
        return GUID(allocated and allocated.GetItemLocation and allocated:GetItemLocation())
    end)
    return ok and guid or nil
end
local function BasicBlockedReason()
    local ok,why=M.CanOpen()
    if not ok then return why end
    if not panel or not panel:IsShown() then return 'Open the queue before using its keybinding.' end
    if not Head() then return 'Choose an enchant and add it to the queue.' end
    if not FindTarget() then return 'Choose a target item that is in your bags or equipped.' end
    if not CraftButton() then return 'The profession craft control is unavailable.' end
    if not C_Timer or type(C_Timer.After)~='function' then
        return "Enchant request tracking is unavailable on this client. Use Blizzard's craft button."
    end
    local form=ProfessionsFrame.CraftingPage.SchematicForm
    if not form or type(form.GetRecipeInfo)~='function' or type(form.GetTransaction)~='function'
        or not C_TradeSkillUI or type(C_TradeSkillUI.OpenRecipe)~='function'
        or not Item or type(Item.CreateFromItemLocation)~='function' then
        return "Verified enchant preparation is unavailable on this client. Use Blizzard's craft button."
    end
end
function M.GetBlockedReason()
    local why=BasicBlockedReason()
    if why then return why end
    if isCasting then return 'Wait for the current enchant to finish.' end
    if pending and pending.phase~='uncertain' and not replacementButton then return 'Waiting for the enchant request.' end
end
local function MarkUncertain(message)
    if not pending then return end
    pending.phase='uncertain';pending.note=message;isCasting=false
    Disarm();M.Refresh()
end
function M.ResolveUncertain(completed)
    if InCombat() or not M.Enabled() or not pending or pending.phase~='uncertain' or Head()~=pending.entry then return false end
    if completed then
        local entry=pending.entry
        entry.remaining=entry.remaining-1
        if entry.remaining<=0 then table.remove(Data().entries,1) end
    end
    ResetAttempt();Disarm();M.Refresh()
    SetStatus(completed and 'One enchant counted after your verification.' or 'Queue resumed after your verification. No count was removed.')
    return true
end
local function ShowVerification()
    local attempt=pending
    if type(StaticPopupDialogs)=='table' and type(StaticPopup_Show)=='function' then
        StaticPopupDialogs.MEFFORTSUITE_ENCHANT_RESULT={
            text='The enchant result could not be confirmed. Inspect the target item before choosing an action. The saved queue count has not changed.',
            button1='Count complete',button2='Keep paused',button3='Nothing applied',
            OnAccept=function()if pending==attempt then M.ResolveUncertain(true) end end,
            OnAlt=function()if pending==attempt then M.ResolveUncertain(false) end end,
            timeout=0,hideOnEscape=true,
        }
        StaticPopup_Show('MEFFORTSUITE_ENCHANT_RESULT')
    else
        SetStatus('Result unconfirmed. Inspect the item; reselect it only after checking whether the enchant completed. Queue count was preserved.')
    end
end
local function PrepareNext()
    if not nextButton then return end
    if InCombat() then return end
    -- No action stays armed between hardware inputs. PreClick must validate anew.
    Disarm()
    local reason=M.GetBlockedReason()
    if reason then
        nextButton:SetText(isCasting and 'Casting...' or 'Next enchant')
        nextButton:Disable()
        SetStatus(reason)
    elseif pending and pending.phase=='uncertain' then
        nextButton:SetText('Check result...')
        nextButton:Enable()
        SetStatus(pending.note or 'Result unconfirmed. Inspect the item before retrying.')
    elseif replacementButton and pending then
        nextButton:SetText('Confirm replacement')
        nextButton:Enable()
        SetStatus("Verify Blizzard's replacement prompt, then press Next to confirm.")
    else
        nextButton:SetText('Next enchant')
        nextButton:Enable()
        local entry=Head()
        SetStatus('Next: '..tostring(entry.name or RecipeName(entry.recipeID))..' ('..Total()..' remaining).')
    end
end
local function StageEnchant()
    local reason=BasicBlockedReason()
    if reason then return false,reason end
    local entry,loc=Head(),FindTarget()
    if not (C_TradeSkillUI and type(C_TradeSkillUI.OpenRecipe)=='function' and Item
        and type(Item.CreateFromItemLocation)=='function') then
        return false,"This client does not support verified enchant preparation. Use Blizzard's craft button."
    end
    local ok,result=pcall(function()
        if CurrentRecipe(true)~=entry.recipeID then C_TradeSkillUI.OpenRecipe(entry.recipeID) end
        -- OpenRecipe may load asynchronously. Never allocate into the old form.
        if CurrentRecipe(true)~=entry.recipeID then return 'Recipe is loading. Press Next again when it is ready.' end
        local page=ProfessionsFrame.CraftingPage
        local form=page.SchematicForm
        local transaction=form and form.GetTransaction and form:GetTransaction()
        if not transaction or type(transaction.SetEnchantAllocation)~='function'
            or type(transaction.GetEnchantAllocation)~='function' then
            return "Verified item allocation is unavailable on this client. Use Blizzard's craft button."
        end
        local enchantType=Enum and Enum.TradeskillRecipeType and Enum.TradeskillRecipeType.Enchant
        if enchantType and type(transaction.IsRecipeType)=='function' then
            if not transaction:IsRecipeType(enchantType) then return 'Choose an item enchant, rather than a crafted item.' end
        elseif not (form.enchantSlot and type(form.enchantSlot.SetItem)=='function'
            and form.enchantSlot.IsVisible and form.enchantSlot:IsVisible()) then
            return "This recipe has no verified enchant target slot. Use Blizzard's craft button."
        end
        local counter=page.CreateMultipleInputBox
        local recipeInfo=form:GetRecipeInfo()
        if counter then
            if not counter.SetValue or not counter.GetValue then return 'Craft quantity cannot be verified on this client.' end
            counter:SetValue(1)
            if counter:GetValue()~=1 then return 'Set the craft quantity to one before continuing.' end
        elseif recipeInfo and recipeInfo.canCreateMultiple then
            return 'Craft quantity cannot be verified on this client.'
        end
        local item=Item:CreateFromItemLocation(loc)
        if not item then return 'The target item is not ready.' end
        transaction:SetEnchantAllocation(item)
        if form.enchantSlot and form.enchantSlot.SetItem then form.enchantSlot:SetItem(item) end
        if page.ValidateControls then page:ValidateControls() end
        if counter and counter:GetValue()~=1 then return 'Craft quantity changed. Set it to one before continuing.' end
        local allocated=transaction:GetEnchantAllocation()
        local actualLoc=allocated and allocated.GetItemLocation and allocated:GetItemLocation()
        local actualGUID=GUID(actualLoc)
        if not actualGUID or actualGUID~=Data().target.guid or actualGUID~=GUID(loc)
            or CurrentRecipe(true)~=entry.recipeID or Head()~=entry then
            return 'The recipe or target changed. Verify your selection and try again.'
        end
        local craft=CraftButton()
        if not craft or not craft.IsEnabled or not craft:IsEnabled() then
            return "Blizzard's craft button is unavailable. Check reagents and item requirements."
        end
        return {entry=entry,recipeID=entry.recipeID,targetGUID=actualGUID,requestedAt=Now(),phase='requested'}
    end)
    if not ok then return false,'Could not prepare the enchant. No craft was requested; verify the recipe and target.' end
    if type(result)~='table' then return false,result end
    return true,result
end
local function BeforeClick()
    lastPress=Now()
    if InCombat() then SetStatus('Enchant Queue is unavailable during combat.');return end
    Disarm()
    local reason=M.GetBlockedReason()
    if reason then SetStatus(reason);return end
    if pending and pending.phase=='uncertain' then ShowVerification();return end
    if replacementButton and pending then
        if not replacementButton.IsVisible or not replacementButton:IsVisible()
            or not replacementButton.IsEnabled or not replacementButton:IsEnabled()
            or Head()~=pending.entry or CurrentRecipe(true)~=pending.recipeID
            or CurrentAllocationGUID()~=pending.targetGUID or not FindTarget() or GUID(FindTarget())~=pending.targetGUID then
            ResetAttempt();SetStatus("The replacement prompt or target changed. Use Blizzard's controls.");return
        end
        pending.phase='confirming';pending.requestedAt=Now()
        nextButton:SetAttribute('clickbutton',replacementButton)
        nextButton:SetAttribute('type','click')
        return
    end
    local ok,result=StageEnchant()
    if not ok then ResetAttempt();SetStatus(result);return end
    pending=result
    nextButton:SetAttribute('clickbutton',CraftButton())
    nextButton:SetAttribute('type','click')
end
local function AfterClick()
    Disarm()
    local attempt=pending
    if attempt and C_Timer and C_Timer.After then
        -- Require immediate ownership acknowledgement; ambiguous requests pause for verification.
        C_Timer.After(0,function()
            if pending==attempt and not attempt.castGUID and not replacementButton then
                MarkUncertain('No request acknowledgement was detected. Inspect the item, then check the result before retrying.')
            end
        end)
    end
end
local function AttachTarget()
    if not C_Cursor or not C_Cursor.GetCursorItem then return end
    local loc=C_Cursor.GetCursorItem()
    if loc and M.SetTarget(loc) then
        if type(ClearCursor)=='function' then ClearCursor() end
    end
end
local function Text(parent,body,x,y,width,size)
    local label=parent:CreateFontString(nil,'OVERLAY','GameFontHighlight')
    label:SetPoint('TOPLEFT',parent,'TOPLEFT',x,y)
    label:SetWidth(width)
    label:SetJustifyH('LEFT')
    label:SetFont(STANDARD_TEXT_FONT or 'Fonts\\FRIZQT__.TTF',size or 12)
    label:SetText(body or '')
    return label
end
local function Button(parent,caption,w,h)
    local button=CreateFrame('Button',nil,parent,'UIPanelButtonTemplate')
    button:SetSize(w,h)
    button:SetText(caption)
    return button
end
local function CreatePanel()
    if panel then return end
    panel=CreateFrame('Frame','MeffortSuiteEnchantPanel',UIParent,'BasicFrameTemplateWithInset')
    panel:SetSize(302,414)
    panel:SetPoint('CENTER',UIParent,'CENTER',180,0)
    panel:SetFrameStrata('DIALOG')
    panel:SetMovable(true)
    panel:SetClampedToScreen(true)
    panel:EnableMouse(true)
    panel:RegisterForDrag('LeftButton')
    panel:SetScript('OnDragStart',function(self)if not InCombat() then self:StartMoving()end end)
    panel:SetScript('OnDragStop',function(self)self:StopMovingOrSizing()end)
    if panel.TitleText then panel.TitleText:SetText('MeffortSuite | Enchant Queue') end
    if panel.CloseButton then panel.CloseButton:HookScript('OnClick',function()Data().hidden=true end) end
    targetButton=CreateFrame('Button',nil,panel,'ItemButtonTemplate')
    targetButton:SetSize(40,40)
    targetButton:SetPoint('TOPLEFT',panel,'TOPLEFT',18,-44)
    targetButton:SetScript('OnReceiveDrag',AttachTarget)
    targetButton:SetScript('OnClick',function(self,mouse)
        if CursorHasItem and CursorHasItem() then AttachTarget()
        elseif IsAltKeyDown and IsAltKeyDown() then Data().target=nil;M.Refresh() end
    end)
    targetButton:SetScript('OnEnter',function(self)
        local target=Data().target
        if target and target.link and GameTooltip then
            GameTooltip:SetOwner(self,'ANCHOR_RIGHT');GameTooltip:SetHyperlink(target.link);GameTooltip:Show()
        end
    end)
    targetButton:SetScript('OnLeave',function()if GameTooltip then GameTooltip:Hide()end end)
    Text(panel,'Item to enchant',70,-47,205,12)
    targetLabel=Text(panel,'Drop a bag or equipped item here',70,-66,205,11)
    recipeLabel=Text(panel,'Select an enchant in the profession list',18,-101,268,11)
    Text(panel,'Repeat count:',18,-133,105,11)
    countInput=CreateFrame('EditBox',nil,panel,'InputBoxTemplate')
    countInput:SetSize(52,24);countInput:SetPoint('TOPLEFT',panel,'TOPLEFT',110,-130)
    countInput:SetAutoFocus(false);countInput:SetNumeric(true);countInput:SetMaxLetters(3);countInput:SetText('10')
    local add=Button(panel,'+ Queue',104,25)
    add:SetPoint('TOPRIGHT',panel,'TOPRIGHT',-18,-131)
    add:SetScript('OnClick',function()
        local ok,errorText=M.Add(CurrentRecipe(),tonumber(countInput:GetText()))
        if not ok then SetStatus(errorText) else SetStatus('Enchants queued; press Next for each action.') end
    end)
    countInput:SetScript('OnEnterPressed',function(self)self:ClearFocus();add:Click()end)
    Text(panel,'Queued enchantments',18,-171,260,12)
    queueScroll=CreateFrame('ScrollFrame',nil,panel,'UIPanelScrollFrameTemplate')
    queueScroll:SetPoint('TOPLEFT',panel,'TOPLEFT',18,-190)
    queueScroll:SetPoint('BOTTOMRIGHT',panel,'BOTTOMRIGHT',-38,93)
    queueBody=CreateFrame('Frame',nil,queueScroll)
    queueBody:SetSize(244,1)
    queueScroll:SetScrollChild(queueBody)
    nextButton=CreateFrame('Button','MeffortSuiteEnchantNextButton',panel,'SecureActionButtonTemplate,SecureHandlerStateTemplate,UIPanelButtonTemplate')
    nextButton:SetSize(136,26);nextButton:SetText('Next enchant')
    nextButton:SetPoint('BOTTOMLEFT',panel,'BOTTOMLEFT',18,37)
    nextButton:RegisterForClicks('AnyUp')
    nextButton:SetAttribute('useOnKeyDown',false)
    nextButton:SetScript('PreClick',BeforeClick)
    nextButton:SetScript('PostClick',AfterClick)
    if type(RegisterStateDriver)=='function' then
        nextButton:SetAttribute('_onstate-combat',[[
            if newstate == 'combat' then
                self:SetAttribute('type', nil)
                self:SetAttribute('clickbutton', nil)
            end
        ]])
        RegisterStateDriver(nextButton,'combat','[combat] combat; safe')
    end
    clearButton=Button(panel,'Clear queue',117,26)
    clearButton:SetPoint('BOTTOMRIGHT',panel,'BOTTOMRIGHT',-18,37)
    clearButton:SetScript('OnClick',function()
        if undoClear then M.UndoClear() elseif M.Clear() then SetStatus('Queue cleared. Undo is available until you edit the queue.') end
    end)
    statusLabel=Text(panel,'Select a recipe and drag in the target item.',18,-366,268,10)
    if statusLabel.SetHeight then statusLabel:SetHeight(38) end
    if type(UISpecialFrames)=='table' then tinsert(UISpecialFrames,'MeffortSuiteEnchantPanel') end
    panel:Hide()
    panel:HookScript('OnHide',function() ResetAttempt();Disarm() end)
end
function M.Refresh()
    if not panel then return end
    if refreshBusy then refreshAgain=true;return end
    refreshBusy=true
    local data=Data()
    local target=data.target
    local loc=FindTarget()
    if targetButton then
        local tex=targetButton.icon or _G[targetButton:GetName() and targetButton:GetName()..'IconTexture' or '']
        if tex and tex.SetTexture then tex:SetTexture(target and target.icon or 'Interface\\Buttons\\UI-EmptySlot') end
    end
    if targetLabel then
        targetLabel:SetText(target and (loc and (target.link or 'Item selected') or '|cffff5555Item not found|r') or 'Drag item here (Alt-click to clear)')
    end
    if recipeLabel then
        recipeLabel:SetText('Selected: '..tostring(RecipeName(CurrentRecipe()) or 'choose an enchant'))
    end
    local rowCount=math.max(VISIBLE_ROWS,#data.entries)
    for n=1,rowCount do
        if not listRows[n] then
            local row=CreateFrame('Frame',nil,queueBody)
            row:SetSize(244,23);row:SetPoint('TOPLEFT',queueBody,'TOPLEFT',0,-(n-1)*23)
            local label=Text(row,'',0,0,211,11)
            if label.SetWordWrap then label:SetWordWrap(false) end
            local remove=Button(row,'x',25,20)
            remove:SetPoint('TOPRIGHT',row,'TOPRIGHT',0,2)
            local index=n
            remove:SetScript('OnClick',function()M.Remove(index)end)
            listRows[n]={frame=row,label=label}
        end
    end
    for n,row in ipairs(listRows) do
        local entry=data.entries[n]
        row.frame:SetShown(entry~=nil)
        if entry then row.label:SetText(tostring(entry.name or RecipeName(entry.recipeID))..'  x'..tostring(entry.remaining)) end
    end
    if queueBody then queueBody:SetHeight(math.max(1,#data.entries*23)) end
    if clearButton then clearButton:SetText(undoClear and 'Undo clear' or 'Clear queue') end
    PrepareNext()
    refreshBusy=false
    if refreshAgain then
        refreshAgain=false
        if C_Timer and C_Timer.After then C_Timer.After(0,function()M.Refresh()end) end
    end
end
local function CreateTab()
    if toggleButton or not ProfessionsFrame then return end
    toggleButton=CreateFrame('Button','MeffortSuiteEnchantTab',ProfessionsFrame,'UIPanelButtonTemplate')
    toggleButton:SetSize(36,36)
    toggleButton:SetFrameStrata('HIGH')
    toggleButton:SetText('')
    local texture=toggleButton:CreateTexture(nil,'ARTWORK')
    texture:SetPoint('TOPLEFT',toggleButton,'TOPLEFT',5,-5)
    texture:SetPoint('BOTTOMRIGHT',toggleButton,'BOTTOMRIGHT',-5,5)
    texture:SetTexture('Interface\\AddOns\\MeffortSuite\\Textures\\MeffortSuiteIcon')
    toggleButton.icon=texture
    toggleButton:SetScript('OnClick',function()M.Toggle()end)
    toggleButton:SetScript('OnEnter',function(self)
        if not GameTooltip then return end
        GameTooltip:SetOwner(self,'ANCHOR_RIGHT')
        GameTooltip:SetText('MeffortSuite - Enchant Queue')
        GameTooltip:AddLine('Click to show or hide your enchant queue.',0.78,0.78,0.78,true)
        GameTooltip:Show()
    end)
    toggleButton:SetScript('OnLeave',function()if GameTooltip then GameTooltip:Hide() end end)
    toggleButton:Hide()
end
local function Position()
    if not ProfessionsFrame or InCombat() then return end
    if toggleButton then
        toggleButton:ClearAllPoints()
        toggleButton:SetPoint('TOPLEFT',ProfessionsFrame,'TOPRIGHT',64,-88)
    end
    if panel and toggleButton then
        panel:ClearAllPoints()
        panel:SetPoint('TOPLEFT',toggleButton,'TOPRIGHT',8,0)
    end
end
local function HideBoth()
    ResetAttempt();Disarm()
    if InCombat() then return end
    if panel then panel:Hide() end
    if toggleButton then toggleButton:Hide() end
end
function M.SyncTab()
    if InCombat() then return end
    if not M.Enabled() or not ProfessionsVisible() or not ProfessionIsEnchanting() then
        HideBoth()
        return
    end
    CreateTab()
    Position()
    if toggleButton then toggleButton:Show() end
end
local function SyncSoon()
    if C_Timer and type(C_Timer.After)=='function' then
        C_Timer.After(0,function()M.SyncTab() end)
    else
        M.SyncTab()
    end
end
local hookedProfessionsFrame
local function HookProfessionWindow()
    local frame=ProfessionsFrame
    if not frame or hookedProfessionsFrame==frame then return end
    hookedProfessionsFrame=frame
    frame:HookScript('OnShow',SyncSoon)
    frame:HookScript('OnHide',HideBoth)
end
function M.Open()
    local ok,why=M.CanOpen()
    if not ok then Say(why);return false end
    HookProfessionWindow()
    M.SyncTab()
    CreatePanel()
    Data().hidden=false
    Position()
    panel:Show()
    M.Refresh()
    return true
end
function M.RefreshMaster()
    if not M.Enabled() then HideBoth() end
    M.SyncTab();M.Refresh()
end
function M.Toggle()
    if InCombat() then Say('Enchant Queue is unavailable during combat.');return end
    if panel and panel:IsShown() then
        Data().hidden=true
        panel:Hide()
        return
    end
    M.Open()
end
local function FindPopupButton(dialog)
    return dialog and (dialog.button1 or (dialog.GetButton1 and dialog:GetButton1()) or (dialog.ButtonContainer and dialog.ButtonContainer.Button1))
end
local function HookReplaceDialogs()
    if type(StaticPopup_Show)~='function' or type(hooksecurefunc)~='function' then return end
    hooksecurefunc('StaticPopup_Show',function(which)
        if not (replacePopups[which] and M.Enabled() and pending and Head()==pending.entry
            and Now()-pending.requestedAt<3 and pending.phase=='requested' and not InCombat()) then return end
        local dialog=StaticPopup_FindVisible and StaticPopup_FindVisible(which)
        local confirm=FindPopupButton(dialog)
        if not confirm then SetStatus('Use the popup to confirm this replacement.');return end
        replacementButton,replacementDialog=confirm,dialog
        if not dialog.meffortSuiteEnchantHooked then
            dialog.meffortSuiteEnchantHooked=true
            dialog:HookScript('OnHide',function()
                if replacementDialog~=dialog then return end
                replacementButton,replacementDialog=nil,nil
                if pending and not pending.castGUID and pending.phase~='confirming' then ResetAttempt() end
                M.Refresh()
            end)
        end
        SetStatus('Press Next again to confirm the replacement.')
        M.Refresh()
    end)
end
local function HookRecipeSelection()
    if hookedRecipeEvent or not (EventRegistry and EventRegistry.RegisterCallback) then return end
    hookedRecipeEvent=true
    EventRegistry:RegisterCallback('ProfessionsRecipeListMixin.Event.OnRecipeSelected',function(_,info)
        selectedRecipe=info and info.recipeID
        M.Refresh()
    end,M)
end
local events=CreateFrame('Frame')
local function UpdateCasting(v)
    if isCasting~=v then isCasting=v;M.Refresh()end
end
local function IsExpected(unit,castGUID,spellID)
    return unit=='player' and M.Enabled() and pending and Head()==pending.entry
        and not Secret(spellID) and spellID==pending.recipeID
        and not Secret(castGUID) and type(castGUID)=='string' and castGUID~=''
end
local function CaptureCast(unit,castGUID,spellID)
    if IsExpected(unit,castGUID,spellID) and pending.phase~='uncertain' and Now()-pending.requestedAt<3 then
        if not pending.castGUID or pending.castGUID==castGUID then
            pending.castGUID=castGUID;pending.phase='casting';UpdateCasting(true)
            local attempt=pending
            C_Timer.After(30,function()
                if pending==attempt then MarkUncertain('Enchant tracking timed out. Inspect the item, then check the result before retrying.') end
            end)
        end
    end
end
events:SetScript('OnEvent',function(_,event,...)
    if event=='ADDON_LOADED' then
        local addon=...
        if addon=='Blizzard_Professions' then HookRecipeSelection();HookProfessionWindow();SyncSoon() end
    elseif event=='PLAYER_LOGIN' then
        Data();HookReplaceDialogs();HookProfessionWindow()
        if (C_AddOns and C_AddOns.IsAddOnLoaded and C_AddOns.IsAddOnLoaded('Blizzard_Professions')) or (IsAddOnLoaded and IsAddOnLoaded('Blizzard_Professions')) then HookRecipeSelection()end
        SyncSoon()
    elseif event=='TRADE_SKILL_SHOW' then
        HookProfessionWindow();SyncSoon()
    elseif event=='TRADE_SKILL_CLOSE' then
        HideBoth()
    elseif event=='PLAYER_REGEN_DISABLED' then
        ResetAttempt()
        -- The secure state driver disarms the protected action during lockdown.
    elseif event=='UNIT_SPELLCAST_SENT' then
        local unit,target,castGUID,spellID=...
        CaptureCast(unit,castGUID,spellID)
    elseif event=='UNIT_SPELLCAST_START' then
        CaptureCast(...)
    elseif event=='UNIT_SPELLCAST_STOP' or event=='UNIT_SPELLCAST_INTERRUPTED' or event=='UNIT_SPELLCAST_FAILED' then
        local unit,castGUID=...
        if unit=='player' and pending and not Secret(castGUID) and pending.castGUID==castGUID then
            if event~='UNIT_SPELLCAST_STOP' then ResetAttempt() else
                isCasting=false
                local attempt=pending
                C_Timer.After(0,function()
                    if pending==attempt then MarkUncertain('The cast stopped without a confirmed result. Inspect the item before retrying.') end
                end)
            end
            M.Refresh()
        end
    elseif event=='UNIT_SPELLCAST_SUCCEEDED' then
        local unit,castGUID,spellID=...
        if IsExpected(unit,castGUID,spellID) and pending.castGUID==castGUID then
            local entry=pending.entry
            local current=FindTarget()
            if current and GUID(current)==pending.targetGUID then
                entry.remaining=entry.remaining-1
                if entry.remaining<=0 then table.remove(Data().entries,1) end
                ResetAttempt();M.Refresh()
                SetStatus(tostring(entry.name or RecipeName(entry.recipeID))..' complete. '..Total()..' remaining.')
            else
                ResetAttempt();M.Refresh();SetStatus('Target changed; queue count was preserved. Verify the completed enchant.')
            end
        end
    elseif event=='PLAYER_REGEN_ENABLED' then
        M.SyncTab();M.Refresh()
    elseif event=='PLAYER_EQUIPMENT_CHANGED' or event=='BAG_UPDATE_DELAYED' then
        if panel and panel:IsShown() then M.Refresh()end
    elseif event=='UI_ERROR_MESSAGE' then
        local a,b=...
        if Now()-lastPress<3 and not Secret(b) and type(b)=='string' then
            if pending then MarkUncertain(b..' Inspect the item before retrying.') else Disarm();M.Refresh();SetStatus(b) end
        end
    end
end)
for _,name in ipairs({'ADDON_LOADED','PLAYER_LOGIN','TRADE_SKILL_SHOW','TRADE_SKILL_CLOSE',
    'UNIT_SPELLCAST_SENT','UNIT_SPELLCAST_START','UNIT_SPELLCAST_STOP','UNIT_SPELLCAST_INTERRUPTED',
    'UNIT_SPELLCAST_FAILED','UNIT_SPELLCAST_SUCCEEDED','PLAYER_REGEN_DISABLED','PLAYER_REGEN_ENABLED',
    'PLAYER_EQUIPMENT_CHANGED','BAG_UPDATE_DELAYED','UI_ERROR_MESSAGE'}) do
    pcall(events.RegisterEvent,events,name)
end
