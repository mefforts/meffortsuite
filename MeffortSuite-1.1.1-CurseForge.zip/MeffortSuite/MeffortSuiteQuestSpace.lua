-- One restricted owner permits binding cleanup on combat entry and dialogue hide.
local owner
local secureReady=false
local controllerAttempted=false
local addon={}
MeffortSuiteQuestSpace=addon
local activeMode=nil
local boundSignature=nil
local warningShown=false
local hooks=setmetatable({},{__mode="k"})
local menuChoices={}
local menuButtons={}
local HINT_WIDTH=255

local function InCombat() return InCombatLockdown and InCombatLockdown() end
local function Secret(v) return issecretvalue and issecretvalue(v) end
local function Number(v) if not Secret(v) and type(v)=="number" then return v end end
local function Text(v) if not Secret(v) and type(v)=="string" then return v end end
local function Boolean(v)
    if Secret(v) then return nil end
    if v==true or v==1 then return true end
    if v==false or v==0 then return false end
end
local function Visible(f)
    if not f then return false end
    if f.IsVisible then local ok,v=pcall(f.IsVisible,f);if ok then return v==true end end
    if f.IsShown then local ok,v=pcall(f.IsShown,f);if ok then return v==true end end
    return false
end
local function Enabled(f)
    if not Visible(f) then return false end
    if f.IsEnabled then local ok,v=pcall(f.IsEnabled,f);return ok and v==true end
    return true
end
local function Configured()
    return type(MeffortSuiteDB)=="table" and MeffortSuiteDB.masterEnabled~=false
        and (not MeffortSuite or not MeffortSuite.StandaloneLoaded("MeffortBars"))
        and MeffortSuiteDB.questSpace==true
end
local function Warn(message)
    if warningShown then return end
    warningShown=true
    if DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then
        DEFAULT_CHAT_FRAME:AddMessage("|cff60d9bdMeffortSuite|r: "..message)
    end
end
-- Manual shortcuts include repeatable quests and entries with incomplete metadata.
local function Add(list,kind,id,title,ready)
    if #list>=9 or not Number(id) then return end
    list[#list+1]={kind=kind,id=id,title=Text(title) or "Option",ready=ready==true}
end

local function GossipChoices()
    if not Visible(GossipFrame) or not C_GossipInfo then return {} end
    local result={}
    local function Get(functionName)
        local fn=C_GossipInfo[functionName]
        if type(fn)~="function" then return {} end
        local ok,list=pcall(fn)
        return ok and type(list)=="table" and list or {}
    end
    if type(C_GossipInfo.SelectActiveQuest)=="function" then
        for _,entry in ipairs(Get("GetActiveQuests")) do
            if type(entry)=="table" and Boolean(entry.isIgnored)~=true then
                Add(result,"gossipActive",entry.questID,entry.title,Boolean(entry.isComplete))
            end
        end
    end
    if type(C_GossipInfo.SelectAvailableQuest)=="function" then
        for _,entry in ipairs(Get("GetAvailableQuests")) do
            if type(entry)=="table" and Boolean(entry.isIgnored)~=true then
                Add(result,"gossipAvailable",entry.questID,entry.title,false)
            end
        end
    end
    if type(C_GossipInfo.SelectOption)=="function" then
        for _,entry in ipairs(Get("GetOptions")) do
            if type(entry)=="table" then
                local status=Number(entry.status)
                -- Bind only available options; leave locked entries click-only.
                if status==nil or status==0 then
                    Add(result,"gossipOption",entry.gossipOptionID,entry.name,false)
                end
            end
        end
    end
    return result
end

local function GreetingChoices()
    if not Visible(QuestFrameGreetingPanel) then return {} end
    if not GetNumActiveQuests or not GetNumAvailableQuests then return {} end
    local okA,active=pcall(GetNumActiveQuests)
    local okB,available=pcall(GetNumAvailableQuests)
    if not okA or not okB or not Number(active) or not Number(available) then return {} end
    local result={}
    if type(GetActiveTitle)=="function" and type(SelectActiveQuest)=="function" then
        for i=1,math.min(40,active) do
            local ok,title,complete=pcall(GetActiveTitle,i)
            if ok and Text(title) then
                Add(result,"greetingActive",i,title,Boolean(complete))
            end
        end
    end
    if type(SelectAvailableQuest)=="function" then
        for i=1,math.min(40,available) do
            local title
            if type(GetAvailableTitle)=="function" then
                local ok,value=pcall(GetAvailableTitle,i)
                if ok then title=Text(value) end
            end
            if not title and type(GetAvailableQuestInfo)=="function" then
                local ok,value=pcall(GetAvailableQuestInfo,i)
                if ok then title=Text(value) end
            end
            Add(result,"greetingAvailable",i,title or "Available quest",false)
        end
    end
    return result
end

local function MenuChoices()
    -- Visible panels take precedence over stale quest-event state.
    if Visible(GossipFrame) then return GossipChoices() end
    if Visible(QuestFrameGreetingPanel) then return GreetingChoices() end
    return {}
end
local function SelectChoice(choice)
    if not choice or not Configured() or InCombat() then return end
    if not (Visible(GossipFrame) or Visible(QuestFrameGreetingPanel)) then return end
    local selections={
        gossipActive=C_GossipInfo and C_GossipInfo.SelectActiveQuest,
        gossipAvailable=C_GossipInfo and C_GossipInfo.SelectAvailableQuest,
        gossipOption=C_GossipInfo and C_GossipInfo.SelectOption,
        greetingActive=SelectActiveQuest,
        greetingAvailable=SelectAvailableQuest,
    }
    local fn=selections[choice.kind]
    if type(fn)=="function" then
        local ok=pcall(fn,choice.id)
        if not ok then Warn("The client refused a quest-menu selection.") end
    end
end
local function MakeProxy(index)
    local name="MeffortSuiteQuestMenuKey"..index
    local f=CreateFrame("Button",name,UIParent)
    if not f then return end
    if f.Show then f:Show() end
    if f.SetScript then
        f:SetScript("OnClick",function()
            local displayed=menuChoices[index]
            if not displayed then return end
            local current=MenuChoices()
            local fresh=current[index]
            if not fresh or fresh.kind~=displayed.kind or fresh.id~=displayed.id then
                addon.Refresh()
                return
            end
            SelectChoice(fresh)
        end)
    end
    return name
end
for i=1,9 do menuButtons[i]=MakeProxy(i) end

local hint,labels
local function EnsureHint()
    if hint or not UIParent then return end
    hint=CreateFrame("Frame",nil,UIParent)
    if not hint then return end
    if hint.SetSize then hint:SetSize(HINT_WIDTH,36) end
    if hint.SetFrameStrata then hint:SetFrameStrata("DIALOG") end
    if hint.CreateTexture then
        local bg=hint:CreateTexture(nil,"BACKGROUND")
        if bg then
            if bg.SetAllPoints then bg:SetAllPoints(hint) end
            if bg.SetColorTexture then bg:SetColorTexture(0.08,0.07,0.06,0.90) end
        end
    end
    labels={}
    if hint.CreateFontString then
        for i=1,10 do
            local label=hint:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            if label then
                if label.SetPoint then label:SetPoint("TOPLEFT",hint,"TOPLEFT",9,-7-17*(i-1)) end
                if label.SetWidth then label:SetWidth(HINT_WIDTH-16) end
                if label.SetJustifyH then label:SetJustifyH("LEFT") end
                labels[i]=label
            end
        end
    end
    if hint.Hide then hint:Hide() end
end
local function UpdateHint(choices)
    EnsureHint()
    if not hint then return end
    if #choices==0 or not Configured() or InCombat() then
        if hint.Hide then hint:Hide() end
        return
    end
    local parent=Visible(GossipFrame) and GossipFrame or QuestFrameGreetingPanel
    if hint.ClearAllPoints and hint.SetPoint and parent then
        hint:ClearAllPoints()
        local flip=false
        if UIParent and UIParent.GetRight and parent.GetRight then
            local okA,screen=pcall(UIParent.GetRight,UIParent)
            local okB,right=pcall(parent.GetRight,parent)
            if okA and okB and type(screen)=="number" and type(right)=="number"
                and right+HINT_WIDTH+12>screen then flip=true end
        end
        if flip then hint:SetPoint("TOPRIGHT",parent,"TOPLEFT",-6,-30)
        else hint:SetPoint("TOPLEFT",parent,"TOPRIGHT",6,-30) end
    end
    if hint.SetSize then hint:SetSize(HINT_WIDTH,20+17*#choices) end
    for i=1,10 do
        local label=labels and labels[i]
        if label and label.SetText then
            local choice=choices[i]
            if choice then
                local prefix=i==1 and "SPACE / 1" or tostring(i)
                local labelText=choice.ready and "Turn in: " or ""
                -- FontString clipping preserves complete UTF-8 glyphs.
                if label.SetWordWrap then label:SetWordWrap(false) end
                if label.SetMaxLines then label:SetMaxLines(1) end
                label:SetText("|cffffd076"..prefix.."|r  "..labelText..choice.title)
            else label:SetText("") end
        end
    end
    if hint.Show then hint:Show() end
end
local function VisibleButton(names)
    for _,name in ipairs(names) do if Enabled(_G[name]) then return name end end
end
local function QuestTarget()
    if activeMode=="detail" then
        return VisibleButton({"QuestFrameAcceptButton","QuestInfoAcceptButton"})
    elseif activeMode=="progress" then
        return VisibleButton({"QuestFrameCompleteButton","QuestInfoCompleteButton"})
    elseif activeMode=="reward" then
        return VisibleButton({"QuestFrameCompleteQuestButton","QuestInfoCompleteQuestButton"})
    end
    if Visible(QuestFrame) then
        if Visible(QuestFrameRewardPanel) then
            return VisibleButton({"QuestFrameCompleteQuestButton","QuestInfoCompleteQuestButton"})
        elseif Visible(QuestFrameProgressPanel) then
            return VisibleButton({"QuestFrameCompleteButton","QuestInfoCompleteButton"})
        elseif Visible(QuestFrameDetailPanel) then
            return VisibleButton({"QuestFrameAcceptButton","QuestInfoAcceptButton"})
        end
    end
end
local function EnsureController()
    if secureReady then return true end
    if InCombat() or type(RegisterStateDriver)~="function" then return false end
    if controllerAttempted then return false end
    controllerAttempted=true
    local ok,created=pcall(CreateFrame,"Frame","MeffortSuiteQuestBindingOwner",UIParent,
        "SecureHandlerStateTemplate,SecureHandlerShowHideTemplate")
    if not ok or not created or type(created.Execute)~="function" then return false end
    local ready=pcall(function()
        created:SetAttribute("_onhide",[[self:ClearBindings()]])
        created:SetAttribute("_onstate-questcombat",[[
            if newstate == "off" then self:ClearBindings() end
        ]])
        RegisterStateDriver(created,"questcombat","[combat] off; on")
        created:Execute([[self:ClearBindings()]])
        created:Hide()
    end)
    if not ready then return false end
    owner,secureReady=created,true
    return true
end
function addon.Available()
    if secureReady then return true end
    return false,InCombat() and "Quest shortcuts will initialize after combat."
        or "Secure quest shortcuts are unavailable; normal controls remain active."
end
local function BindingPlan()
    local plan={}
    if not Configured() then return plan,{} end
    local questButton=QuestTarget()
    if questButton then
        plan[1]={key="SPACE",button=questButton}
        return plan,{}
    end
    local choices=MenuChoices()
    if #choices>0 then
        if menuButtons[1] then plan[#plan+1]={key="SPACE",button=menuButtons[1]} end
        for i=1,math.min(9,#choices) do
            if menuButtons[i] then plan[#plan+1]={key=tostring(i),button=menuButtons[i]} end
        end
    end
    return plan,choices
end
local function Signature(plan,choices)
    local parts={}
    for _,b in ipairs(plan) do parts[#parts+1]=b.key.."="..b.button end
    for _,c in ipairs(choices) do parts[#parts+1]=c.kind..":"..tostring(c.id) end
    return table.concat(parts,"|")
end
function addon.Refresh()
    if InCombat() then
        -- The secure state driver withdraws bindings during lockdown.
        boundSignature=nil
        menuChoices={}
        if hint and hint.Hide then hint:Hide() end
        return
    end
    if not EnsureController() then
        if Configured() then Warn("Quest keyboard shortcuts require secure state handling; normal controls remain active.") end
        return
    end
    local plan,choices=BindingPlan()
    local signature=Signature(plan,choices)
    menuChoices=choices
    UpdateHint(choices)
    if signature==boundSignature then return end
    local ok=pcall(owner.Execute,owner,[[self:ClearBindings()]])
    boundSignature=nil
    if not ok then return end
    if #plan==0 then owner:Hide();return end
    -- Inherit dialogue visibility so secure OnHide also handles combat closure.
    local parent=(#choices>0 and (Visible(GossipFrame) and GossipFrame or QuestFrameGreetingPanel))
        or _G[plan[1].button]
    if not parent then owner:Hide();return end
    local statements={}
    for _,b in ipairs(plan) do
        statements[#statements+1]=string.format("self:SetBindingClick(true,%q,%q,\"LeftButton\")",b.key,b.button)
    end
    local applied=pcall(function()
        owner:SetParent(parent)
        owner:Show()
        owner:Execute(table.concat(statements,"\n"))
    end)
    if not applied then
        pcall(owner.Execute,owner,[[self:ClearBindings()]])
        owner:Hide()
        Warn("Could not activate quest keyboard shortcuts; normal controls remain active.")
        return
    end
    boundSignature=signature
end
local pendingChecks=false
local function ScheduleChecks()
    addon.Refresh()
    if pendingChecks or not (C_Timer and C_Timer.After) then return end
    pendingChecks=true
    -- Coalesce related events; still refresh once after each population stage.
    for i,delay in ipairs({0.08,0.22,0.45}) do
        local final=i==3
        C_Timer.After(delay,function()
            if final then pendingChecks=false end
            addon.Refresh()
        end)
    end
end
local function Hook(frame,onShow,onHide)
    if not frame or hooks[frame] or not frame.HookScript then return end
    hooks[frame]=true
    if onShow then frame:HookScript("OnShow",onShow) end
    if onHide then frame:HookScript("OnHide",onHide) end
end
local function HookQuestUI()
    Hook(QuestFrameDetailPanel,function()activeMode="detail";ScheduleChecks()end,
        function()if activeMode=="detail"then activeMode=nil end;addon.Refresh()end)
    Hook(QuestFrameProgressPanel,function()activeMode="progress";ScheduleChecks()end,
        function()if activeMode=="progress"then activeMode=nil end;addon.Refresh()end)
    Hook(QuestFrameRewardPanel,function()activeMode="reward";ScheduleChecks()end,
        function()if activeMode=="reward"then activeMode=nil end;addon.Refresh()end)
    Hook(QuestFrameGreetingPanel,function()activeMode=nil;ScheduleChecks()end,
        function()addon.Refresh()end)
    Hook(GossipFrame,function()activeMode=nil;ScheduleChecks()end,
        function()addon.Refresh()end)
    for _,name in ipairs({"QuestFrameAcceptButton","QuestInfoAcceptButton",
        "QuestFrameCompleteButton","QuestInfoCompleteButton",
        "QuestFrameCompleteQuestButton","QuestInfoCompleteQuestButton"}) do
        Hook(_G[name],function()ScheduleChecks()end,function()addon.Refresh()end)
    end
    Hook(QuestFrame,nil,function()activeMode=nil;addon.Refresh()end)
end
local watcher=CreateFrame("Frame")
for _,event in ipairs({"PLAYER_LOGIN","PLAYER_REGEN_ENABLED","PLAYER_REGEN_DISABLED","QUEST_DETAIL",
    "QUEST_FINISHED","QUEST_ACCEPTED","QUEST_GREETING","QUEST_PROGRESS",
    "QUEST_COMPLETE","GOSSIP_SHOW","GOSSIP_CLOSED","QUEST_LOG_UPDATE"}) do
    watcher:RegisterEvent(event)
end
watcher:SetScript("OnEvent",function(_,event)
    if event=="PLAYER_REGEN_DISABLED" then addon.Refresh();return end
    if event=="PLAYER_LOGIN" then
        if type(MeffortSuiteDB)=="table" and MeffortSuiteDB.questSpace==nil then
            MeffortSuiteDB.questSpace=true
        end
    elseif event=="QUEST_DETAIL" then activeMode="detail"
    elseif event=="QUEST_PROGRESS" then activeMode="progress"
    elseif event=="QUEST_COMPLETE" then activeMode="reward"
    elseif event=="QUEST_FINISHED" or event=="QUEST_ACCEPTED"
        or event=="QUEST_GREETING" or event=="GOSSIP_SHOW"
        or event=="GOSSIP_CLOSED" then activeMode=nil end
    HookQuestUI()
    if event=="PLAYER_REGEN_ENABLED" or event=="QUEST_LOG_UPDATE" then
        addon.Refresh()
    else
        ScheduleChecks()
    end
end)
