-- Open the map only for one unambiguous taxi service; never select a destination.
local suite = MeffortSuite
MeffortSuiteFlightMasters = {}
local flight = MeffortSuiteFlightMasters
local TAXI_ICON = 132057
local selectedInGossip = false
local status = "not used"

local function DB()
    if type(MeffortSuiteDB) ~= "table" then MeffortSuiteDB = {} end
    return MeffortSuiteDB
end

function flight.Enabled()
    return DB().autoOpenFlightMaster ~= false
end

function flight.SetEnabled(value)
    DB().autoOpenFlightMaster = value == true
    suite.Message("Skip flight master dialogue " .. (flight.Enabled() and "ON" or "OFF") ..
        (flight.Enabled() and ". Hold Shift while talking to see the normal dialogue." or "."))
end

local function SelectFlightMasterGossip()
    if selectedInGossip or not suite or not suite.Active() or not flight.Enabled() then return end
    if type(IsShiftKeyDown) == "function" and IsShiftKeyDown() then return end
    if type(InCombatLockdown) == "function" and InCombatLockdown() then return end
    if not C_GossipInfo or type(C_GossipInfo.GetOptions) ~= "function"
        or type(C_GossipInfo.SelectOption) ~= "function" then return end

    local ok, options = pcall(C_GossipInfo.GetOptions)
    if not ok or type(options) ~= "table" then return end
    local choice, matches = nil, 0
    for _, option in ipairs(options) do
        if type(option) == "table" and tonumber(option.icon) == TAXI_ICON
            and type(option.gossipOptionID) == "number"
            and (option.status == nil or option.status == 0) then
            matches = matches + 1
            choice = option.gossipOptionID
        end
    end
    if matches ~= 1 then return end
    -- Set before selection in case choosing it fires nested gossip events.
    selectedInGossip = true
    local selected, err = pcall(C_GossipInfo.SelectOption, choice)
    if selected then
        status = "taxi map requested"
    else
        status = "selection failed: " .. tostring(err)
        suite.Message("Flight master: " .. status)
    end
end

function flight.Status()
    suite.Message("Flight master dialogue: " .. (flight.Enabled() and "ON" or "OFF") ..
        "; last action: " .. status)
end

function flight.Command(arg)
    arg = (arg or ""):lower():match("^%s*(.-)%s*$")
    if arg == "on" then
        flight.SetEnabled(true)
    elseif arg == "off" then
        flight.SetEnabled(false)
    else
        flight.Status()
        if arg ~= "status" then suite.Message("/msuite flight on | off | status") end
    end
end

local frame = CreateFrame("Frame")
frame:RegisterEvent("PLAYER_LOGIN")
frame:RegisterEvent("GOSSIP_SHOW")
frame:RegisterEvent("GOSSIP_CLOSED")
frame:RegisterEvent("TAXIMAP_OPENED")
frame:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        local db = DB()
        if db.autoOpenFlightMaster == nil then db.autoOpenFlightMaster = true end
    elseif event == "GOSSIP_SHOW" then
        SelectFlightMasterGossip()
    elseif event == "GOSSIP_CLOSED" or event == "TAXIMAP_OPENED" then
        selectedInGossip = false
    end
end)
