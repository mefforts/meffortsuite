MeffortSuiteRewardValue={}
local M=MeffortSuiteRewardValue
local events=CreateFrame("Frame")
local entries,roots,requested={},{},{}
local hooked,tooltipHooks,scrollHooks={},{},{}
local elapsed,queued,away=0,false,false
local generation=0
local shown,waiting,skipped=0,0,0
local Refresh,Queue
local MAX=1000000000000
local function Secret(v)
    if type(issecretvalue)~="function" then return false end
    local ok,result=pcall(issecretvalue,v)
    return not ok or result==true
end
local function Number(v)
    if not Secret(v) and type(v)=="number" and v==v and v~=math.huge and v~=-math.huge then return v end
end
local function Text(v)if not Secret(v) and type(v)=="string" then return v end end
local function Read(fn,...)
    if type(fn)~="function" then return end
    local ok,v=pcall(fn,...)
    if ok and not Secret(v) then return v end
end
local function Combat()return Read(InCombatLockdown)~=false end
function M.Enabled()return type(MeffortSuiteDB)~="table" or MeffortSuiteDB.questRewardVendor~=false end
local function Active()return not away and M.Enabled() and (not MeffortSuite or not MeffortSuite.Active or MeffortSuite.Active())end
local function Visible(f)
    return f and Read(f.IsForbidden,f)~=true and Read(f.IsVisible or f.IsShown,f)==true
end
local function Money(value)
    if value==0 then return "No vendor value" end
    local result={}
    for _,coin in ipairs({{10000,"Gold"},{100,"Silver"},{1,"Copper"}}) do
        local n=math.floor(value/coin[1]);value=value%coin[1]
        if n>0 then result[#result+1]=n.."|TInterface\\MoneyFrame\\UI-"..coin[2].."Icon:10:10:1:0|t" end
    end
    return table.concat(result," ")
end
local function Details(button)
    if not Active() or Combat() or not Visible(button) or Text(button.objectType)~="item" then return end
    local kind,index=Text(button.type),Number(Read(button.GetID,button))
    if (kind~="choice" and kind~="reward") or not index or index<1 or index>100 or index~=math.floor(index) then return end
    local log=QuestInfoFrame and QuestInfoFrame.questLog==true
    local quest
    if log then quest=Read(C_QuestLog and C_QuestLog.GetSelectedQuest) else quest=Read(GetQuestID) end
    local expected=Number(button.questID)
    if expected and (not Number(quest) or expected~=quest) then return end
    local get,linkGetter
    if log then
        if kind=="choice" then get=GetQuestLogChoiceInfo else get=GetQuestLogRewardInfo end
        linkGetter=GetQuestLogItemLink
    else get=GetQuestItemInfo;linkGetter=GetQuestItemLink end
    if type(get)~="function" then return end
    local ok,name,_,count
    if log then ok,name,_,count=pcall(get,index) else ok,name,_,count=pcall(get,kind,index) end
    count=Number(count)
    if not ok or not Text(name) or not count or count<1 or count>1000000 or count~=math.floor(count) then return end
    local link=Text(Read(linkGetter,kind,index))
    local id=link and tonumber(link:match("item:(%d+)"))
    if not Number(id) or id<1 or id>2147483647 then return end
    local getter=C_Item and C_Item.GetItemInfo or GetItemInfo
    if type(getter)~="function" then return end
    local loaded,itemName,_,_,_,_,_,_,_,_,_,sell=pcall(getter,link)
    sell=Number(sell)
    if not loaded or not Text(itemName) or not sell then
        if not requested[id] then requested[id]=true;Read(C_Item and C_Item.RequestLoadItemDataByID,id) end
        return nil,"waiting"
    end
    if sell<0 or sell~=math.floor(sell) or sell>MAX/count then return end
    return {value=sell*count,count=count,text=Money(sell*count)}
end
local function Tooltip(button)
    local tip=GameTooltip
    if not tip or Read(tip.GetOwner,tip)~=button then return end
    local data=Details(button)
    if not data or type(tip.AddDoubleLine)~="function" then return end
    tip:AddDoubleLine(data.count>1 and ("Vendor value (x"..data.count..")") or "Vendor value",data.text,.72,.67,.56,1,.82,.35)
    tip:Show()
end
local function HideAll()
    shown=0
    for _,entry in pairs(entries) do if entry.frame then entry.frame:Hide() end end
    events:SetScript("OnUpdate",nil)
end
local function Rect(f)
    if Read(f.IsForbidden,f)==true then return end
    local scale=Number(Read(f.GetEffectiveScale,f))
    local parentScale=Number(Read(UIParent and UIParent.GetEffectiveScale,UIParent)) or 1
    local left,right,top,bottom=Number(Read(f.GetLeft,f)),Number(Read(f.GetRight,f)),Number(Read(f.GetTop,f)),Number(Read(f.GetBottom,f))
    if not scale or scale<=0 or parentScale<=0 or not left or not right or not top or not bottom then return end
    local ratio=scale/parentScale
    if right<=left or top<=bottom then return end
    return left*ratio,right*ratio,top*ratio,bottom*ratio,ratio
end
local function Layout(button,entry,data)
    local name=button.Name
    if not name then local key=Text(Read(button.GetName,button));name=key and _G[key.."Name"] end
    if not name then return false end
    local left,right,top,bottom,scale=Rect(button)
    local nl,nr,nt,nb,ns=Rect(name)
    local height,justify=Number(Read(name.GetStringHeight,name)),Text(Read(name.GetJustifyV,name))
    if not left or not nl or not height or height<=0 or not justify then return false end
    local inkBottom
    if justify=="TOP" then inkBottom=nt-height*ns
    elseif justify=="BOTTOM" then inkBottom=nb
    elseif justify=="MIDDLE" then inkBottom=(nt+nb-height*ns)/2 else return false end
    local labelBottom,labelTop=bottom+2*scale,bottom+12*scale
    local width=math.min(nr,right-3*scale)-nl
    if inkBottom<labelTop+scale or width<35*scale or nl<left or labelTop>top then return false end
    local ancestor=Read(button.GetParent,button)
    for _=1,16 do
        if not ancestor or ancestor==UIParent then break end
        if Read(ancestor.GetClipsChildren,ancestor)==true or Read(ancestor.IsObjectType,ancestor,"ScrollFrame")==true then
            local al,ar,at,ab=Rect(ancestor)
            if not al or nl<al or nl+width>ar or labelBottom<ab or labelTop>at then return false end
            if not scrollHooks[ancestor] then
                scrollHooks[ancestor]=true
                if Read(ancestor.IsObjectType,ancestor,"ScrollFrame")==true and type(ancestor.HookScript)=="function" then
                    pcall(ancestor.HookScript,ancestor,"OnVerticalScroll",function()Queue()end)
                end
                if type(hooksecurefunc)=="function" then
                    for _,method in ipairs({"SetVerticalScroll","SetScrollPercentage"}) do
                        if type(ancestor[method])=="function" then pcall(hooksecurefunc,ancestor,method,function()Queue()end) end
                    end
                end
            end
        end
        local parent=Read(ancestor.GetParent,ancestor)
        if parent==ancestor then return false end
        ancestor=parent
    end
    if not entry.frame then
        -- Own the overlay independently of native reward layout and input.
        local f=CreateFrame("Frame",nil,UIParent)
        f:Hide();f:EnableMouse(false)
        local label=f:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        label:SetPoint("LEFT",f,"LEFT",0,0);label:SetJustifyH("LEFT")
        label:SetTextColor(.92,.78,.49,1)
        entry.frame,entry.label=f,label
    end
    local f,label=entry.frame,entry.label
    label:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF",9*scale,"")
    label:SetText(data.value>0 and ("Vendor: "..data.text) or data.text)
    local textWidth=Number(Read(label.GetStringWidth,label))
    if not textWidth or textWidth>width then return false end
    f:SetFrameStrata(Text(Read(button.GetFrameStrata,button)) or "MEDIUM")
    f:SetFrameLevel((Number(Read(button.GetFrameLevel,button)) or 1)+3)
    f:SetSize(width,10*scale)
    f:ClearAllPoints();f:SetPoint("BOTTOMLEFT",button,"BOTTOMLEFT",nl-left,2*scale)
    f:Show()
    return true
end
local function Discover()
    local count=0
    for _ in pairs(entries) do count=count+1 end
    for _,root in ipairs({QuestInfoRewardsFrame or false,MapQuestInfoRewardsFrame or false}) do
        if root and Read(root.IsForbidden,root)~=true and not roots[root] and not Combat() and type(root.HookScript)=="function" then
            roots[root]=true;root:HookScript("OnHide",HideAll)
        end
        local buttons=root and root.RewardButtons
        if type(buttons)=="table" then
            for _,button in pairs(buttons) do
                if count>=80 then break end
                if type(button)=="table" and Read(button.IsForbidden,button)~=true and not entries[button] and type(button.HookScript)=="function" and not Combat() then
                    entries[button]={};count=count+1
                    button:HookScript("OnHide",function()local e=entries[button];if e and e.frame then e.frame:Hide() end end)
                    button:HookScript("OnEnter",function()
                        local log=QuestInfoFrame and QuestInfoFrame.questLog==true
                        if not tooltipHooks[log and "SetQuestLogItem" or "SetQuestItem"] then Tooltip(button) end
                    end)
                end
            end
        end
    end
end
Refresh=function()
    shown,waiting,skipped=0,0,0
    if not Active() or Combat() then HideAll();return end
    Discover()
    local visible=Visible(QuestInfoRewardsFrame) or Visible(MapQuestInfoRewardsFrame)
    for button,entry in pairs(entries) do
        if entry.frame then entry.frame:Hide() end
        if visible and Visible(button) then
            local data,reason=Details(button)
            if data then
                if Layout(button,entry,data) then shown=shown+1 else skipped=skipped+1 end
            elseif reason=="waiting" then waiting=waiting+1 end
        end
    end
    if visible then
        events:SetScript("OnUpdate",function(_,delta)
            elapsed=elapsed+delta
            if elapsed>=.2 then elapsed=0;Refresh() end
        end)
    else HideAll();requested={} end
end
Queue=function()
    HideAll()
    if queued then return end
    if C_Timer and type(C_Timer.After)=="function" then
        local token=generation
        queued=true;C_Timer.After(0,function()
            if token~=generation then return end
            queued=false;Refresh()
        end)
    else Refresh() end
end
local function Install()
    if Combat() or type(hooksecurefunc)~="function" then return end
    for _,key in ipairs({"QuestInfo_Display","QuestInfo_ShowRewards","QuestInfo_GetRewardButton"}) do
        if not hooked[key] and type(_G[key])=="function" then
            local ok,result=pcall(hooksecurefunc,key,Queue);hooked[key]=ok and result~=false
        end
    end
    if GameTooltip then
        for _,key in ipairs({"SetQuestItem","SetQuestLogItem"}) do
            if not tooltipHooks[key] and type(GameTooltip[key])=="function" then
                local ok,result=pcall(hooksecurefunc,GameTooltip,key,function(tip)
                    local button=Read(tip.GetOwner,tip)
                    if entries[button] then Tooltip(button) end
                end)
                tooltipHooks[key]=ok and result~=false
            end
        end
    end
end
function M.Refresh()Install();Refresh()end
function M.SetEnabled(value)
    if type(MeffortSuiteDB)~="table" then MeffortSuiteDB={} end
    MeffortSuiteDB.questRewardVendor=value==true;M.Refresh()
end
function M.Status()
    return (M.Enabled() and "enabled" or "disabled").."; labels "..shown.."; waiting for item data "..waiting..
        "; compact/unsupported layouts "..skipped.."; hover a reward for its stack value"
end
for _,event in ipairs({"PLAYER_LOGIN","ADDON_LOADED","QUEST_DETAIL","QUEST_PROGRESS","QUEST_COMPLETE",
    "QUEST_FINISHED","QUEST_ITEM_UPDATE","GET_ITEM_INFO_RECEIVED","QUEST_LOG_UPDATE","PLAYER_REGEN_DISABLED",
    "PLAYER_REGEN_ENABLED","UI_SCALE_CHANGED","PLAYER_ENTERING_WORLD","PLAYER_LEAVING_WORLD"}) do pcall(events.RegisterEvent,events,event) end
events:SetScript("OnEvent",function(_,event)
    if event=="QUEST_FINISHED" or event=="PLAYER_LEAVING_WORLD" or event=="PLAYER_REGEN_DISABLED" then
        generation=generation+1;queued=false
        if event=="PLAYER_LEAVING_WORLD" then away=true end
        shown,waiting,skipped=0,0,0;HideAll();requested={};return
    end
    if event=="PLAYER_ENTERING_WORLD" then away=false end
    Install();Queue()
end)
