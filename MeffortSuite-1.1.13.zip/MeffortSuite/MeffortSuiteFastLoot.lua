MeffortSuiteFastLoot={}
local M=MeffortSuiteFastLoot
local events=CreateFrame("Frame")
local open,stopped,serial=false,false,0
local status="waiting for loot"
local function Secret(value)
    if type(issecretvalue)~="function" then return false end
    local ok,result=pcall(issecretvalue,value)
    return not ok or result==true
end
local function Number(value)
    if not Secret(value) and type(value)=="number" and value==value and value>=0
        and value<math.huge and value==math.floor(value) then return value end
end
local function Read(fn,...)
    if type(fn)~="function" then return end
    local ok,value=pcall(fn,...)
    if ok and not Secret(value) then return value end
end
function M.Enabled()
    return type(MeffortSuiteDB)=="table" and MeffortSuiteDB.fastAutoLoot==true
end
local function Active()
    return M.Enabled() and MeffortSuite and MeffortSuite.Active and MeffortSuite.Active()
end
function M.RefreshMaster()
    if not Active() then stopped=true;serial=serial+1 end
end
function M.SetEnabled(value)
    if type(MeffortSuiteDB)~="table" then MeffortSuiteDB={} end
    MeffortSuiteDB.fastAutoLoot=value==true
    if not M.Enabled() then stopped=true end
end
local function AutoLoot(value)
    if Secret(value) then return false end
    if value~=nil then return value==true or value==1 end
    local default=Read(GetCVarBool,"autoLootDefault")
    local modified=Read(IsModifiedClick,"AUTOLOOTTOGGLE")
    if type(default)~="boolean" or type(modified)~="boolean" then return false end
    return default~=modified
end
local function LootPass(token,fromItem)
    if not open or stopped or token~=serial or not Active() then return end
    if Read(InCombatLockdown)~=false then status="combat or combat state unavailable; native loot retained";return end
    if type(LootSlot)~="function" or type(GetLootSlotType)~="function" then
        status="loot API unavailable";return
    end
    local observer=MeffortSuiteLootValue
    if observer and type(observer.PrepareLoot)=="function" then
        local ok=pcall(observer.PrepareLoot,fromItem)
        if not ok then status="loot snapshot unavailable; native loot retained";return end
    end
    local count=Number(Read(GetNumLootItems))
    if not count or count>100 then status="loot slots not ready; native loot retained";return end
    local requests=0
    for slot=count,1,-1 do
        if not open or stopped or token~=serial or not Active() or Read(InCombatLockdown)~=false then break end
        local kind=Number(Read(GetLootSlotType,slot))
        if kind==(LOOT_SLOT_ITEM or 1) or kind==(LOOT_SLOT_MONEY or 2) or kind==(LOOT_SLOT_CURRENCY or 3) then
            local ok,result
            if MeffortSuite and type(MeffortSuite.TryClientCall)=="function" then
                ok,result=MeffortSuite.TryClientCall("Fast loot","loot slot",LootSlot,slot)
            else ok,result=pcall(LootSlot,slot) end
            if not ok or Secret(result) or result==false then
                stopped=true;status="loot request refused; native loot retained";return
            end
            requests=requests+1
        end
    end
    if not stopped and (not open or token==serial) then status="fast pass: "..requests.." slots requested" end
end
local function Start(autoLoot,fromItem)
    if open then return end
    open,stopped=true,false
    serial=serial+1
    local token=serial
    if not Active() then status="disabled";return end
    if not AutoLoot(autoLoot) then status="manual loot; native modifier respected";return end
    if not C_Timer or type(C_Timer.After)~="function" then status="loot timer unavailable; native loot retained";return end
    -- Let all loot-open listeners snapshot metadata before requesting slots.
    C_Timer.After(0,function()LootPass(token,fromItem)end)
end
function M.Status()return (M.Enabled() and "enabled; " or "disabled; ")..status end
for _,event in ipairs({"LOOT_OPENED","LOOT_CLOSED","LOOT_BIND_CONFIRM","UI_ERROR_MESSAGE","PLAYER_LEAVING_WORLD"}) do
    pcall(events.RegisterEvent,events,event)
end
events:SetScript("OnEvent",function(_,event,...)
    if event=="LOOT_OPENED" then Start(...)
    elseif event=="LOOT_CLOSED" or event=="PLAYER_LEAVING_WORLD" then
        open=false;serial=serial+1
    elseif event=="LOOT_BIND_CONFIRM" and open then
        stopped=true;status="confirmation required; use the native loot window"
    elseif event=="UI_ERROR_MESSAGE" and open then
        local text=select(2,...)
        if Secret(text) or type(text)~="string" then return end
        for _,key in ipairs({"ERR_INV_FULL","ERR_ITEM_MAX_COUNT","ERR_LOOT_LOCKED","ERR_CANT_LOOT_THAT_NOW"}) do
            if type(_G[key])=="string" and text==_G[key] then
                stopped=true;status="loot interrupted; use the native loot window";return
            end
        end
    end
end)
