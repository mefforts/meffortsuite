local M={}
MeffortSuiteFishingBobber=M

local suite=MeffortSuite
local fishing=MeffortSuiteFishing
local tracker=CreateFrame("Frame")
local ring,glow,readout,anchoredPlate,anchoredOffset,screenAnchor,trackingText
local cast,beforeCast,lastBobber,lastStats
local softEventGuid
local status="waiting for a fishing cast"
local elapsed=0
local sampleInterval,flashDuration,flashSpeed=.05,.35,48
local defaultSize,minSize,maxSize=34,16,64
local defaultOffset,minOffset,maxOffset=-18,-80,40
local ringTexture="Interface\\AddOns\\MeffortSuite\\Textures\\BobberRing.tga"
local zoomSetting={name="cameraFov",applied=50}
local castSettings={
    {name="SoftTargetInteract", minimum=2, applied=3},
    {name="SoftTargetNameplateInteract", minimum=1, applied=1},
    {name="SoftTargetIconGameObject", minimum=1, applied=1},
    {name="SoftTargetIconInteract", minimum=1, applied=1},
    {name="SoftTargetInteractRange", minimum=30, applied=30},
    {name="SoftTargetInteractArc", minimum=2, applied=2},
    zoomSetting,
}

local function Secret(value)
    if type(issecretvalue)~="function" then return false end
    local ok,result=pcall(issecretvalue,value)
    return not ok or result==true
end
local function Number(value)
    if not Secret(value) and type(value)=="number" and value==value
        and value~=math.huge and value~=-math.huge then return value end
end
local function Text(value)
    if not Secret(value) and type(value)=="string" then return value end
end
local function Read(fn,...)
    if type(fn)~="function" then return end
    local ok,a,b=pcall(fn,...)
    if ok and not Secret(a) and not Secret(b) then return a,b end
end
local function Field(frame,key)
    if Secret(frame) or not frame then return end
    return Read(function() return frame[key] end)
end
local function Method(frame,key,...)
    return Read(Field(frame,key),frame,...)
end
local function Account()
    if type(MeffortSuiteDB)~="table" then MeffortSuiteDB={} end
    return MeffortSuiteDB
end
local function Character()
    if type(MeffortSuiteCharDB)~="table" then MeffortSuiteCharDB={} end
    return MeffortSuiteCharDB
end
function M.Enabled() return Character().fishingBobberHighlight~=false end
function M.MotionEnabled() return Character().fishingBobberMotion==true end
function M.ZoomEnabled() return Character().fishingBobberZoom==true end
local function LayoutValue(value,fallback,minimum,maximum)
    value=Number(value) or fallback
    return math.max(minimum,math.min(maximum,math.floor(value+.5)))
end
function M.Size() return LayoutValue(Character().fishingBobberSize,defaultSize,minSize,maxSize) end
function M.Offset() return LayoutValue(Character().fishingBobberOffset,defaultOffset,minOffset,maxOffset) end
local function InCombat() return Read(InCombatLockdown)==true end
local function ReadCVar(name)
    local value=Read(C_CVar and C_CVar.GetCVar or GetCVar,name)
    if type(value)=="string" or type(value)=="number" then return Number(tonumber(value)) end
end
local function WriteCVar(name,value)
    local setter=C_CVar and C_CVar.SetCVar or SetCVar
    if type(setter)~="function" then return end
    if suite and suite.TryClientCall then
        suite.TryClientCall("Bobber ring","set "..name,setter,name,tostring(value))
    else
        pcall(setter,name,tostring(value))
    end
end
local function RestoreCastSettings(only)
    local db=Account()
    local saved=db.fishingBobberTargetRestore
    if type(saved)~="table" then db.fishingBobberTargetRestore=nil;return true end
    if InCombat() then return not next(saved) or (only~=nil and saved[only]==nil) end
    for _,option in ipairs(castSettings) do
        local name=option.name
        if not only or name==only then
            local entry=saved[name]
            if type(entry)=="table" and Number(entry.previous) and entry.applied==option.applied then
                local current=ReadCVar(name)
                if current==entry.applied then
                    WriteCVar(name,entry.previous)
                    local after=ReadCVar(name)
                    if after and after~=entry.applied then saved[name]=nil end
                elseif current~=nil then
                    saved[name]=nil
                end
            else
                saved[name]=nil
            end
        end
    end
    if not next(saved) then db.fishingBobberTargetRestore=nil;return true end
    return only~=nil and saved[only]==nil
end
local function ApplySetting(option,previous)
    local db=Account()
    local saved=db.fishingBobberTargetRestore or {}
    db.fishingBobberTargetRestore=saved
    saved[option.name]={previous=previous,applied=option.applied}
    WriteCVar(option.name,option.applied)
    local after=ReadCVar(option.name)
    if after and after~=option.applied then saved[option.name]=nil end
    if not next(saved) then db.fishingBobberTargetRestore=nil end
    return after==option.applied
end
local function PrepareTargeting()
    for _,option in ipairs(castSettings) do
        if option.minimum then
            local current=ReadCVar(option.name)
            if current and current<option.minimum then ApplySetting(option,current) end
        end
    end
end
local function ZoomView(now)
    if cast.zoomAttempted or not M.ZoomEnabled() then return end
    cast.zoomAttempted=true
    local current=ReadCVar(zoomSetting.name)
    if not current or current<=0 then cast.zoomStatus="field of view unavailable";return end
    if current<=zoomSetting.applied then cast.zoomStatus="already narrow";return end
    if ApplySetting(zoomSetting,current) then
        cast.zoomStatus="50 degrees"
        cast.motionPausedUntil=now+.85
    else
        cast.zoomStatus="field of view change unconfirmed"
    end
end

local function BobberGuid(value)
    local guid=Text(value)
    if guid and guid:match("^GameObject%-%d+%-%d+%-%d+%-%d+%-35591%-") then return guid end
end
local function SoftBobber()
    local guid=Text(Read(UnitGUID,"softinteract"))
    if guid and guid~="" then return BobberGuid(guid) end
    return softEventGuid
end
local function PlateGuid(plate)
    local token=Text(Field(plate,"namePlateUnitToken")) or Text(Field(Field(plate,"UnitFrame"),"unit"))
    return token and BobberGuid(Read(UnitGUID,token))
end
local function Visible(plate)
    return plate and Method(plate,"IsForbidden")~=true and Method(plate,"IsVisible")==true
end
local function Nameplates()
    local plates=C_NamePlate and Read(C_NamePlate.GetNamePlates)
    return type(plates)=="table" and plates or {}
end
local function HasNameplateAPI()
    return C_NamePlate and (type(C_NamePlate.GetNamePlateForUnit)=="function" or type(C_NamePlate.GetNamePlates)=="function")
end
local function CaptureBeforeCast(castID)
    local existing={}
    local guid=SoftBobber()
    if guid then existing[guid]=true end
    for _,plate in ipairs(Nameplates()) do
        local known=Visible(plate) and PlateGuid(plate)
        if known then existing[known]=true end
    end
    beforeCast={id=Text(castID),existing=existing}
end
local function NewBobber(guid)
    return guid and not cast.existing[guid] and (not cast.id or guid~=lastBobber)
end
local function FindPlate()
    if not HasNameplateAPI() then return nil,nil,"Nameplate API unavailable." end
    local guid=SoftBobber()
    local preferred=cast.guid or (NewBobber(guid) and guid)
    if preferred and guid==preferred then
        local plate=C_NamePlate and Read(C_NamePlate.GetNamePlateForUnit,"softinteract")
        local plateGuid=plate and PlateGuid(plate)
        if Visible(plate) and (not plateGuid or plateGuid==preferred) then return plate,preferred end
    end
    local candidate,candidateGuid,ambiguous
    for _,plate in ipairs(Nameplates()) do
        local found=Visible(plate) and PlateGuid(plate)
        if found then
            if found==preferred then return plate,found end
            if not cast.guid and NewBobber(found) then
                if candidateGuid and candidateGuid~=found then ambiguous=true end
                candidate,candidateGuid=plate,found
            end
        end
    end
    if not ambiguous and candidate and not preferred then return candidate,candidateGuid end
    if preferred then return nil,nil,"Bobber found. Waiting for its nameplate." end
    if ambiguous then return nil,nil,"Multiple bobbers. Face yours to select it." end
    return nil,nil,"Looking for a bobber. Face the water where you cast."
end

local function CreateRing()
    if ring then return end
    ring=CreateFrame("Frame","MeffortSuiteBobberRing",UIParent)
    local size=M.Size()
    ring:SetSize(size,size)
    ring:SetFrameStrata("HIGH")
    ring:EnableMouse(false)
    local outline=ring:CreateTexture(nil,"ARTWORK")
    outline:SetAllPoints(ring)
    outline:SetTexture(ringTexture)
    glow=ring:CreateTexture(nil,"OVERLAY")
    glow:SetAllPoints(ring)
    glow:SetTexture(ringTexture)
    glow:SetBlendMode("ADD")
    glow:SetAlpha(0)
    readout=ring:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    readout:SetPoint("BOTTOM",ring,"TOP",0,1)
    readout:SetTextColor(.61,1,.9)
    readout:SetShadowColor(0,0,0,1)
    readout:SetShadowOffset(1,-1)
    ring:Hide()
end
local function ShowTracking(message)
    if not message then
        if trackingText then trackingText:Hide() end
        return
    end
    if not trackingText then
        local hint=CreateFrame("Frame",nil,UIParent)
        hint:SetSize(360,22)
        hint:SetPoint("CENTER",UIParent,"CENTER",0,-126)
        hint:SetFrameStrata("HIGH")
        hint:EnableMouse(false)
        trackingText=hint:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        trackingText:SetAllPoints(hint)
        trackingText:SetTextColor(.61,1,.9)
        trackingText:SetShadowColor(0,0,0,1)
        trackingText:SetShadowOffset(1,-1)
    end
    trackingText:SetText("Bobber ring | "..message)
    trackingText:Show()
end
local function HideRing()
    if ring then
        ring:Hide()
        ring:ClearAllPoints()
        glow:SetAlpha(0)
    end
    anchoredPlate,anchoredOffset,screenAnchor=nil,nil,nil
    if cast then cast.sample=nil;cast.flashUntil=nil;cast.flashStrength=nil;cast.above=false end
end
local function ScreenCenter(frame)
    if Method(frame,"IsAnchoringSecret")==true then return nil,nil,nil,"secret anchor" end
    if Method(frame,"HasAnyAccessRestrictions")==true then return nil,nil,nil,"restricted frame" end
    local getter=Field(frame,"GetCenter")
    if type(getter)~="function" then return nil,nil,nil,"center unavailable" end
    local ok,x,y=pcall(getter,frame)
    if not ok then return nil,nil,nil,"center refused" end
    if Secret(x) or Secret(y) then return nil,nil,nil,"secret coordinates" end
    x,y=Number(x),Number(y)
    if not x or not y then return nil,nil,nil,"center unavailable" end
    local scale=Number(Method(frame,"GetEffectiveScale"))
    if not scale or scale<=0 then return nil,nil,nil,"scale unavailable" end
    return x,y,scale
end
local function AnchorRing(plate)
    local offset=M.Offset()
    if plate~=anchoredPlate or offset~=anchoredOffset then
        HideRing()
        local ok,result
        if suite and suite.TryClientCall then
            ok,result=suite.TryClientCall("Bobber ring","attach to nameplate",ring.SetPoint,ring,"CENTER",plate,"CENTER",0,offset)
        else
            ok,result=pcall(ring.SetPoint,ring,"CENTER",plate,"CENTER",0,offset)
        end
        anchoredPlate,anchoredOffset=plate,offset
        screenAnchor=not ok or result==false
    end
    if screenAnchor then
        local x,y,scale=ScreenCenter(plate)
        local rootScale=Number(Method(UIParent,"GetEffectiveScale"))
        if not x or not rootScale or rootScale<=0 then return false end
        local ratio=scale/rootScale
        ring:ClearAllPoints()
        local ok,result=pcall(ring.SetPoint,ring,"CENTER",UIParent,"BOTTOMLEFT",x*ratio,y*ratio+offset)
        return ok and result~=false
    end
    return true
end
local function TrackMotion(plate,now)
    if not M.MotionEnabled() then
        readout:Hide()
        glow:SetAlpha(0)
        cast.sample=nil
        cast.motion="off"
        return
    end
    if cast.motionPausedUntil and now<cast.motionPausedUntil then
        cast.sample=nil;cast.flashUntil=nil;cast.above=false
        cast.motion="waiting for camera zoom"
        readout:SetText("Camera zooming")
        readout:Show()
        glow:SetAlpha(0)
        return
    end
    local source=screenAnchor and "nameplate" or "ring"
    local x,y,scale,issue=ScreenCenter(screenAnchor and plate or ring)
    if not screenAnchor and not x and (issue=="center unavailable" or issue=="scale unavailable") then
        local px,py,plateScale,plateIssue=ScreenCenter(plate)
        if px then
            source="nameplate"
            x,y,scale=px,py,plateScale
        else
            issue="ring "..issue..", nameplate "..plateIssue
        end
    elseif not x then
        issue=source.." "..issue
    end
    local zoom=Number(Read(GetCameraZoom))
    if not x then
        cast.sample=nil;cast.flashUntil=nil;cast.above=false
        cast.motion=issue
        readout:Hide()
        glow:SetAlpha(0)
        return
    end
    cast.motion=source.." coordinates"
    readout:Show()
    local previous=cast.sample
    cast.sample={x=x,y=y,scale=scale,zoom=zoom,time=now,source=source}
    local dt=previous and now-previous.time
    if Read(IsMouselooking)==true or (previous and previous.zoom~=zoom) then
        cast.sample=nil;cast.flashUntil=nil;cast.above=false
        readout:SetText("Camera moving")
        glow:SetAlpha(0)
        return
    end
    local speed=0
    if previous and dt>0 and dt<.30 and previous.scale==scale and previous.source==source then
        local dx,dy=x-previous.x,y-previous.y
        speed=Number(math.sqrt(dx*dx+dy*dy)*scale/dt) or 0
        cast.samples=cast.samples+1
        cast.peak=math.max(cast.peak,speed)
        if speed>=flashSpeed then
            if not cast.above then cast.flashes=cast.flashes+1 end
            cast.flashUntil=now+flashDuration
            cast.flashStrength=math.min(1,.35+speed/220)
        end
        cast.above=speed>=flashSpeed
    else
        cast.above=false
    end
    local fade=cast.flashUntil and math.max(0,(cast.flashUntil-now)/flashDuration) or 0
    glow:SetAlpha(fade*(cast.flashStrength or 0))
    readout:SetText(string.format("Anchor %.0f px/s  |  Peak %.0f",speed,cast.peak))
end
local function Stop(reason)
    if cast then
        lastBobber=cast.guid or lastBobber
        lastStats={samples=cast.samples,peak=cast.peak,flashes=cast.flashes,motion=cast.motion,
            result=cast.result or status,targeting=cast.targeting,ringSeen=cast.ringSeen,zoomStatus=cast.zoomStatus}
        cast=nil
    end
    HideRing()
    ShowTracking(nil)
    tracker:SetScript("OnUpdate",nil)
    status=RestoreCastSettings() and reason or "fishing settings restoration pending"
end
local function IsActive()
    return M.Enabled() and (not suite or not suite.Active or suite.Active())
end
local function Scan()
    if not cast then return end
    if not IsActive() or InCombat() then Stop("waiting for your next fishing cast");return end
    local now=Number(Read(GetTime))
    if not now then Stop("clock unavailable");return end
    local inChannel=fishing.IsFishingChannel()
    if inChannel then
        cast.sawChannel=true
        cast.channelMissingAt=nil
    elseif cast.sawChannel then
        cast.channelMissingAt=cast.channelMissingAt or now
    end
    if (cast.channelMissingAt and now-cast.channelMissingAt>.35) or now-cast.started>32 then
        Stop("waiting for your next fishing cast")
        return
    end
    local plate,guid,why=FindPlate()
    if not plate then
        HideRing()
        status=why
        cast.result=status
        ShowTracking(status)
        return
    end
    CreateRing()
    if not AnchorRing(plate) then
        ring:Hide()
        cast.sample=nil
        status="Nameplate found. Its screen position is unavailable."
        cast.result=status
        ShowTracking(status)
        return
    end
    cast.guid=guid
    cast.ringSeen=true
    ShowTracking(nil)
    ring:Show()
    ZoomView(now)
    TrackMotion(plate,now)
    status="ring visible"
    cast.result=status
end
local function Start(castID)
    local previous=beforeCast
    beforeCast=nil
    if cast then Stop("new cast") end
    if not IsActive() or InCombat() then return end
    if not RestoreCastSettings() then status="fishing settings restoration pending";return end
    local now=Number(Read(GetTime))
    if not now then status="clock unavailable";return end
    castID=Text(castID)
    cast={id=castID,started=now,existing=previous and previous.id==castID and previous.existing or {},
        peak=0,samples=0,flashes=0}
    elapsed=0
    if HasNameplateAPI() then PrepareTargeting() end
    cast.targeting=string.format("Interact %s, nameplate %s, icon %s",tostring(ReadCVar("SoftTargetInteract") or "?"),
        tostring(ReadCVar("SoftTargetNameplateInteract") or "?"),tostring(ReadCVar("SoftTargetIconGameObject") or "?"))
    tracker:SetScript("OnUpdate",function(_,dt)
        elapsed=elapsed+dt
        if elapsed>=sampleInterval then
            elapsed=0
            Scan()
        end
    end)
    Scan()
end

function M.Refresh()
    if not IsActive() then
        beforeCast=nil
        Stop(M.Enabled() and "suite off" or "off")
    elseif not cast then
        if not InCombat() and fishing.IsFishingChannel() then Start()
        else status=RestoreCastSettings() and "waiting for your next fishing cast" or "fishing settings restoration pending" end
    end
end
function M.SetEnabled(value)
    Character().fishingBobberHighlight=value==true
    M.Refresh()
end
function M.SetMotionEnabled(value)
    Character().fishingBobberMotion=value==true
    if cast then
        cast.sample=nil;cast.flashUntil=nil;cast.above=false
        cast.motion=M.MotionEnabled() and "waiting for a sample" or "off"
        if ring and not M.MotionEnabled() then readout:Hide();glow:SetAlpha(0) end
    end
end
function M.SetSize(value)
    local size=LayoutValue(value,defaultSize,minSize,maxSize)
    Character().fishingBobberSize=size
    if ring then ring:SetSize(size,size) end
end
function M.SetOffset(value)
    Character().fishingBobberOffset=LayoutValue(value,defaultOffset,minOffset,maxOffset)
    if cast then Scan() end
end
function M.SetZoomEnabled(value)
    Character().fishingBobberZoom=value==true
    if value==true then
        if cast then cast.zoomAttempted=nil;Scan() end
    else
        local saved=Account().fishingBobberTargetRestore
        local restoring=type(saved)=="table" and saved[zoomSetting.name]~=nil
        local restored=RestoreCastSettings(zoomSetting.name)
        if cast then
            cast.zoomStatus=restored and "off" or "restoration pending"
            if restoring and restored then cast.motionPausedUntil=(Number(Read(GetTime)) or 0)+.85 end
        end
    end
end
function M.Status()
    local stats=cast or lastStats
    if not stats then return status end
    return string.format("%s; %s %s; ring shown %s, motion %s; samples %d, peak %.0f px/s, flashes %d; zoom %s; %s",status,
        cast and "current cast" or "last cast",stats.result or "started",stats.ringSeen and "yes" or "no",
        stats.motion or "no visible anchor",stats.samples,stats.peak,stats.flashes,
        stats.zoomStatus or "off",stats.targeting or "targeting unavailable")
end

for _,event in ipairs({"PLAYER_LOGIN","PLAYER_ENTERING_WORLD","PLAYER_LEAVING_WORLD","PLAYER_LOGOUT",
    "PLAYER_REGEN_DISABLED","PLAYER_REGEN_ENABLED","PLAYER_EQUIPMENT_CHANGED","CVAR_UPDATE"}) do
    tracker:RegisterEvent(event)
end
pcall(tracker.RegisterEvent,tracker,"PLAYER_SOFT_INTERACT_CHANGED")
for _,event in ipairs({"UNIT_SPELLCAST_SENT","UNIT_SPELLCAST_CHANNEL_START","UNIT_SPELLCAST_CHANNEL_STOP"}) do
    tracker:RegisterUnitEvent(event,"player")
end
tracker:SetScript("OnEvent",function(_,event,unit,second,third,fourth)
    if event=="PLAYER_SOFT_INTERACT_CHANGED" then
        softEventGuid=BobberGuid(second)
    elseif event=="UNIT_SPELLCAST_SENT" then
        if Text(unit)=="player" and IsActive() and fishing.IsFishingSpell(fourth) then CaptureBeforeCast(third) end
    elseif event=="UNIT_SPELLCAST_CHANNEL_START" then
        if Text(unit)=="player" and IsActive() and (fishing.IsFishingSpell(third) or fishing.IsFishingChannel()) then Start(second) end
    elseif event=="UNIT_SPELLCAST_CHANNEL_STOP" then
        local ended=Text(second)
        if cast and Text(unit)=="player" and (not cast.id or not ended or ended==cast.id) then
            Stop("waiting for your next fishing cast")
        end
    elseif event=="PLAYER_LEAVING_WORLD" or event=="PLAYER_LOGOUT" or event=="PLAYER_REGEN_DISABLED" then
        beforeCast=nil
        softEventGuid=nil
        Stop("waiting for your next fishing cast")
    elseif event=="PLAYER_EQUIPMENT_CHANGED" then
        if cast and not fishing.IsPoleEquipped() then Stop("waiting for a fishing pole") end
    elseif event=="CVAR_UPDATE" then
        if not cast then return end
        local changed=Text(unit)
        local saved=Account().fishingBobberTargetRestore
        if not changed or not saved then return end
        changed=changed:lower():gsub("_","")
        for _,option in ipairs(castSettings) do
            local entry=saved[option.name]
            if entry and changed==option.name:lower() then
                local current=ReadCVar(option.name)
                if current and current~=entry.applied then
                    saved[option.name]=nil
                    if option==zoomSetting then
                        cast.zoomStatus="field of view changed in game"
                        cast.motionPausedUntil=(Number(Read(GetTime)) or 0)+.85
                    end
                end
                return
            end
        end
    else
        M.Refresh()
    end
end)
