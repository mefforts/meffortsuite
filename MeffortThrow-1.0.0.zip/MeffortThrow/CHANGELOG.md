# 1.0.0

Initial release for World of Warcraft: Forever. Rogues and Warriors can Throw at the enemy under the cursor with right-click or Shift + right-click. Each character can choose its own shortcut in Settings.
