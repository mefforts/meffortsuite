local THROW_SPELL_ID = 2764
local WEAPON_CLASS = 2
local THROWN_SUBCLASS = 16
local FISHING_POLE_SUBCLASS = 20

local MODES = {
    right = { label = "Right-click", key = "BUTTON2", condition = "nomod" },
    shift = { label = "Shift + right-click", key = "SHIFT-BUTTON2", condition = "mod:shift,nomod:ctrl,nomod:alt" },
    off = { label = "Off" },
}

local events = CreateFrame("Frame")
local controller, attackButton
local settingsCategory, modeSetting
local supportedClass, activeMode, pending
local ownMouselook, spellDataRequested
local thrownType, fishingPoleType, throwName
local unavailableReason

local function Message(message)
    print("|cff69ccf0MeffortThrow:|r " .. message)
end

local function StopMouselook()
    if not ownMouselook then return end
    ownMouselook = false
    events:SetScript("OnUpdate", nil)
    MouselookStop()
end

local function CheckMouselookRelease()
    if not IsMouseButtonDown("RightButton") then StopMouselook() end
end

local function HandleClick(_, button, down)
    if button ~= "RightButton" then return end
    if not down then
        StopMouselook()
    elseif activeMode == "right" and not ownMouselook and not IsMouselooking() then
        if MouselookStart() ~= false then
            ownMouselook = true
            events:SetScript("OnUpdate", CheckMouselookRelease)
        end
    end
end

local function ClearBinding()
    if not activeMode then return end
    UnregisterStateDriver(controller, "throw")
    ClearOverrideBindings(controller)
    controller:SetAttribute("state-throw", nil)
    activeMode = nil
end

local function InitSecureFrames()
    attackButton = CreateFrame("Button", "MeffortThrowAttackButton", UIParent, "SecureActionButtonTemplate")
    attackButton:RegisterForClicks("AnyDown", "AnyUp")
    attackButton:SetAttribute("useOnKeyDown", true)
    attackButton:SetAttribute("*type2", "macro")
    attackButton:SetScript("PostClick", HandleClick)

    controller = CreateFrame("Frame", "MeffortThrowBinding", UIParent, "SecureHandlerStateTemplate")
    controller:SetAttribute("_onstate-throw", [[
        self:ClearBindings()
        if newstate == "on" then
            self:SetBindingClick(false, self:GetAttribute("throw-key"), "MeffortThrowAttackButton", "RightButton")
        end
    ]])

    -- The default driver polls mouseover. Ask it to check promptly when the hovered unit changes.
    if SecureStateDriverManager then
        SecureStateDriverManager:RegisterEvent("UPDATE_MOUSEOVER_UNIT")
    end
end

local function ReadClientData()
    thrownType = C_Item.GetItemSubClassInfo(WEAPON_CLASS, THROWN_SUBCLASS)
    fishingPoleType = C_Item.GetItemSubClassInfo(WEAPON_CLASS, FISHING_POLE_SUBCLASS)
    throwName = C_Spell.GetSpellName(THROW_SPELL_ID)
    if not throwName and not spellDataRequested and C_Spell.RequestLoadSpellData then
        spellDataRequested = true
        C_Spell.RequestLoadSpellData(THROW_SPELL_ID)
    end
    return thrownType and fishingPoleType and throwName
end

local function ApplyMode()
    local mode = MeffortThrowDB.mode
    if mode == "off" and not activeMode then
        pending, unavailableReason = false, nil
        return
    end
    if mode == activeMode then
        pending = false
        return
    end
    if InCombatLockdown() then
        pending = true
        return
    end

    pending = false
    ClearBinding()
    unavailableReason = nil
    if mode == "off" then return end
    if not supportedClass then
        unavailableReason = "Throw shortcuts are available to Rogues and Warriors."
        return
    end
    if not (RegisterStateDriver and UnregisterStateDriver and ClearOverrideBindings and SecureCmdOptionParse
        and C_Item and C_Item.GetItemSubClassInfo and C_Spell and C_Spell.GetSpellName
        and C_Macro and C_Macro.RunMacroText) then
        unavailableReason = "This client does not provide the required secure controls."
        return
    end
    if mode == "right" and not (MouselookStart and MouselookStop and IsMouselooking and IsMouseButtonDown) then
        unavailableReason = "Camera controls are unavailable. Choose Shift + right-click."
        return
    end
    if not ReadClientData() then
        unavailableReason = "Waiting for Throw and weapon data from the client."
        return
    end
    if not SecureCmdOptionParse(("[known:%d] yes; [noknown:%d] no"):format(THROW_SPELL_ID, THROW_SPELL_ID)) then
        unavailableReason = "The client could not verify Throw."
        return
    end

    local choice = MODES[mode]
    local target = "[@mouseover,exists,harm,nodead]"
    local condition = ("[equipped:%s] off; [known:%d,equipped:%s,%s,@mouseover,exists,harm,nodead] on; off"):format(
        fishingPoleType, THROW_SPELL_ID, thrownType, choice.condition)

    -- Mouseover and equipment can change before the state driver updates.
    local action = ("/stopmacro [equipped:%s][noequipped:%s][noknown:%d]\n/target %s mouseover\n/cast %s %s"):format(
        fishingPoleType, thrownType, THROW_SPELL_ID, target, target, throwName)
    if not controller then InitSecureFrames() end
    attackButton:SetAttribute("*macrotext2", action)
    controller:SetAttribute("throw-key", choice.key)
    activeMode = mode
    local ok, result = pcall(RegisterStateDriver, controller, "throw", condition)
    if not ok or result == false then
        ClearBinding()
        unavailableReason = "The client could not register the Throw shortcut."
    end
end

local function GetMode()
    return MeffortThrowDB.mode
end

local function SetMode(mode)
    MeffortThrowDB.mode = mode
    ApplyMode()
    if pending then Message("Change saved. It will apply after combat.") end
end

local function Status()
    local label = MODES[GetMode()].label
    if pending then
        Message(label .. " selected. " .. MODES[activeMode or "off"].label .. " applies until combat ends.")
    elseif unavailableReason then
        Message(label .. " selected. " .. unavailableReason)
    elseif not activeMode then
        Message("Off.")
    else
        local state = SecureCmdOptionParse(("[equipped:%s] pole; [noknown:%d] spell; [noequipped:%s] weapon; ready"):format(
            fishingPoleType, THROW_SPELL_ID, thrownType))
        local hint = {
            pole = "Unequip your fishing pole to use Throw.",
            spell = "Learn Throw to use this shortcut.",
            weapon = "Equip a thrown weapon to use this shortcut.",
            ready = "Ready. Use the shortcut on a living enemy.",
        }
        Message(label .. ". " .. (hint[state] or "The client could not check your equipment."))
    end
end

local function RegisterSettings()
    if not (Settings and Settings.RegisterVerticalLayoutCategory and Settings.RegisterProxySetting
        and Settings.VarType and Settings.CreateControlTextContainer and Settings.CreateDropdown
        and Settings.RegisterAddOnCategory and Settings.OpenToCategory) then return end

    local function Options()
        local container = Settings.CreateControlTextContainer()
        for _, mode in ipairs({ "right", "shift", "off" }) do
            container:Add(mode, MODES[mode].label)
        end
        return container:GetData()
    end

    local category = Settings.RegisterVerticalLayoutCategory("MeffortThrow")
    modeSetting = Settings.RegisterProxySetting(category, "MeffortThrow_Mode", Settings.VarType.String,
        "Throw shortcut", "right", GetMode, SetMode)
    Settings.CreateDropdown(category, modeSetting, Options,
        "Targets a living enemy under the cursor and uses Throw. Requires a thrown weapon and the Throw skill.")
    Settings.RegisterAddOnCategory(category)
    settingsCategory = category
end

local function SlashCommand(text)
    local command = text:match("^%s*(%S*)%s*$")
    command = command and command:lower()
    if command == "on" then command = "right" end
    if MODES[command] then
        if modeSetting then modeSetting:SetValue(command) else SetMode(command) end
        if not pending then Status() end
    elseif command == "status" then
        Status()
    elseif command == "" and settingsCategory then
        Settings.OpenToCategory(settingsCategory:GetID())
    else
        Message("Use /mthrow on, shift, off, or status.")
    end
end

events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("PLAYER_ENTERING_WORLD")
events:RegisterEvent("SPELLS_CHANGED")
events:RegisterEvent("SPELL_DATA_LOAD_RESULT")
events:RegisterEvent("PLAYER_REGEN_ENABLED")
events:RegisterEvent("GLOBAL_MOUSE_UP")
events:RegisterEvent("PLAYER_LEAVING_WORLD")
events:SetScript("OnEvent", function(_, event, detail, success)
    if event == "PLAYER_LOGIN" then
        local _, class = UnitClass("player")
        supportedClass = class == "ROGUE" or class == "WARRIOR"
        if type(MeffortThrowDB) ~= "table" then MeffortThrowDB = {} end
        if not MODES[MeffortThrowDB.mode] then MeffortThrowDB.mode = "right" end
        SLASH_MEFFORTTHROW1 = "/meffortthrow"
        SLASH_MEFFORTTHROW2 = "/mthrow"
        SlashCmdList.MEFFORTTHROW = SlashCommand
        RegisterSettings()
        ApplyMode()
    elseif event == "PLAYER_LEAVING_WORLD" or (event == "GLOBAL_MOUSE_UP" and detail == "RightButton") then
        StopMouselook()
    elseif MeffortThrowDB and (event == "PLAYER_ENTERING_WORLD" or event == "SPELLS_CHANGED"
        or (event == "SPELL_DATA_LOAD_RESULT" and detail == THROW_SPELL_ID and success)
        or (event == "PLAYER_REGEN_ENABLED" and pending)) then
        ApplyMode()
    end
end)
