MeffortSuiteFishingCamera={}
local M=MeffortSuiteFishingCamera
local fishing=MeffortSuiteFishing
local tracker=CreateFrame("Frame")
local fov,closeup="cameraFov",50
local zoomInTime,zoomOutTime,updateInterval=.65,.50,1/30
local ready,inWorld,wantsZoom=false,false,false
local animation,writing
local castID
local status="off"
local legacySettings={
    SoftTargetInteract=3,
    SoftTargetNameplateInteract=1,
    SoftTargetIconGameObject=1,
    SoftTargetIconInteract=1,
    SoftTargetInteractRange=30,
    SoftTargetInteractArc=2,
    cameraFov=closeup,
}

local function DB()
    if type(MeffortSuiteDB)~="table" then MeffortSuiteDB={} end
    return MeffortSuiteDB
end
local function Char()
    if type(MeffortSuiteCharDB)~="table" then MeffortSuiteCharDB={} end
    return MeffortSuiteCharDB
end
local function Public(value)
    if not issecretvalue or not issecretvalue(value) then return value end
end
local function Read(name)
    local getter=C_CVar and C_CVar.GetCVar or GetCVar
    if type(getter)~="function" then return end
    local ok,value=pcall(getter,name)
    if ok then
        value=Public(value)
        if type(value)=="string" or type(value)=="number" then return tonumber(value) end
    end
end
local function Write(name,value)
    local setter=C_CVar and C_CVar.SetCVar or SetCVar
    if type(setter)=="function" then pcall(setter,name,tostring(value)) end
end
local function Locked()
    return type(InCombatLockdown)=="function" and InCombatLockdown()
end
local function RestoreValue(name,previous,applied)
    if type(previous)~="number" or previous~=previous or previous<0 or previous==math.huge then return true end
    local current=Read(name)
    if current==nil then return false end
    if current~=applied then return true end
    if Locked() then return false end
    Write(name,previous)
    local restored=Read(name)
    return restored~=nil and restored~=applied
end
local function RestoreLegacy()
    local db=DB()
    local entries=db.fishingBobberTargetRestore
    if entries==nil then return true end
    local pending={}
    if type(entries)=="table" then
        for name,applied in pairs(legacySettings) do
            local entry=entries[name]
            if type(entry)=="table" and entry.applied==applied and not RestoreValue(name,entry.previous,applied) then
                pending[name]=entry
            end
        end
    end
    db.fishingBobberTargetRestore=next(pending) and pending or nil
    return db.fishingBobberTargetRestore==nil
end
local function Same(a,b)
    return a and b and math.abs(a-b)<.001
end
local function ValidFov(value)
    return type(value)=="number" and value>0 and value<math.huge
end
local function Lease()
    local db=DB()
    local lease=db.fishingCameraRestore
    -- The prior version stored only the original FOV and always applied 50.
    if ValidFov(lease) then
        lease={previous=lease,applied=closeup}
        db.fishingCameraRestore=lease
    end
    if type(lease)=="table" and ValidFov(lease.previous) and ValidFov(lease.applied) then return lease end
    db.fishingCameraRestore=nil
end
local function CancelAnimation()
    animation=nil
    tracker:SetScript("OnUpdate",nil)
end
local function ReleaseCamera()
    CancelAnimation()
    DB().fishingCameraRestore=nil
end
local function Observe(lease)
    local current=Read(fov)
    if not ValidFov(current) then return nil end
    if Same(current,lease.applied) or (ValidFov(lease.pending) and Same(current,lease.pending)) then
        lease.applied,lease.pending=current,nil
        return current
    end
    ReleaseCamera()
    status="field of view changed in game"
end
local function Apply(lease,value)
    lease.pending=value
    writing=true
    Write(fov,value)
    writing=false
    local after=Observe(lease)
    return Same(after,value)
end

function M.Enabled() return Char().fishingCameraZoom==true end
local function IdleStatus()
    return M.Enabled() and "waiting for a fishing cast" or "off"
end
local function Eligible()
    return ready and inWorld and M.Enabled() and MeffortSuite.Active() and not Locked()
end

local function Animate(lease,from,target,duration)
    local move={from=from,target=target,elapsed=0,sinceUpdate=0}
    animation=move
    status=target==lease.previous and "restoring field of view" or "zooming in"
    tracker:SetScript("OnUpdate",function(_,dt)
        if Locked() then CancelAnimation();status="field of view restoration pending";return end
        move.elapsed=move.elapsed+dt
        move.sinceUpdate=move.sinceUpdate+dt
        local t=math.min(1,move.elapsed/duration)
        if t<1 and move.sinceUpdate<updateInterval then return end
        move.sinceUpdate=0
        local current=Observe(lease)
        if not current then
            if animation then CancelAnimation();status="field of view unavailable" end
            return
        end
        -- Intermediate steps use whole degrees so integer-only clients can apply them.
        local eased=t*t*(3-2*t)
        local value=t==1 and target or math.floor(move.from+(target-move.from)*eased+.5)
        value=math.max(math.min(move.from,target),math.min(math.max(move.from,target),value))
        if not Same(current,value) and not Apply(lease,value) then
            if animation then CancelAnimation();status="field of view change unconfirmed" end
            return
        end
        if t==1 then
            if Same(target,lease.previous) then ReleaseCamera();status=IdleStatus()
            else CancelAnimation();status="zoomed to 50 degrees" end
        end
    end)
end

local function Stop(instant)
    wantsZoom=false
    if not instant and animation and animation.target~=closeup then return false end
    CancelAnimation()
    local lease=Lease()
    if not lease then status=IdleStatus();return true end
    local current=Observe(lease)
    if current and Same(current,lease.previous) then
        ReleaseCamera();status=IdleStatus();return true
    end
    if DB().fishingCameraRestore~=lease then return true end
    if not current or Locked() then status="field of view restoration pending";return false end
    if not instant then Animate(lease,current,lease.previous,zoomOutTime);return false end
    if Apply(lease,lease.previous) then ReleaseCamera();status=IdleStatus();return true end
    status="field of view restoration pending"
    return false
end
function M.Restore()
    local restored=Stop(true)
    local legacyRestored=RestoreLegacy()
    if not legacyRestored then status="prior settings restoration pending" end
    return restored and legacyRestored
end
local function Start()
    if wantsZoom then return end
    if not RestoreLegacy() then status="prior settings restoration pending";return end
    wantsZoom=true
    local lease=Lease()
    local current
    if lease then
        current=Observe(lease)
        if DB().fishingCameraRestore~=lease then return end
    else
        current=Read(fov)
    end
    if not ValidFov(current) then status="field of view unavailable";return end
    if current<=closeup then
        CancelAnimation()
        status="field of view already narrow"
        return
    end
    if not lease then
        lease={previous=current,applied=current}
        DB().fishingCameraRestore=lease
    end
    Animate(lease,current,closeup,zoomInTime)
end
function M.Refresh()
    if Eligible() and fishing.IsFishingChannel() then Start()
    else
        Stop()
        if not RestoreLegacy() then status="prior settings restoration pending" end
    end
end
function M.SetEnabled(value)
    Char().fishingCameraZoom=value==true
    M.Refresh()
end
function M.Status() return status end

for _,event in ipairs({"PLAYER_LOGIN","PLAYER_ENTERING_WORLD","PLAYER_LEAVING_WORLD","PLAYER_LOGOUT",
    "PLAYER_REGEN_DISABLED","PLAYER_REGEN_ENABLED","CVAR_UPDATE"}) do
    tracker:RegisterEvent(event)
end
for _,event in ipairs({"UNIT_SPELLCAST_CHANNEL_START","UNIT_SPELLCAST_CHANNEL_STOP"}) do
    tracker:RegisterUnitEvent(event,"player")
end
tracker:SetScript("OnEvent",function(_,event,unit,guid,spellID)
    if event=="CVAR_UPDATE" then
        unit=Public(unit)
        if not writing and type(unit)=="string" and unit:lower()=="camerafov" then
            local lease=Lease()
            if lease then Observe(lease) end
        end
        return
    end
    if event=="UNIT_SPELLCAST_CHANNEL_START" then
        if unit=="player" and Eligible() and (fishing.IsFishingSpell(spellID) or fishing.IsFishingChannel()) then
            castID=Public(guid)
            Start()
        end
        return
    end
    if event=="UNIT_SPELLCAST_CHANNEL_STOP" then
        guid=Public(guid)
        if unit~="player" or (castID and guid and castID~=guid) then return end
        castID=nil
        Stop()
        return
    end
    if event=="PLAYER_LOGIN" then ready=true;M.Restore();return end
    if event=="PLAYER_ENTERING_WORLD" then inWorld=true end
    if event=="PLAYER_LEAVING_WORLD" or event=="PLAYER_LOGOUT" then inWorld=false;castID=nil;M.Restore();return end
    M.Refresh()
end)
