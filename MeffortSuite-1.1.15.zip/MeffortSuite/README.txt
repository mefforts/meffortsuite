MeffortSuite 1.1.15
WoW Forever | Interface 16001

MeffortSuite adds bag and bank tools, loot and quest reward values, dialogue
shortcuts, fishing controls, waypoints, combat indicators, and custom tooltips
and action-bar labels.

INSTALLATION
Extract the MeffortSuite folder into Interface/AddOns, replacing the previous
MeffortSuite folder. Keep the folder name unchanged, then reload the game.
Existing SavedVariables and saved OFF preferences are retained.

SETTINGS
Open /msuite, or Options > AddOns > MeffortSuite, to configure each tool.
Each feature page starts with setup guidance. Use ? on any page for task links,
saving instructions and report-copy help. Back restores your previous page and
scroll position; text drafts stay intact. /msuite help opens this guidance.
/msuite loot opens loot settings; /msuite rewards opens Quests; /msuite bags
opens bag and bank settings.
The login announcement appears once in chat when logging in or reloading.
Disable Show login message in Options or /msuite > About to hide it for all
characters. No announcement popup opens on screen.

Toggles save immediately. Text fields save with Enter or Apply; Esc discards
the current edit. Unsaved text is retained
when navigating between settings pages. Scope labels identify account and
character settings. The master switch keeps individual preferences saved.
Each launcher tile shows ON and lights up when at least one of its features is
enabled. Tiles show OFF when all their features or the suite are switched off.
Protected input and display changes requested in combat finish after combat.

SOUND CONTROLS
Open Sounds in /msuite, or use /msuite sounds. Mute native pet sounds starts
off and controls the game's Pet Sounds category. It may affect combat pets as
well as companions, and shared creature footsteps may remain audible. It does
not change SFX or master volume. Prior settings restore when disabled or the
suite is off. Manual game-setting changes are respected for the session;
turn the suite option off to retain that choice across reloads.

Advanced sound-file muting accepts verified numeric file IDs, not pet names,
spell IDs or sound-kit IDs. It starts off and has no assumed companion presets.
Shared files affect all creatures using them. Avoid managing the same files
through multiple sound addons. Disabling restores files recorded by this
feature. Unsupported APIs, refused requests and pending restorations appear in
settings and /msuite export. No sound scan, download or repeating timer runs.
Quiet fishing audio is available here and on the Fishing page.

RESTORE DEFAULTS
Restore Defaults is on the launcher, About and Help; /msuite defaults opens
the review directly. Nothing resets until Restore defaults & reload is clicked.
It restores account preferences and this character's feature settings. Bank
item lists, custom sound-file lists, macros, game keybindings, other addons and
other characters' personal settings are kept. Unapplied drafts are discarded.
The suite stops active work and restores the audio and backpack settings it
changed before staging the reset. Finish combat, clear the cursor and release
the right mouse button.
Preferences reset during reload so cached settings initialize cleanly. If a
reload fails, use Reload UI on this page. Pending game-setting restoration prevents
resetting; recovery records are retained. Defaults turn automatic bag/merchant/
bank tools back to their installation choices.

QUEST REWARD VALUES
Vendor labels are enabled by default under /msuite > Quests. They show the
sell value of the full item-reward stack, with native coin icons. Names and
reward selection remain unchanged. When a long name or compact layout leaves
no safe space, hover that recognized reward for its stack value instead.
Unsellable items show No vendor value. Item data may need a moment to load.
Labels withdraw during combat and return afterward; rewards are never selected
or claimed automatically. The preference is saved for all characters.

FLOATING LOOT VALUE
Floating loot value is enabled by default. Open /msuite > Bags > Looting & loot value to turn it off
for all characters or use Preview loot value to see a sample. Include all item
qualities is on by default in this version. Turn it off for grey items only.
Quality and pricing choices apply from the next loot window and are saved
account-wide.

By default, after closing a loot window, one gently rising total combines coins actually
received with the vendor value of all items received. Items with zero vendor
value contribute zero. Quantities and copper values are retained exactly. AoE loot uses one combined total. Short delayed
receipts can update the same float. Unclaimed items and other players' loot do
not count. Fishing and loot opened from inventory items are excluded, including
delayed receipts that might otherwise match a recently closed corpse.

Use Auctionator AH values is optional and starts off in the loot settings.
It uses cached per-item AH estimates from Auctionator's public item-link API.
Missing or invalid prices, bind-on-pickup items and quest items use vendor
value. Coins still count exactly as received, and the quality filter still
applies. No auction scan is started. Estimates depend on your Auctionator data
and are not guaranteed sale proceeds. If its price API is unavailable, vendor
values are used. Diagnostics include the pricing mode and last item sources.

Show vendor + AH together is a separate, optional display in the loot settings. It starts
off. Vendor value appears first, with a smaller muted (AH estimate) beside it.
Both sides include received coins: compare the totals; do not add them together.
Missing AH data uses vendor fallback on the AH side. This display takes priority
over Use Auctionator AH values without changing that saved single-value choice.
The quality filter still applies. Preview loot value shows the selected layout.

Floats rise and fade over six seconds by default. Set Float duration from
2 to 12 seconds in the loot settings and use Preview loot value to try it.
Changes apply to new floats and previews; existing animations keep their timing.

The float uses an available corpse nameplate's screen position outside combat,
or a briefly remembered nameplate position. Otherwise it appears near the
cursor position captured when looting begins. This is a screen-space display;
it cannot follow a hidden 3D corpse as the camera moves. No nameplate layout or
mouse controls are changed.

Uncached included-item prices are requested once and checked briefly. A batch with
unavailable prices is omitted rather than guessed. Native localized self-loot
messages are used where available. The preview does not change bags or money.

FAST AUTO LOOT
Fast auto loot is on by default under /msuite > Bags > Looting & loot value.
The setting applies to all characters and keeps saved OFF choices. The game's
Auto Loot setting and modifier determine whether to loot automatically. The addon
records the loot contents, then requests eligible slots on the next frame.
Confirmations, full bags and combat retain native handling. The feature does not
hide or replace the loot window, change your auto-loot setting or auto-confirm
items. Closing loot, leaving the world or disabling the feature cancels pending
requests. No repeating loot timer is used. Exports include fast-loot status.

BACKPACK FREE SLOTS
Backpack free-slot count is on by default under /msuite > Bags. It enables the
client's native empty-slot number over the backpack icon and uses the game's
counting/update rules. Custom bag bars may manage their own display. No new
overlay, bag scan or repeating timer is added.

Turning the feature or suite off restores the previous game setting. A count
you had already enabled in game can therefore remain visible. Changes during
combat wait until it ends. Manual game-setting changes are respected for the
session; toggle the suite option off/on to reapply it. Failed restoration keeps
its recovery record and is shown in /msuite export. Restore Defaults restores
the recorded native setting before staging its reset.

BAGS AND BANKING
- Sort bags when opened; sell junk and repair with personal gold at merchants.
- If combat interrupts merchant work, unfinished steps resume after combat
  while the merchant remains open. Completed steps are not repeated. Leaving
  the world cancels pending merchant requests.
- Deposit crafting reagents and sort the personal bank when opened.
- In /msuite > Bags, add non-crafting items under Also deposit. Use exact item
  names or numeric item IDs, separated by commas. IDs work across languages.
- Keep in bags takes priority over Also deposit and ordinary reagent deposits.
  Both lists are saved per character. Leave Also deposit empty to retain the
  normal reagent selection.
- Save list changes with Enter or Save list. Saving either list stops remaining
  transfers. Use Deposit items now at an open bank, or reopen the bank, to apply
  the new selection. Requests already sent cannot be reversed.
- Unidentified items stay in bags until their names and stack information are
  ready. Native bank restrictions still apply. Custom lists never fall back to
  an unrestricted deposit if selective transfer support is unavailable.
- Bank dialogue uses the general single-option service shortcut or quest keys.
  Configure them under Quests. Hold Shift to bypass service shortcuts.

FISHING
- Right-click fishing with a pole equipped. New characters use double-click;
  existing choices are retained. Single-click prevents normal camera turning.
- Quiet fishing audio is optional under /msuite > Fishing and starts off
  per character. Equipping a fishing pole mutes music, ambience and dialogue;
  no cast is needed. Sound effects, including the bite, keep their current
  volume, and other effects remain audible. Prior volumes restore when the pole
  is removed or the feature is disabled. Manual volume changes are retained.

COMBAT AND INTERFACE
- Right-click wand, bow, gun, crossbow, and thrown attacks with shared macros.
  Warriors and rogues use one macro that selects the current weapon's attack
  on each input, including equipment swaps during combat. Missing item-cache
  data does not select Throw. An unsuitable/empty weapon slot keeps native input.
- Account/custom macros are preserved. Turning the feature off keeps generated
  macros saved; duplicate removal requires Clean up old duplicate macros or the
  explicit cleanup command. Native macro-space and spell-data limits apply.
- Choose Shift + right-click to keep ordinary right-click for native melee and use
  Shift + right-click for the ranged shot. No measured-distance switch is used.
  Warriors use native single-shot attacks; Shoot Gun needs a new input for each
  shot. Hunter Auto Shot is a separate repeating ability.
- Optional conservative target-range warning; unknown distances show no warning.
- Mage Arcane Blast stacks, countdown, and timer wheel on Blizzard Tracked Buffs.
  Add Arcane Blast to Tracked Buffs first. Combat estimates reconcile afterward.
- English spell explanations, tooltip-header badges, rank alerts, and colors.
- Custom keybind labels under Bars use size 20 and horizontal and vertical
  offsets of -15 by default. Saved sizes and offsets carry forward. Use the live
  position preview to adjust them or Reset appearance to restore the defaults.
  Native red range warnings take priority over custom colors. Full styling
  refreshes wait until combat ends.
- Quest dialogue shortcuts: Space prefers available quests, then quests ready
  to turn in, then unfinished quests. It still accepts/continues/completes the
  current quest dialogue; with no quests it selects the first conversation
  choice. Number keys 1-9 keep their original menu order, with
  labels to the left of native menu icons; * marks the Spacebar choice. Normal controls
  return outside dialogue. Long or unsupported rows keep their native layout;
  their number may be omitted while the keyboard shortcut remains available.
  If a row changes layout unexpectedly, its original spacing is restored and
  its number is paused for that conversation. A new conversation can show it
  again; its keyboard shortcut remains available throughout.
- Single-option service shortcuts open recognized shops, trainers, banks, or
  flight maps only when there is exactly one choice and no quests. Hold Shift
  to see the dialogue. Unknown, paid, or confirmation choices stay manual.
  Configure this under Quests. Banks use this general setting; the separate
  flight-master preference and its saved OFF choice are retained.
- Optional waypoint arrow and flight-master dialogue shortcut. The shortcut
  opens the flight map without selecting a route. Hold Shift to bypass.

COMMANDS
/msuite                         Open settings
/msuite on | off                Toggle the suite; retain feature preferences
/msuite professions             Open fishing settings
/msuite sounds                  Open pet and fishing sound settings
/msuite defaults                Review Restore Defaults; no immediate reset
/msuite fishing status          Check fishing setup
/msuite arcane                  Open Arcane Blast settings
/msuite bank now                Deposit selected items and reagents at an open bank
/msuite bank on | off           Toggle automatic deposits
/msuite bank sort on | off      Toggle personal-bank sorting
/msuite flight on | off         Toggle flight-master shortcut
/msuite services on | off       Toggle single-option service shortcuts
/msuite vendor [retry]          Check or retry merchant actions
/way 49.4 12.9                  Set a native map pin at percentage coordinates
/way Hillsbrad Foothills 87.3 49.6  Set a pin in a named zone
/msuite way 49.4 12.9           Set a pin even if another addon owns /way
/msuite diagnostics             Show client, menu-label state, and recorded errors
/msuite export                  Open a copyable diagnostic report
/msuite help                    Open setup and support guidance

COMPATIBILITY
Coordinate commands use an explicit zone name when supplied, otherwise the
displayed world map when open, or your current zone. Zone names come from the
client's live map data, including newly added Forever zones such as Zephras and
Hyjal. Use the name shown by your client; names may be quoted. Ambiguous names
report map IDs: /way #mapID x y selects one explicitly. Coordinates must be
between 0 and 100. The existing arrow follows the new pin when enabled; quest super-tracking is preserved. Other addons'
/way commands are retained.

Targets WoW Forever Interface 16001. Spell explanations and header parsing use
English data. Saved banking lists and fishing/ranged preferences are per character.
Enabled standalone MeffortWand takes priority over the suite's wand handling.
Supported preferences from older Meffort addons migrate on first installation.

TROUBLESHOOTING
Use /msuite diagnostics to review the current session in chat, or /msuite export
to open a copyable report. The About page also has Copy diagnostic report.
A blocked interface action produces one chat notice per UI session with these
steps, including when no Lua error appears:
1. Before reloading or logging out, type /msuite export.
2. Click Select report, then press Ctrl+C (Command+C on Mac).
3. Switch out of the game and paste the report into your bug report to Mefforts
   with Ctrl+V (Command+V on Mac). Include what you clicked or pressed, the NPC
   or window involved, and whether the issue repeats.
Reloading or logging out clears the session log. The report window also shows
copy/share instructions and opens only when requested.

The report records
client-reported blocked and forbidden actions, generic interface failures,
recent guarded-operation errors, and menu status even when no Lua error appears.
Reports include the active suite call, bounded event stacks, and nearby calls
when available. Nearby calls are correlation only; an event may arrive after
the triggering call has returned.
Reports identify the source and function only when the client supplies them;
a reported addon name does not identify every step in a taint chain.
If a range or camera call is blocked, that call is paused for the affected
combat condition until reload. Out-of-combat calls remain available after a
combat-only block. Saved tool preferences are retained. Owned camera-release
cleanup retries after combat.
Events are recorded after this version loads and are cleared by a UI reload.
The report contains no chat transcript and never sends information to others.

If an item move is blocked, follow the status message and check your cursor
before retrying. This unofficial addon
is not affiliated with Blizzard.

See ATTRIBUTION.txt and LICENSE for credits and licensing.
