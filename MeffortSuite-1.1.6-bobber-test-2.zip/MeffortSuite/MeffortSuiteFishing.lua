MeffortSuiteFishing = {}
local module = MeffortSuiteFishing
local tracker = CreateFrame("Frame")
local bindingOwner, castButton
local armGeneration=0
local UpdateArm
local castSpell
local armed = false
local armTime = 0
local armDuration = 0.85
local lastCast = -10
local previousDown = -10
local doubleWindow=0.5
local firstReleasePending,awaitingSecond,secondPress=false,false,false
local singleReady=false
local eventCount = 0
local lastResult = "no mouse click yet"
local lastFocus="not checked"
local secureReleases=0
local lootOpen = false
local deferredClear = false
local releaseEventAvailable=false
local initializationAttempted=false

local function Message(message)
    if MeffortSuite and MeffortSuite.Message then
        MeffortSuite.Message("Fishing: "..message)
    end
end
local function InLockdown()
    return type(InCombatLockdown)=="function" and InCombatLockdown()==true
end
local function Settings()
    if type(MeffortSuiteCharDB)~="table" then MeffortSuiteCharDB={} end
    if MeffortSuiteCharDB.fishingRightClick==nil then
        MeffortSuiteCharDB.fishingRightClick=true
    end
    if MeffortSuiteCharDB.fishingClickMode~="single" and
       MeffortSuiteCharDB.fishingClickMode~="double" then
        MeffortSuiteCharDB.fishingClickMode="double"
    end
    return MeffortSuiteCharDB
end
function module.Enabled() return Settings().fishingRightClick==true end
function module.Mode() return Settings().fishingClickMode end

-- An uncached equipped item may have an ID before its link is available.
function module.IsPoleEquipped()
    if type(IsEquippedItemType)=="function" then
        local ok,yes=pcall(IsEquippedItemType,"Fishing Poles")
        if ok and yes then return true end
    end
    local link
    if type(GetInventoryItemLink)=="function" then
        local ok,value=pcall(GetInventoryItemLink,"player",16)
        if ok then link=value end
    end
    if not link and type(GetInventoryItemID)=="function" then
        local ok,value=pcall(GetInventoryItemID,"player",16)
        if ok then link=value end
    end
    if not link then return false end
    local instant = type(GetItemInfoInstant)=="function" and GetItemInfoInstant
        or (C_Item and type(C_Item.GetItemInfoInstant)=="function" and C_Item.GetItemInfoInstant)
    if instant then
        local ok,_,_,_,_,_,classID,subclassID=pcall(instant,link)
        if ok and classID==2 and (subclassID==20 or subclassID==25) then return true end
    end
    if type(GetItemInfo)=="function" then
        local ok,_,_,_,_,_,_,subclass=pcall(GetItemInfo,link)
        if ok and type(subclass)=="string" and
            subclass:lower():find("fishing pole",1,true) then return true end
    end
    return false
end

local function FishingSpell()
    if castSpell then return castSpell end
    if C_Spell and type(C_Spell.GetSpellInfo)=="function" then
        local ok,info=pcall(C_Spell.GetSpellInfo,7620)
        if ok and type(info)=="table" and type(info.name)=="string" then
            castSpell=info.name
            return castSpell
        end
    end
    if C_Spell and type(C_Spell.GetSpellName)=="function" then
        local ok,name=pcall(C_Spell.GetSpellName,7620)
        if ok and type(name)=="string" and name~="" then
            castSpell=name
            return name
        end
    end
    if type(GetSpellInfo)=="function" then
        local ok,name=pcall(GetSpellInfo,7620)
        if ok and type(name)=="string" then castSpell=name;return name end
    end
    return "Fishing" -- Leave the fallback uncached until localized data loads.
end
function module.IsFishingSpell(id,name)
    if issecretvalue and issecretvalue(name) then name=nil end
    if not (issecretvalue and issecretvalue(id)) then
        if id==7620 or id==131474 or id==131476 then return true end
        if type(id)=="number" and not name then
            local getter=C_Spell and C_Spell.GetSpellName or GetSpellInfo
            if type(getter)=="function" then
                local ok,value=pcall(getter,id)
                if ok then name=value end
            end
        end
    end
    return (not issecretvalue or not issecretvalue(name)) and type(name)=="string" and name==FishingSpell()
end
function module.IsFishingChannel()
    if type(UnitChannelInfo)~="function" then return false end
    local ok,name,_,_,_,_,_,_,id=pcall(UnitChannelInfo,"player")
    return ok and module.IsFishingSpell(id,name)
end
local function IsChanneling()
    if type(UnitChannelInfo)~="function" then return false end
    local ok,name=pcall(UnitChannelInfo,"player")
    return ok and type(name)=="string"
end
local function WorldClick()
    local focus,available,source
    -- GetMouseFoci returns a frame list; GetMouseFocus returns a single frame.
    if type(GetMouseFoci)=="function" then
        local ok,value=pcall(GetMouseFoci)
        available=ok
        if ok then source="GetMouseFoci" end
        if ok and type(value)=="table" then
            focus=type(value.GetParent)=="function" and value or value[1]
        elseif ok then focus=value end
    end
    if not focus and type(GetMouseFocus)=="function" then
        local ok,value=pcall(GetMouseFocus)
        available=available or ok
        if ok then source="GetMouseFocus" end
        if ok then focus=value end
    end
    local name
    if focus and type(focus.GetName)=="function" then
        local ok,value=pcall(focus.GetName,focus)
        if ok then name=value end
    end
    lastFocus=type(name)=="string" and name or (focus and "anonymous frame" or source and (source.." background") or "focus API unavailable")
    if not available or not WorldFrame then return false end
    if not focus or focus==UIParent then
        local ok,looking=false,false
        if type(IsMouselooking)=="function" then ok,looking=pcall(IsMouselooking) end
        if ok and (looking==true or looking==1) then
            lastFocus=lastFocus.."; native camera active"
            return true
        end
        -- An empty successful focus query represents background, including before camera starts.
        lastFocus=lastFocus.."; world background"
        return true
    end
    for _=1,8 do
        if focus==WorldFrame then return true end
        if type(focus.GetParent)~="function" then break end
        local ok,parent=pcall(focus.GetParent,focus)
        if not ok or not parent or parent==focus then break end
        focus=parent
    end
    return false
end
local function CanCast()
    return module.Enabled() and MeffortSuite and MeffortSuite.Active()
        and module.IsPoleEquipped() and not IsChanneling() and not lootOpen
end

local function ClearArm()
    armGeneration=armGeneration+1
    previousDown=-10
    firstReleasePending,awaitingSecond,secondPress=false,false,false
    singleReady=false
    if not armed and not deferredClear then return end
    if InLockdown() then
        deferredClear=true
        armed=false
        tracker:SetScript("OnUpdate",nil)
        -- The restricted state driver clears the actual binding in combat.
        return
    end
    local ok=bindingOwner and pcall(function()
        if castButton then castButton:SetAttribute("type",nil) end
        bindingOwner:Execute([[self:ClearBindings()]])
    end)
    armed=false
    deferredClear=not ok
    tracker:SetScript("OnUpdate",nil)
end

local function ArmCast(firstDown,idleSingle)
    if not bindingOwner or not castButton then lastResult="secure binding API unavailable";return end
    ClearArm()
    if InLockdown() then lastResult="combat lockdown";return end
    local spell=FishingSpell()
    local ok=pcall(function()
        castButton:SetAttribute("spell",spell)
        castButton:SetAttribute("type","spell")
        bindingOwner:Execute([[self:SetBindingClick(true,"BUTTON2","MeffortSuiteFishingCastButton","RightButton")]])
    end)
    if not ok then
        pcall(bindingOwner.Execute,bindingOwner,[[self:ClearBindings()]])
        pcall(castButton.SetAttribute,castButton,"type",nil)
        lastResult="binding rejected";return
    end
    armed=true
    armGeneration=armGeneration+1
    armTime=0
    awaitingSecond=firstDown~=nil
    previousDown=firstDown or -10
    singleReady=idleSingle==true
    secondPress=not awaitingSecond and not singleReady
    tracker:SetScript("OnUpdate",not singleReady and UpdateArm or nil)
    lastResult=singleReady and "single-click ready" or awaitingSecond and "ready for second right-click" or ("armed "..spell.." for mouse release")
end

function module.Refresh()
    if not bindingOwner then return end
    if deferredClear or ((armed or firstReleasePending or previousDown>=0) and not CanCast()) then ClearArm() end
    if not InLockdown() and module.Mode()=="single" and CanCast() and not armed then ArmCast(nil,true) end
end
function module.SetEnabled(value)
    Settings().fishingRightClick=value==true
    module.Refresh()
end
function module.SetMode(value)
    if value~="double" then value="single" end
    Settings().fishingClickMode=value
    previousDown=-10
    ClearArm()
    module.Refresh()
end
function module.Command(argument)
    local cmd=(argument or ""):lower():match("^%s*(.-)%s*$")
    if cmd=="on" or cmd=="off" then
        module.SetEnabled(cmd=="on")
        Message("right-click casting "..(module.Enabled() and "enabled" or "disabled").." ("..module.Mode()..")")
    elseif cmd=="single" or cmd=="double" then
        module.SetMode(cmd)
        module.SetEnabled(true)
        Message(cmd.." right-click mode enabled with fishing pole")
    elseif cmd=="status" or cmd=="debug" or cmd=="" then
        Message((module.Enabled() and "on" or "off")..", mode "..module.Mode()
            ..", pole "..(module.IsPoleEquipped() and "recognized" or "NOT recognized")
            ..", spell "..FishingSpell()..", clicks "..eventCount
            ..", button releases "..secureReleases
            ..", last: "..lastResult.."; focus "..lastFocus..". /msuite fishing on|off|single|double")
    else
        Message("/msuite fishing on|off|single|double|status")
    end
end

local function OnMouseDown(button)
    if button~="RightButton" then
        if button=="LeftButton" then ClearArm() end
        return
    end
    eventCount=eventCount+1
    if not bindingOwner or not castButton then ClearArm();lastResult="secure binding API unavailable";return end
    if type(IsMouseButtonDown)=="function" and IsMouseButtonDown("LeftButton") then ClearArm();return end
    if InLockdown() then ClearArm();lastResult="combat lockdown";return end
    if not CanCast() then ClearArm();lastResult="not ready (feature, pole, channel or loot)";return end
    local world=WorldClick()
    if world==false or (world==nil and not (armed and awaitingSecond)) then
        ClearArm()
        lastResult="world-click focus unavailable or an interface frame was clicked"
        return
    end
    local now=type(GetTime)=="function" and GetTime() or 0
    if now-lastCast<0.6 then ClearArm();return end
    if module.Mode()=="double" then
        if armed and awaitingSecond and now>=previousDown and now-previousDown<=doubleWindow then
            awaitingSecond=false;secondPress=true;firstReleasePending=false
            armTime=0;lastCast=now;lastResult="second right-click accepted; cast on release"
            return
        end
        ClearArm()
        previousDown=now
        firstReleasePending=true
        lastResult="first right-click received"
        return
    end
    if armed and singleReady then
        singleReady=false;secondPress=true;armTime=0
        tracker:SetScript("OnUpdate",UpdateArm)
        lastResult="single right-click accepted; cast on release"
    else
        ArmCast()
    end
    lastCast=now
end
local function OnMouseUp(button)
    if button~="RightButton" then
        if button=="LeftButton" and module.Mode()=="single" and bindingOwner then C_Timer.After(0,module.Refresh) end
        return
    end
    if firstReleasePending and module.Mode()=="double" then
        firstReleasePending=false
        local generation,firstDown=armGeneration,previousDown
        -- Install between clicks; changing a binding during mouse-down can miss that release.
        C_Timer.After(0,function()
            if generation~=armGeneration then return end
            local now=type(GetTime)=="function" and GetTime() or 0
            if InLockdown() or not CanCast() or module.Mode()~="double" or WorldClick()==false
                or now<firstDown or now-firstDown>doubleWindow then ClearArm();return end
            ArmCast(firstDown)
        end)
        return
    end
    if not armed or not secondPress then
        if module.Mode()=="single" and bindingOwner then C_Timer.After(0,module.Refresh) end
        return
    end
    local generation=armGeneration
    -- Clear next frame: GLOBAL_MOUSE_UP can precede protected click dispatch.
    C_Timer.After(0,function()
        if armed and generation==armGeneration then ClearArm();module.Refresh() end
    end)
end
local function Initialize()
    Settings()
    if bindingOwner or initializationAttempted or InLockdown() then return end
    if not releaseEventAvailable or type(RegisterStateDriver)~="function"
        or not (C_Timer and type(C_Timer.After)=="function") then
        lastResult="secure state/timer API unavailable"
        Message("Secure right-click casting is unavailable; normal mouse controls remain active.")
        return
    end
    initializationAttempted=true
    local owner
    local ok=pcall(function()
        owner=CreateFrame("Frame","MeffortSuiteFishingSecureController",UIParent,"SecureHandlerStateTemplate")
        if type(owner.Execute)~="function" then error("restricted execution unavailable") end
        owner:SetAttribute("_onstate-fishcombat",[[
            if newstate == "off" then
                local button=self:GetFrameRef("cast")
                if button then button:SetAttribute("type",nil) end
                self:ClearBindings()
            end
        ]])
        if RegisterStateDriver(owner,"fishcombat","[combat] off; on")==false then
            error("secure combat state unavailable")
        end
        local button=CreateFrame("Button","MeffortSuiteFishingCastButton",UIParent,"SecureActionButtonTemplate")
        button:RegisterForClicks("AnyUp")
        button:SetAttribute("useOnKeyDown",false)
        button:SetAttribute("type",nil)
        button:SetScript("PostClick",function(self,mouse,down)
            if mouse=="RightButton" and not down then
                secureReleases=secureReleases+1
                if self:GetAttribute("type")=="spell" then lastResult="casting button received release" end
            end
        end)
        owner:SetFrameRef("cast",button)
        owner:Execute([[self:ClearBindings()]])
        bindingOwner,castButton=owner,button
    end)
    if not ok then
        if owner and type(UnregisterStateDriver)=="function" then
            pcall(UnregisterStateDriver,owner,"fishcombat")
        end
        lastResult="secure binding setup rejected"
        Message("Secure right-click casting could not initialize; normal mouse controls remain active.")
    else
        module.Refresh()
    end
end
function module.Available()
    if bindingOwner and castButton then return true end
    return false,InLockdown() and "Right-click fishing will initialize after combat."
        or "Secure right-click fishing is unavailable; normal mouse controls remain active."
end
UpdateArm=function(_,elapsed)
    if not armed then tracker:SetScript("OnUpdate",nil);return end
    if InLockdown() or not CanCast() then ClearArm();return end
    if awaitingSecond then
        local now=type(GetTime)=="function" and GetTime() or 0
        if now<previousDown or now-previousDown>doubleWindow or WorldClick()==false then ClearArm();return end
    end
    armTime=armTime+(elapsed or 0)
    if armTime>armDuration then ClearArm() end
end

tracker:RegisterEvent("PLAYER_LOGIN")
tracker:RegisterEvent("GLOBAL_MOUSE_DOWN")
do
    local ok,result=pcall(tracker.RegisterEvent,tracker,"GLOBAL_MOUSE_UP")
    releaseEventAvailable=ok and result~=false
end
tracker:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
tracker:RegisterEvent("UNIT_INVENTORY_CHANGED")
tracker:RegisterEvent("PLAYER_REGEN_ENABLED")
tracker:RegisterEvent("PLAYER_REGEN_DISABLED")
tracker:RegisterEvent("UNIT_SPELLCAST_CHANNEL_START")
tracker:RegisterEvent("UNIT_SPELLCAST_CHANNEL_STOP")
tracker:RegisterEvent("UNIT_SPELLCAST_INTERRUPTED")
tracker:RegisterEvent("UNIT_SPELLCAST_STOP")
tracker:RegisterEvent("UNIT_SPELLCAST_FAILED")
tracker:RegisterEvent("SPELLS_CHANGED")
tracker:RegisterEvent("LOOT_OPENED")
tracker:RegisterEvent("LOOT_CLOSED")
tracker:SetScript("OnEvent",function(_,event,unit)
    if event=="PLAYER_LOGIN" then Initialize();return end
    if event=="GLOBAL_MOUSE_DOWN" then OnMouseDown(unit);return end
    if event=="GLOBAL_MOUSE_UP" then OnMouseUp(unit);return end
    if event=="SPELLS_CHANGED" then castSpell=nil end
    if event=="LOOT_OPENED" then lootOpen=true end
    if event=="LOOT_CLOSED" then lootOpen=false end
    if (event=="UNIT_INVENTORY_CHANGED" or event:match("^UNIT_SPELLCAST"))
        and unit~="player" then return end
    if event=="PLAYER_REGEN_DISABLED" then
        -- The state driver clears bindings; defer ordinary cleanup until combat ends.
        ClearArm()
    elseif event=="UNIT_SPELLCAST_CHANNEL_START" or event=="UNIT_SPELLCAST_FAILED"
        or event=="UNIT_SPELLCAST_INTERRUPTED" or event=="UNIT_SPELLCAST_STOP" or event=="LOOT_OPENED" then
        ClearArm()
        if event~="UNIT_SPELLCAST_CHANNEL_START" and event~="LOOT_OPENED" and bindingOwner then C_Timer.After(0,module.Refresh) end
    elseif event=="PLAYER_EQUIPMENT_CHANGED" or event=="UNIT_INVENTORY_CHANGED"
        or event=="PLAYER_REGEN_ENABLED" or event=="SPELLS_CHANGED" or event=="LOOT_CLOSED"
        or event=="UNIT_SPELLCAST_CHANNEL_STOP" then
        if event=="PLAYER_REGEN_ENABLED" and not bindingOwner then Initialize() end
        module.Refresh()
    end
end)
