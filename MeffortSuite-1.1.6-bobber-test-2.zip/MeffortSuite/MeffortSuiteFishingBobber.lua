local M={}
MeffortSuiteFishingBobber=M

local suite=MeffortSuite
local fishing=MeffortSuiteFishing
local tracker=CreateFrame("Frame")
local ring,glow,readout,anchoredPlate,screenAnchor,trackingText
local cast,beforeCast,lastBobber,lastStats
local softEventGuid
local status="waiting for a fishing cast"
local elapsed=0
local sampleInterval,flashDuration,flashSpeed=.05,.35,48
local ringTexture="Interface\\AddOns\\MeffortSuite\\Textures\\BobberRing.tga"
local targeting={
    {name="SoftTargetInteract", minimum=2, applied=3},
    {name="SoftTargetNameplateInteract", minimum=1, applied=1},
    {name="SoftTargetIconGameObject", minimum=1, applied=1},
    {name="SoftTargetIconInteract", minimum=1, applied=1},
    {name="SoftTargetInteractRange", minimum=30, applied=30},
    {name="SoftTargetInteractArc", minimum=2, applied=2},
}

local function Secret(value)
    if type(issecretvalue)~="function" then return false end
    local ok,result=pcall(issecretvalue,value)
    return not ok or result==true
end
local function Number(value)
    if not Secret(value) and type(value)=="number" and value==value
        and value~=math.huge and value~=-math.huge then return value end
end
local function Text(value)
    if not Secret(value) and type(value)=="string" then return value end
end
local function Read(fn,...)
    if type(fn)~="function" then return end
    local ok,a,b=pcall(fn,...)
    if ok and not Secret(a) and not Secret(b) then return a,b end
end
local function Field(frame,key)
    if Secret(frame) or not frame then return end
    return Read(function() return frame[key] end)
end
local function Method(frame,key,...)
    return Read(Field(frame,key),frame,...)
end
local function Account()
    if type(MeffortSuiteDB)~="table" then MeffortSuiteDB={} end
    return MeffortSuiteDB
end
local function Character()
    if type(MeffortSuiteCharDB)~="table" then MeffortSuiteCharDB={} end
    return MeffortSuiteCharDB
end
function M.Enabled() return Character().fishingBobberHighlight~=false end
function M.MotionEnabled() return Character().fishingBobberMotion==true end
local function InCombat() return Read(InCombatLockdown)==true end
local function ReadCVar(name)
    local value=Read(C_CVar and C_CVar.GetCVar or GetCVar,name)
    if type(value)=="string" or type(value)=="number" then return Number(tonumber(value)) end
end
local function WriteCVar(name,value)
    local setter=C_CVar and C_CVar.SetCVar or SetCVar
    if type(setter)~="function" then return end
    if suite and suite.TryClientCall then
        suite.TryClientCall("Bobber ring","set "..name,setter,name,tostring(value))
    else
        pcall(setter,name,tostring(value))
    end
end
local function RestoreTargeting()
    local db=Account()
    local saved=db.fishingBobberTargetRestore
    if type(saved)~="table" then db.fishingBobberTargetRestore=nil;return true end
    if InCombat() and next(saved) then return false end
    for _,option in ipairs(targeting) do
        local name=option.name
        local entry=saved[name]
        if type(entry)=="table" and Number(entry.previous) and entry.applied==option.applied then
            local current=ReadCVar(name)
            if current==entry.applied then
                WriteCVar(name,entry.previous)
                local after=ReadCVar(name)
                if after and after~=entry.applied then saved[name]=nil end
            elseif current~=nil then
                saved[name]=nil
            end
        else
            saved[name]=nil
        end
    end
    if not next(saved) then db.fishingBobberTargetRestore=nil;return true end
    return false
end
local function PrepareTargeting()
    local db=Account()
    local saved={}
    db.fishingBobberTargetRestore=saved
    for _,option in ipairs(targeting) do
        local current=ReadCVar(option.name)
        if current and current<option.minimum then
            saved[option.name]={previous=current,applied=option.applied}
            WriteCVar(option.name,option.applied)
            local after=ReadCVar(option.name)
            if after and after~=option.applied then saved[option.name]=nil end
        end
    end
    if not next(saved) then db.fishingBobberTargetRestore=nil end
end

local function BobberGuid(value)
    local guid=Text(value)
    if guid and guid:match("^GameObject%-%d+%-%d+%-%d+%-%d+%-35591%-") then return guid end
end
local function SoftBobber()
    local guid=Text(Read(UnitGUID,"softinteract"))
    if guid and guid~="" then return BobberGuid(guid) end
    return softEventGuid
end
local function PlateGuid(plate)
    local token=Text(Field(plate,"namePlateUnitToken")) or Text(Field(Field(plate,"UnitFrame"),"unit"))
    return token and BobberGuid(Read(UnitGUID,token))
end
local function Visible(plate)
    return plate and Method(plate,"IsForbidden")~=true and Method(plate,"IsVisible")==true
end
local function Nameplates()
    local plates=C_NamePlate and Read(C_NamePlate.GetNamePlates)
    return type(plates)=="table" and plates or {}
end
local function HasNameplateAPI()
    return C_NamePlate and (type(C_NamePlate.GetNamePlateForUnit)=="function" or type(C_NamePlate.GetNamePlates)=="function")
end
local function CaptureBeforeCast(castID)
    local existing={}
    local guid=SoftBobber()
    if guid then existing[guid]=true end
    for _,plate in ipairs(Nameplates()) do
        local known=Visible(plate) and PlateGuid(plate)
        if known then existing[known]=true end
    end
    beforeCast={id=Text(castID),existing=existing}
end
local function NewBobber(guid)
    return guid and not cast.existing[guid] and (not cast.id or guid~=lastBobber)
end
local function FindPlate()
    if not HasNameplateAPI() then return nil,nil,"Nameplate API unavailable." end
    local guid=SoftBobber()
    local preferred=cast.guid or (NewBobber(guid) and guid)
    if preferred and guid==preferred then
        local plate=C_NamePlate and Read(C_NamePlate.GetNamePlateForUnit,"softinteract")
        local plateGuid=plate and PlateGuid(plate)
        if Visible(plate) and (not plateGuid or plateGuid==preferred) then return plate,preferred end
    end
    local candidate,candidateGuid,ambiguous
    for _,plate in ipairs(Nameplates()) do
        local found=Visible(plate) and PlateGuid(plate)
        if found then
            if found==preferred then return plate,found end
            if not cast.guid and NewBobber(found) then
                if candidateGuid and candidateGuid~=found then ambiguous=true end
                candidate,candidateGuid=plate,found
            end
        end
    end
    if not ambiguous and candidate and not preferred then return candidate,candidateGuid end
    if preferred then return nil,nil,"Bobber found. Waiting for its nameplate." end
    if ambiguous then return nil,nil,"Multiple bobbers. Face yours to select it." end
    return nil,nil,"Looking for a bobber. Face the water where you cast."
end

local function CreateRing()
    if ring then return end
    ring=CreateFrame("Frame","MeffortSuiteBobberRing",UIParent)
    ring:SetSize(54,54)
    ring:SetFrameStrata("HIGH")
    ring:EnableMouse(false)
    local outline=ring:CreateTexture(nil,"ARTWORK")
    outline:SetAllPoints(ring)
    outline:SetTexture(ringTexture)
    glow=ring:CreateTexture(nil,"OVERLAY")
    glow:SetAllPoints(ring)
    glow:SetTexture(ringTexture)
    glow:SetBlendMode("ADD")
    glow:SetAlpha(0)
    readout=ring:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    readout:SetPoint("BOTTOM",ring,"TOP",0,1)
    readout:SetTextColor(.61,1,.9)
    readout:SetShadowColor(0,0,0,1)
    readout:SetShadowOffset(1,-1)
    ring:Hide()
end
local function ShowTracking(message)
    if not message then
        if trackingText then trackingText:Hide() end
        return
    end
    if not trackingText then
        local hint=CreateFrame("Frame",nil,UIParent)
        hint:SetSize(360,22)
        hint:SetPoint("CENTER",UIParent,"CENTER",0,-126)
        hint:SetFrameStrata("HIGH")
        hint:EnableMouse(false)
        trackingText=hint:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        trackingText:SetAllPoints(hint)
        trackingText:SetTextColor(.61,1,.9)
        trackingText:SetShadowColor(0,0,0,1)
        trackingText:SetShadowOffset(1,-1)
    end
    trackingText:SetText("Bobber ring | "..message)
    trackingText:Show()
end
local function HideRing()
    if ring then
        ring:Hide()
        ring:ClearAllPoints()
        glow:SetAlpha(0)
    end
    anchoredPlate,screenAnchor=nil,nil
    if cast then cast.sample=nil;cast.flashUntil=nil;cast.flashStrength=nil;cast.above=false end
end
local function AnchorRing(plate)
    if plate~=anchoredPlate then
        HideRing()
        local ok,result
        if suite and suite.TryClientCall then
            ok,result=suite.TryClientCall("Bobber ring","attach to nameplate",ring.SetPoint,ring,"CENTER",plate,"CENTER",0,0)
        else
            ok,result=pcall(ring.SetPoint,ring,"CENTER",plate,"CENTER",0,0)
        end
        anchoredPlate=plate
        screenAnchor=not ok or result==false
    end
    if screenAnchor then
        local x,y=Method(plate,"GetCenter")
        local scale=Number(Method(plate,"GetEffectiveScale"))
        local rootScale=Number(Method(UIParent,"GetEffectiveScale"))
        if not Number(x) or not Number(y) or not scale or scale<=0 or not rootScale or rootScale<=0 then return false end
        local ratio=scale/rootScale
        ring:ClearAllPoints()
        local ok,result=pcall(ring.SetPoint,ring,"CENTER",UIParent,"BOTTOMLEFT",x*ratio,y*ratio)
        return ok and result~=false
    end
    return true
end
local function TrackMotion(plate,now)
    if not M.MotionEnabled() then
        readout:Hide()
        glow:SetAlpha(0)
        cast.sample=nil
        return
    end
    local x,y=Method(plate,"GetCenter")
    x,y=Number(x),Number(y)
    local scale=Number(Method(plate,"GetEffectiveScale")) or 1
    local zoom=Number(Read(GetCameraZoom))
    readout:Show()
    if not x or not y or scale<=0 then
        cast.sample=nil;cast.flashUntil=nil;cast.above=false
        readout:SetText("Anchor position unavailable")
        glow:SetAlpha(0)
        return
    end
    local previous=cast.sample
    cast.sample={x=x,y=y,scale=scale,zoom=zoom,time=now}
    local dt=previous and now-previous.time
    if Read(IsMouselooking)==true or (previous and previous.zoom~=zoom) then
        cast.sample=nil;cast.flashUntil=nil;cast.above=false
        readout:SetText("Camera moving")
        glow:SetAlpha(0)
        return
    end
    local speed=0
    if previous and dt>0 and dt<.30 and previous.scale==scale then
        local dx,dy=x-previous.x,y-previous.y
        speed=Number(math.sqrt(dx*dx+dy*dy)*scale/dt) or 0
        cast.samples=cast.samples+1
        cast.peak=math.max(cast.peak,speed)
        if speed>=flashSpeed then
            if not cast.above then cast.flashes=cast.flashes+1 end
            cast.flashUntil=now+flashDuration
            cast.flashStrength=math.min(1,.35+speed/220)
        end
        cast.above=speed>=flashSpeed
    else
        cast.above=false
    end
    local fade=cast.flashUntil and math.max(0,(cast.flashUntil-now)/flashDuration) or 0
    glow:SetAlpha(fade*(cast.flashStrength or 0))
    readout:SetText(string.format("Anchor %.0f px/s  |  Peak %.0f",speed,cast.peak))
end
local function Stop(reason)
    if cast then
        lastBobber=cast.guid or lastBobber
        lastStats={samples=cast.samples,peak=cast.peak,flashes=cast.flashes,
            result=cast.result or status,targeting=cast.targeting,ringSeen=cast.ringSeen}
        cast=nil
    end
    HideRing()
    ShowTracking(nil)
    tracker:SetScript("OnUpdate",nil)
    status=RestoreTargeting() and reason or "interaction settings restoration pending"
end
local function IsActive()
    return M.Enabled() and (not suite or not suite.Active or suite.Active())
end
local function Scan()
    if not cast then return end
    if not IsActive() or InCombat() then Stop("waiting for your next fishing cast");return end
    local now=Number(Read(GetTime))
    if not now then Stop("clock unavailable");return end
    local inChannel=fishing.IsFishingChannel()
    if inChannel then
        cast.sawChannel=true
        cast.channelMissingAt=nil
    elseif cast.sawChannel then
        cast.channelMissingAt=cast.channelMissingAt or now
    end
    if (cast.channelMissingAt and now-cast.channelMissingAt>.35) or now-cast.started>32 then
        Stop("waiting for your next fishing cast")
        return
    end
    local plate,guid,why=FindPlate()
    if not plate then
        HideRing()
        status=why
        cast.result=status
        ShowTracking(status)
        return
    end
    CreateRing()
    if not AnchorRing(plate) then
        ring:Hide()
        cast.sample=nil
        status="Nameplate found. Its screen position is unavailable."
        cast.result=status
        ShowTracking(status)
        return
    end
    cast.guid=guid
    cast.ringSeen=true
    ShowTracking(nil)
    ring:Show()
    TrackMotion(plate,now)
    status="ring visible"
    cast.result=status
end
local function Start(castID)
    local previous=beforeCast
    beforeCast=nil
    if cast then Stop("new cast") end
    if not IsActive() or InCombat() then return end
    if not RestoreTargeting() then status="interaction settings restoration pending";return end
    local now=Number(Read(GetTime))
    if not now then status="clock unavailable";return end
    castID=Text(castID)
    cast={id=castID,started=now,existing=previous and previous.id==castID and previous.existing or {},
        peak=0,samples=0,flashes=0}
    elapsed=0
    if HasNameplateAPI() then PrepareTargeting() end
    cast.targeting=string.format("Interact %s, nameplate %s, icon %s",tostring(ReadCVar("SoftTargetInteract") or "?"),
        tostring(ReadCVar("SoftTargetNameplateInteract") or "?"),tostring(ReadCVar("SoftTargetIconGameObject") or "?"))
    tracker:SetScript("OnUpdate",function(_,dt)
        elapsed=elapsed+dt
        if elapsed>=sampleInterval then
            elapsed=0
            Scan()
        end
    end)
    Scan()
end

function M.Refresh()
    if not IsActive() then
        beforeCast=nil
        Stop(M.Enabled() and "suite off" or "off")
    elseif not cast then
        if not InCombat() and fishing.IsFishingChannel() then Start()
        else status=RestoreTargeting() and "waiting for your next fishing cast" or "interaction settings restoration pending" end
    end
end
function M.SetEnabled(value)
    Character().fishingBobberHighlight=value==true
    M.Refresh()
end
function M.SetMotionEnabled(value)
    Character().fishingBobberMotion=value==true
    if cast then
        cast.sample=nil;cast.flashUntil=nil;cast.above=false
        if ring and not M.MotionEnabled() then readout:Hide();glow:SetAlpha(0) end
    end
end
function M.Status()
    local stats=cast or lastStats
    if not stats then return status end
    return string.format("%s; %s %s; ring shown %s, samples %d, peak %.0f px/s, flashes %d; %s",status,
        cast and "current cast" or "last cast",stats.result or "started",stats.ringSeen and "yes" or "no",
        stats.samples,stats.peak,stats.flashes,
        stats.targeting or "targeting unavailable")
end

for _,event in ipairs({"PLAYER_LOGIN","PLAYER_ENTERING_WORLD","PLAYER_LEAVING_WORLD","PLAYER_LOGOUT",
    "PLAYER_REGEN_DISABLED","PLAYER_REGEN_ENABLED","PLAYER_EQUIPMENT_CHANGED","CVAR_UPDATE"}) do
    tracker:RegisterEvent(event)
end
pcall(tracker.RegisterEvent,tracker,"PLAYER_SOFT_INTERACT_CHANGED")
for _,event in ipairs({"UNIT_SPELLCAST_SENT","UNIT_SPELLCAST_CHANNEL_START","UNIT_SPELLCAST_CHANNEL_STOP"}) do
    tracker:RegisterUnitEvent(event,"player")
end
tracker:SetScript("OnEvent",function(_,event,unit,second,third,fourth)
    if event=="PLAYER_SOFT_INTERACT_CHANGED" then
        softEventGuid=BobberGuid(second)
    elseif event=="UNIT_SPELLCAST_SENT" then
        if Text(unit)=="player" and IsActive() and fishing.IsFishingSpell(fourth) then CaptureBeforeCast(third) end
    elseif event=="UNIT_SPELLCAST_CHANNEL_START" then
        if Text(unit)=="player" and IsActive() and (fishing.IsFishingSpell(third) or fishing.IsFishingChannel()) then Start(second) end
    elseif event=="UNIT_SPELLCAST_CHANNEL_STOP" then
        local ended=Text(second)
        if cast and Text(unit)=="player" and (not cast.id or not ended or ended==cast.id) then
            Stop("waiting for your next fishing cast")
        end
    elseif event=="PLAYER_LEAVING_WORLD" or event=="PLAYER_LOGOUT" or event=="PLAYER_REGEN_DISABLED" then
        beforeCast=nil
        softEventGuid=nil
        Stop("waiting for your next fishing cast")
    elseif event=="PLAYER_EQUIPMENT_CHANGED" then
        if cast and not fishing.IsPoleEquipped() then Stop("waiting for a fishing pole") end
    elseif event=="CVAR_UPDATE" then
        if not cast then return end
        local changed=Text(unit)
        local saved=Account().fishingBobberTargetRestore
        if not changed or not saved then return end
        for _,option in ipairs(targeting) do
            local entry=saved[option.name]
            if entry and changed:lower()==option.name:lower() then
                local current=ReadCVar(option.name)
                if current and current~=entry.applied then saved[option.name]=nil end
                return
            end
        end
    else
        M.Refresh()
    end
end)
