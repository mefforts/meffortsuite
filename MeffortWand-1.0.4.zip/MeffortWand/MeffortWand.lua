local addonName = ... or "MeffortWand"
local app = {Version="1.0.4"}
MeffortWand = app
local frame = CreateFrame("Frame")
local deferred = CreateFrame("Frame")
local controller, shootButton
local initialized, started, loginShown = false, false, false
local applying, refreshScheduled, queued = false, false, false
local activeDriver, installedSignature, macroIndex, macroName
local activeSequence=false
local macroDirty, provisioned, eligible, lastClaim = true, false, false, false
local ownMouselook, reason = false, "Waiting for login."
local warnings, errors = {}, {}
local waitingItems, requestedItems = {}, {}
local spellDataRequested=false
local supportedClasses = {MAGE=true, PRIEST=true, WARLOCK=true}
local facts = {supported=false, equipped=false, known=false, pole=false}

local function Secret(v) return issecretvalue and issecretvalue(v) end
local function Number(v)
    if not Secret(v) and type(v)=="number" and v==v and v~=math.huge and v~=-math.huge then return v end
end
local function Text(v) if not Secret(v) and type(v)=="string" then return v end end
local function Bool(v)
    if not Secret(v) then
        if v==true or v==1 then return true end
        if v==false or v==0 then return false end
    end
end
local function Combat() return type(InCombatLockdown)=="function" and InCombatLockdown() end
local function DB()
    if type(MeffortWandDB)~="table" then MeffortWandDB={} end
    local db=MeffortWandDB
    if db.mode~="right" and db.mode~="shift" and db.mode~="off" then db.mode="right" end
    if db.mode~="off" then db.lastMode=db.mode end
    if db.lastMode~="right" and db.lastMode~="shift" then db.lastMode="right" end
    if type(db.showLogin)~="boolean" then db.showLogin=true end
    if type(db.sequenceMode)~="boolean" then db.sequenceMode=false end
    if db.lastMode=="shift" then db.sequenceMode=false end
    db.schemaVersion=2
    return db
end
function app.Message(text)
    local line="|cff73d9ffMeffortWand|r: "..tostring(text)
    if DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then DEFAULT_CHAT_FRAME:AddMessage(line)
    else print(line) end
end
local function Warn(text)
    text=tostring(text):gsub("[\r\n]"," "):sub(1,180)
    if warnings[text] then return end
    warnings[text]=true
    errors[#errors+1]=text
    if #errors>6 then table.remove(errors,1) end
    app.Message(text)
end
local function UpdateUI()
    if MeffortWandSettingsUI and type(MeffortWandSettingsUI.Refresh)=="function" then
        pcall(MeffortWandSettingsUI.Refresh)
    end
end
function app.GetMode() return DB().mode end
function app.GetActivationMode() return DB().lastMode end
function app.GetEnabled() return DB().mode~="off" end
function app.GetShowLogin() return DB().showLogin end
function app.GetSequenceMode() return DB().sequenceMode end
function app.SetShowLogin(value) DB().showLogin=value==true;UpdateUI() end

local function StopMouselook()
    frame:SetScript("OnUpdate",nil)
    if ownMouselook then
        ownMouselook=false
        if type(MouselookStop)=="function" then
            local ok=pcall(MouselookStop)
            if not ok then Warn("The client could not release the camera.") end
        end
    end
end
local function CheckMouselook()
    if not ownMouselook then frame:SetScript("OnUpdate",nil);return end
    local ok,down=pcall(IsMouseButtonDown,"RightButton")
    if not ok or Bool(down)~=true then StopMouselook() end
end
local function ItemType(slot)
    local item
    if type(GetInventoryItemID)=="function" then
        local ok,id=pcall(GetInventoryItemID,"player",slot)
        if ok then item=Number(id) end
    end
    if not item and type(GetInventoryItemLink)=="function" then
        local ok,link=pcall(GetInventoryItemLink,"player",slot)
        if ok then item=Text(link) end
    end
    if not item or item==0 or item=="" then return nil,nil,nil end
    local providers={C_Item and C_Item.GetItemInfoInstant,GetItemInfoInstant,
        C_Item and C_Item.GetItemInfo,GetItemInfo}
    for i=1,4 do
        local fn=providers[i]
        if type(fn)=="function" then
            local values={pcall(fn,item)}
            local class=Number(values[i<=2 and 7 or 13])
            local subclass=Number(values[i<=2 and 8 or 14])
            if values[1] and class and subclass then return class,subclass,item end
        end
    end
    local id=Number(item) or (Text(item) and tonumber(item:match("item:(%d+)")))
    if id then
        waitingItems[id]=true
        if not requestedItems[id] and C_Item and type(C_Item.RequestLoadItemDataByID)=="function" then
            requestedItems[id]=true
            pcall(C_Item.RequestLoadItemDataByID,id)
        end
    end
    return nil,nil,item
end
local function ShootKnown()
    local providers={C_SpellBook and C_SpellBook.IsSpellKnown,IsPlayerSpell,IsSpellKnown}
    for i=1,3 do
        if type(providers[i])=="function" then
            local ok,value=pcall(providers[i],5019)
            local known
            if ok then known=Bool(value) end
            if known~=nil then return known end
        end
    end
    return false
end
local function SubclassName(id)
    local providers={C_Item and C_Item.GetItemSubClassInfo,GetItemSubClassInfo}
    for i=1,2 do
        if type(providers[i])=="function" then
            local ok,value=pcall(providers[i],2,id)
            value=ok and Text(value)
            if value and value~="" and not value:find("[%[%],;]") then return value end
        end
    end
    local locale=type(GetLocale)=="function" and GetLocale() or "enUS"
    if locale=="enUS" or locale=="enGB" then return id==19 and "Wands" or "Fishing Poles" end
end
local function ReadEligibility()
    waitingItems={}
    local class
    if type(UnitClass)=="function" then
        local ok,_,value=pcall(UnitClass,"player")
        if ok then class=Text(value) end
    end
    facts.supported=supportedClasses[class]==true
    facts.known=ShootKnown()
    local itemClass,subclass,item=ItemType(18)
    facts.equipped=itemClass==2 and subclass==19
    local handClass,handSubclass=ItemType(16)
    facts.pole=handClass==2 and handSubclass==20
    if not facts.supported then return false,"Wands are supported for mages, priests, and warlocks." end
    if not facts.known then return false,"Learn Shoot to use wand shortcuts." end
    if not facts.equipped then
        if item and not itemClass then return false,"Waiting for equipped wand information." end
        return false,"Equip a wand to use wand shortcuts."
    end
    if facts.pole then return false,"Fishing pole equipped; normal fishing controls are available." end
    return true
end
local function NativeCondition(condition,expected)
    if type(SecureCmdOptionParse)~="function" then return false end
    local ok,value=pcall(SecureCmdOptionParse,"["..condition.."] yes; no")
    return ok and Text(value)==(expected and "yes" or "no")
end
local function DriverCondition(mode,sequence)
    local wand,pole=SubclassName(19),SubclassName(20)
    if not wand or not pole then return nil,"Localized equipment names are unavailable." end
    for _,check in ipairs({{"equipped:"..wand,true},{"noequipped:"..wand,false},
        {"known:5019",true},{"noknown:5019",false},
        {"equipped:"..pole,false},{"noequipped:"..pole,true}}) do
        if not NativeCondition(check[1],check[2]) then
            return nil,"The client could not verify wand shortcut conditions."
        end
    end
    local modifier=mode=="right" and "nomod" or "mod:shift,nomod:ctrl,nomod:alt"
    if mode=="right" and sequence then modifier="nomod:ctrl,nomod:alt" end
    return "[equipped:"..pole.."] off; [known:5019,equipped:"..wand..","..modifier..
        ",@mouseover,exists,harm,nodead] on; off"
end
local function ClearDriver()
    local ok=true
    if controller then
        ok=pcall(controller.SetAttribute,controller,"enabled",false) and ok
        for _,state in ipairs({"right","shift"}) do
            ok=pcall(UnregisterStateDriver,controller,state) and ok
        end
        -- UnregisterStateDriver leaves state-* behind; reset it before reinstalling.
        ok=pcall(controller.SetAttribute,controller,"state-right",nil) and ok
        ok=pcall(controller.SetAttribute,controller,"state-shift",nil) and ok
        ok=pcall(controller.Execute,controller,[[self:ClearBindings()]]) and ok
    end
    if shootButton then
        ok=pcall(shootButton.SetAttribute,shootButton,"type",nil) and ok
        ok=pcall(shootButton.SetAttribute,shootButton,"macro",nil) and ok
    end
    activeDriver,installedSignature,macroIndex,macroName=nil,nil,nil,nil
    activeSequence=false
    return ok
end
local function Initialize()
    if initialized then return true end
    if Combat() then queued=true;return false end
    if type(RegisterStateDriver)~="function" or type(UnregisterStateDriver)~="function" then
        reason="Secure wand controls are unavailable in this client."
        return false
    end
    local ok=pcall(function()
        shootButton=shootButton or CreateFrame("Button","MeffortWandSecureShootButton",UIParent,"SecureActionButtonTemplate")
        shootButton:RegisterForClicks("AnyDown","AnyUp")
        shootButton:SetAttribute("useOnKeyDown",true)
        shootButton:SetScript("PostClick",function(_,button,down)
            if button~="RightButton" then return end
            if down and activeDriver=="right" and not ownMouselook then
                if type(IsMouselooking)=="function" then
                    local got,looking=pcall(IsMouselooking)
                    if got and Bool(looking)==true then return end
                end
                local got,result=pcall(MouselookStart)
                if got and result~=false then
                    ownMouselook=true
                    frame:SetScript("OnUpdate",CheckMouselook)
                else Warn("The client could not start camera movement.") end
            elseif not down then StopMouselook() end
        end)
        controller=controller or CreateFrame("Frame","MeffortWandSecureController",UIParent,"SecureHandlerStateTemplate")
        assert(type(controller.Execute)=="function","restricted binding owner unavailable")
        controller:SetAttribute("enabled",false)
        controller:SetAttribute("_onstate-right",[[
            self:ClearBindings()
            if newstate == "on" and self:GetAttribute("enabled") and self:GetAttribute("mode") == "right" then
                self:SetBindingClick(true,"BUTTON2","MeffortWandSecureShootButton","RightButton")
                if self:GetAttribute("sequence") then
                    self:SetBindingClick(true,"SHIFT-BUTTON2","MeffortWandSecureShootButton","RightButton")
                end
            end
        ]])
        controller:SetAttribute("_onstate-shift",[[
            self:ClearBindings()
            if newstate == "on" and self:GetAttribute("enabled") and self:GetAttribute("mode") == "shift" then
                self:SetBindingClick(true,"SHIFT-BUTTON2","MeffortWandSecureShootButton","RightButton")
            end
        ]])
        controller:Execute([[self:ClearBindings()]])
    end)
    if not ok then
        ClearDriver()
        reason="Secure wand controls could not initialize; normal mouse controls remain available."
        return false
    end
    initialized=true
    return true
end
local function ClaimReady()
    return initialized and eligible and provisioned and DB().mode~="off"
end
MeffortWandRuntime={Ready=ClaimReady,Refresh=function()app.Refresh()end}
local function Notify()
    UpdateUI()
    local claim=ClaimReady()
    if lastClaim~=claim then
        if Combat() then return end
        local shared=MeffortRightClickShared
        if shared and type(shared.RefreshPeer)=="function" then
            local ok,result=pcall(shared.RefreshPeer,"MeffortWand")
            if ok and result~=false then lastClaim=claim end
        else lastClaim=claim end
    end
end
local function RefreshNow()
    local usable,unavailable=ReadEligibility()
    eligible=usable
    if Combat() then
        queued=true
        if not usable then reason=unavailable
        elseif activeDriver then
            reason=activeDriver=="right" and "Right-click is ready." or "Shift + right-click is ready."
        else reason="Wand setup will finish after combat." end
        return
    end
    queued=false
    local mode=DB().mode
    local sequence=DB().sequenceMode and mode=="right"
    if mode=="off" or not usable then
        StopMouselook();ClearDriver();provisioned=false
        reason=mode=="off" and "Off; normal mouse controls are available." or unavailable
        return
    end
    if mode=="right" and (type(MouselookStart)~="function" or type(MouselookStop)~="function"
        or type(IsMouseButtonDown)~="function") then
        eligible=false;provisioned=false;ClearDriver();reason="Camera functions are unavailable; try Shift + right-click."
        return
    end
    local condition,conditionError=DriverCondition(mode,sequence)
    if not condition then
        eligible=false;provisioned=false;ClearDriver();reason=conditionError;return
    end
    if not Initialize() then eligible=false;provisioned=false;return end
    local shared=MeffortRightClickShared
    if type(shared)~="table" or type(shared.Acquire)~="function" or type(shared.Verify)~="function" then
        provisioned=false;ClearDriver();reason="The shared macro verifier is unavailable.";return
    end
    if sequence and shared.supportsWandSequence~=true then
        provisioned=false;ClearDriver();reason="The shared macro manager does not support start-once sequences.";return
    end
    if type(shared.Busy)=="function" and shared.Busy() then queued=true;return end
    local valid=not macroDirty and macroIndex and shared.Verify(macroIndex,"Shoot",sequence)
    if not valid then
        StopMouselook();ClearDriver();provisioned=false
        local index,err=shared.Acquire("Shoot",sequence)
        if not index or not shared.Verify(index,"Shoot",sequence) then
            if err=="localized spell name unavailable" and not spellDataRequested
                and C_Spell and type(C_Spell.RequestLoadSpellData)=="function" then
                spellDataRequested=true
                pcall(C_Spell.RequestLoadSpellData,5019)
            end
            reason="Could not prepare Shoot: "..tostring(err or "macro verification failed").."."
            return
        end
        macroIndex=index
        local ok,name=pcall(GetMacroInfo,index)
        macroName=ok and Text(name) or nil
        macroDirty=false
    end
    provisioned=true
    if type(shared.Owner)~="function" or shared.Owner()~="MeffortWand" then
        StopMouselook();ClearDriver();provisioned=false
        reason="Another Meffort addon is handling right-click input.";return
    end
    local body=shared.Body("Shoot",sequence)
    local signature=mode.."|"..tostring(macroIndex).."|"..condition.."|"..tostring(body)
    if activeDriver==mode and installedSignature==signature then
        reason=mode=="right" and "Right-click is ready." or "Shift + right-click is ready."
        return
    end
    local index,name=macroIndex,macroName
    StopMouselook()
    if not ClearDriver() then provisioned=false;reason="The previous input binding could not be withdrawn.";return end
    macroIndex,macroName=index,name
    shootButton:SetAttribute("macro",index)
    shootButton:SetAttribute("type","macro")
    controller:SetAttribute("mode",mode)
    controller:SetAttribute("sequence",sequence)
    controller:SetAttribute("enabled",true)
    local ok,result=pcall(RegisterStateDriver,controller,mode,condition)
    if not ok or result==false then
        ClearDriver();provisioned=false;reason="The client refused wand input state handling.";return
    end
    activeDriver,installedSignature=mode,signature
    activeSequence=sequence
    reason=mode=="right" and "Right-click is ready." or "Shift + right-click is ready."
end
function app.Refresh()
    if applying then queued=true;return end
    applying=true
    local ok,err=pcall(RefreshNow)
    applying=false
    if not ok then
        provisioned=false
        if not Combat() then StopMouselook();ClearDriver() end
        reason="Wand controls could not refresh; normal controls will be restored when possible."
        Warn(reason.." "..tostring(err))
    end
    Notify()
end
local function ScheduleRefresh()
    if refreshScheduled then return end
    refreshScheduled=true
    local function Run()
        deferred:SetScript("OnUpdate",nil)
        refreshScheduled=false
        app.Refresh()
    end
    if C_Timer and type(C_Timer.After)=="function" then C_Timer.After(0,Run)
    else deferred:SetScript("OnUpdate",Run) end
end
function app.SetMode(mode)
    if mode~="right" and mode~="shift" and mode~="off" then return false end
    if mode=="shift" and DB().sequenceMode then
        app.Message("Turn off Start-once sequence before choosing Shift + right-click activation.");return false
    end
    local db=DB();db.mode=mode
    if mode~="off" then db.lastMode=mode end
    if mode=="off" then StopMouselook() end
    app.Refresh()
    if queued then app.Message("Change saved for after combat. Current input mode: "..tostring(activeDriver or "off")..".") end
    return true
end
function app.SetEnabled(value) return app.SetMode(value==true and DB().lastMode or "off") end
function app.SetActivationMode(mode)
    if mode~="right" and mode~="shift" then return false end
    if mode=="shift" and DB().sequenceMode then
        app.Message("Turn off Start-once sequence before choosing Shift + right-click activation.");return false
    end
    local db=DB();db.lastMode=mode
    if db.mode~="off" then return app.SetMode(mode) end
    UpdateUI();return true
end
function app.SetSequenceMode(value)
    local db=DB()
    if value==true and db.lastMode~="right" then
        app.Message("Choose Right-click activation before enabling Start-once sequence.");return false
    end
    db.sequenceMode=value==true
    app.Refresh()
    if queued then app.Message("Sequence choice saved for after combat.") end
    return true
end
function app.Status()
    local shared=MeffortRightClickShared
    local owner
    if shared and type(shared.Owner)=="function" then
        local ok,value=pcall(shared.Owner);if ok then owner=Text(value) end
    end
    return {requestedMode=DB().mode,appliedMode=activeDriver or "off",pending=queued,
        requestedSequence=DB().sequenceMode,appliedSequence=activeSequence,
        supported=facts.supported,equipped=facts.equipped,known=facts.known,
        available=initialized and eligible and provisioned,owner=owner,reason=reason,
        macroIndex=macroIndex,macroName=macroName,
        macroStatus=macroIndex and "Verified Shoot macro" or "No active macro binding"}
end
function app.CleanupMacros()
    if Combat() then return nil,"Finish combat before cleaning duplicate macros." end
    local shared=MeffortRightClickShared
    if not shared or type(shared.CleanupOnly)~="function" then return nil,"Macro cleanup is unavailable." end
    StopMouselook();ClearDriver();provisioned=false;macroDirty=true
    applying=true
    local ok,removed,err=pcall(shared.CleanupOnly,true,"Shoot",DB().sequenceMode)
    applying=false
    app.Refresh()
    if not ok then return nil,"The client refused macro cleanup." end
    return removed,err
end
function app.Diagnostics()
    local s=app.Status()
    local interface=type(GetBuildInfo)=="function" and select(4,GetBuildInfo()) or "unknown"
    app.Message("Version "..app.Version.."; interface "..tostring(interface).."; requested "..s.requestedMode..
        "; applied "..s.appliedMode.."; pending "..tostring(s.pending).."; "..tostring(s.reason))
    app.Message("Shoot learned "..tostring(s.known).."; wand equipped "..tostring(s.equipped)..
        "; input owner "..tostring(s.owner or "none").."; macro "..tostring(s.macroName or "none")..
        " ("..tostring(s.macroIndex or "unbound")..").")
    app.Message("Start-once sequence: saved "..tostring(s.requestedSequence).."; applied "..tostring(s.appliedSequence)..".")
    if #errors==0 then app.Message("No errors recorded in this session.") end
    for _,err in ipairs(errors) do app.Message(err) end
end
local function OpenSettings()
    if MeffortWandSettingsUI and type(MeffortWandSettingsUI.Open)=="function" then MeffortWandSettingsUI.Open()
    else app.Message("Settings are unavailable. Use /mwand status or /mwand diagnostics.") end
end
local function LoginNotice()
    if loginShown or not DB().showLogin then return end
    loginShown=true
    app.Message("Version "..app.Version.."; "..reason.." Use /mwand for settings. New: optional Start-once sequence with Shift reset; off by default.")
end
local help="/mwand opens settings; /mw on|off|right|shift|status|cleanup|diagnostics."
SLASH_MEFFORTWAND1="/mw"
SLASH_MEFFORTWAND2="/meffortwand"
SLASH_MEFFORTWAND3="/mwand"
SlashCmdList.MEFFORTWAND=function(input)
    local command=(Text(input) or ""):lower():match("^%s*(.-)%s*$")
    local mode=({on="right",right="right",off="off",shift="shift",
        ["mode right"]="right",["mode shift"]="shift",["mode off"]="off"})[command]
    if mode then
        app.SetMode(mode)
        if not queued then app.Message("Mode: "..mode..". "..reason) end
    elseif command=="" or command=="settings" then OpenSettings()
    elseif command=="status" then
        local s=app.Status()
        app.Message("Requested: "..s.requestedMode.."; applied: "..s.appliedMode..
            (s.pending and "; waiting for combat to end" or "")..". "..s.reason)
        app.Message(help)
    elseif command=="diagnostics" or command=="debug" then app.Diagnostics()
    elseif command=="cleanup" then
        local removed,err=app.CleanupMacros()
        if removed then app.Message("Removed "..removed.." unchanged duplicate wand macros.")
        else app.Message(tostring(err)) end
    else app.Message(help) end
end
local function Start()
    if started then return end
    started=true;DB();app.Refresh();LoginNotice()
end
for _,event in ipairs({"ADDON_LOADED","PLAYER_LOGIN","PLAYER_REGEN_ENABLED","PLAYER_EQUIPMENT_CHANGED",
    "SPELLS_CHANGED","LEARNED_SPELL_IN_TAB","UPDATE_MACROS","GLOBAL_MOUSE_UP","PLAYER_LEAVING_WORLD",
    "GET_ITEM_INFO_RECEIVED","ITEM_DATA_LOAD_RESULT","SPELL_DATA_LOAD_RESULT"}) do pcall(frame.RegisterEvent,frame,event) end
frame:SetScript("OnEvent",function(_,event,value)
    if event=="ADDON_LOADED" and value==addonName then
        DB()
        if type(IsLoggedIn)=="function" and IsLoggedIn() then ScheduleRefresh();Start() end
    elseif event=="PLAYER_LOGIN" then Start()
    elseif event=="PLAYER_REGEN_ENABLED" then if queued then app.Refresh() end
    elseif event=="UPDATE_MACROS" then
        macroDirty=true;provisioned=false
        if Combat() then queued=true;UpdateUI();return end
        if activeDriver or macroIndex then StopMouselook();ClearDriver() end
        if not applying then ScheduleRefresh() end
    elseif event=="PLAYER_EQUIPMENT_CHANGED" then
        if value==16 or value==17 or value==18 then ScheduleRefresh() end
    elseif event=="SPELLS_CHANGED" or event=="LEARNED_SPELL_IN_TAB" then ScheduleRefresh()
    elseif event=="GET_ITEM_INFO_RECEIVED" or event=="ITEM_DATA_LOAD_RESULT" then
        local id=Number(value)
        if id and waitingItems[id] and DB().mode~="off" then ScheduleRefresh() end
    elseif event=="SPELL_DATA_LOAD_RESULT" and Number(value)==5019 then
        if spellDataRequested and DB().mode~="off" then ScheduleRefresh() end
    elseif event=="GLOBAL_MOUSE_UP" and value=="RightButton" then StopMouselook()
    elseif event=="PLAYER_LEAVING_WORLD" then StopMouselook() end
end)
DB()
if type(IsLoggedIn)=="function" and IsLoggedIn() then
    if C_Timer and type(C_Timer.After)=="function" then C_Timer.After(0,Start)
    else deferred:SetScript("OnUpdate",function()deferred:SetScript("OnUpdate",nil);Start()end) end
end
