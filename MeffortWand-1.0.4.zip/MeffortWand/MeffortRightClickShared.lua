local previous=MeffortRightClickShared
local previousVersion=type(previous)=="table" and previous.version
if type(previousVersion)=="number" and previousVersion==previousVersion
    and previousVersion>=10 and previousVersion<math.huge then return end
local knownPrevious=type(previous)=="table" and (previousVersion==2 or previousVersion==6 or previousVersion==7 or previousVersion==8 or previousVersion==9)
    and type(previous.Acquire)=="function" and type(previous.Body)=="function"
local shared=knownPrevious and previous or {}
shared.version,shared.revision,shared.name,shared.alternateName=10,nil,"MeffortAim","MeffortRC"
shared.supportsWandSequence=true
MeffortRightClickShared=shared

local spells={"Shoot","Auto Shot","Throw","Shoot Bow","Shoot Gun","Shoot Crossbow"}
local spellIDs={ ["Shoot"]=5019,["Auto Shot"]=75,["Throw"]=2764,
    ["Shoot Bow"]=2480,["Shoot Gun"]=7918,["Shoot Crossbow"]=7919 }
local shootNames={frFR="Tir",zhTW="射擊",zhCN="射击",esES="Disparar",esMX="Disparar"}
local busy,refreshing=false,false
local function Secret(value)
    if type(issecretvalue)~="function" then return false end
    local ok,result=pcall(issecretvalue,value)
    return not ok or result==true
end
local function Text(value)
    if not Secret(value) and type(value)=="string" then return value end
end
local function Integer(value,minimum,maximum)
    if not Secret(value) and type(value)=="number" and value==value
        and value>=minimum and value<=maximum and value==math.floor(value) then return value end
end
local function Normalize(value)
    value=Text(value)
    if value then return (value:gsub("\r\n","\n"):gsub("\r","\n"):gsub("^%s+",""):gsub("%s+$","")) end
end
local function SpellName(value)
    value=Text(value)
    if value and value~="" and not value:find("[\r\n%z;%[%]]") then return value end
end
local function ClientSpellName(id)
    if C_Spell and type(C_Spell.GetSpellInfo)=="function" then
        local ok,info=pcall(C_Spell.GetSpellInfo,id)
        if ok and not Secret(info) and type(info)=="table" then
            local name=SpellName(info.name)
            if name then return name end
        end
    end
    if C_Spell and type(C_Spell.GetSpellName)=="function" then
        local ok,name=pcall(C_Spell.GetSpellName,id)
        if ok and SpellName(name) then return name end
    end
    if type(GetSpellInfo)=="function" then
        local ok,name=pcall(GetSpellInfo,id)
        if ok and SpellName(name) then return name end
    end
end
function shared.LocalizedName(english)
    if not spellIDs[english] then return nil end
    local name=ClientSpellName(spellIDs[english])
    if name then return name end
    local locale
    if type(GetLocale)=="function" then
        local ok,value=pcall(GetLocale)
        if ok then locale=Text(value) end
    end
    if english=="Shoot" and shootNames[locale] then return shootNames[locale] end
    if not locale or locale=="enUS" or locale=="enGB" then return english end
end
local function Body(english,name,legacy,sequence)
    local target="/target [@mouseover,harm,nodead]"
    local cast="/cast [harm,nodead] "..name
    if english=="Shoot" then
        cast="/cast [harm,nodead,nochanneling:"..name.."] "..name
        if sequence then
            return "#showtooltip "..name.."\n/stopmacro [channeling,nomod:shift]"
                .."\n/cleartarget [mod:shift,btn:1,@mouseover,harm,nodead]\n"..target
                .."\n/castsequence [nomod:shift,harm,nodead][btn:2,harm,nodead] reset=target/combat !"..name..",null"
        end
        if not legacy then target="/target [@mouseover,harm,nodead,nochanneling:"..name.."]" end
    elseif english=="Auto Shot" then cast="/cast [harm,nodead] !"..name end
    return "#showtooltip "..name.."\n"..target.."\n"..cast
end
function shared.Body(english,sequence)
    english=english or "Shoot"
    local name=shared.LocalizedName(english)
    if not name then return nil,"localized spell name unavailable" end
    return Body(english,name,false,sequence==true)
end
local function OwnedName(name)
    return name==shared.name or name==shared.alternateName or name=="MWand_Target" or name=="MWand_Fire"
        or (type(name)=="string" and (name:match("^MWand_%d+$")
            or name:match("^MSuite_Wand%d*$") or name:match("^MSuite_Ranged%d*$")))~=nil
end
local function OwnedBodies()
    local bodies={}
    for _,english in ipairs(spells) do
        local names={[english]=true}
        local localized=shared.LocalizedName(english)
        if localized then names[localized]=true end
        if english=="Shoot" then for _,name in pairs(shootNames) do names[name]=true end end
        for name in pairs(names) do
            bodies[Body(english,name)]=english
            bodies[Body(english,name,true)]=english
            if english=="Shoot" then
                bodies[Body(english,name,false,true)]=english
                bodies["#showtooltip "..name.."\n/stopmacro [channeling:"..name..",nomod:shift]\n/cleartarget [mod:shift,@mouseover,harm,nodead]\n/target [@mouseover,harm,nodead]\n/castsequence [nomod:shift,harm,nodead] reset=target/combat !"..name..", null"]=english
                bodies["#showtooltip "..name.."\n/target [@mouseover,harm,nodead,nochanneling:"..name.."]\n/castsequence [harm,nodead,nochanneling:"..name.."] reset=target/combat/shift !"..name..", null"]=english
                bodies["#showtooltip "..name.."\n/target [@mouseover,harm,nodead]\n/cast [@mouseover,harm,nodead,nochanneling:"..name.."] "..name]=english
            end
        end
    end
    return bodies
end
local function Counts()
    if type(GetNumMacros)~="function" or type(GetMacroInfo)~="function" then return nil,"macro API unavailable" end
    local ok,account,character=pcall(GetNumMacros)
    local accountLimit=Integer(MAX_ACCOUNT_MACROS,1,500) or 120
    local characterLimit=Integer(MAX_CHARACTER_MACROS,1,500) or 30
    if not ok or not Integer(account,0,accountLimit) or not Integer(character,0,characterLimit) then
        return nil,"macro counts unavailable"
    end
    return {account=account,character=character,first=accountLimit+1}
end
local function Read(index)
    local ok,name,_,body=pcall(GetMacroInfo,index)
    if body==nil then body="" end
    name,body=Text(name),Normalize(body)
    if not ok or not name or not body then return nil,"macro contents unavailable" end
    return {index=index,name=name,body=body}
end
local function CharacterIndex(index,counts)
    return index>=counts.first and index<counts.first+counts.character
end
local function Scan()
    local counts,reason=Counts()
    if not counts then return nil,reason end
    local result={counts=counts,entries={},used={}}
    local recognized=OwnedBodies()
    local function Add(index,character)
        local entry,error=Read(index)
        if not entry then return nil,error end
        entry.character=character
        entry.spell=OwnedName(entry.name) and recognized[entry.body] or nil
        result.entries[#result.entries+1]=entry
        result.used[entry.name]=true
        return true
    end
    for index=1,counts.account do
        local ok,error=Add(index,false)
        if not ok then return nil,error end
    end
    for index=counts.first,counts.first+counts.character-1 do
        local ok,error=Add(index,true)
        if not ok then return nil,error end
    end
    return result
end
function shared.Verify(index,english,sequence)
    if not Integer(index,1,1000) then return false,"macro index unavailable" end
    local expected,reason=shared.Body(english,sequence)
    if not expected then return false,reason end
    local counts,error=Counts()
    if not counts then return false,error end
    if index>counts.account and not CharacterIndex(index,counts) then return false,"macro no longer exists" end
    local entry,readError=Read(index)
    if not entry then return false,readError end
    if entry.body~=expected then return false,"macro contents changed" end
    return true
end
function shared.Busy()return busy end
local function Mutation(operation)
    if busy then return nil,"macro update already in progress" end
    if type(InCombatLockdown)~="function" then return nil,"combat state API unavailable" end
    local ok,inCombat=pcall(InCombatLockdown)
    if not ok or inCombat then return nil,"combat lockdown" end
    busy=true
    local success,a,b,c=pcall(operation)
    busy=false
    if not success then return nil,"macro operation failed" end
    return a,b,c
end
local function Keeper(entries,english,body)
    local first
    for _,entry in ipairs(entries) do
        if entry.character and entry.spell==english then
            if entry.body==body and (entry.name==shared.name or entry.name==shared.alternateName) then return entry end
            if not first or (entry.body==body and first.body~=body) then first=entry end
        end
    end
    return first
end
local function FindWritten(index,name,body)
    local inventory,reason=Scan()
    if not inventory then return nil,reason end
    local fallback
    for _,entry in ipairs(inventory.entries) do
        if entry.character and entry.name==name and entry.body==body then
            if entry.index==index then return entry.index end
            fallback=fallback or entry.index
        end
    end
    if fallback then return fallback end
    return nil,"macro write failed verification"
end
function shared.Acquire(english,sequence)
    english=english or "Shoot"
    return Mutation(function()
        local body,reason=shared.Body(english,sequence)
        if not body then return nil,reason end
        local inventory,error=Scan()
        if not inventory then return nil,error end
        local keeper=Keeper(inventory.entries,english,body)
        if keeper then
            if keeper.body==body then return keeper.index end
            if type(EditMacro)~="function" then return nil,"macro editing unavailable" end
            local current=Read(keeper.index)
            if not current or current.name~=keeper.name or current.body~=keeper.body then
                return nil,"macro changed during preparation"
            end
            local newName=keeper.name
            if newName~=shared.name and newName~=shared.alternateName then
                newName=not inventory.used[shared.name] and shared.name
                    or (not inventory.used[shared.alternateName] and shared.alternateName or keeper.name)
            end
            local ok,index=pcall(EditMacro,keeper.index,newName,nil,body)
            if not ok then return nil,"could not update owned macro" end
            return FindWritten(Integer(index,1,1000),newName,body)
        end
        for _,entry in ipairs(inventory.entries) do
            if entry.body==body then return entry.index end
        end
        local name=not inventory.used[shared.name] and shared.name
            or (not inventory.used[shared.alternateName] and shared.alternateName or nil)
        if not name then return nil,"both addon macro names are in use" end
        if type(CreateMacro)~="function" then return nil,"macro creation unavailable" end
        local ok,index=pcall(CreateMacro,name,"INV_Misc_QuestionMark",body,true)
        if not ok then return nil,"no available character macro slot" end
        return FindWritten(Integer(index,1,1000),name,body)
    end)
end
-- Compatibility callbacks from older managers must not delete macros at login.
function shared.CleanupOnly(explicit,english,sequence)
    if explicit~=true then return 0 end
    english=english or "Shoot"
    return Mutation(function()
        local inventory,reason=Scan()
        if not inventory then return nil,reason end
        local body=shared.Body(english,sequence)
        local keeper=Keeper(inventory.entries,english,body)
        if not keeper then return 0 end
        local duplicates={}
        for _,entry in ipairs(inventory.entries) do
            if entry.character and entry.spell==english and entry.index~=keeper.index then
                duplicates[#duplicates+1]=entry
            end
        end
        if #duplicates==0 then return 0 end
        if type(DeleteMacro)~="function" then return nil,"macro deletion unavailable" end
        local expectedCount=inventory.counts.character
        local keepIndex,removed=keeper.index,0
        for position=#duplicates,1,-1 do
            local entry=duplicates[position]
            local counts,error=Counts()
            if not counts or counts.character~=expectedCount then return nil,error or "macros changed during cleanup",removed end
            local current=Read(entry.index)
            local retained=Read(keepIndex)
            if not current or current.name~=entry.name or current.body~=entry.body
                or not retained or retained.name~=keeper.name or retained.body~=keeper.body then
                return nil,"macros changed during cleanup",removed
            end
            local ok=pcall(DeleteMacro,entry.index)
            local after=Counts()
            if not ok or not after or after.character~=expectedCount-1 then
                return nil,"macro deletion was not confirmed",removed
            end
            removed,expectedCount=removed+1,expectedCount-1
            if entry.index<keepIndex then keepIndex=keepIndex-1 end
        end
        local retained=Read(keepIndex)
        if not retained or retained.name~=keeper.name or retained.body~=keeper.body then
            return nil,"retained macro could not be verified",removed
        end
        return removed
    end)
end
local function CameraAvailable(mode)
    return mode~="right" or (type(MouselookStart)=="function" and type(MouselookStop)=="function"
        and type(IsMouseButtonDown)=="function")
end
function shared.Owner()
    if MeffortSuiteFishing and type(MeffortSuiteFishing.IsPoleEquipped)=="function" then
        local ok,equipped=pcall(MeffortSuiteFishing.IsPoleEquipped)
        if ok and equipped then return nil end
    end
    local class
    if type(UnitClass)=="function" then
        local ok,_,value=pcall(UnitClass,"player")
        if ok then class=Text(value) end
    end
    local mode=type(MeffortWandDB)=="table" and MeffortWandDB.mode
    if (class=="MAGE" or class=="PRIEST" or class=="WARLOCK") and (mode=="right" or mode=="shift")
        and CameraAvailable(mode) and type(MeffortWandRuntime)=="table"
        and type(MeffortWandRuntime.Ready)=="function" then
        local ok,ready=pcall(MeffortWandRuntime.Ready)
        if ok and ready then return "MeffortWand" end
    end
    if type(MeffortSuite)=="table" and type(MeffortSuite.Active)=="function"
        and type(MeffortSuiteRanged)=="table" and type(MeffortSuiteRanged.Mode)=="function" then
        local activeOk,active=pcall(MeffortSuite.Active)
        local modeOk,suiteMode=pcall(MeffortSuiteRanged.Mode)
        if activeOk and active and modeOk and (suiteMode=="right" or suiteMode=="shift") and CameraAvailable(suiteMode) then
            return "MeffortSuite"
        end
    end
end
function shared.RefreshPeer(source)
    if busy then return false,"macro update already in progress" end
    if refreshing then return false,"peer refresh already in progress" end
    if type(InCombatLockdown)~="function" then return false,"combat state API unavailable" end
    local ok,combat=pcall(InCombatLockdown)
    if not ok or combat then return false,"combat lockdown" end
    refreshing=true
    local success=true
    if source~="MeffortWand" and type(MeffortWandRuntime)=="table" and type(MeffortWandRuntime.Refresh)=="function" then
        success=pcall(MeffortWandRuntime.Refresh) and success
    end
    if source~="MeffortSuite" and type(MeffortSuiteRanged)=="table" and type(MeffortSuiteRanged.Refresh)=="function" then
        -- Older Suite releases retain state-driver values after clearing their bindings.
        local controller=MeffortSuiteSecureController
        if controller and type(controller.SetAttribute)=="function" then
            pcall(controller.SetAttribute,controller,"state-right",nil)
            pcall(controller.SetAttribute,controller,"state-shift",nil)
        end
        success=pcall(MeffortSuiteRanged.Refresh) and success
    end
    refreshing=false
    if success then return true end
    return false,"peer refresh failed"
end
