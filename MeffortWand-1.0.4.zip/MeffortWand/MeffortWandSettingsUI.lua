local UI={}
MeffortWandSettingsUI=UI

local FONT=STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
local WIDTH,HEIGHT=410,500
local GOLD={1,.82,.28}
local WHITE={1,.92,.74}
local MUTED={.71,.67,.59}
local frame,master,statusTitle,statusDetail,macroText,macroHelp,loginCheck
local sequenceRow,sequenceCheck,sequenceHelp,notice
local choices={}
local cleanupButton,checkButton
local tooltipOwner,refreshQueued,feedback
local RefreshUI,FitToScreen

local function Api(name,...)
    local app=MeffortWand
    local fn=type(app)=="table" and app[name]
    if type(fn)=="function" then return fn(...) end
end
local function Combat()
    if type(InCombatLockdown)~="function" then return false end
    local value=InCombatLockdown()
    return value==true or value==1
end
local function Font(parent,text,size,color)
    local label=parent:CreateFontString(nil,"OVERLAY","GameFontHighlight")
    label:SetFont(FONT,size or 12,"")
    label:SetTextColor(unpack(color or WHITE))
    label:SetJustifyH("LEFT")
    label:SetText(text or "")
    return label
end
local function HideTooltip()
    local tip=GameTooltip
    if tooltipOwner and tip then
        local owns=false
        if type(tip.GetOwner)=="function" then owns=tip:GetOwner()==tooltipOwner
        elseif type(tip.IsOwned)=="function" then owns=tip:IsOwned(tooltipOwner)==true end
        if owns and tip.Hide then tip:Hide() end
    end
    tooltipOwner=nil
end
local function Tips(widget,title,detail)
    widget:SetScript("OnEnter",function(self)
        local tip=GameTooltip
        if not tip or not tip.SetOwner then return end
        HideTooltip()
        tooltipOwner=self
        tip:SetOwner(self,"ANCHOR_RIGHT")
        tip:SetText(title,1,1,1)
        local text=type(detail)=="function" and detail() or detail
        if type(text)=="string" and text~="" then tip:AddLine(text,.83,.79,.69,true) end
        tip:Show()
    end)
    widget:SetScript("OnLeave",function(self)
        if tooltipOwner==self then HideTooltip() end
    end)
end
local function Backdrop(widget)
    if widget.SetBackdrop then
        widget:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",
            edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",tile=true,tileSize=32,edgeSize=24,
            insets={left=7,right=7,top=7,bottom=7}})
        widget:SetBackdropColor(.11,.085,.06,.98)
        widget:SetBackdropBorderColor(.78,.62,.30,1)
    else
        local background=widget:CreateTexture(nil,"BACKGROUND")
        background:SetAllPoints(widget)
        background:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Background")
        background:SetVertexColor(.72,.60,.44,1)
        local border=widget:CreateTexture(nil,"BORDER")
        border:SetAllPoints(widget)
        border:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Border")
    end
end
local function Button(parent,text,width,height,onClick)
    local button=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
    button:SetSize(width,height)
    button:SetText("")
    local label=Font(button,text,12)
    label:SetPoint("CENTER",button,"CENTER",0,1)
    label:SetSize(width-14,20)
    label:SetJustifyH("CENTER")
    label:SetWordWrap(false)
    local selected=button:CreateTexture(nil,"OVERLAY")
    selected:SetPoint("BOTTOMLEFT",button,"BOTTOMLEFT",7,4)
    selected:SetPoint("BOTTOMRIGHT",button,"BOTTOMRIGHT",-7,4)
    selected:SetHeight(2)
    selected:SetTexture("Interface\\Buttons\\WHITE8X8")
    selected:SetVertexColor(1,.79,.22,1)
    selected:Hide()
    button:SetScript("OnClick",onClick)
    return {button=button,label=label,selected=selected}
end
local function Select(button,selected)
    button.selected:SetShown(selected==true)
    button.label:SetTextColor(unpack(selected and GOLD or WHITE))
end
local function ModeName(mode)
    if mode=="right" then return "Right-click" end
    if mode=="shift" then return "Shift + right-click" end
    return "Off"
end
local function StatusText(status,enabled)
    local applied=status.appliedMode
    if status.pending then
        local detail="Saved: "..ModeName(status.requestedMode or Api("GetMode"))..". "
        if status.available==false and type(status.reason)=="string" and status.reason~="" then
            detail=detail..status.reason
        elseif applied=="right" or applied=="shift" then
            detail=detail..ModeName(applied).." remains active until combat ends."
        else detail=detail.."The new choice takes effect after combat." end
        if status.requestedSequence~=status.appliedSequence then
            detail=detail.." Sequence: "..(status.requestedSequence and "on" or "off").." after combat."
        end
        return "Change pending until combat ends",detail
    end
    if not enabled then
        if status.owner=="MeffortSuite" then
            return "MeffortWand is off","MeffortSuite handles ranged input. Your standalone choice is saved."
        end
        return "MeffortWand is off","Your activation choice is saved. Turn it on above when you want to use it."
    end
    if applied=="right" and status.appliedSequence then
        return "Start-once sequence is active","Right-click to start. After moving or casting, hold Shift for one right-click to attempt a restart."
    elseif applied=="right" then
        return "Right-click is active","Right-click a living enemy to begin Shoot. Hold the button to turn the camera."
    elseif applied=="shift" then
        return "Shift + right-click is active","Use Shift + right-click on a living enemy to begin Shoot."
    end
    local reason=status.reason
    if type(reason)~="string" or reason=="" then
        if status.supported==false then reason="Wand controls are available to Mages, Priests, and Warlocks."
        elseif status.equipped==false then reason="Equip a wand to use your saved activation choice."
        elseif status.known==false then reason="Learn Shoot to use your saved activation choice."
        else reason="Your choice is saved. Check your wand, Shoot, and macro setup below." end
    end
    return "Wand controls are waiting",reason
end
FitToScreen=function()
    if not frame then return end
    local width,height=UIParent:GetWidth(),UIParent:GetHeight()
    if type(width)~="number" or type(height)~="number" or width<=0 or height<=0 then return end
    frame:SetScale(math.max(.1,math.min(1,(width-24)/WIDTH,(height-24)/HEIGHT)))
end
RefreshUI=function()
    if not frame or not frame:IsShown() then return end
    local enabled=Api("GetEnabled")==true
    local status=Api("Status")
    if type(status)~="table" then status={} end
    master.label:SetText(enabled and "Wand ON" or "Wand OFF")
    Select(master,enabled)
    local activation=Api("GetActivationMode")
    for mode,button in pairs(choices) do Select(button,mode==activation) end
    loginCheck:SetChecked(Api("GetShowLogin")==true)
    local sequence=Api("GetSequenceMode")==true
    sequenceCheck:SetChecked(sequence)
    if activation=="right" then sequenceRow:Enable() else sequenceRow:Disable() end
    if sequence then choices.shift.button:Disable() else choices.shift.button:Enable() end
    sequenceHelp:SetText(activation=="right" and
        "Right-click to start once. Hold Shift for one right-click to restart after moving or casting. Restarting may still fail." or
        "Choose Right-click activation to use this option; Shift is reserved for restarting.")
    local title,detail=StatusText(status,enabled)
    statusTitle:SetText(title)
    statusDetail:SetText(detail)
    if type(status.macroName)=="string" and status.macroName~="" then
        macroText:SetText(status.macroName)
    elseif type(status.macroStatus)=="string" and status.macroStatus~="" then
        macroText:SetText(status.macroStatus)
    else macroText:SetText("Prepared when wand controls are enabled.") end
    macroHelp:SetText(feedback or "Only extra, unchanged addon character macros are removed. Custom and account macros are kept.")
    local safe=not Combat()
    if safe then cleanupButton.button:Enable();checkButton.button:Enable()
    else cleanupButton.button:Disable();checkButton.button:Disable() end
end
local function CreatePanel()
    if frame then return frame end
    frame=CreateFrame("Frame","MeffortWandSettings",UIParent,BackdropTemplateMixin and "BackdropTemplate" or nil)
    frame:SetSize(WIDTH,HEIGHT)
    frame:SetPoint("CENTER",UIParent,"CENTER",0,0)
    frame:SetFrameStrata("DIALOG")
    frame:SetClampedToScreen(true)
    frame:EnableMouse(true)
    frame:SetMovable(true)
    Backdrop(frame)

    local header=CreateFrame("Frame",nil,frame)
    header:SetPoint("TOPLEFT",frame,"TOPLEFT",11,-7)
    header:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-11,-7)
    header:SetHeight(40)
    header:EnableMouse(true)
    header:RegisterForDrag("LeftButton")
    header:SetScript("OnDragStart",function()frame:StartMoving()end)
    header:SetScript("OnDragStop",function()frame:StopMovingOrSizing()end)
    local strip=header:CreateTexture(nil,"BACKGROUND")
    strip:SetAllPoints(header)
    strip:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Background")
    strip:SetVertexColor(.55,.42,.21,.89)
    local line=frame:CreateTexture(nil,"ARTWORK")
    line:SetPoint("TOPLEFT",frame,"TOPLEFT",12,-47)
    line:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-12,-47)
    line:SetHeight(1)
    line:SetTexture("Interface\\Buttons\\WHITE8X8")
    line:SetVertexColor(.83,.67,.32,1)
    local icon=header:CreateTexture(nil,"ARTWORK")
    icon:SetTexture("Interface\\Icons\\INV_Wand_01")
    icon:SetSize(29,29);icon:SetPoint("TOPLEFT",header,"TOPLEFT",4,-5)
    local title=Font(header,"MeffortWand",16,GOLD)
    title:SetPoint("TOPLEFT",header,"TOPLEFT",42,-9);title:SetSize(145,22)
    local version=Font(header,tostring(MeffortWand and MeffortWand.Version or ""),10,MUTED)
    version:SetPoint("LEFT",title,"RIGHT",2,-1);version:SetSize(42,16)
    local close=CreateFrame("Button",nil,header,"UIPanelCloseButton")
    close:SetSize(29,29);close:SetPoint("TOPRIGHT",header,"TOPRIGHT",3,-1)
    close:SetScript("OnClick",function()frame:Hide()end)
    master=Button(header,"",80,26,function()
        Api("SetEnabled",not (Api("GetEnabled")==true));feedback=nil;RefreshUI()
    end)
    master.button:SetPoint("RIGHT",close,"LEFT",-1,0)
    Tips(master.button,"Enable MeffortWand","Turn wand controls on or off. Your activation choice stays saved. Changes during combat take effect after combat ends.")

    local status=CreateFrame("Frame",nil,frame)
    status:SetPoint("TOPLEFT",frame,"TOPLEFT",18,-56);status:SetSize(WIDTH-36,62)
    status:EnableMouse(true)
    statusTitle=Font(status,"",12,GOLD)
    statusTitle:SetPoint("TOPLEFT",status,"TOPLEFT",0,0);statusTitle:SetSize(WIDTH-36,18)
    statusDetail=Font(status,"",11,MUTED)
    statusDetail:SetPoint("TOPLEFT",status,"TOPLEFT",0,-21);statusDetail:SetSize(WIDTH-36,40)
    statusDetail:SetWordWrap(true)
    Tips(status,"Wand controls",function()
        local current=Api("Status") or {}
        local titleText,detail=StatusText(current,Api("GetEnabled")==true)
        return titleText.."\n"..detail
    end)

    local activation=Font(frame,"Activation",12,GOLD)
    activation:SetPoint("TOPLEFT",frame,"TOPLEFT",18,-121);activation:SetHeight(18)
    for index,mode in ipairs({"right","shift"}) do
        local selectedMode=mode
        local button=Button(frame,ModeName(mode),183,32,function()
            Api("SetActivationMode",selectedMode);feedback=nil;RefreshUI()
        end)
        button.button:SetPoint("TOPLEFT",frame,"TOPLEFT",18+(index-1)*191,-142)
        choices[mode]=button
        Tips(button.button,ModeName(mode),mode=="right" and
            "Right-click a living enemy to start Shoot. Holding right-click also turns the camera. Other modifiers keep their normal behavior." or
            "Hold Shift while right-clicking a living enemy to start Shoot. Plain right-click keeps its normal behavior.")
    end
    local activationHelp=Font(frame,"Choose how to start Shoot. This choice stays saved when MeffortWand is off.",11,MUTED)
    activationHelp:SetPoint("TOPLEFT",frame,"TOPLEFT",18,-183);activationHelp:SetSize(WIDTH-36,30)
    activationHelp:SetWordWrap(true)

    sequenceRow=CreateFrame("Button",nil,frame)
    sequenceRow:SetPoint("TOPLEFT",frame,"TOPLEFT",16,-216);sequenceRow:SetSize(WIDTH-32,28)
    sequenceCheck=CreateFrame("CheckButton",nil,sequenceRow,"UICheckButtonTemplate")
    sequenceCheck:SetSize(24,24);sequenceCheck:SetPoint("LEFT",sequenceRow,"LEFT",0,0)
    sequenceCheck:EnableMouse(false)
    local sequenceLabel=Font(sequenceRow,"Start-once sequence (Shift to restart)",12)
    sequenceLabel:SetPoint("LEFT",sequenceRow,"LEFT",30,0);sequenceLabel:SetSize(WIDTH-68,20)
    sequenceRow:SetScript("OnClick",function()
        if Api("GetActivationMode")~="right" then return end
        Api("SetSequenceMode",not (Api("GetSequenceMode")==true));feedback=nil;RefreshUI()
    end)
    Tips(sequenceRow,"Start-once sequence","Optional; off by default. Right-click starts Shoot once and further clicks leave it running. After moving or casting, hold Shift for one right-click, then release Shift. Target changes and leaving combat also reset it. Forever may still fail to restart; turn this option off to restore normal casting. Requires Right-click activation. Changes apply after combat.")
    sequenceHelp=Font(frame,"",11,MUTED)
    sequenceHelp:SetPoint("TOPLEFT",frame,"TOPLEFT",18,-247);sequenceHelp:SetSize(WIDTH-36,34)
    sequenceHelp:SetWordWrap(true)

    local loginRow=CreateFrame("Button",nil,frame)
    loginRow:SetPoint("TOPLEFT",frame,"TOPLEFT",16,-286);loginRow:SetSize(WIDTH-32,28)
    loginCheck=CreateFrame("CheckButton",nil,loginRow,"UICheckButtonTemplate")
    loginCheck:SetSize(24,24);loginCheck:SetPoint("LEFT",loginRow,"LEFT",0,0)
    loginCheck:EnableMouse(false)
    local loginLabel=Font(loginRow,"Show login message",12)
    loginLabel:SetPoint("LEFT",loginRow,"LEFT",30,0);loginLabel:SetSize(WIDTH-68,20)
    loginRow:SetScript("OnClick",function()
        Api("SetShowLogin",not (Api("GetShowLogin")==true));RefreshUI()
    end)
    Tips(loginRow,"Show login message","Show a short MeffortWand chat notice and clickable login announcement when this character logs in or reloads.")

    local divider=frame:CreateTexture(nil,"ARTWORK")
    divider:SetPoint("TOPLEFT",frame,"TOPLEFT",18,-325)
    divider:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-18,-325)
    divider:SetHeight(1);divider:SetTexture("Interface\\Buttons\\WHITE8X8")
    divider:SetVertexColor(.55,.44,.23,.65)
    local macroTitle=Font(frame,"Shared macro",12,GOLD)
    macroTitle:SetPoint("TOPLEFT",frame,"TOPLEFT",18,-338);macroTitle:SetHeight(18)
    macroText=Font(frame,"",11,MUTED)
    macroText:SetPoint("TOPLEFT",frame,"TOPLEFT",18,-359);macroText:SetSize(WIDTH-36,18)
    macroText:SetWordWrap(false)
    checkButton=Button(frame,"Check setup",183,27,function()
        if Combat() then return RefreshUI() end
        feedback=nil;Api("Refresh");RefreshUI()
    end)
    checkButton.button:SetPoint("TOPLEFT",frame,"TOPLEFT",18,-385)
    Tips(checkButton.button,"Check setup","Recheck your wand, Shoot, and the shared macro. Turning wand controls on prepares a macro if needed. Available after combat.")
    cleanupButton=Button(frame,"Clean duplicates",183,27,function()
        if Combat() then return RefreshUI() end
        local removed,reason=Api("CleanupMacros")
        if type(removed)=="number" then
            feedback=removed==0 and "No extra addon macros were found." or
                (tostring(removed)..(removed==1 and " extra addon macro removed." or " extra addon macros removed."))
        else feedback=type(reason)=="string" and reason or "Macro cleanup is unavailable." end
        Api("Message",feedback);RefreshUI()
    end)
    cleanupButton.button:SetPoint("TOPLEFT",frame,"TOPLEFT",209,-385)
    Tips(cleanupButton.button,"Clean duplicate macros","Remove only extra, unchanged addon character macros. Keep the retained macro, custom text, and all account macros. This never turns wand controls on. Available after combat.")
    macroHelp=Font(frame,"",10,MUTED)
    macroHelp:SetPoint("TOPLEFT",frame,"TOPLEFT",18,-421);macroHelp:SetSize(WIDTH-36,42)
    macroHelp:SetWordWrap(true)
    local footer=Font(frame,"Settings are saved for this character.",10,MUTED)
    footer:SetPoint("TOPLEFT",frame,"TOPLEFT",18,-472);footer:SetSize(WIDTH-36,16)

    if type(UISpecialFrames)=="table" then
        local present=false
        for _,name in ipairs(UISpecialFrames) do if name=="MeffortWandSettings" then present=true;break end end
        if not present then UISpecialFrames[#UISpecialFrames+1]="MeffortWandSettings" end
    end
    frame:SetScript("OnShow",function()FitToScreen();RefreshUI()end)
    frame:SetScript("OnHide",function()frame:StopMovingOrSizing();HideTooltip()end)
    frame:SetScript("OnEvent",function(_,event)
        if not frame:IsShown() then return end
        if event=="UI_SCALE_CHANGED" or event=="DISPLAY_SIZE_CHANGED" then FitToScreen() end
        RefreshUI()
        if not refreshQueued and C_Timer and type(C_Timer.After)=="function" then
            refreshQueued=true
            C_Timer.After(0,function()
                refreshQueued=false
                if frame:IsShown() then RefreshUI() end
            end)
        end
    end)
    for _,event in ipairs({"PLAYER_REGEN_DISABLED","PLAYER_REGEN_ENABLED","PLAYER_EQUIPMENT_CHANGED",
        "SPELLS_CHANGED","UPDATE_MACROS","UI_SCALE_CHANGED","DISPLAY_SIZE_CHANGED"}) do
        pcall(frame.RegisterEvent,frame,event)
    end
    frame:Hide()
    return frame
end
function UI.Open()
    if notice then notice:Hide() end
    local panel=CreatePanel()
    feedback=nil
    panel:Show()
    FitToScreen();RefreshUI()
end
function UI.Hide()if frame then frame:Hide() end end
function UI.Refresh()RefreshUI()end

function UI.ShowLoginNotice()
    if not notice then
        notice=CreateFrame("Button",nil,UIParent,BackdropTemplateMixin and "BackdropTemplate" or nil)
        notice:SetSize(360,88)
        notice:SetPoint("TOP",UIParent,"TOP",0,-120)
        notice:SetFrameStrata("HIGH")
        notice:SetClampedToScreen(true)
        notice:RegisterForClicks("LeftButtonUp","RightButtonUp")
        Backdrop(notice)
        local title=Font(notice,"MeffortWand "..tostring(MeffortWand and MeffortWand.Version or ""),13,GOLD)
        title:SetPoint("TOPLEFT",notice,"TOPLEFT",16,-12);title:SetSize(305,19)
        local detail=Font(notice,"New: Start-once sequence; off by default.\nClick for settings and Shift restart instructions.",11,WHITE)
        detail:SetPoint("TOPLEFT",notice,"TOPLEFT",16,-36);detail:SetSize(328,36)
        detail:SetWordWrap(true)
        notice:SetScript("OnClick",function(_,button)
            notice:Hide()
            if button=="LeftButton" then UI.Open() end
        end)
        notice:SetScript("OnHide",HideTooltip)
        Tips(notice,"Start-once sequence","Optional repeated-click protection with a manual Shift restart. It may still fail to restart on Forever. Left-click for settings; right-click to dismiss.")
    end
    local width=UIParent:GetWidth()
    if type(width)=="number" and width>0 then notice:SetScale(math.max(.1,math.min(1,(width-24)/360))) end
    notice:Show()
    if C_Timer and type(C_Timer.After)=="function" then
        C_Timer.After(12,function()if notice then notice:Hide() end end)
    end
end
