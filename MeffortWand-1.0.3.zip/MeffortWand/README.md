# MeffortWand 1.0.3

Right-click a living enemy to target it and start Shoot with an equipped wand in **World of Warcraft: Forever**, Interface 16001. Supports mages, priests, and warlocks with Shoot learned. Each attack starts from your own mouse input; the addon does not automate combat.

## Install

Extract the ZIP and place the inner `MeffortWand` folder in `Interface/AddOns`. Replace the existing folder. Remove older `MeffortsWand` copies so only one standalone version is enabled, then reload the UI.

## Settings

Use **`/mwand`** to open the settings panel. Its native dialog border, gold headings, and controls match MeffortSuite. Settings are saved per character.

- **Wand ON/OFF:** turn the feature on or off while retaining your activation choice.
- **Right-click:** click a living enemy to start Shoot; holding the button also turns the camera. Other modifiers retain normal behavior.
- **Shift + right-click:** require Shift; plain right-click retains normal behavior.
- **Show login message:** display a short startup notice containing the settings command.
- **Check setup:** recheck the equipped wand, learned Shoot, and shared macro.
- **Clean duplicates:** explicitly remove extra, unchanged addon character macros for Shoot. Custom text, other attacks, and account macros are preserved.

Hover controls for help. Press Escape or the close button to dismiss the panel; drag its header to move it. The panel fits smaller viewports automatically.

Changes that affect protected input during combat are saved for after combat. The panel shows the requested and applied modes separately. The previous applied mode can remain installed until combat ends; use the pending status rather than assuming a saved OFF choice has already withdrawn it.

## Commands

- `/mwand`, `/mw`, or `/meffortwand`: open settings.
- `/mw on` or `/mw right`: choose right-click mode.
- `/mw shift`: choose Shift + right-click mode.
- `/mw off`: turn standalone wand controls off.
- `/mw status`: show requested mode, applied mode, and current setup.
- `/mw cleanup`: explicitly clean duplicate generated wand macros.
- `/mw diagnostics`: show version, setup, macro identity, and recorded session errors.

New characters default to right-click mode. Unsupported classes, missing wands or Shoot, fishing poles, unavailable client functions, and unverified macro setup leave normal controls available. Secure equipment conditions also suppress the shortcut when equipment or spell knowledge changes during combat.

## Macro care and MeffortSuite

Turning MeffortWand off **retains its macro**, including any action-bar references. The addon never deletes macros automatically at login or during ordinary enable/disable changes. Its macro manager upgrades recognized legacy addon macros, reuses an exact safe existing macro read-only, or creates one character macro named `MeffortAim` or `MeffortRC`. It preserves account macros and custom edits. If both names are occupied and no exact safe macro exists, it reports the conflict instead of overwriting one.

Macro deletion, editing, or reordering withdraws and re-verifies the shortcut before rebinding out of combat, preventing an old numeric slot from calling another macro. Explicit duplicate cleanup only affects recognized, unchanged addon character macros for Shoot; remove duplicates only when you no longer need their separate action-bar entries.

When installed with MeffortSuite, an available, enabled standalone MeffortWand takes priority. The suite can handle ranged input when standalone controls are off or unavailable. The shared manager respects load order and avoids duplicate ownership. Older suite cleanup calls are non-destructive while the newer manager is installed; use MeffortWand's explicit cleanup control to remove duplicates.

Normal corpse looting and non-hostile NPC interaction are not shortcut targets. Starting a camera turn directly over a living enemy can also start Shoot in right-click mode; choose Shift mode if you prefer a separate gesture. Client-specific mouse dispatch, camera behavior, and combat restrictions still need in-game validation.

Licensed under MIT. See `LICENSE`.
