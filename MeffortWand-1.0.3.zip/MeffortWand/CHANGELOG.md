# MeffortWand 1.0.3

- Add `/mwand` settings with native Forever dialog styling, help tooltips, per-character activation preferences, and a configurable login notice.
- Preserve the selected activation method when turning the addon off and back on; show pending combat changes separately from applied controls.
- Withdraw and re-verify numeric macro bindings when macros change, preserving custom and account macros.
- Handle macro rename/reordering, custom-name conflicts, localized Shoot, and either MeffortSuite load order.
- Retain macros on disable; remove unchanged duplicate wand macros only through explicit cleanup.
- Keep working bindings across repeated state-driver refreshes and recover safely after partial initialization or registration failures.
- Use the applied mode for camera handling while combat changes are pending.
- Limit camera polling to an owned mouse-look session and avoid refreshes for unrelated armor or item-data events.
- Check wand equipment, Shoot knowledge, fishing poles, and native conditional support before enabling the shortcut.

## 1.0.2

- Use the client's localized Shoot name and refresh when spell data changes.

## 1.0.1

- Share a character macro with MeffortSuite and coordinate standalone priority and suite fallback.

## 1.0.0

- Initial Forever release with right-click and Shift + right-click wand controls.
