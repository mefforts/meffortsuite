MeffortSuite 1.1.1
WoW Forever | Interface 16001

INSTALLATION
Extract the MeffortSuite folder into Interface/AddOns, replacing the previous
MeffortSuite folder. Keep the folder name unchanged, then reload the game.
Existing SavedVariables and saved OFF preferences are retained.

SETTINGS
Open /msuite to configure each tool. Toggles save immediately. Text fields
save with Enter or Apply; Esc discards the current edit. Unsaved text is retained
when navigating between settings pages. Scope labels identify account and
character settings. The master switch keeps individual preferences saved.
Protected input and display changes requested in combat finish after combat.

BAGS AND BANKING
- Sort bags when opened; sell junk and repair with personal gold at merchants.
- Deposit crafting reagents and sort the personal bank when opened.
- Keep selected items in bags using per-character deposit exclusions: exact
  names or numeric item IDs, separated by commas. IDs work across languages.
- With exclusions, unidentified or ineligible items stay in bags. Transfers never
  fall back to an unrestricted deposit. Saving new exclusions stops pending
  transfers; requests already sent cannot be reversed.
- Skip Orgrimmar banker dialogue for Soran, Karus, and Koma. Hold Shift to bypass.

PROFESSIONS
- Right-click fishing with a pole equipped. New characters use double-click;
  existing choices are retained. Single-click prevents normal camera turning.
- Open Enchanting and click the MeffortSuite side tab to use Enchant Queue.
  Select a recipe, drag in a target item, enter a count, and add it to the queue.
- Next requires a separate click or key press for every enchant and confirmation.
  Bind it under Keybindings > AddOns > MeffortSuite.
- Queues scroll and persist per character. Clear offers Undo until the next edit.
  If a result cannot be confirmed, Check result pauses for your inspection;
  uncertain enchants are never automatically retried.
- The queue closes with Enchanting. If Next is unavailable, follow its status
  message or use Blizzard's crafting controls.

COMBAT AND INTERFACE
- Right-click wand, bow, gun, crossbow, and thrown attacks with shared macros.
- Choose Shift + click to keep ordinary right-click for native melee and use
  Shift + right-click for the ranged shot. No measured-distance switch is used.
  Warriors use native single-shot attacks; Shoot Gun needs a new input for each
  shot. Hunter Auto Shot is a separate repeating ability.
- Optional conservative target-range warning; unknown distances show no warning.
- Mage Arcane Blast stacks, countdown, and timer wheel on Blizzard Tracked Buffs.
  Add Arcane Blast to Tracked Buffs first. Combat estimates reconcile afterward.
- English spell explanations, tooltip-header badges, rank alerts, and colors.
- Action-bar keybinding labels with a live position preview.
- Quest dialogue shortcuts: Space prefers available quests, then quests ready
  to turn in, then unfinished quests. It still accepts/continues/completes the
  current quest dialogue; with no quests it selects the first conversation
  choice. Number keys 1-9 keep their original menu order, with
  labels in the native menu; * marks the Spacebar choice. Normal controls
  return outside dialogue.
- Single-option service shortcuts open recognized shops, trainers, banks, or
  flight maps only when there is exactly one choice and no quests. Hold Shift
  to see the dialogue. Unknown, paid, or confirmation choices stay manual.
  Configure this separately under Quests; existing bank/flight settings remain
  independent and their saved OFF choices are respected.
- Optional waypoint arrow and flight-master dialogue shortcut. The shortcut
  opens the flight map without selecting a route. Hold Shift to bypass.

COMMANDS
/msuite                         Open settings
/msuite on | off                Toggle the suite; retain feature preferences
/msuite professions             Open profession settings
/msuite enchant                 Toggle the queue while Enchanting is open
/msuite fishing status          Check fishing setup
/msuite arcane                  Open Arcane Blast settings
/msuite bank now                Deposit reagents at an open bank
/msuite bank on | off           Toggle automatic deposits
/msuite bank sort on | off      Toggle personal-bank sorting
/msuite bank gossip on | off    Toggle Orgrimmar banker shortcut
/msuite flight on | off         Toggle flight-master shortcut
/msuite services on | off       Toggle single-option service shortcuts
/msuite vendor [retry]          Check or retry merchant actions
/msuite diagnostics             Show client state and recorded errors
/msuite help                    Show command help

COMPATIBILITY
Targets WoW Forever Interface 16001. Spell explanations and header parsing use
English data. Saved deposit exclusions and enchant queues are per character.
Enabled standalone MeffortWand takes priority over the suite's wand handling.
Supported preferences from older Meffort addons migrate on first installation.

If an item move is blocked, follow the status message and check your cursor
before retrying. Enchanting always requires player input. This unofficial addon
is not affiliated with Blizzard.

See ATTRIBUTION.txt, LICENSE, and THIRD-PARTY-EnchantQueue-LICENSE.txt for credits
and licensing.
