local UI={}
MeffortSuiteSettingsUI=UI

local FONT=STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
local HOME_W,HOME_H=362,410
local DETAIL_W,MAX_DETAIL_H=452,560
local BODY_W=406
local C={
  mint={1,.81,.30,1}, gold={1,.82,.28,1}, red={.56,.54,.48,1},
  muted={.71,.67,.59,1}, white={1,.92,.74,1},
}
local frame,headerTitle,logo,backButton,infoButton,masterButton,masterText,statusTitle,statusDetail
local home,tiles,scroller
local pages={};local activePage="overview"
local history,inputDrafts={},{}
local OpenPage,RefreshUI
local function RGB(tex,c)
  tex:SetColorTexture(c[1],c[2],c[3],c[4] or 1)
end
local function WoWBackdrop(widget)
  local backdrop={
    bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",
    tile=true,tileSize=32,edgeSize=24,
    insets={left=7,right=7,top=7,bottom=7},
  }
  if widget.SetBackdrop then
    widget:SetBackdrop(backdrop)
    if widget.SetBackdropColor then widget:SetBackdropColor(.11,.085,.06,.98)end
    if widget.SetBackdropBorderColor then widget:SetBackdropBorderColor(.78,.62,.30,1)end
  else
    local bg=widget:CreateTexture(nil,"BACKGROUND")
    bg:SetAllPoints(widget)
    bg:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Background")
    bg:SetVertexColor(.72,.60,.44,1)
    local edge=widget:CreateTexture(nil,"BORDER")
    edge:SetAllPoints(widget)
    edge:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Border")
  end
end

local function Font(parent,text,size,color,flags)
  local t=parent:CreateFontString(nil,"OVERLAY","GameFontHighlight")
  t:SetFont(FONT,size or 12,flags or "")
  t:SetTextColor((color or C.white)[1],(color or C.white)[2],(color or C.white)[3],1)
  t:SetText(text or "")
  return t
end
local function DB()
  if type(MeffortSuiteDB)~="table" then MeffortSuiteDB={} end
  return MeffortSuiteDB
end
local function Char()
  if type(MeffortSuiteCharDB)~="table" then MeffortSuiteCharDB={} end
  return MeffortSuiteCharDB
end
local function Range()
  local char=Char()
  if type(char.targetDistance)~="table" then char.targetDistance={} end
  return char.targetDistance
end
local function Action()
  local d=DB()
  if type(d.actionText)~="table" then d.actionText={} end
  local s=d.actionText
  if s.enabled==nil then s.enabled=true end
  if s.size==nil then s.size=18 end
  if s.x==nil then s.x=0 end
  if s.y==nil then s.y=0 end
  if s.outline==nil then s.outline=true end
  if s.shadow==nil then s.shadow=true end
  if s.hex==nil then s.hex="fff0c2" end
  return s
end
local function IsActive() return not MeffortSuite or not MeffortSuite.Active or MeffortSuite.Active() end
local function OnOff(active) return active and "ON" or "OFF" end
local function Capability(module)
  if module and type(module.Available)=="function" then return module.Available() end
end
local function Features()
  local d=DB()
  local range,ranged=MeffortSuiteTargetDistance,MeffortSuiteRanged
  local fish,enchant,arcane=MeffortSuiteFishing,MeffortSuiteEnchantQueue,MeffortSuiteArcaneBlast
  local function Count(values)
    local enabled=0
    for _,value in ipairs(values) do if value then enabled=enabled+1 end end
    return tostring(enabled).."/"..tostring(#values)
  end
  local mode=ranged and ranged.Mode and ranged.Mode() or "off"
  local combat={range and range.Enabled and range.Enabled() or false}
  if arcane and arcane.IsMage and arcane.IsMage() then
    combat[#combat+1]=arcane.GetOption and arcane.GetOption("enabled") or false
  end
  local enchantOn=enchant and ((enchant.Configured and enchant.Configured()) or
    (not enchant.Configured and enchant.Enabled and enchant.Enabled())) or false
  return {
    ranged=OnOff(mode=="right" or mode=="shift"),
    range=Count(combat),
    inventory=Count({d.autoSortBags~=false,d.autoSellJunk~=false,d.autoRepair~=false,
      d.autoBankCrafting~=false,d.autoOpenOrgBank~=false,d.autoSortBank~=false}),
    quest=Count({d.questSpace~=false,d.autoOpenSingleService~=false}),
    way=Count({d.wayEnabled~=false,d.autoOpenFlightMaster~=false}),
    tooltips=Count({d.enabled==true,d.style~=false,d.badges~=false,d.rankHint~=false}),
    action=OnOff(Action().enabled==true),
    fishing=Count({fish and fish.Enabled and fish.Enabled() or false,enchantOn}),
    badges=OnOff(d.badges~=false),
  }
end
local function Weapon()
  local m=MeffortSuiteRanged
  if not m or not m.Kind then return nil end
  local kind=m.Kind()
  if kind=="wand" then return "Wand","Interface\\Icons\\INV_Wand_01" end
  if kind~="ranged" then return nil end
  local attack=m.EquippedWeapon and m.EquippedWeapon() or (m.AbilityName and m.AbilityName())
  if attack=="Shoot Gun" then return "Gun","Interface\\Icons\\INV_Weapon_Rifle_03" end
  if attack=="Shoot Crossbow" then return "Crossbow","Interface\\Icons\\INV_Weapon_Crossbow_01" end
  if attack=="Shoot Bow" or attack=="Auto Shot" then return "Bow","Interface\\Icons\\INV_Weapon_Bow_07" end
  return "Thrown","Interface\\Icons\\INV_ThrowingKnife_03"
end

local function Skin(button)
  local active=button:CreateTexture(nil,"OVERLAY")
  active:SetPoint("BOTTOMLEFT",button,"BOTTOMLEFT",7,4)
  active:SetPoint("BOTTOMRIGHT",button,"BOTTOMRIGHT",-7,4)
  active:SetHeight(2)
  active:SetTexture("Interface\\Buttons\\WHITE8X8")
  active:SetVertexColor(1,.79,.22)
  active:Hide()
  local obj={button=button,selected=false,active=active}
  function obj:Paint()
    if self.selected then self.active:Show() else self.active:Hide() end
  end
  return obj
end
local function PressButton(parent,label,width,height,fn)
  local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
  b:SetSize(width,height)
  b:SetText("")
  local skin=Skin(b)
  local text=Font(b,label,12,C.white)
  text:SetPoint("CENTER",b,"CENTER",0,1)
  text:SetJustifyH("CENTER")
  text:SetWidth(width-14)
  b:SetScript("OnClick",function() if fn then fn() end end)
  return {button=b,skin=skin,text=text}
end
local function Tips(widget,title,detail)
  local oldEnter=widget:GetScript("OnEnter")
  local oldLeave=widget:GetScript("OnLeave")
  widget:SetScript("OnEnter",function(self)
    if oldEnter then oldEnter(self) end
    if GameTooltip then
      GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
      GameTooltip:SetText(title,1,1,1)
      local body=type(detail)=="function" and detail() or detail
      if body and body~="" then GameTooltip:AddLine(body,.83,.79,.69,true) end
      GameTooltip:Show()
    end
  end)
  widget:SetScript("OnLeave",function(self)
    if oldLeave then oldLeave(self) end
    if GameTooltip then GameTooltip:Hide() end
  end)
end

local entry={
  {"ranged","Wand","Interface\\Icons\\INV_Wand_01","Right-click ranged attack"},
  {"inventory","Bags","Interface\\Icons\\INV_Misc_Bag_08","Sorting, junk sales, repair and banking"},
  {"quest","Quests","Interface\\Icons\\INV_Misc_Note_01","Quest hotkeys and service dialogue"},
  {"range","Combat","Interface\\Icons\\Ability_Warrior_Charge","Target range and Arcane Blast tracking"},
  {"way","Map","Interface\\Icons\\INV_Misc_Map_01","Waypoints and flight masters"},
  {"tooltips","Tooltips","Interface\\Icons\\INV_Misc_Book_09","Spell explanations and badges"},
  {"action","Bars","Interface\\Icons\\Spell_Frost_FrostBolt02","Action bar keybind labels"},
  {"fishing","Professions","Interface\\Icons\\Trade_Engraving","Fishing and enchanting tools"},
  {"badges","Colors","Interface\\Icons\\INV_Misc_Gem_Pearl_05","Badge palette"},
}
local function BuildHome()
  home=CreateFrame("Frame",nil,frame)
  home:SetPoint("TOPLEFT",frame,"TOPLEFT",10,-88)
  home:SetSize(HOME_W-20,HOME_H-94)
  tiles={}
  for _,data in ipairs(entry) do
    local id,label,icon,tip=data[1],data[2],data[3],data[4]
    local b=CreateFrame("Button",nil,home)
    b:SetSize(108,96)
    local face=b:CreateTexture(nil,"BACKGROUND")
    face:SetAllPoints(b)
    face:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Background")
    face:SetVertexColor(.40,.37,.32,.98)
    local edges={}
    local function Edge(anchor1,thickness)
      local t=b:CreateTexture(nil,"BORDER")
      t:SetTexture("Interface\\Buttons\\WHITE8X8")
      t:SetVertexColor(.66,.52,.28,.90)
      if anchor1=="TOP" or anchor1=="BOTTOM" then
        t:SetPoint(anchor1.."LEFT",b,anchor1.."LEFT",1,0)
        t:SetPoint(anchor1.."RIGHT",b,anchor1.."RIGHT",-1,0)
        t:SetHeight(thickness)
      else
        t:SetPoint("TOP"..anchor1,b,"TOP"..anchor1,0,-1)
        t:SetPoint("BOTTOM"..anchor1,b,"BOTTOM"..anchor1,0,1)
        t:SetWidth(thickness)
      end
      edges[#edges+1]=t
    end
    Edge("TOP",1)
    Edge("BOTTOM",1)
    Edge("LEFT",1)
    Edge("RIGHT",1)

    local over=b:CreateTexture(nil,"HIGHLIGHT")
    over:SetAllPoints(b)
    over:SetTexture("Interface\\Buttons\\WHITE8X8")
    over:SetVertexColor(1,.77,.31,.10)

    local down=b:CreateTexture(nil,"ARTWORK")
    down:SetAllPoints(b)
    down:SetTexture("Interface\\Buttons\\WHITE8X8")
    down:SetVertexColor(.18,.13,.05,.30)
    down:Hide()

    local pict=b:CreateTexture(nil,"ARTWORK")
    pict:SetSize(46,46)
    pict:SetPoint("TOP",b,"TOP",0,-7)
    pict:SetTexture(icon)
    pict:SetTexCoord(.08,.92,.08,.92)
    local caption=Font(b,label,12,C.white)
    caption:SetPoint("TOP",b,"TOP",0,-56)
    caption:SetWidth(100)
    caption:SetJustifyH("CENTER")
    local badge=Font(b,"OFF",10,C.muted,"OUTLINE")
    badge:SetPoint("BOTTOM",b,"BOTTOM",0,9)
    badge:SetJustifyH("CENTER")
    b:SetScript("OnMouseDown",function()down:Show();pict:ClearAllPoints();pict:SetPoint("TOP",b,"TOP",0,-8)end)
    b:SetScript("OnMouseUp",function()down:Hide();pict:ClearAllPoints();pict:SetPoint("TOP",b,"TOP",0,-7)end)
    b:SetScript("OnLeave",function()down:Hide();pict:ClearAllPoints();pict:SetPoint("TOP",b,"TOP",0,-7)end)
    b:SetScript("OnClick",function() OpenPage(id) end)
    Tips(b,label,function()
      local preference=Features()[id] or "OFF"
      return tip.."\n\nConfigured: "..preference..(IsActive() and
        "\nSettings stay saved when the suite is disabled." or
        "\nMeffortSuite is disabled. Enable it to activate these preferences.")
    end)
    tiles[#tiles+1]={id=id,b=b,pict=pict,caption=caption,badge=badge,edges=edges,face=face}
  end
end
local function UpdateHome()
  if not tiles then return end
  local weaponLabel,weaponIcon=Weapon()
  local status=Features()
  local n=0
  for _,t in ipairs(tiles) do
    local visible=t.id~="ranged" or weaponLabel~=nil
    if visible then
      local c=n%3
      local r=math.floor(n/3)
      t.b:ClearAllPoints()
      t.b:SetPoint("TOPLEFT",home,"TOPLEFT",4+c*112,-3-r*101)
      t.b:Show()
      if t.id=="ranged" then t.caption:SetText(weaponLabel);t.pict:SetTexture(weaponIcon)end
      local value=status[t.id] or "OFF"
      local off=not IsActive() or value=="OFF" or (type(value)=="string" and value:match("^0/%d+$")~=nil)
      local counted=value:match("^%d+/%d+$")
      t.badge:SetText(counted and (value..(IsActive() and " enabled" or " saved")) or
        (not IsActive() and value=="ON" and "ON (saved)" or value))
      t.badge:SetTextColor(off and .56 or 1,off and .54 or .83,off and .49 or .33,1)
      for _,edge in ipairs(t.edges) do
        edge:SetVertexColor(off and .40 or .80,off and .37 or .64,off and .30 or .33,.92)
      end
      t.pict:SetDesaturated(off)
      n=n+1
    else t.b:Hide() end
  end
end

local scopes={ranged="Character settings",range="Character settings",rangeadvanced="Character settings",
  arcaneblast="Character settings | Mage only",inventory="Account settings | Exclusions: this character",
  quest="Account settings",way="Account settings",tooltips="Account settings",
  action="Account settings",fishing="Character settings | Queue saved per character",badges="Account settings"}
local function Page(key,heading)
  local p=CreateFrame("Frame",nil,scroller)
  p:SetSize(BODY_W,130)
  p.height=8
  if scopes[key] then
    local scope=Font(p,scopes[key],10,C.muted)
    scope:SetPoint("TOPLEFT",p,"TOPLEFT",11,-8)
    scope:SetWidth(BODY_W-24);scope:SetJustifyH("LEFT")
    p.height=29
  end
  p.refreshers={}
  p.label=heading
  pages[key]=p
  return p
end
local function AddRefresh(p,fn) p.refreshers[#p.refreshers+1]=fn end
local function Reserve(p,h)
  local y=-p.height
  p.height=p.height+h
  p:SetHeight(math.max(130,p.height+10))
  return y
end
local function RowFrame(p,h)
  local y=Reserve(p,h+2)
  local f=CreateFrame("Frame",nil,p)
  f:SetPoint("TOPLEFT",p,"TOPLEFT",1,y)
  f:SetSize(BODY_W-5,h)
  local line=f:CreateTexture(nil,"BACKGROUND")
  line:SetPoint("BOTTOMLEFT",f,"BOTTOMLEFT",7,0)
  line:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",-7,0)
  line:SetHeight(1)
  line:SetTexture("Interface\\Buttons\\WHITE8X8")
  line:SetVertexColor(.35,.29,.20,.65)
  return f,line
end
local function TextRow(p,message,color)
  local row=RowFrame(p,30)
  local t=Font(row,message,11,color or C.muted)
  t:SetPoint("LEFT",row,"LEFT",10,0)
  t:SetWidth(BODY_W-22)
  t:SetJustifyH("LEFT")
  return t
end
local function Toggle(p,label,detail,read,write)
  local row=RowFrame(p,37)
  local check=CreateFrame("CheckButton",nil,row,"UICheckButtonTemplate")
  check:SetSize(29,29)
  check:SetPoint("LEFT",row,"LEFT",7,0)
  local txt=Font(row,label,12,C.white)
  txt:SetPoint("LEFT",check,"RIGHT",3,0)
  txt:SetWidth(BODY_W-100);txt:SetJustifyH("LEFT")
  local state=Font(row,"OFF",10,C.muted)
  state:SetPoint("RIGHT",row,"RIGHT",-9,0)
  state:SetWidth(48);state:SetJustifyH("RIGHT")
  local function Change(value) write(value);RefreshUI() end
  check:SetScript("OnClick",function(self)Change(self:GetChecked() and true or false)end)
  local hit=CreateFrame("Button",nil,row)
  hit:SetPoint("TOPLEFT",row,"TOPLEFT",39,0)
  hit:SetPoint("BOTTOMRIGHT",row,"BOTTOMRIGHT",0,0)
  hit:RegisterForClicks("LeftButtonUp")
  hit:SetScript("OnClick",function()Change(read()~=true)end)
  AddRefresh(p,function()
    local on=read()==true
    check:SetChecked(on)
    state:SetText(on and "ON" or "OFF")
    state:SetTextColor(on and 1 or .55,on and .82 or .53,on and .28 or .49)
  end)
  Tips(check,label,detail);Tips(hit,label,detail)
  return check
end
local function Choice(p,label,options,read,write)
  local row=RowFrame(p,66)
  local l=Font(row,label,12,C.white);l:SetPoint("TOPLEFT",row,"TOPLEFT",11,-8)
  local state=Font(row,"",11,C.mint)
  state:SetPoint("TOPRIGHT",row,"TOPRIGHT",-11,-10)
  local list={}
  local w=(BODY_W-27-(#options-1)*5)/#options
  for i,o in ipairs(options) do
    local b=PressButton(row,o.label,w,29,function()write(o.value);RefreshUI()end)
    b.button:SetPoint("BOTTOMLEFT",row,"BOTTOMLEFT",9+(i-1)*(w+5),8)
    list[#list+1]={ui=b,item=o}
  end
  AddRefresh(p,function()
    local now=read()
    for _,o in ipairs(list) do
      local selected=o.item.value==now
      o.ui.skin.selected=selected
      o.ui.skin:Paint()
      o.ui.text:SetText((selected and "* " or "")..o.item.label)
      o.ui.text:SetTextColor(selected and C.gold[1] or C.white[1],selected and C.gold[2] or C.white[2],selected and C.gold[3] or C.white[3])
      if selected then state:SetText("Selected: "..o.item.label) end
    end
  end)
end
local function Stepper(p,label,lo,hi,step,read,write,unit)
  local row=RowFrame(p,52)
  local name=Font(row,label,12,C.white)
  name:SetPoint("TOPLEFT",row,"TOPLEFT",11,-7)
  local value=Font(row,"",19,C.gold)
  value:SetPoint("BOTTOMLEFT",row,"BOTTOMLEFT",12,7)
  value:SetWidth(150)
  local function change(delta)
    local n=tonumber(read()) or lo
    n=math.max(lo,math.min(hi,n+delta))
    write(n)
    RefreshUI()
  end
  local controls={ {"-5",-step*5},{"-",-step},{"+",step},{"+5",step*5}}
  for i,c in ipairs(controls) do
    local b=PressButton(row,c[1],46,29,function()change(c[2])end)
    b.button:SetPoint("RIGHT",row,"RIGHT",-(9+(4-i)*49),-8)
  end
  AddRefresh(p,function()
    local n=read() or lo
    value:SetText(tostring(n)..(unit or ""))
  end)
end
local function Link(p,label,action,right,available)
  local row=RowFrame(p,available and 55 or 35)
  local b=PressButton(row,label,BODY_W-19,29,function()
    local ready=true
    if available then ready=available() end
    if ready then action() end
    RefreshUI()
  end)
  b.button:SetPoint(available and "TOP" or "CENTER",row,available and "TOP" or "CENTER",0,available and -2 or 1)
  b.text:SetJustifyH("LEFT")
  b.text:ClearAllPoints();b.text:SetPoint("LEFT",b.button,"LEFT",12,1)
  b.text:SetWidth(BODY_W-100)
  local suffix
  if right then
    suffix=Font(b.button,right,11,C.gold)
    suffix:SetPoint("RIGHT",b.button,"RIGHT",-12,1)
  end
  if available then
    local reason=Font(row,"",10,C.muted)
    reason:SetPoint("BOTTOMLEFT",row,"BOTTOMLEFT",12,6)
    reason:SetWidth(BODY_W-28);reason:SetJustifyH("LEFT")
    AddRefresh(p,function()
      local ready,why=available()
      if ready then b.button:Enable() else b.button:Disable() end
      b.text:SetTextColor(ready and C.white[1] or C.muted[1],ready and C.white[2] or C.muted[2],ready and C.white[3] or C.muted[3])
      reason:SetText(why or (ready and "Ready" or "Unavailable"))
    end)
  end
  return b
end
local function Input(p,label,get,apply,buttonName,maxLetters)
  local row=RowFrame(p,96)
  local l=Font(row,label,12,C.white)
  l:SetPoint("TOPLEFT",row,"TOPLEFT",11,-9)
  l:SetWidth(BODY_W-24);l:SetJustifyH("LEFT")
  local field=CreateFrame("EditBox",nil,row,"InputBoxTemplate")
  field:SetPoint("TOPLEFT",row,"TOPLEFT",17,-34)
  field:SetSize(240,26)
  field:SetAutoFocus(false)
  field:SetMaxLetters(maxLetters or 60)
  Tips(field,label,"Use Enter or the save button to apply. Esc discards this draft. Maximum "..tostring(maxLetters or 60).." characters.")
  local feedback=Font(row,"Saved",10,C.muted)
  feedback:SetPoint("BOTTOMLEFT",row,"BOTTOMLEFT",12,9)
  feedback:SetWidth(BODY_W-28);feedback:SetJustifyH("LEFT")
  local dirty,loading=false,false
  local function Restore(message)
    loading=true;field:SetText(tostring(get() or ""));loading=false;dirty=false
    feedback:SetText(message or "Saved")
  end
  local function Save()
    local ok,result,why=pcall(apply,field:GetText())
    if not ok or result==false then
      feedback:SetText(why or "Could not save. Check the value and try again.")
      return
    end
    Restore("Saved");field:ClearFocus();RefreshUI()
  end
  field:SetScript("OnTextChanged",function()
    if loading then return end
    dirty=field:GetText()~=tostring(get() or "")
    feedback:SetText(dirty and ("Unsaved - Enter or "..(buttonName or "Apply").."; Esc discards") or "Saved")
    if frame and frame:IsShown() then RefreshUI() end
  end)
  field:SetScript("OnEnterPressed",Save)
  field:SetScript("OnEscapePressed",function(self)Restore("Changes discarded");self:ClearFocus();RefreshUI()end)
  local btn=PressButton(row,buttonName or "Apply",105,30,Save)
  btn.button:SetPoint("TOPRIGHT",row,"TOPRIGHT",-10,-32)
  inputDrafts[#inputDrafts+1]=function()return dirty end
  AddRefresh(p,function()
    -- Never replace an unapplied draft on blur, navigation, or status refresh.
    if not dirty and not field:HasFocus() then Restore() end
    if dirty then btn.button:Enable() else btn.button:Disable() end
  end)
  return field
end
local function ColorHex(s)
  s=tostring(s or "ffffff"):gsub("#","")
  if not s:match("^%x%x%x%x%x%x$") then s="ffffff" end
  return {tonumber(s:sub(1,2),16)/255,tonumber(s:sub(3,4),16)/255,tonumber(s:sub(5,6),16)/255,1}
end
local function Swatch(p,title,category)
  local row=RowFrame(p,40)
  local preview=row:CreateTexture(nil,"ARTWORK")
  preview:SetPoint("TOPLEFT",row,"TOPLEFT",11,-7)
  preview:SetPoint("BOTTOMLEFT",row,"BOTTOMLEFT",11,7)
  preview:SetWidth(150)
  preview:SetTexture("Interface\\AddOns\\MeffortSuite\\Textures\\SoftBadge.tga")
  local text=Font(row,title,11,C.white)
  text:SetPoint("CENTER",preview,"CENTER",0,0)
  text:SetWidth(140);text:SetJustifyH("CENTER")
  local function chip(offset,kind)
    local b=CreateFrame("Button",nil,row,"UIPanelButtonTemplate")
    b:SetSize(66,25)
    b:SetPoint("RIGHT",row,"RIGHT",offset,0)
    local sample=b:CreateTexture(nil,"OVERLAY")
    sample:SetPoint("TOPLEFT",b,"TOPLEFT",5,-5)
    sample:SetPoint("BOTTOMRIGHT",b,"BOTTOMRIGHT",-5,5)
    b:SetScript("OnClick",function()
      if MeffortSuiteBadgeThemeRead and MeffortSuiteBadgeThemeWrite and MeffortSuiteShowColorPicker then
        MeffortSuiteShowColorPicker(MeffortSuiteBadgeThemeRead(category,kind),function(hex)
          MeffortSuiteBadgeThemeWrite(category,kind,hex);RefreshUI()
        end)
      end
    end)
    Tips(b,title..(kind=="background" and ": background" or ": text"),"Choose a color. The preview shows the two colors together. Esc in the color picker cancels.")
    AddRefresh(p,function()
      if MeffortSuiteBadgeThemeRead then RGB(sample,ColorHex(MeffortSuiteBadgeThemeRead(category,kind))) end
    end)
  end
  chip(-85,"background");chip(-9,"text")
  AddRefresh(p,function()
    if not MeffortSuiteBadgeThemeRead then return end
    local bg=ColorHex(MeffortSuiteBadgeThemeRead(category,"background"))
    local fg=ColorHex(MeffortSuiteBadgeThemeRead(category,"text"))
    preview:SetVertexColor(bg[1],bg[2],bg[3],.9)
    text:SetTextColor(fg[1],fg[2],fg[3],1)
    text:SetFont(FONT,11,DB().badgeTextOutline==true and "OUTLINE" or "")
    text:SetShadowColor(0,0,0,DB().badgeTextShadow~=false and .95 or 0)
    text:SetShadowOffset(DB().badgeTextShadow~=false and 1 or 0,DB().badgeTextShadow~=false and -1 or 0)
  end)
end
local function ApplyBar()
  if MeffortSuiteActionText and MeffortSuiteActionText.ApplyAll then MeffortSuiteActionText.ApplyAll() end
end
local function Build(key)
  local m=MeffortSuiteTargetDistance
  local fishing=MeffortSuiteFishing
  local ranged=MeffortSuiteRanged
  local p
  if key=="range" then
    p=Page(key,"Combat")
    Toggle(p,"Out-of-range dot","Only appears when the target is definitely beyond range.",function()return m and m.Enabled()end,function(v)if m then m.SetEnabled(v)end end)
    Stepper(p,"Warning distance",1,100,1,function()return Range().rangeYards or 30 end,function(n)if m then m.SetYards(n)end end," yd")
    Stepper(p,"Dot size",10,26,1,function()return Range().fontSize or 19 end,function(n)if m then m.SetSize(n)end end," px")
    Toggle(p,"Lock dot position","Turn off to drag the marker near your character.",function()return Range().locked~=false end,function(v)if m then m.SetLocked(v)end end)
    Link(p,"Reset position",function()if m then m.Reset()end end,"RESET")
    Link(p,"Advanced spell detection",function()OpenPage("rangeadvanced")end," > ")
    if MeffortSuiteArcaneBlast and MeffortSuiteArcaneBlast.IsMage() then
      Link(p,"Arcane Blast stacks / timer",function()OpenPage("arcaneblast")end," > ")
    end
  elseif key=="rangeadvanced" then
    p=Page(key,"Range: Advanced")
    TextRow(p,"Optional spell override; leave blank for automatic checks.")
    Input(p,"Spell name (exact spellbook text)",function()return Range().spellName or "" end,function(s)if m then m.SetSpell(s)end end,"Use spell")
    Link(p,"Use automatic range checks",function()if m then m.SetSpell("auto")end end,"AUTO")
    TextRow(p,"Unknown distances intentionally show no warning.")
  elseif key=="arcaneblast" then
    p=Page(key,"Arcane Blast")
    local ab=MeffortSuiteArcaneBlast
    if not ab or not ab.IsMage or not ab.IsMage() then
      TextRow(p,"Arcane Blast tracking is available to Mages.")
      return p
    end
    Toggle(p,"Arcane Blast on Tracked Buffs","Mage-only stack and timer overlay on Blizzard tracked buff icons.",function()return ab and ab.GetOption("enabled")end,function(v)if ab then ab.SetOption("enabled",v)end end)
    Toggle(p,"Show stack count","Display 1-4 in the lower-right corner of the icon.",function()return ab and ab.GetOption("stacks")end,function(v)if ab then ab.SetOption("stacks",v)end end)
    Toggle(p,"Show remaining time","Seconds until the 18-second Arcane Blast effect expires.",function()return ab and ab.GetOption("timer")end,function(v)if ab then ab.SetOption("timer",v)end end)
    Toggle(p,"Show timer wheel","Optional swipe shading over the tracked buff icon.",function()return ab and ab.GetOption("wheel")end,function(v)if ab then ab.SetOption("wheel",v)end end)
    TextRow(p,"Add Arcane Blast to Blizzard Tracked Buffs first.")
    TextRow(p,"Combat tracking uses successful casts; syncs afterward.")
  elseif key=="ranged" then
    p=Page(key,"Ranged attack")
    local message=TextRow(p,"")
    AddRefresh(p,function()message:SetText("Detected: "..tostring(ranged and ranged.AbilityName() or "Unavailable"))end)
    local readiness=TextRow(p,"")
    AddRefresh(p,function()
      local available,why=Capability(ranged)
      local pending=ranged and ranged.Pending and ranged.Pending()
      readiness:SetText(pending and "Right-click changes will apply after combat." or
        (available==false and (why or "Right-click controls unavailable; normal mouse controls retained.") or "Right-click behavior is saved for this character."))
    end)
    Choice(p,"Right-click behavior",{{label="Off",value="off"},{label="Right click",value="right"},{label="Shift + click",value="shift"}},function()return ranged and ranged.Mode() or "off"end,function(v)if ranged then ranged.SetMode(v)end end)
    local owner=TextRow(p,"")
    AddRefresh(p,function()owner:SetText("Macro owner: "..tostring(MeffortRightClickShared and MeffortRightClickShared.Owner() or "None"))end)
    Link(p,"Clean up old duplicate macros",function()
      if MeffortRightClickShared then
        local count,err=MeffortRightClickShared.CleanupOnly()
        if MeffortSuite and MeffortSuite.Message then
          MeffortSuite.Message(count and ("Removed "..tostring(count).." duplicates.") or ("Macro cleanup: "..tostring(err)))
        end
      end
      if ranged then ranged.Refresh()end
    end,"CLEAN")
    TextRow(p,"Standalone MeffortWand takes priority when enabled.")
  elseif key=="fishing" then
    p=Page(key,"Professions")
    Toggle(p,"Right-click to fish","Works only with a fishing pole equipped.",function()return fishing and fishing.Enabled()end,function(v)if fishing then fishing.SetEnabled(v)end end)
    Choice(p,"Casting gesture",{{label="Single click",value="single"},{label="Double click",value="double"}},function()return fishing and fishing.Mode() or "double"end,function(v)if fishing then fishing.SetMode(v)end end)
    TextRow(p,"Single click blocks camera turning. Double click recommended.",C.gold)
    local equip=TextRow(p,"")
    AddRefresh(p,function()
      local available,why=Capability(fishing)
      equip:SetText(available==false and (why or "This client cannot safely enable right-click fishing.") or
        (fishing and fishing.IsPoleEquipped() and "Fishing pole equipped" or "Equip a fishing pole to use this feature"))
    end)
    TextRow(p,"ENCHANTING",C.gold)
    Toggle(p,"Enchant queue","Queue repeated enchants on a selected item. Each enchant needs a real keypress or click.",function()
      return MeffortSuiteEnchantQueue and ((MeffortSuiteEnchantQueue.Configured and MeffortSuiteEnchantQueue.Configured()) or (not MeffortSuiteEnchantQueue.Configured and MeffortSuiteEnchantQueue.Enabled())) or false
    end,function(v)if MeffortSuiteEnchantQueue then MeffortSuiteEnchantQueue.SetEnabled(v) end end)
    Link(p,"Show Enchant Queue (requires Enchanting)",function()
      if MeffortSuiteEnchantQueue and MeffortSuiteEnchantQueue.Open and MeffortSuiteEnchantQueue.Open() then
        if frame then frame:Hide() end
      end
    end,"OPEN",function()
      local eq=MeffortSuiteEnchantQueue
      if not eq then return false,"Enchant Queue is unavailable." end
      if eq.CanOpen then return eq.CanOpen() end
      return IsActive(),IsActive() and "Open Enchanting first." or "Enable MeffortSuite first."
    end)
    local count=TextRow(p,"")
    AddRefresh(p,function()
      count:SetText(tostring(MeffortSuiteEnchantQueue and MeffortSuiteEnchantQueue.QueueCount() or 0).." queued enchants  |  /msuite enchant")
    end)
    TextRow(p,"Open Enchanting, then click the MeffortSuite tab beside it.")
    TextRow(p,"Queue window closes when you close Enchanting.")
    TextRow(p,"Use Next once per enchant; confirm replacements similarly.")
  elseif key=="inventory" then
    p=Page(key,"Bags")
    Toggle(p,"Auto-sort","Sort bags when opened.",function()return DB().autoSortBags~=false end,function(v)DB().autoSortBags=v;if MeffortSuiteInventory then MeffortSuiteInventory.RefreshBags()end end)
    Toggle(p,"Sell junk","Automatically sell grey items at a merchant.",function()return DB().autoSellJunk~=false end,function(v)DB().autoSellJunk=v end)
    Toggle(p,"Auto-repair","Automatically repair equipment at merchants.",function()return DB().autoRepair~=false end,function(v)DB().autoRepair=v end)
    Toggle(p,"Auto-bank crafting","Deposit crafting reagents when your personal bank opens.",function()return MeffortSuiteBank and MeffortSuiteBank.Enabled() or false end,function(v)if MeffortSuiteBank then MeffortSuiteBank.SetEnabled(v)end end)
    Toggle(p,"Auto-sort personal bank","Sort your personal-bank tabs when the bank opens and after deposits.",function()return MeffortSuiteBank and MeffortSuiteBank.SortEnabled() or false end,function(v)if MeffortSuiteBank then MeffortSuiteBank.SetSortEnabled(v)end end)
    Input(p,"Keep in bags (comma-separated item names or IDs)",function()return MeffortSuiteBank and MeffortSuiteBank.Exclusions() or "" end,function(value)if MeffortSuiteBank then return MeffortSuiteBank.SetExclusions(value)end end,"Save list",250)
    TextRow(p,"Example: Light Feather, Soul Shard, 12345")
    TextRow(p,"Exact names or IDs; empty uses native deposit.")
    TextRow(p,"Saving new exclusions stops an active selective transfer.")
    Toggle(p,"Skip Orgrimmar banker dialogue","Automatically select Bank for Soran, Karus and Koma. Hold Shift for their dialogue.",function()return MeffortSuiteBank and MeffortSuiteBank.GossipEnabled() or false end,function(v)if MeffortSuiteBank then MeffortSuiteBank.SetGossipEnabled(v)end end)
    Link(p,"Deposit reagents now",function()if MeffortSuiteBank then MeffortSuiteBank.DepositNow(false)end end,"BANK",function()
      local bank=MeffortSuiteBank
      if not bank then return false,"Banking is unavailable." end
      if bank.CanDepositStatus then return bank.CanDepositStatus() end
      return false,"Open your personal bank to deposit reagents."
    end)
    Link(p,"Retry merchant actions",function()if MeffortSuiteInventory and MeffortSuiteInventory.VendorStatus then MeffortSuiteInventory.VendorStatus(true)end end,"RETRY")
  elseif key=="quest" then
    p=Page(key,"Quests")
    Toggle(p,"Quest dialog hotkeys","Space prefers available quests, then ready turn-ins, then unfinished quests. In quest dialogue it accepts, continues or completes. 1-9 keep menu order.",function()return DB().questSpace~=false end,function(v)DB().questSpace=v;if MeffortSuiteQuestSpace then MeffortSuiteQuestSpace.Refresh()end end)
    local readiness=TextRow(p,"")
    AddRefresh(p,function()
      local q=MeffortSuiteQuestSpace
      local available,why=Capability(q)
      readiness:SetText(available==false and (why or "Safe quest hotkeys are unavailable in this client.") or "Quest hotkeys are suspended during combat.")
    end)
    TextRow(p,"SPACE   Available > Ready to turn in > Unfinished",C.gold)
    TextRow(p,"1-9   Menu order   |   * marks the Spacebar choice")
    Toggle(p,"Skip single-option service dialogue","Open a known shop or service when it is the only choice and no quests are offered. Hold Shift to see the dialogue.",
      function()return DB().autoOpenSingleService~=false end,
      function(value)if MeffortSuiteGossipServices then MeffortSuiteGossipServices.SetEnabled(value)else DB().autoOpenSingleService=value end end)
    TextRow(p,"Hold Shift to keep normal NPC dialogue.")
    TextRow(p,"Unknown, paid and confirmation choices stay manual.")
  elseif key=="way" then
    p=Page(key,"Map")
    Toggle(p,"Suite waypoint arrow","Show the Suite arrow for map pins, including pins created with /way.",function()return DB().wayEnabled~=false end,function(v)DB().wayEnabled=v;if MeffortSuiteWay then MeffortSuiteWay.Refresh()end end)
    TextRow(p,"/way 49.4 12.9 sets a pin on the open map, or your current zone.")
    TextRow(p,"/way Hillsbrad Foothills 87.3 49.6 sets a pin in a named zone.")
    TextRow(p,"Use /msuite way 49.4 12.9 if another addon provides /way.")
    Toggle(p,"Skip flight master dialogue","Open the flight map when talking to any flight master. Hold Shift for normal dialogue. Never selects a destination.",function()return MeffortSuiteFlightMasters and MeffortSuiteFlightMasters.Enabled() or false end,function(v)if MeffortSuiteFlightMasters then MeffortSuiteFlightMasters.SetEnabled(v)end end)
    Choice(p,"Arrow style",{{label="Teal",value="teal"},{label="Treecko",value="treecko"}},function()return DB().wayTheme or "teal"end,function(v)if MeffortSuiteWay then MeffortSuiteWay.SetTheme(v,true)end end)
  elseif key=="tooltips" then
    p=Page(key,"Tooltips")
    Toggle(p,"Simple spell explanations","Replace complex descriptions with simplified tooltips.",function()return DB().enabled==true end,function(v)if MeffortSuiteSetTooltipsEnabled then MeffortSuiteSetTooltipsEnabled(v)end end)
    Choice(p,"Description display",{{label="Replace",value="replace"},{label="Compare",value="compare"}},function()return MeffortSuiteGetTooltipMode and MeffortSuiteGetTooltipMode() or "replace"end,function(v)if MeffortSuiteSetTooltipMode then MeffortSuiteSetTooltipMode(v)end end)
    Toggle(p,"Highlight headers & costs","Higher contrast for spell information.",function()return DB().style~=false end,function(v)DB().style=v end)
    Toggle(p,"Spell badges","Show cast time, range and resource tags.",function()return DB().badges~=false end,function(v)DB().badges=v end)
    Toggle(p,"New-rank reminder","Display a notice when new spell ranks are available.",function()return DB().rankHint~=false end,function(v)DB().rankHint=v end)
    Link(p,"Customize badge colors",function()OpenPage("badges")end," > ")
    TextRow(p,"Badges require Highlight headers & costs.")
    TextRow(p,"Simplified spell text currently uses English data.")
  elseif key=="badges" then
    p=Page(key,"Colors")
    TextRow(p,"Preview your palette; native warning colors stay unchanged.")
    Toggle(p,"Text outline","Improve readability against bright badges.",function()return DB().badgeTextOutline==true end,function(v)DB().badgeTextOutline=v end)
    Toggle(p,"Text shadow","Increase contrast on badge text.",function()return DB().badgeTextShadow~=false end,function(v)DB().badgeTextShadow=v end)
    TextRow(p,"PREVIEW                         BACKGROUND       TEXT",C.gold)
    local palette={{"instant","Instant"},{"channel","Channel"},{"cast","Cast"},{"cooldown","Cooldown"},
      {"range","Range"},{"Mana","Mana"},{"Rage","Rage"},{"Energy","Energy"},
      {"Focus","Focus"},{"Health","Health"},{"Combo","Combo"},{"Reagent","Reagent"},{"Requirement","Requirement"}}
    for _,pair in ipairs(palette) do Swatch(p,pair[2],pair[1])end
    Link(p,"Restore default colors",function()if MeffortSuiteBadgeThemeReset then MeffortSuiteBadgeThemeReset()end end,"RESET")
  elseif key=="action" then
    p=Page(key,"Bars")
    Toggle(p,"Custom keybind labels","Use Suite hotkey labels on action bars.",function()return Action().enabled end,function(v)Action().enabled=v;ApplyBar()end)
    Stepper(p,"Text size",8,24,1,function()return Action().size end,function(n)Action().size=n;ApplyBar()end," px")
    Stepper(p,"Horizontal offset",-22,22,1,function()return Action().x end,function(n)Action().x=n;Action().position="custom";ApplyBar()end,"")
    Stepper(p,"Vertical offset",-22,22,1,function()return Action().y end,function(n)Action().y=n;Action().position="custom";ApplyBar()end,"")
    Toggle(p,"Text outline","Improve contrast on icons.",function()return Action().outline end,function(v)Action().outline=v;ApplyBar()end)
    Toggle(p,"Text shadow","Add a subtle shadow behind hotkeys.",function()return Action().shadow end,function(v)Action().shadow=v;ApplyBar()end)
    Link(p,"Pick text color",function()
      if MeffortSuiteShowColorPicker then MeffortSuiteShowColorPicker(Action().hex,function(hex)Action().hex=hex;ApplyBar();RefreshUI()end)end
    end,"COLOR")
    Link(p,"Open live position preview",function()
      if MeffortSuiteActionText and MeffortSuiteActionText.OpenPreview then
        frame:Hide();MeffortSuiteActionText.OpenPreview()
      end
    end,"EDIT")
  elseif key=="about" then
    p=Page(key,"About")
    TextRow(p,"MeffortSuite "..tostring(MeffortSuite and MeffortSuite.Version or "1.1.1"),C.gold)
    TextRow(p,"Toggles save immediately. Text fields use Enter / Apply.")
    TextRow(p,"Unapplied text stays here; Esc in its field discards it.")
    TextRow(p,"/msuite   Open feature launcher")
    TextRow(p,"/msuite diagnostics   Module status and recent errors")
    TextRow(p,"/msuite distance   Range command")
    TextRow(p,"/msuite arcane   Mage Tracked Buffs settings")
    TextRow(p,"/msuite fishing   Fishing command")
    TextRow(p,"/msuite enchant   Open enchant queue")
    TextRow(p,"/msuite bank now   Deposit reagents")
    TextRow(p,"/msuite bank sort on/off   Bank auto-sort")
    TextRow(p,"/msuite bank gossip on/off   Bank dialogue")
    TextRow(p,"/msuite flight on/off   Flight master dialogue")
  else return nil end
  return p
end
local names={overview="MeffortSuite",ranged="Ranged attack",range="Combat",arcaneblast="Arcane Blast",rangeadvanced="Advanced range",inventory="Bags",quest="Quests",way="Map",tooltips="Tooltips",action="Bars",fishing="Professions",badges="Colors",about="About"}
local aliases={home="overview",combat="range",interface="tooltips",appearance="tooltips",convenience="inventory",distance="range",arcane="arcaneblast",wand="ranged",shoot="ranged",throw="ranged",bags="inventory",quests="quest",dialogue="quest",services="quest",map="way",bars="action",colors="badges",professions="fishing",profession="fishing",enchants="fishing",enchanting="fishing"}
local function HasDrafts()
  for _,dirty in ipairs(inputDrafts) do if dirty() then return true end end
  return false
end
local function FitToScreen()
  if not frame or not frame.SetScale or not UIParent or not UIParent.GetWidth or not UIParent.GetHeight then return end
  local w,h=UIParent:GetWidth(),UIParent:GetHeight()
  if type(w)~="number" or type(h)~="number" or w<=0 or h<=0 then return end
  frame:SetScale(math.max(.1,math.min(1,(w-24)/frame:GetWidth(),(h-24)/frame:GetHeight())))
end
RefreshUI=function()
  if not frame then return end
  local on=IsActive()
  masterText:SetText(on and "Suite ON" or "Suite OFF")
  masterText:SetTextColor(on and C.mint[1] or C.red[1],on and C.mint[2] or C.red[2],on and C.mint[3] or C.red[3])
  masterButton.skin.selected=on;masterButton.skin:Paint()
  local ranged=MeffortSuiteRanged
  local pending=ranged and ranged.Pending and ranged.Pending() and
    type(InCombatLockdown)=="function" and InCombatLockdown()
  statusTitle:SetText(pending and (on and "MeffortSuite enabled - input changes pending" or
    "MeffortSuite disabled - input changes pending") or
    (on and "MeffortSuite enabled" or "MeffortSuite disabled - preferences retained"))
  statusTitle:SetTextColor(on and C.gold[1] or C.muted[1],on and C.gold[2] or C.muted[2],on and C.gold[3] or C.muted[3])
  statusDetail:SetText(pending and "Right-click changes apply after combat; preferences saved." or
    HasDrafts() and "Unsaved text - Enter / Apply saves; Esc discards." or
    (on and "Badges show saved preferences; tools depend on context." or "Enable the suite above to use your saved preferences."))
  UpdateHome()
  local page=pages[activePage]
  if page then for _,fn in ipairs(page.refreshers) do fn()end end
end
OpenPage=function(id,goingBack,scroll)
  if not frame then return end
  id=aliases[id] or id or "overview"
  if id~="overview" and not names[id] then id="overview" end
  local same=id==activePage
  if not same and not goingBack then
    if id=="overview" then history={}
    else history[#history+1]={id=activePage,scroll=scroller:GetVerticalScroll() or 0} end
  end
  local isHome=id=="overview"
  activePage=id
  if isHome then
    history={}
    frame:SetSize(HOME_W,HOME_H)
    headerTitle:SetText("MeffortSuite")
    headerTitle:ClearAllPoints();headerTitle:SetPoint("TOPLEFT",frame,"TOPLEFT",53,-16)
    headerTitle:SetWidth(144)
    logo:Show();infoButton:Show();backButton:Hide()
    scroller:Hide();home:Show()
  else
    local page=pages[id] or Build(id)
    if not page then return OpenPage("overview") end
    frame:SetSize(DETAIL_W,math.max(180,math.min(MAX_DETAIL_H,page.height+108)))
    headerTitle:SetText(names[id] or "Settings")
    headerTitle:ClearAllPoints();headerTitle:SetPoint("TOPLEFT",frame,"TOPLEFT",83,-16)
    headerTitle:SetWidth(DETAIL_W-225)
    logo:Hide();infoButton:Hide();backButton:Show()
    home:Hide();scroller:Show()
    for key,v in pairs(pages) do if key~=id then v:Hide()end end
    scroller:SetScrollChild(page);page:Show()
    if scroll then scroller:SetVerticalScroll(scroll)
    elseif not same then scroller:SetVerticalScroll(0) end
  end
  FitToScreen();RefreshUI()
end
local function CreatePanel()
  if frame then return frame end
  local backdropTemplate=BackdropTemplateMixin and "BackdropTemplate" or nil
  frame=CreateFrame("Frame","MeffortSuiteSettingsV2",UIParent,backdropTemplate)
  frame:SetSize(HOME_W,HOME_H)
  frame:SetPoint("CENTER",UIParent,"CENTER",0,0)
  frame:SetFrameStrata("DIALOG")
  frame:SetClampedToScreen(true)
  frame:EnableMouse(true)
  frame:SetMovable(true)
  frame:RegisterForDrag("LeftButton")
  frame:SetScript("OnDragStart",function(self)self:StartMoving()end)
  frame:SetScript("OnDragStop",function(self)self:StopMovingOrSizing()end)
  WoWBackdrop(frame)
  local hdr=frame:CreateTexture(nil,"ARTWORK")
  hdr:SetPoint("TOPLEFT",frame,"TOPLEFT",11,-7)
  hdr:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-11,-7)
  hdr:SetHeight(40)
  hdr:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Background")
  hdr:SetVertexColor(.55,.42,.21,.89)
  local line=frame:CreateTexture(nil,"ARTWORK")
  line:SetPoint("TOPLEFT",frame,"TOPLEFT",12,-47)
  line:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-12,-47)
  line:SetHeight(1)
  line:SetTexture("Interface\\Buttons\\WHITE8X8")
  line:SetVertexColor(.83,.67,.32,1)
  logo=frame:CreateTexture(nil,"ARTWORK")
  logo:SetTexture("Interface\\AddOns\\MeffortSuite\\Textures\\MeffortSuiteIcon.tga")
  logo:SetPoint("TOPLEFT",frame,"TOPLEFT",15,-12)
  logo:SetSize(29,29)
  headerTitle=Font(frame,"MeffortSuite",16,C.gold)
  headerTitle:SetPoint("TOPLEFT",frame,"TOPLEFT",53,-16)
  local close=CreateFrame("Button",nil,frame,"UIPanelCloseButton")
  close:SetSize(29,29)
  close:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-10,-11)
  close:SetScript("OnClick",function()frame:Hide()end)
  masterButton=PressButton(frame,"",86,26,function()
    if MeffortSuiteSetMasterEnabled then MeffortSuiteSetMasterEnabled(not IsActive())end
    RefreshUI()
  end)
  masterButton.button:SetPoint("RIGHT",close,"LEFT",-1,0)
  masterText=masterButton.text
  Tips(masterButton.button,"Enable MeffortSuite","Turn the whole suite on or off. Individual preferences stay saved. During combat, protected input changes may wait until combat ends.")
  statusTitle=Font(frame,"",11,C.gold)
  statusTitle:SetPoint("TOPLEFT",frame,"TOPLEFT",16,-55)
  statusTitle:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-16,-55)
  statusTitle:SetJustifyH("LEFT")
  statusDetail=Font(frame,"",10,C.muted)
  statusDetail:SetPoint("TOPLEFT",frame,"TOPLEFT",16,-71)
  statusDetail:SetPoint("TOPRIGHT",frame,"TOPRIGHT",-16,-71)
  statusDetail:SetJustifyH("LEFT")
  infoButton=PressButton(frame,"?",24,24,function()OpenPage("about")end).button
  infoButton:SetPoint("RIGHT",masterButton.button,"LEFT",-2,0)
  backButton=PressButton(frame,"< Back",60,25,function()
    local previous=table.remove(history)
    OpenPage(previous and previous.id or "overview",true,previous and previous.scroll or 0)
  end).button
  backButton:SetPoint("TOPLEFT",frame,"TOPLEFT",11,-11)
  if frame.GetFrameLevel and backButton.SetFrameLevel then backButton:SetFrameLevel(frame:GetFrameLevel()+9)end
  scroller=CreateFrame("ScrollFrame",nil,frame,"UIPanelScrollFrameTemplate")
  scroller:SetPoint("TOPLEFT",frame,"TOPLEFT",14,-91)
  scroller:SetPoint("BOTTOMRIGHT",frame,"BOTTOMRIGHT",-29,16)
  scroller:Hide()
  BuildHome()
  if type(UISpecialFrames)=="table" then
    local found=false
    for _,v in ipairs(UISpecialFrames) do if v=="MeffortSuiteSettingsV2" then found=true;break end end
    if not found then table.insert(UISpecialFrames,"MeffortSuiteSettingsV2")end
  end
  local evt=CreateFrame("Frame",nil,frame)
  evt:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
  evt:RegisterEvent("SPELLS_CHANGED")
  for _,event in ipairs({"PLAYER_REGEN_ENABLED","PLAYER_REGEN_DISABLED","BANKFRAME_OPENED","BANKFRAME_CLOSED","TRADE_SKILL_SHOW","TRADE_SKILL_CLOSE","UI_SCALE_CHANGED","DISPLAY_SIZE_CHANGED"}) do
    pcall(evt.RegisterEvent,evt,event)
  end
  local refreshQueued=false
  evt:SetScript("OnEvent",function()
    if frame and frame:IsShown() then
      FitToScreen();RefreshUI()
      -- Modules may receive the same event after the settings frame does.
      if not refreshQueued and C_Timer and C_Timer.After then
        refreshQueued=true
        C_Timer.After(0,function()
          refreshQueued=false
          if frame and frame:IsShown() then FitToScreen();RefreshUI() end
        end)
      end
    end
  end)
  frame:Hide()
  return frame
end
function UI.Open(id)
  local win=CreatePanel()
  if not win:IsShown() then history={};activePage="overview" end
  if MeffortSuiteActionText and MeffortSuiteActionText.HidePanel then MeffortSuiteActionText.HidePanel() end
  win:Show()
  OpenPage(id or "overview")
end
function UI.Hide()if frame then frame:Hide()end end
function UI.Refresh()RefreshUI()end
function UI.HasUnsavedChanges()return HasDrafts()end
function UI.CurrentPage()return activePage end
function MeffortSuiteOpenSettings(page)UI.Open(page or "overview")end
function MeffortSuiteShowMainSettings()UI.Open(activePage=="action" and "action" or "overview")end
function MeffortSuiteHideMainSettings()UI.Hide()end
