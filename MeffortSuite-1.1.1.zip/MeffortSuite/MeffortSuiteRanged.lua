local module = {}
MeffortSuiteRanged = module
local frame = CreateFrame("Frame")
local controller, attackButton
local activeDriver, queued, ownMouselook = nil, false, false
local macroRefreshPending = false
local playerClass, ability
local attacksBySubclass = {
    [2]="Shoot Bow", [3]="Shoot Gun", [16]="Throw", [18]="Shoot Crossbow",
}

local function AttackFromSubtype(classID, subclassID, subtype)
    if classID==2 and attacksBySubclass[subclassID] then
        return attacksBySubclass[subclassID]
    end
    if classID~=nil and classID~=2 then return nil end
    if type(subtype)~="string" then return nil end
    subtype=subtype:lower()
    if subtype:find("crossbow",1,true) then return "Shoot Crossbow" end
    if subtype:find("bow",1,true) then return "Shoot Bow" end
    if subtype:find("gun",1,true) then return "Shoot Gun" end
    if subtype:find("thrown",1,true) or subtype:find("throwing",1,true) then return "Throw" end
end

local function EquippedAttack()
    local item
    if type(GetInventoryItemID)=="function" then
        local ok,id=pcall(GetInventoryItemID,"player",18)
        if ok and type(id)=="number" and id>0 then item=id end
    end
    if not item and type(GetInventoryItemLink)=="function" then
        local ok,link=pcall(GetInventoryItemLink,"player",18)
        if ok and type(link)=="string" and link~="" then item=link end
    end
    if not item then return nil end

    local function Instant(get)
        if type(get)~="function" then return nil end
        -- GetItemInfoInstant returns classID in slot 6 and subclassID in slot 7.
        local ok,_,_,subtype,_,_,classID,subclassID=pcall(get,item)
        if ok then return AttackFromSubtype(classID,subclassID,subtype) end
    end
    local attack=Instant(C_Item and C_Item.GetItemInfoInstant)
        or Instant(GetItemInfoInstant)
    if attack then return attack end

    local function Cached(get)
        if type(get)~="function" then return nil end
        local ok,_,_,_,_,_,_,subtype,_,_,_,_,classID,subclassID=pcall(get,item)
        if ok then return AttackFromSubtype(classID,subclassID,subtype) end
    end
    return Cached(C_Item and C_Item.GetItemInfo) or Cached(GetItemInfo)
end

local profiles = {
    WARLOCK = {spell="Shoot", kind="wand", default="right"},
    PRIEST = {spell="Shoot", kind="wand", default="right"},
    MAGE = {spell="Shoot", kind="wand", default="right"},
    HUNTER = {spell="Auto Shot", kind="ranged", default="off"},
    WARRIOR = {spell="Throw", kind="ranged", default="off"},
    ROGUE = {spell="Throw", kind="ranged", default="off"},
}

local function Profile()
    if not playerClass and type(UnitClass)=="function" then
        local _, class=UnitClass("player")
        playerClass=class
    end
    return profiles[playerClass]
end

function module.AbilityName()
    local profile=Profile()
    if not profile then return nil end
    if profile.spell=="Throw" then return EquippedAttack() or "Throw" end
    return profile.spell
end

function module.EquippedWeapon()
    local profile=Profile()
    if not profile or profile.kind~="ranged" then return nil end
    return EquippedAttack() or profile.spell
end

function module.Kind()
    local profile=Profile()
    return profile and profile.kind or nil
end

local function DB()
    if type(MeffortSuiteCharDB)~="table" then MeffortSuiteCharDB={} end
    local profile=Profile()
    if MeffortSuiteCharDB.rangedMode==nil then
        MeffortSuiteCharDB.rangedMode=profile and profile.default or "off"
    end
    if MeffortSuiteCharDB.rangedMode~="right" and MeffortSuiteCharDB.rangedMode~="shift" then
        MeffortSuiteCharDB.rangedMode="off"
    end
    MeffortSuiteCharDB.rangedStartOnly=false
    return MeffortSuiteCharDB
end

function module.Mode()
    return DB().rangedMode
end

local function Message(msg)
    if MeffortSuite and MeffortSuite.Message then MeffortSuite.Message(msg) end
end

function module.StartOnly()
    return DB().rangedStartOnly
end

function module.SetStartOnly(enabled)
    if module.Kind()~="wand" then
        Message("Start-only mode is available for wands.")
        return false
    end
    DB().rangedStartOnly=false
    Message("Start-only right-click is not supported on Forever; normal controls remain active.")
    return false
end

local function StopMouselook()
    if ownMouselook then
        ownMouselook=false
        pcall(MouselookStop)
    end
    frame:SetScript("OnUpdate",nil)
end
local function CheckMouselookRelease()
    if ownMouselook and not IsMouseButtonDown("RightButton") then StopMouselook() end
end

-- Share one owned character macro; never modify macros during combat.
local function SharedMacro(spell)
    if not MeffortRightClickShared then return nil,"shared macro manager unavailable" end
    return MeffortRightClickShared.Acquire(spell)
end

local function ClearDriver()
    if activeDriver then
        pcall(UnregisterStateDriver,controller,activeDriver)
        activeDriver=nil
    end
    pcall(ClearOverrideBindings,controller)
end

local function CanUse()
    return MeffortRightClickShared and
        MeffortRightClickShared.Owner()=="MeffortSuite"
end

function module.Refresh()
    if not controller or not Profile() then return end
    if InCombatLockdown and InCombatLockdown() then
        queued=true
        return
    end
    queued=false
    StopMouselook()
    ClearDriver()
    attackButton:RegisterForClicks("AnyDown","AnyUp")
    attackButton:SetAttribute("useOnKeyDown",true)
    if module.Mode()=="off" then return end
    if not MeffortSuite or not MeffortSuite.Active or not MeffortSuite.Active() then return end
    -- A pole suppresses input, not the managed macro. Preserve standalone ownership.
    local standalone=MeffortWandDB and
        (MeffortWandDB.mode=="right" or MeffortWandDB.mode=="shift") and
        MeffortWandRuntime and MeffortWandRuntime.Ready and MeffortWandRuntime.Ready()
    if standalone then return end
    ability=module.AbilityName()
    local index,reason=SharedMacro(ability)
    if not index then
        Message("Could not prepare "..ability.." macro: "..(reason or "unknown error")..".")
        return
    end
    attackButton:SetAttribute("macro",index)
    attackButton:SetAttribute("type","macro")
    if not CanUse() or (MeffortSuiteFishing and MeffortSuiteFishing.IsPoleEquipped()) then return end
    if module.Mode()=="right" and (type(MouselookStart)~="function" or type(MouselookStop)~="function"
        or type(IsMouseButtonDown)~="function") then
        Message("Camera functions unavailable; ranged override not applied.")
        return
    end
    local mode=module.Mode()
    local ok,result=pcall(RegisterStateDriver,controller,mode,
        mode=="right" and "[nomod,@mouseover,exists,harm,nodead] on; off"
            or "[mod:shift,@mouseover,exists,harm,nodead] on; off")
    if not ok or result==false then
        ClearDriver()
        Message("The client refused ranged input state handling; normal controls remain active.")
        return
    end
    activeDriver=mode
end

function module.SetMode(nextMode)
    if not Profile() then
        Message("No supported ranged attack for your class.")
        return false
    end
    if nextMode~="right" and nextMode~="shift" then nextMode="off" end
    DB().rangedMode=nextMode
    module.Refresh()
    if MeffortRightClickShared then MeffortRightClickShared.RefreshPeer("MeffortSuite") end
    Message(module.AbilityName().." right-click mode: "..nextMode..(queued and " (queued until combat ends)" or ""))
    return true
end

function module.Command(kind,argument)
    local profile=Profile()
    if not profile or (kind=="wand" and profile.kind~="wand")
        or ((kind=="ranged" or kind=="shoot" or kind=="throw") and profile.kind~="ranged") then
        Message("This ranged attack isn't supported for your class.")
        return
    end
    local cmd=(argument or ""):lower():match("^%s*(.-)%s*$")
    if cmd=="on" or cmd=="right" then module.SetMode("right")
    elseif cmd=="off" or cmd=="shift" then module.SetMode(cmd)
    elseif cmd=="startonly on" or cmd=="startonly off" then
        module.SetStartOnly(cmd=="startonly on")
    elseif cmd=="cleanup" then
        local removed,err=MeffortRightClickShared.CleanupOnly()
        if removed then Message("Macro cleanup complete: "..removed.." duplicates removed.")
        else Message("Macro cleanup unavailable: "..tostring(err)) end
        module.Refresh()
    elseif cmd=="status" or cmd=="" then
        Message(module.AbilityName().." right-click mode: "..module.Mode()
            ..(profile.kind=="wand" and ("; start-only: "..(module.StartOnly() and "on" or "off")) or "")
            .."; /msuite "..kind.." on|off|shift|startonly on|off")
    else Message("/msuite "..kind.." on|off|shift|startonly on|off|status") end
end

function module.Pending() return queued end
function module.Available()
    if controller and attackButton then return true end
    return false,"Secure ranged controls are unavailable; normal mouse controls remain active."
end
local function Initialize()
    local profile=Profile()
    if not profile then return end
    if type(RegisterStateDriver)~="function" or type(UnregisterStateDriver)~="function"
        or type(ClearOverrideBindings)~="function" then
        Message("Secure ranged controls are unavailable; normal mouse controls remain active.")
        return
    end
    ability=module.AbilityName()
    DB()
    local initialized=pcall(function()
        attackButton=CreateFrame("Button","MeffortSuiteSecureAttackButton",UIParent,"SecureActionButtonTemplate")
        attackButton:RegisterForClicks("AnyDown","AnyUp")
        attackButton:SetAttribute("useOnKeyDown",true)
        attackButton:SetScript("PostClick",function(_,button,down)
            if button~="RightButton" then return end
            if down and module.Mode()=="right" then
                if not ownMouselook then
                    local ok=pcall(MouselookStart)
                    if ok then
                        ownMouselook=true
                        frame:SetScript("OnUpdate",CheckMouselookRelease)
                    end
                end
            elseif not down then StopMouselook() end
        end)
        controller=CreateFrame("Frame","MeffortSuiteSecureController",UIParent,"SecureHandlerStateTemplate")
        controller:SetAttribute("_onstate-right",[[
            if newstate == "on" then
                self:SetBindingClick(true,"BUTTON2","MeffortSuiteSecureAttackButton","RightButton")
            else
                self:ClearBindings()
            end
        ]])
        controller:SetAttribute("_onstate-shift",[[
            if newstate == "on" then
                self:SetBindingClick(true,"SHIFT-BUTTON2","MeffortSuiteSecureAttackButton","RightButton")
            else
                self:ClearBindings()
            end
        ]])
        if SecureStateDriverManager and SecureStateDriverManager.RegisterEvent then
            pcall(SecureStateDriverManager.RegisterEvent,SecureStateDriverManager,"UPDATE_MOUSEOVER_UNIT")
        end
    end)
    if not initialized then
        if controller then pcall(ClearOverrideBindings,controller) end
        controller,attackButton=nil,nil
        Message("Secure ranged controls could not initialize; normal mouse controls remain active.")
        return
    end
    module.Refresh()
end

frame:RegisterEvent("PLAYER_LOGIN")
frame:RegisterEvent("PLAYER_REGEN_ENABLED")
frame:RegisterEvent("SPELLS_CHANGED")
frame:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
frame:RegisterEvent("UPDATE_MACROS")
frame:SetScript("OnEvent",function(_,event)
    if event=="PLAYER_LOGIN" then Initialize()
    elseif event=="PLAYER_REGEN_ENABLED" and queued then module.Refresh()
    elseif event=="UPDATE_MACROS" and controller and module.Mode()~="off" then
        if not macroRefreshPending then
            macroRefreshPending=true
            if C_Timer and C_Timer.After then
                C_Timer.After(0,function()
                    macroRefreshPending=false
                    if controller then module.Refresh() end
                end)
            else
                macroRefreshPending=false
                module.Refresh()
            end
        end
    elseif (event=="SPELLS_CHANGED" or event=="PLAYER_EQUIPMENT_CHANGED")
        and controller then module.Refresh() end
end)
