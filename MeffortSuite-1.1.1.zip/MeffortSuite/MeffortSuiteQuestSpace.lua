-- One restricted owner permits binding cleanup on combat entry and dialogue hide.
local owner
local secureReady=false
local controllerAttempted=false
local addon={}
MeffortSuiteQuestSpace=addon
local activeMode=nil
local boundSignature=nil
local warningShown=false
local hooks=setmetatable({},{__mode="k"})
local menuChoices={}
local spaceChoice
local menuButtons={}
local MAX_CHOICES=200

local function InCombat() return InCombatLockdown and InCombatLockdown() end
local function Secret(v) return issecretvalue and issecretvalue(v) end
local function Number(v)
    if not Secret(v) and type(v)=="number" and v==v and v~=math.huge and v~=-math.huge then return v end
end
local function Text(v) if not Secret(v) and type(v)=="string" then return v end end
local function Boolean(v)
    if Secret(v) then return nil end
    if v==true or v==1 then return true end
    if v==false or v==0 then return false end
end
local function Visible(f)
    if not f then return false end
    if f.IsVisible then local ok,v=pcall(f.IsVisible,f);if ok then return v==true end end
    if f.IsShown then local ok,v=pcall(f.IsShown,f);if ok then return v==true end end
    return false
end
local function Enabled(f)
    if not Visible(f) then return false end
    if f.IsEnabled then local ok,v=pcall(f.IsEnabled,f);return ok and v==true end
    return true
end
local function Configured()
    return type(MeffortSuiteDB)=="table" and MeffortSuiteDB.masterEnabled~=false
        and (not MeffortSuite or not MeffortSuite.StandaloneLoaded("MeffortBars"))
        and MeffortSuiteDB.questSpace==true
end
local function Warn(message)
    if warningShown then return end
    warningShown=true
    if DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then
        DEFAULT_CHAT_FRAME:AddMessage("|cff60d9bdMeffortSuite|r: "..message)
    end
end
-- Manual shortcuts include repeatable quests and entries with incomplete metadata.
local function Add(list,kind,id,title,ready)
    id=Number(id)
    if #list>=MAX_CHOICES or not id or id<1 or id~=math.floor(id) then return end
    list[#list+1]={kind=kind,id=id,title=Text(title) or "Option",ready=ready==true}
end
local function PreferredIndex(choices)
    local selected,rank
    for i,choice in ipairs(choices) do
        local priority=4
        if choice.kind=="gossipAvailable" or choice.kind=="greetingAvailable" then
            priority=1
        elseif choice.kind=="gossipActive" or choice.kind=="greetingActive" then
            priority=choice.ready and 2 or 3
        end
        if not rank or priority<rank then selected,rank=i,priority end
    end
    return selected
end

local function GossipChoices()
    if not Visible(GossipFrame) or not C_GossipInfo then return {} end
    local result={}
    local function Get(functionName)
        local fn=C_GossipInfo[functionName]
        if type(fn)~="function" then return {} end
        local ok,list=pcall(fn)
        return ok and not Secret(list) and type(list)=="table" and list or {}
    end
    if type(C_GossipInfo.SelectActiveQuest)=="function" then
        for _,entry in ipairs(Get("GetActiveQuests")) do
            if not Secret(entry) and type(entry)=="table" and Boolean(entry.isIgnored)~=true then
                Add(result,"gossipActive",entry.questID,entry.title,Boolean(entry.isComplete))
            end
        end
    end
    if type(C_GossipInfo.SelectAvailableQuest)=="function" then
        for _,entry in ipairs(Get("GetAvailableQuests")) do
            if not Secret(entry) and type(entry)=="table" and Boolean(entry.isIgnored)~=true then
                Add(result,"gossipAvailable",entry.questID,entry.title,false)
            end
        end
    end
    if type(C_GossipInfo.SelectOption)=="function" then
        for _,entry in ipairs(Get("GetOptions")) do
            if not Secret(entry) and type(entry)=="table" then
                local status=Number(entry.status)
                -- Bind only available options; leave locked entries click-only.
                if status==nil or status==0 then
                    Add(result,"gossipOption",entry.gossipOptionID,entry.name,false)
                end
            end
        end
    end
    return result
end

local function GreetingChoices()
    if not Visible(QuestFrameGreetingPanel) then return {} end
    if not GetNumActiveQuests or not GetNumAvailableQuests then return {} end
    local okA,active=pcall(GetNumActiveQuests)
    local okB,available=pcall(GetNumAvailableQuests)
    if not okA or not okB or not Number(active) or not Number(available) then return {} end
    local result={}
    if type(GetActiveTitle)=="function" and type(SelectActiveQuest)=="function" then
        for i=1,math.min(40,active) do
            local ok,title,complete=pcall(GetActiveTitle,i)
            if ok and Text(title) then
                Add(result,"greetingActive",i,title,Boolean(complete))
            end
        end
    end
    if type(SelectAvailableQuest)=="function" then
        for i=1,math.min(40,available) do
            local title
            if type(GetAvailableTitle)=="function" then
                local ok,value=pcall(GetAvailableTitle,i)
                if ok then title=Text(value) end
            end
            if not title and type(GetAvailableQuestInfo)=="function" then
                local ok,value=pcall(GetAvailableQuestInfo,i)
                if ok then title=Text(value) end
            end
            Add(result,"greetingAvailable",i,title or "Available quest",false)
        end
    end
    return result
end

local function MenuChoices()
    -- Visible panels take precedence over stale quest-event state.
    if Visible(GossipFrame) then return GossipChoices() end
    if Visible(QuestFrameGreetingPanel) then return GreetingChoices() end
    return {}
end
local function SelectChoice(choice)
    if not choice or not Configured() or InCombat() then return end
    if not (Visible(GossipFrame) or Visible(QuestFrameGreetingPanel)) then return end
    local selections={
        gossipActive=C_GossipInfo and C_GossipInfo.SelectActiveQuest,
        gossipAvailable=C_GossipInfo and C_GossipInfo.SelectAvailableQuest,
        gossipOption=C_GossipInfo and C_GossipInfo.SelectOption,
        greetingActive=SelectActiveQuest,
        greetingAvailable=SelectAvailableQuest,
    }
    local fn=selections[choice.kind]
    if type(fn)=="function" then
        local ok=pcall(fn,choice.id)
        if not ok then Warn("The client refused a quest-menu selection.") end
    end
end
local function MakeProxy(index)
    local name=index and ("MeffortSuiteQuestMenuKey"..index) or "MeffortSuiteQuestSpaceKey"
    local f=CreateFrame("Button",name,UIParent)
    if not f then return end
    if f.Show then f:Show() end
    if f.SetScript then
        f:SetScript("OnClick",function()
            local displayed=spaceChoice
            if index then displayed=menuChoices[index] end
            if not displayed then return end
            local current=MenuChoices()
            local fresh
            if index then fresh=current[index] else fresh=current[PreferredIndex(current)] end
            if not fresh or fresh.kind~=displayed.kind or fresh.id~=displayed.id then
                addon.Refresh()
                return
            end
            SelectChoice(fresh)
        end)
    end
    return name
end
for i=1,9 do menuButtons[i]=MakeProxy(i) end
local spaceButton=MakeProxy()

local badges={}
local badgeCount=0
local inlineTicker=CreateFrame("Frame")
local inlineElapsed=0
local function Field(object,key)
    if not object or Secret(object) then return end
    local ok,value=pcall(function()return object[key]end)
    if ok and not Secret(value) then return value end
end
local function Call(object,key,...)
    local fn=Field(object,key)
    if type(fn)~="function" then return end
    local ok,value=pcall(fn,object,...)
    if ok and not Secret(value) then return value end
end
local function HideBadges()
    for _,badge in pairs(badges) do badge.frame:Hide() end
end
local function StopInline()
    inlineTicker:SetScript("OnUpdate",nil)
    inlineElapsed=0
    HideBadges()
end
local function CleanTitle(value)
    value=Text(value)
    if not value then return end
    return value:gsub("|c%x%x%x%x%x%x%x%x",""):gsub("|r","")
        :gsub("|T.-|t",""):gsub("|A.-|a",""):gsub("%s+"," "):match("^%s*(.-)%s*$")
end
local function Kind(value,scope)
    if type(value)=="number" then
        if value==(GOSSIP_BUTTON_TYPE_OPTION or 3) then return "gossipOption" end
        if value==(GOSSIP_BUTTON_TYPE_ACTIVE_QUEST or 4) then return "gossipActive" end
        if value==(GOSSIP_BUTTON_TYPE_AVAILABLE_QUEST or 5) then return "gossipAvailable" end
    end
    value=Text(value)
    if not value then return end
    value=value:lower()
    if value=="active" or value=="activequest" then return scope.."Active" end
    if value=="available" or value=="availablequest" then return scope.."Available" end
    if scope=="gossip" and (value=="gossip" or value=="option") then return "gossipOption" end
end
local function RowTitle(row)
    local title=CleanTitle(Call(row,"GetText") or Call(Call(row,"GetFontString"),"GetText"))
    if title and title~="" then return title end
    for _,key in ipairs({"Text","text"}) do
        local label=Field(row,key)
        title=CleanTitle(Text(label) or Call(label,"GetText"))
        if title and title~="" then return title end
    end
    local name=Text(Call(row,"GetName"))
    if name then return CleanTitle(Call(_G[name.."Text"],"GetText")) end
end
local function MatchRow(row,scope,choices,legacy)
    local data=Call(row,"GetElementData") or Field(row,"elementData")
    if type(data)~="table" then data=nil end
    local info=data and Field(data,"info")
    if type(info)~="table" then info=data end
    local kind=Kind(data and Field(data,"buttonType"),scope) or Kind(Field(row,"type"),scope)
    if scope=="greeting" then
        local active=Boolean(Field(row,"isActive"))
        if active~=nil then kind=active and "greetingActive" or "greetingAvailable" end
    end
    local optionID=Number(info and Field(info,"gossipOptionID")) or Number(Field(row,"gossipOptionID"))
    local questID=scope=="gossip" and
        (Number(info and Field(info,"questID")) or Number(Field(row,"questID"))) or nil
    local explicitID=optionID or questID
    if not legacy and not data and not kind and not explicitID then return end
    local id=explicitID or Number(Call(row,"GetID"))
    local title=RowTitle(row)
    local function Compatible(choice)
        return choice.kind:sub(1,#scope)==scope and (not kind or choice.kind==kind)
            and (not optionID or choice.kind=="gossipOption")
            and (not questID or choice.kind~="gossipOption")
    end
    local found
    if id then
        for index,choice in ipairs(choices) do
            if Compatible(choice) and choice.id==id and
                (explicitID or not title or CleanTitle(choice.title)==title) then
                if found then return end
                found=index
            end
        end
        if found then return found end
        if explicitID then return end
    end
    if not title or title=="" or not (legacy or kind) then return end
    for index,choice in ipairs(choices) do
        if Compatible(choice) and CleanTitle(choice.title)==title then
            if found then return end
            found=index
        end
    end
    return found
end
local function Enumerate(container,method,add)
    local fn=Field(container,method)
    if type(fn)~="function" then return end
    local ok,iterator,state,key=pcall(fn,container)
    if not ok or type(iterator)~="function" then return end
    for _=1,MAX_CHOICES do
        local got,a,b=pcall(iterator,state,key)
        if not got or a==nil then return end
        key=a
        local candidate=(type(a)=="table" or type(a)=="userdata") and a or b
        add(candidate)
    end
end
local function InViewport(row,viewport)
    if not viewport then return true end
    local top,bottom=Number(Call(row,"GetTop")),Number(Call(row,"GetBottom"))
    local upper,lower=Number(Call(viewport,"GetTop")),Number(Call(viewport,"GetBottom"))
    if not top or not bottom or not upper or not lower then return true end
    local rowScale=Number(Call(row,"GetEffectiveScale")) or 1
    local viewScale=Number(Call(viewport,"GetEffectiveScale")) or 1
    local center=(top+bottom)*rowScale/2
    return center<=upper*viewScale and center>=lower*viewScale
end
local function BadgeFor(row)
    if badges[row] then return badges[row] end
    badgeCount=badgeCount+1
    local frame=CreateFrame("Frame","MeffortSuiteQuestInlineKey"..badgeCount,UIParent)
    frame:SetSize(16,16)
    frame:EnableMouse(false)
    local number=frame:CreateFontString(nil,"OVERLAY","GameFontNormal")
    number:SetAllPoints(frame)
    number:SetTextColor(1,.82,.28,1)
    number:SetShadowColor(0,0,0,1);number:SetShadowOffset(1,-1)
    local marker=frame:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    marker:SetPoint("TOPRIGHT",frame,"TOPRIGHT",3,3)
    marker:SetTextColor(1,.82,.28,1)
    local background=frame:CreateTexture(nil,"BACKGROUND")
    background:SetAllPoints(frame)
    background:SetColorTexture(.12,.09,.04,.95)
    local badge={frame=frame,number=number,marker=marker,background=background}
    badges[row]=badge
    if type(Field(row,"HookScript"))=="function" and Call(row,"HasScript","OnHide")~=false then
        pcall(row.HookScript,row,"OnHide",function()frame:Hide()end)
    end
    return badge
end
local function UpdateInline(choices)
    if InCombat() or not Configured() or #choices==0 then StopInline();return end
    HideBadges()
    local scope,root
    if Visible(GossipFrame) then scope,root="gossip",GossipFrame
    elseif Visible(QuestFrameGreetingPanel) then scope,root="greeting",QuestFrameGreetingPanel end
    if not root then StopInline();return end
    local selected=PreferredIndex(choices)
    local seen={}
    local function AddRow(row,legacy,viewport)
        if not row or Secret(row) or (type(row)~="table" and type(row)~="userdata") or seen[row] then return end
        seen[row]=true
        if Call(row,"IsForbidden")==true or not Enabled(row) or not InViewport(row,viewport) then return end
        local index=MatchRow(row,scope,choices,legacy)
        if not index or (index>9 and index~=selected) then return end
        local badge=BadgeFor(row)
        local frame=badge.frame
        local icon=Field(row,"Icon") or Field(row,"icon")
        local name=Call(row,"GetName")
        if not icon and type(name)=="string" then
            icon=_G[name.."Icon"] or _G[name.."GossipIcon"] or _G[name.."QuestIcon"]
        end
        if type(icon)~="table" and type(icon)~="userdata" then icon=nil end
        frame:ClearAllPoints()
        if icon and Visible(icon) then
            if choices[index].kind=="gossipOption" then
                frame:SetPoint("CENTER",icon,"CENTER",0,0);badge.background:Show()
            else
                frame:SetPoint("RIGHT",icon,"LEFT",-1,0);badge.background:Hide()
            end
        else
            frame:SetPoint("RIGHT",row,"LEFT",-2,0);badge.background:Hide()
        end
        local scale=Number(Call(row,"GetEffectiveScale"))
        local parentScale=Number(Call(UIParent,"GetEffectiveScale"))
        if frame.SetScale and scale and parentScale and parentScale>0 then frame:SetScale(scale/parentScale) end
        local strata=Text(Call(row,"GetFrameStrata"))
        if strata then frame:SetFrameStrata(strata) end
        local level=Number(Call(row,"GetFrameLevel"))
        if level and frame.SetFrameLevel then frame:SetFrameLevel(level+2) end
        badge.number:SetText(index<=9 and tostring(index) or "*")
        badge.marker:SetText(index==selected and index<=9 and "*" or "")
        frame:Show()
    end
    local prefix=scope=="gossip" and "GossipTitleButton" or "QuestTitleButton"
    for i=1,MAX_CHOICES do AddRow(_G[prefix..i],true) end
    local greeting=Field(root,"GreetingPanel")
    local scroll=Field(greeting,"ScrollBox") or Field(root,"ScrollBox")
    if scroll then Enumerate(scroll,"EnumerateFrames",function(row)AddRow(row,false,scroll)end) end
    Enumerate(Field(root,"titleButtonPool"),"EnumerateActive",function(row)AddRow(row,false)end)
    Enumerate(Field(greeting,"titleButtonPool"),"EnumerateActive",function(row)AddRow(row,false)end)
    if not inlineTicker:GetScript("OnUpdate") then
        inlineTicker:SetScript("OnUpdate",function(_,elapsed)
            inlineElapsed=inlineElapsed+elapsed
            if inlineElapsed<.15 then return end
            inlineElapsed=0
            if InCombat() or not Configured() or not (Visible(GossipFrame) or Visible(QuestFrameGreetingPanel)) then StopInline()
            else addon.Refresh() end
        end)
    end
end
local function VisibleButton(names)
    for _,name in ipairs(names) do if Enabled(_G[name]) then return name end end
end
local function QuestTarget()
    if activeMode=="detail" then
        return VisibleButton({"QuestFrameAcceptButton","QuestInfoAcceptButton"})
    elseif activeMode=="progress" then
        return VisibleButton({"QuestFrameCompleteButton","QuestInfoCompleteButton"})
    elseif activeMode=="reward" then
        return VisibleButton({"QuestFrameCompleteQuestButton","QuestInfoCompleteQuestButton"})
    end
    if Visible(QuestFrame) then
        if Visible(QuestFrameRewardPanel) then
            return VisibleButton({"QuestFrameCompleteQuestButton","QuestInfoCompleteQuestButton"})
        elseif Visible(QuestFrameProgressPanel) then
            return VisibleButton({"QuestFrameCompleteButton","QuestInfoCompleteButton"})
        elseif Visible(QuestFrameDetailPanel) then
            return VisibleButton({"QuestFrameAcceptButton","QuestInfoAcceptButton"})
        end
    end
end
local function EnsureController()
    if secureReady then return true end
    if InCombat() or type(RegisterStateDriver)~="function" then return false end
    if controllerAttempted then return false end
    controllerAttempted=true
    local ok,created=pcall(CreateFrame,"Frame","MeffortSuiteQuestBindingOwner",UIParent,
        "SecureHandlerStateTemplate,SecureHandlerShowHideTemplate")
    if not ok or not created or type(created.Execute)~="function" then return false end
    local ready=pcall(function()
        created:SetAttribute("_onhide",[[self:ClearBindings()]])
        created:SetAttribute("_onstate-questcombat",[[
            if newstate == "off" then self:ClearBindings() end
        ]])
        RegisterStateDriver(created,"questcombat","[combat] off; on")
        created:Execute([[self:ClearBindings()]])
        created:Hide()
    end)
    if not ready then return false end
    owner,secureReady=created,true
    return true
end
function addon.Available()
    if secureReady then return true end
    return false,InCombat() and "Quest shortcuts will initialize after combat."
        or "Secure quest shortcuts are unavailable; normal controls remain active."
end
local function BindingPlan()
    local plan={}
    if not Configured() then return plan,{} end
    local questButton=QuestTarget()
    if questButton then
        plan[1]={key="SPACE",button=questButton}
        return plan,{}
    end
    local choices=MenuChoices()
    if #choices>0 then
        if spaceButton then plan[#plan+1]={key="SPACE",button=spaceButton} end
        for i=1,math.min(9,#choices) do
            if menuButtons[i] then plan[#plan+1]={key=tostring(i),button=menuButtons[i]} end
        end
    end
    return plan,choices
end
local function Signature(plan,choices)
    local parts={}
    for _,b in ipairs(plan) do parts[#parts+1]=b.key.."="..b.button end
    for _,c in ipairs(choices) do parts[#parts+1]=c.kind..":"..tostring(c.id)..":"..(c.ready and "1" or "0") end
    return table.concat(parts,"|")
end
function addon.Refresh()
    if InCombat() then
        -- The secure state driver withdraws bindings during lockdown.
        boundSignature=nil
        menuChoices={}
        spaceChoice=nil
        StopInline()
        return
    end
    if not EnsureController() then
        if Configured() then Warn("Quest keyboard shortcuts require secure state handling; normal controls remain active.") end
        return
    end
    local plan,choices=BindingPlan()
    local signature=Signature(plan,choices)
    menuChoices=choices
    spaceChoice=choices[PreferredIndex(choices)]
    local updated,err=pcall(UpdateInline,choices)
    if not updated then
        StopInline()
        if MeffortSuite and MeffortSuite.ReportError then MeffortSuite.ReportError("quests","inline keys",err) end
    end
    if signature==boundSignature then return end
    local ok=pcall(owner.Execute,owner,[[self:ClearBindings()]])
    boundSignature=nil
    if not ok then return end
    if #plan==0 then owner:Hide();return end
    -- Inherit dialogue visibility so secure OnHide also handles combat closure.
    local parent=(#choices>0 and (Visible(GossipFrame) and GossipFrame or QuestFrameGreetingPanel))
        or _G[plan[1].button]
    if not parent then owner:Hide();return end
    local statements={}
    for _,b in ipairs(plan) do
        statements[#statements+1]=string.format("self:SetBindingClick(true,%q,%q,\"LeftButton\")",b.key,b.button)
    end
    local applied=pcall(function()
        owner:SetParent(parent)
        owner:Show()
        owner:Execute(table.concat(statements,"\n"))
    end)
    if not applied then
        pcall(owner.Execute,owner,[[self:ClearBindings()]])
        owner:Hide()
        Warn("Could not activate quest keyboard shortcuts; normal controls remain active.")
        return
    end
    boundSignature=signature
end
local pendingChecks=false
local function ScheduleChecks()
    addon.Refresh()
    if pendingChecks or not (C_Timer and C_Timer.After) then return end
    pendingChecks=true
    -- Coalesce related events; still refresh once after each population stage.
    for i,delay in ipairs({0.08,0.22,0.45}) do
        local final=i==3
        C_Timer.After(delay,function()
            if final then pendingChecks=false end
            addon.Refresh()
        end)
    end
end
local function Hook(frame,onShow,onHide)
    if not frame or hooks[frame] or not frame.HookScript then return end
    hooks[frame]=true
    if onShow then frame:HookScript("OnShow",onShow) end
    if onHide then frame:HookScript("OnHide",onHide) end
end
local function HookQuestUI()
    Hook(QuestFrameDetailPanel,function()activeMode="detail";ScheduleChecks()end,
        function()if activeMode=="detail"then activeMode=nil end;addon.Refresh()end)
    Hook(QuestFrameProgressPanel,function()activeMode="progress";ScheduleChecks()end,
        function()if activeMode=="progress"then activeMode=nil end;addon.Refresh()end)
    Hook(QuestFrameRewardPanel,function()activeMode="reward";ScheduleChecks()end,
        function()if activeMode=="reward"then activeMode=nil end;addon.Refresh()end)
    Hook(QuestFrameGreetingPanel,function()activeMode=nil;ScheduleChecks()end,
        function()addon.Refresh()end)
    Hook(GossipFrame,function()activeMode=nil;ScheduleChecks()end,
        function()addon.Refresh()end)
    for _,name in ipairs({"QuestFrameAcceptButton","QuestInfoAcceptButton",
        "QuestFrameCompleteButton","QuestInfoCompleteButton",
        "QuestFrameCompleteQuestButton","QuestInfoCompleteQuestButton"}) do
        Hook(_G[name],function()ScheduleChecks()end,function()addon.Refresh()end)
    end
    Hook(QuestFrame,nil,function()activeMode=nil;addon.Refresh()end)
end
local watcher=CreateFrame("Frame")
for _,event in ipairs({"PLAYER_LOGIN","PLAYER_REGEN_ENABLED","PLAYER_REGEN_DISABLED","QUEST_DETAIL",
    "QUEST_FINISHED","QUEST_ACCEPTED","QUEST_GREETING","QUEST_PROGRESS",
    "QUEST_COMPLETE","GOSSIP_SHOW","GOSSIP_CLOSED","QUEST_LOG_UPDATE"}) do
    watcher:RegisterEvent(event)
end
watcher:SetScript("OnEvent",function(_,event)
    if event=="PLAYER_REGEN_DISABLED" then addon.Refresh();return end
    if event=="PLAYER_LOGIN" then
        if type(MeffortSuiteDB)=="table" and MeffortSuiteDB.questSpace==nil then
            MeffortSuiteDB.questSpace=true
        end
    elseif event=="QUEST_DETAIL" then activeMode="detail"
    elseif event=="QUEST_PROGRESS" then activeMode="progress"
    elseif event=="QUEST_COMPLETE" then activeMode="reward"
    elseif event=="QUEST_FINISHED" or event=="QUEST_ACCEPTED"
        or event=="QUEST_GREETING" or event=="GOSSIP_SHOW"
        or event=="GOSSIP_CLOSED" then activeMode=nil end
    HookQuestUI()
    if event=="PLAYER_REGEN_ENABLED" or event=="QUEST_LOG_UPDATE" then
        addon.Refresh()
    else
        ScheduleChecks()
    end
end)
