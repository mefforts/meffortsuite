local suite = MeffortSuite
MeffortSuiteInventory = {}
local inventory = MeffortSuiteInventory
local bagOpen = false
local sortSerial = 0
local merchantSerial = 0
local hookedFrames = {}

local function Settings()
    if type(MeffortSuiteDB) ~= "table" then MeffortSuiteDB = {} end
    return MeffortSuiteDB
end

local function Enabled(key)
    return suite and suite.Active() and Settings()[key] ~= false
end

local function Shown(frame)
    return frame and type(frame.IsShown) == "function" and frame:IsShown()
end

local function BagsVisible()
    if Shown(_G.ContainerFrameCombinedBags) then return true end
    for i = 1, 13 do
        if Shown(_G["ContainerFrame" .. i]) then return true end
    end
    return false
end

local function Busy()
    if type(InCombatLockdown) == "function" and InCombatLockdown() then return true end
    if type(CursorHasItem) == "function" and CursorHasItem() then return true end
    if type(GetCursorInfo) == "function" and GetCursorInfo() then return true end
    for _, name in ipairs({"MerchantFrame", "TradeFrame", "BankFrame", "GuildBankFrame",
        "MailFrame", "AuctionHouseFrame", "AuctionFrame", "LootFrame"}) do
        if Shown(_G[name]) then return true end
    end
    return false
end

local function SortNow()
    if not Enabled("autoSortBags") or Busy() then return false end
    if not C_Container or type(C_Container.SortBags) ~= "function" then return false end
    return pcall(C_Container.SortBags)
end

local function OnBagsShown()
    if not BagsVisible() or bagOpen then return end
    bagOpen = true
    sortSerial = sortSerial + 1
    local serial = sortSerial
    if C_Timer and type(C_Timer.After) == "function" then
        C_Timer.After(0.15, function()
            if serial == sortSerial and bagOpen and BagsVisible() then SortNow() end
        end)
    else
        SortNow()
    end
end

local function OnBagsHidden()
    local function Check()
        if not BagsVisible() then
            bagOpen = false
            sortSerial = sortSerial + 1
        end
    end
    if C_Timer and C_Timer.After then C_Timer.After(0, Check) else Check() end
end

local function HookBagFrames()
    local function Hook(frame)
        if frame and not hookedFrames[frame] and type(frame.HookScript) == "function" then
            hookedFrames[frame] = true
            frame:HookScript("OnShow", OnBagsShown)
            frame:HookScript("OnHide", OnBagsHidden)
        end
    end
    Hook(_G.ContainerFrameCombinedBags)
    for i = 1, 13 do Hook(_G["ContainerFrame" .. i]) end
end

local function CheckBagsAfterClick()
    HookBagFrames()
    if C_Timer and type(C_Timer.After) == "function" then
        C_Timer.After(0, function()
            HookBagFrames()
            if BagsVisible() then OnBagsShown() else OnBagsHidden() end
        end)
    else
        if BagsVisible() then OnBagsShown() else OnBagsHidden() end
    end
end

local function InstallBagHooks()
    HookBagFrames()
    if type(hooksecurefunc) == "function" then
        for _, name in ipairs({"OpenAllBags", "ToggleAllBags", "OpenBackpack", "ToggleBackpack",
            "OpenBag", "ToggleBag", "CloseAllBags", "CloseBackpack", "CloseBag"}) do
            if type(_G[name]) == "function" then
                pcall(hooksecurefunc, name, CheckBagsAfterClick)
            end
        end
    end
    if C_Timer and type(C_Timer.After) == "function" then
        C_Timer.After(2, HookBagFrames)
        C_Timer.After(8, HookBagFrames)
    end
end

local merchantOpen = false
local repairDone = false
local junkDone = false
local repairStatus = "waiting for merchant"
local junkStatus = "waiting for merchant"
local repairRetryUntil

local function MerchantReady()
    if not merchantOpen or not suite.Active() then return false end
    local frame = _G.MerchantFrame
    return not frame or Shown(frame)
end

local function AutoRepair()
    if repairDone then return end
    if not Enabled("autoRepair") then
        repairDone = true
        repairStatus = "disabled"
        return
    end
    if type(InCombatLockdown) == "function" and InCombatLockdown() then
        repairStatus = "in combat"
        return
    end
    if type(CanMerchantRepair) ~= "function" or type(GetRepairAllCost) ~= "function"
        or type(RepairAllItems) ~= "function" then
        repairDone = true
        repairStatus = "repair API unavailable"
        return
    end
    local ok, merchantCanRepair = pcall(CanMerchantRepair)
    if not ok then
        repairStatus = "repair permission not ready"
        return
    end
    if not merchantCanRepair then
        repairDone = true
        repairStatus = "merchant cannot repair"
        return
    end
    local costOK, cost, canRepair = pcall(GetRepairAllCost)
    if not costOK or type(cost) ~= "number" then
        repairStatus = "repair cost not ready"
        return
    end
    if cost <= 0 then
        repairDone = true
        repairStatus = "nothing needs repair"
        return
    end
    if not canRepair then
        repairStatus = "repair unavailable"
        return
    end
    if type(GetMoney) ~= "function" then
        repairDone = true
        repairStatus = "gold check unavailable"
        return
    end
    local moneyOK, money = pcall(GetMoney)
    if not moneyOK or type(money) ~= "number" then
        repairStatus = "gold check not ready"
        return
    end
    if money < cost then
        -- A pending junk sale can make repair affordable later in this visit.
        repairStatus = "insufficient gold"
        return
    end
    local success, err = pcall(RepairAllItems, false)
    if success then
        repairDone = true
        repairStatus = "repair requested (personal gold)"
    else
        repairDone = true
        repairStatus = "repair error: " .. tostring(err)
    end
end

local function AutoJunk()
    if junkDone then return end
    if not Enabled("autoSellJunk") then
        junkDone = true
        junkStatus = "disabled"
        return
    end
    if type(InCombatLockdown) == "function" and InCombatLockdown() then
        junkStatus = "in combat"
        return
    end
    if type(CursorHasItem) == "function" and CursorHasItem() then
        junkStatus = "item on cursor"
        return
    end
    if type(GetCursorInfo) == "function" and GetCursorInfo() then
        junkStatus = "occupied cursor"
        return
    end
    local api = _G.C_MerchantFrame
    if not api or type(api.SellAllJunkItems) ~= "function" then
        junkDone = true
        junkStatus = "native Sell All Junk API unavailable"
        return
    end
    local quantity = nil
    if type(api.GetNumJunkItems) == "function" then
        local ok, count = pcall(api.GetNumJunkItems)
        if not ok or type(count) ~= "number" then
            junkStatus = "junk count not ready"
            return
        end
        quantity = count
        if count == 0 then
            junkDone = true
            junkStatus = "no sellable junk"
            return
        end
    end
    if type(api.IsSellAllJunkEnabled) == "function" then
        local ok, allowed = pcall(api.IsSellAllJunkEnabled)
        if not ok or not allowed then
            junkStatus = "Sell All Junk unavailable"
            return
        end
    end
    local success, err = pcall(api.SellAllJunkItems)
    junkDone = true
    if success then
        junkStatus = "Sell All Junk requested" .. (quantity and " (" .. quantity .. " items)" or "")
    else
        junkStatus = "junk sale error: " .. tostring(err)
    end
end

local function MerchantAttempt(serial)
    if serial ~= merchantSerial or not merchantOpen then return end
    if not MerchantReady() then
        repairStatus = "waiting for merchant window"
        junkStatus = "waiting for merchant window"
        return
    end
    AutoJunk()
    AutoRepair()
end

local function AttemptSoon(serial, seconds)
    if C_Timer and type(C_Timer.After) == "function" then
        C_Timer.After(seconds, function() MerchantAttempt(serial) end)
    else
        MerchantAttempt(serial)
    end
end

function inventory.RefreshBags()
    sortSerial = sortSerial + 1
    if Enabled("autoSortBags") and BagsVisible() then SortNow() end
end

function inventory.RefreshMerchant()
    if not merchantOpen then return end
    merchantSerial = merchantSerial + 1
    repairDone, junkDone = false, false
    repairStatus, junkStatus = "pending", "pending"
    repairRetryUntil = type(GetTime) == "function" and GetTime() + 3.5 or nil
    local serial = merchantSerial
    AttemptSoon(serial, 0.20)
    AttemptSoon(serial, 0.65)
    AttemptSoon(serial, 1.25)
    AttemptSoon(serial, 2.0)
end

function inventory.VendorStatus(retry)
    if retry and merchantOpen then inventory.RefreshMerchant() end
    local state = merchantOpen and (MerchantReady() and "ready" or "opening") or "closed"
    suite.Message("Merchant: " .. state .. "; repair: " .. repairStatus .. "; junk: " .. junkStatus)
end

local events = CreateFrame("Frame")
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("MERCHANT_SHOW")
events:RegisterEvent("MERCHANT_CLOSED")
events:RegisterEvent("PLAYER_MONEY")
events:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_LOGIN" then
        local db = Settings()
        if db.autoSortBags == nil then db.autoSortBags = true end
        if db.autoSellJunk == nil then db.autoSellJunk = true end
        if db.autoRepair == nil then db.autoRepair = true end
        InstallBagHooks()
        if _G.MerchantFrame and type(_G.MerchantFrame.HookScript) == "function" then
            _G.MerchantFrame:HookScript("OnShow", function()
                if merchantOpen then AttemptSoon(merchantSerial, 0.1) end
            end)
        end
    elseif event == "MERCHANT_SHOW" then
        merchantOpen = true
        inventory.RefreshMerchant()
    elseif event == "PLAYER_MONEY" then
        if merchantOpen and not repairDone and repairRetryUntil and type(GetTime) == "function"
            and GetTime() <= repairRetryUntil then
            AttemptSoon(merchantSerial, 0.10)
        end
    elseif event == "MERCHANT_CLOSED" then
        merchantOpen = false
        repairRetryUntil = nil
        merchantSerial = merchantSerial + 1
    end
end)
